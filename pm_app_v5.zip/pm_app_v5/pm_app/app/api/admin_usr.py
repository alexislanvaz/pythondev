"""
Admin Users API blueprint.
Prefix: /api/v1/admin  (registered via api_bp)
Only accessible to users with role 'admin'.
"""

from flask import Blueprint, request, jsonify
from flask_login import current_user, login_required

from app.extensions import db
from app.database.models import User, Role, ProjectMember

admin_usr_api_bp = Blueprint("admin_usr_api", __name__, url_prefix="/v1/admin")


# ------------------------------------------------------------------ #
# Helpers
# ------------------------------------------------------------------ #

def _ok(data, meta=None):
    return jsonify({"data": data, "error": None, "meta": meta or {}})


def _err(message, status=400):
    return jsonify({"data": None, "error": message, "meta": {}}), status


def _require_admin():
    """Return True if current user is admin, else False."""
    return (
        current_user.is_authenticated
        and current_user.role
        and current_user.role.name.lower() == "admin"
    )


def _user_dict(u):
    return {
        "id":         u.id,
        "username":   u.username,
        "email":      u.email,
        "full_name":  u.full_name,
        "avatar_url": u.avatar_url,
        "role_id":    u.role_id,
        "role_name":  u.role.name if u.role else None,
        "is_active":  u.is_active,
        "last_login": u.last_login.isoformat() if u.last_login else None,
        "created_at": u.created_at.isoformat(),
        "project_count": ProjectMember.query.filter_by(user_id=u.id).count(),
    }


# ------------------------------------------------------------------ #
# GET /api/v1/admin/users
# ------------------------------------------------------------------ #

@admin_usr_api_bp.get("/users")
@login_required
def list_users():
    if not _require_admin():
        return _err("Forbidden — admin only", 403)

    # Filters
    search    = request.args.get("search", "").strip()
    role_id   = request.args.get("role_id",   type=int)
    is_active = request.args.get("is_active")   # "true" | "false" | ""
    page      = request.args.get("page",  1,  type=int)
    per_page  = request.args.get("per_page", 20, type=int)
    per_page  = min(per_page, 100)

    q = User.query

    if search:
        pattern = f"%{search}%"
        q = q.filter(
            db.or_(
                User.username.ilike(pattern),
                User.full_name.ilike(pattern),
                User.email.ilike(pattern),
            )
        )
    if role_id:
        q = q.filter(User.role_id == role_id)
    if is_active == "true":
        q = q.filter(User.is_active == True)   # noqa: E712
    elif is_active == "false":
        q = q.filter(User.is_active == False)  # noqa: E712

    total   = q.count()
    users   = q.order_by(User.created_at.desc()).offset((page - 1) * per_page).limit(per_page).all()

    return _ok(
        [_user_dict(u) for u in users],
        meta={"total": total, "page": page, "per_page": per_page,
              "pages": (total + per_page - 1) // per_page},
    )


# ------------------------------------------------------------------ #
# GET /api/v1/admin/users/<user_id>
# ------------------------------------------------------------------ #

@admin_usr_api_bp.get("/users/<int:user_id>")
@login_required
def get_user(user_id):
    if not _require_admin():
        return _err("Forbidden — admin only", 403)

    user = User.query.get_or_404(user_id)
    return _ok(_user_dict(user))


# ------------------------------------------------------------------ #
# PATCH /api/v1/admin/users/<user_id>/role
# ------------------------------------------------------------------ #

@admin_usr_api_bp.patch("/users/<int:user_id>/role")
@login_required
def change_role(user_id):
    if not _require_admin():
        return _err("Forbidden — admin only", 403)

    user = User.query.get_or_404(user_id)

    if user.id == current_user.id:
        return _err("You cannot change your own role")

    body    = request.get_json(silent=True) or {}
    role_id = body.get("role_id")
    if not role_id:
        return _err("role_id is required")

    role = Role.query.get(role_id)
    if not role:
        return _err("Role not found", 404)

    old_role = user.role.name if user.role else None
    user.role_id = role_id
    db.session.commit()

    return _ok({
        "id":       user.id,
        "username": user.username,
        "role_id":  role_id,
        "role_name": role.name,
        "old_role":  old_role,
    })


# ------------------------------------------------------------------ #
# PATCH /api/v1/admin/users/<user_id>/activate
# ------------------------------------------------------------------ #

@admin_usr_api_bp.patch("/users/<int:user_id>/activate")
@login_required
def activate_user(user_id):
    if not _require_admin():
        return _err("Forbidden — admin only", 403)

    user = User.query.get_or_404(user_id)

    if user.id == current_user.id:
        return _err("You cannot change your own status")

    user.is_active = True
    db.session.commit()
    return _ok({"id": user.id, "is_active": True})


# ------------------------------------------------------------------ #
# PATCH /api/v1/admin/users/<user_id>/deactivate
# ------------------------------------------------------------------ #

@admin_usr_api_bp.patch("/users/<int:user_id>/deactivate")
@login_required
def deactivate_user(user_id):
    if not _require_admin():
        return _err("Forbidden — admin only", 403)

    user = User.query.get_or_404(user_id)

    if user.id == current_user.id:
        return _err("You cannot deactivate your own account")

    # Protect: at least one admin must remain active
    if user.role and user.role.name.lower() == "admin":
        active_admins = (
            User.query
            .join(Role)
            .filter(Role.name == "admin", User.is_active == True, User.id != user_id)  # noqa: E712
            .count()
        )
        if active_admins == 0:
            return _err("Cannot deactivate the last active admin")

    user.is_active = False
    db.session.commit()
    return _ok({"id": user.id, "is_active": False})


# ------------------------------------------------------------------ #
# GET /api/v1/admin/roles
# ------------------------------------------------------------------ #

@admin_usr_api_bp.get("/roles")
@login_required
def list_roles():
    if not _require_admin():
        return _err("Forbidden — admin only", 403)

    roles = Role.query.order_by(Role.name).all()
    return _ok([{"id": r.id, "name": r.name, "description": r.description} for r in roles])


# ------------------------------------------------------------------ #
# GET /api/v1/admin/stats
# ------------------------------------------------------------------ #

@admin_usr_api_bp.get("/stats")
@login_required
def admin_stats():
    if not _require_admin():
        return _err("Forbidden — admin only", 403)

    total_users   = User.query.count()
    active_users  = User.query.filter_by(is_active=True).count()
    inactive_users = total_users - active_users

    by_role = (
        db.session.query(Role.name, db.func.count(User.id))
        .join(User, User.role_id == Role.id)
        .group_by(Role.name)
        .all()
    )

    return _ok({
        "total_users":    total_users,
        "active_users":   active_users,
        "inactive_users": inactive_users,
        "by_role": [{"role": r, "count": c} for r, c in by_role],
    })

from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from app.blueprints.db import run_query

ingenieria_bp = Blueprint('ingenieria', __name__, template_folder='templates')

@ingenieria_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        if current_user.rol == 'Lider de Linea':
            return redirect(url_for('lider.crear_orden_trabajo'))
        elif current_user.rol == 'Tecnico':
            return redirect(url_for('tecnico.panel_tareas'))
        return redirect(url_for('auth.login'))

    # 1. Resumen de estados usando run_query
    resumen_estados = run_query("""
        SELECT eo.Nombre, COUNT(ot.ID) AS Cantidad
        FROM OrdenesTrabajo ot
        INNER JOIN CatEstadosOT eo ON ot.EstadoID = eo.ID
        WHERE ot.activo = 1
        GROUP BY eo.Nombre
    """, query_type='SELECT')
    
    estados_dict = {row['Nombre']: row['Cantidad'] for row in resumen_estados}

    # 2. MTTR Neto
    mttr_neto_rows = run_query("""
        WITH TiemposPausa AS (
            SELECT OrdenTrabajoID,
                   SUM(DATEDIFF(MINUTE, FechaInicioPausa, COALESCE(FechaFinPausa, GETDATE()))) AS MinutosPausados
            FROM RegistroPausasOT WHERE activo = 1 GROUP BY OrdenTrabajoID
        )
        SELECT AVG(DATEDIFF(MINUTE, dt.FechaArriboQR, dt.FechaFinActividad) - COALESCE(tp.MinutosPausados, 0)) AS MTTR_Neto
        FROM OrdenesTrabajo ot
        INNER JOIN DetalleTecnicosOT dt ON dt.OrdenTrabajoID = ot.ID 
            AND dt.FechaArriboQR IS NOT NULL AND dt.FechaFinActividad IS NOT NULL
        LEFT JOIN TiemposPausa tp ON tp.OrdenTrabajoID = ot.ID
        WHERE ot.EstadoID = (SELECT ID FROM CatEstadosOT WHERE Nombre = 'Completada')
          AND ot.activo = 1
    """, query_type='SELECT')
    
    mttr_neto = round(mttr_neto_rows[0]['MTTR_Neto'], 1) if mttr_neto_rows and mttr_neto_rows[0]['MTTR_Neto'] is not None else 0.0

    # 3. Down Time Total
    downtime_total_rows = run_query("""
        SELECT SUM(DATEDIFF(MINUTE, ot.FechaReporte, dt.FechaFinActividad)) / 60.0 AS DownTimeTotal
        FROM OrdenesTrabajo ot
        INNER JOIN DetalleTecnicosOT dt ON dt.OrdenTrabajoID = ot.ID AND dt.FechaFinActividad IS NOT NULL
        WHERE ot.EstadoID = (SELECT ID FROM CatEstadosOT WHERE Nombre = 'Completada')
          AND ot.activo = 1
    """, query_type='SELECT')
    
    downtime_total = round(downtime_total_rows[0]['DownTimeTotal'], 1) if downtime_total_rows and downtime_total_rows[0]['DownTimeTotal'] is not None else 0.0

    # Catálogos para filtros gerenciales
    areas = run_query("SELECT ID, Nombre FROM CatAreas WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    lineas = run_query("SELECT ID, Nombre, AreaID FROM CatLineas WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')

    return render_template(
        'ingenieria/dashboard.html',
        estados=estados_dict,
        mttr_neto=mttr_neto,
        downtime_total=downtime_total,
        areas=areas,
        lineas=lineas
    )

@ingenieria_bp.route('/calendario')
@login_required
def vista_calendario_pm():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('auth.login'))
        
    lineas = run_query("SELECT ID, Nombre FROM CatLineas WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    tecnicos = run_query("""
        SELECT u.ID, u.Nombre 
        FROM CatUsuarios u
        INNER JOIN CatRoles r ON u.RolID = r.ID
        WHERE r.Nombre IN ('Tecnico', 'Técnico', 'Mantenimiento') AND u.activo = 1
        ORDER BY u.Nombre
    """, query_type='SELECT')
    if not tecnicos:
        tecnicos = run_query("SELECT ID, Nombre FROM CatUsuarios WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
        
    rutinas = run_query("SELECT ID, Nombre, FrecuenciaDias FROM CatRutinasPreventivas WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')

    return render_template(
        'ingenieria/calendario.html',
        lineas=lineas,
        tecnicos=tecnicos,
        rutinas=rutinas
    )

@ingenieria_bp.route('/historial-ot')
@login_required
def historial_ot():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('auth.login'))
        
    try:
        # Consulta de todas las OTs
        ots = run_query("""
            SELECT 
                ot.ID, 
                ot.TipoMantenimiento,
                lin.Nombre AS Linea, 
                est.Nombre AS Estacion, 
                eq.Nombre AS EquipoNombre, 
                eq.Modelo AS EquipoModelo,
                sfl.Nombre AS SintomaReportado, 
                fr.Nombre AS FallaReal,
                eo.Nombre AS Estado,
                ot.FechaReporte,
                ot.FechaInicioSoporte,
                (
                    SELECT TOP 1 dt.FechaFinActividad 
                    FROM DetalleTecnicosOT dt 
                    WHERE dt.OrdenTrabajoID = ot.ID AND dt.activo = 1 
                    ORDER BY dt.ID DESC
                ) AS FechaFin,
                (
                    SELECT TOP 1 b.Comentario 
                    FROM BitacoraEstadosOT b 
                    WHERE b.OrdenTrabajoID = ot.ID 
                      AND b.EstadoNuevoID = (SELECT ID FROM CatEstadosOT WHERE Nombre = 'CLOSED') 
                    ORDER BY b.ID DESC
                ) AS ComentariosSolucion,
                (
                    SELECT TOP 1 u.Nombre 
                    FROM DetalleTecnicosOT dt 
                    INNER JOIN CatUsuarios u ON dt.TecnicoID = u.ID
                    WHERE dt.OrdenTrabajoID = ot.ID AND dt.activo = 1 
                    ORDER BY dt.ID DESC
                ) AS TecnicoNombre
            FROM OrdenesTrabajo ot
            INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
            INNER JOIN CatLineas lin ON est.LineaID = lin.ID
            INNER JOIN CatEstadosOT eo ON ot.EstadoID = eo.ID
            LEFT JOIN CatEquipos eq ON ot.EquipoID = eq.ID
            LEFT JOIN CatFallasComunes sfl ON ot.SintomaFallaLiderID = sfl.ID
            LEFT JOIN CatFallasComunes fr ON ot.FallaRealID = fr.ID
            WHERE ot.activo = 1
            ORDER BY ot.ID DESC
        """, query_type='SELECT')

        # Cargar mapa de evidencias por OT
        evidencias_rows = run_query("""
            SELECT ID, OrdenTrabajoID, PathArchivo, TipoEvidencia 
            FROM EvidenciasOT 
            WHERE activo = 1
        """, query_type='SELECT')

        evidencias_map = {}
        for ev in evidencias_rows:
            ot_id = ev['OrdenTrabajoID']
            if ot_id not in evidencias_map:
                evidencias_map[ot_id] = []
            evidencias_map[ot_id].append({
                'id': ev['ID'],
                'path': ev['PathArchivo'],
                'tipo': ev['TipoEvidencia'] or 'FALLA'
            })

        for ot in ots:
            ot['Evidencias'] = evidencias_map.get(ot['ID'], [])

        return render_template('ingenieria/historial_ot.html', ots=ots)
    except Exception as e:
        flash(f"Error al cargar historial: {str(e)}", 'danger')
        return redirect(url_for('ingenieria.dashboard'))

@ingenieria_bp.route('/historial-ot/<int:ot_id>')
@login_required
def detalle_ot(ot_id):
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('auth.login'))
        
    try:
        # 1. Cargar detalles principales de la OT
        ot_rows = run_query("""
            SELECT 
                ot.ID, 
                ot.TipoMantenimiento,
                lin.Nombre AS Linea, 
                est.Nombre AS Estacion, 
                eq.Nombre AS EquipoNombre, 
                eq.Modelo AS EquipoModelo,
                eq.NumeroSerie AS EquipoSerie,
                eq.CodigoQR AS EquipoQR,
                eo.Nombre AS Estado,
                ot.FechaReporte,
                ot.FechaInicioSoporte,
                (
                    SELECT TOP 1 dt.FechaFinActividad 
                    FROM DetalleTecnicosOT dt 
                    WHERE dt.OrdenTrabajoID = ot.ID AND dt.activo = 1 
                    ORDER BY dt.ID DESC
                ) AS FechaFin,
                (
                    SELECT TOP 1 dt.FechaArriboQR 
                    FROM DetalleTecnicosOT dt 
                    WHERE dt.OrdenTrabajoID = ot.ID AND dt.activo = 1 
                    ORDER BY dt.ID DESC
                ) AS FechaArriboQR,
                
                -- Reporta Líder
                lid.Nombre AS LiderNombre,
                sfl.Nombre AS SintomaReportado, 
                cfl.Nombre AS ClasificacionReportada,
                c4m.Nombre AS Causa4MReportada,
                ot.AreaAfectadaImpacto,
                ot.EmpleadosAfectados,
                ot.ComentarioLider,
                
                -- Técnico Atiende
                fr.Nombre AS FallaReal,
                (
                    SELECT TOP 1 b.Comentario 
                    FROM BitacoraEstadosOT b 
                    WHERE b.OrdenTrabajoID = ot.ID 
                      AND b.EstadoNuevoID = (SELECT ID FROM CatEstadosOT WHERE Nombre = 'CLOSED') 
                    ORDER BY b.ID DESC
                ) AS ComentariosSolucion,
                (
                    SELECT TOP 1 u.Nombre 
                    FROM DetalleTecnicosOT dt 
                    INNER JOIN CatUsuarios u ON dt.TecnicoID = u.ID
                    WHERE dt.OrdenTrabajoID = ot.ID AND dt.activo = 1 
                    ORDER BY dt.ID DESC
                ) AS TecnicoNombre
            FROM OrdenesTrabajo ot
            INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
            INNER JOIN CatLineas lin ON est.LineaID = lin.ID
            INNER JOIN CatEstadosOT eo ON ot.EstadoID = eo.ID
            LEFT JOIN CatEquipos eq ON ot.EquipoID = eq.ID
            LEFT JOIN CatUsuarios lid ON ot.LiderReportaID = lid.ID
            LEFT JOIN CatFallasComunes sfl ON ot.SintomaFallaLiderID = sfl.ID
            LEFT JOIN CatClasificacionesFallaLider cfl ON ot.ClasificacionFallaLiderID = cfl.ID
            LEFT JOIN CatCausas4M c4m ON ot.Causa4MID = c4m.ID
            LEFT JOIN CatFallasComunes fr ON ot.FallaRealID = fr.ID
            WHERE ot.ID = ? AND ot.activo = 1
        """, (ot_id,), 'SELECT')
        
        if not ot_rows:
            flash("Orden de trabajo no encontrada.", "warning")
            return redirect(url_for('ingenieria.historial_ot'))
            
        ot_info = ot_rows[0]
        
        # 2. Cargar evidencias de la OT
        evidencias = run_query("""
            SELECT PathArchivo, TipoEvidencia 
            FROM EvidenciasOT 
            WHERE OrdenTrabajoID = ? AND activo = 1
        """, (ot_id,), 'SELECT')
        
        # 3. Cargar Bitácora de la OT (Línea de Tiempo)
        timeline = run_query("""
            SELECT b.FechaCambio, u.Nombre AS Usuario, ea.Nombre AS EstadoAnterior, en.Nombre AS EstadoNuevo, b.Comentario
            FROM BitacoraEstadosOT b
            LEFT JOIN CatUsuarios u ON b.UsuarioID = u.ID
            LEFT JOIN CatEstadosOT ea ON b.EstadoAnteriorID = ea.ID
            INNER JOIN CatEstadosOT en ON b.EstadoNuevoID = en.ID
            WHERE b.OrdenTrabajoID = ? AND b.activo = 1
            ORDER BY b.ID ASC
        """, (ot_id,), 'SELECT')
        
        # 4. Calcular Downtime (en minutos y formateado)
        downtime_mins = None
        if ot_info['FechaReporte'] and ot_info['FechaFin']:
            delta = ot_info['FechaFin'] - ot_info['FechaReporte']
            downtime_mins = int(delta.total_seconds() / 60)
            
        # Calcular tiempo de soporte técnico activo (FechaInicioSoporte o FechaArriboQR a FechaFin)
        fecha_inicio_sop = ot_info['FechaInicioSoporte'] or ot_info['FechaArriboQR']
        soporte_mins = None
        if fecha_inicio_sop and ot_info['FechaFin']:
            delta_sop = ot_info['FechaFin'] - fecha_inicio_sop
            soporte_mins = int(delta_sop.total_seconds() / 60)
            if soporte_mins < 0:
                soporte_mins = 0
            
        # Calcular tiempo total en pausa
        pausas = run_query("""
            SELECT SUM(DATEDIFF(MINUTE, FechaInicioPausa, COALESCE(FechaFinPausa, GETDATE()))) AS MinutosPausados
            FROM RegistroPausasOT 
            WHERE OrdenTrabajoID = ? AND activo = 1
        """, (ot_id,), 'SELECT')
        pausado_mins = pausas[0]['MinutosPausados'] if pausas and pausas[0]['MinutosPausados'] else 0
        
        # MTTR Neto = Tiempo Soporte Activo - Tiempo Pausado
        mttr_neto = None
        if soporte_mins is not None:
            mttr_neto = soporte_mins - pausado_mins
            if mttr_neto < 0:
                mttr_neto = 0

        return render_template(
            'ingenieria/detalle_ot.html', 
            ot=ot_info, 
            evidencias=evidencias, 
            timeline=timeline,
            downtime_mins=downtime_mins,
            soporte_mins=soporte_mins,
            pausado_mins=pausado_mins,
            mttr_neto=mttr_neto
        )
    except Exception as e:
        flash(f"Error al cargar detalle de OT: {str(e)}", 'danger')
        return redirect(url_for('ingenieria.historial_ot'))

TRANSLATIONS = {
    'es': {
        'app_title': 'CMMS',
        'auth_title': 'Acceso al Sistema CMMS',
        'auth_subtitle': 'Ingrese sus credenciales de empleado para continuar',
        'employee_no': 'Número de Empleado',
        'employee_no_placeholder': 'Ej. 9999 o 2001',
        'pin_password': 'PIN / Contraseña',
        'pin_placeholder': 'Ingrese su clave',
        'enter_system': 'Ingresar al Sistema',
        'remember_me': 'Recordar credenciales',
        'forgot_pin': '¿Olvidó su PIN o necesita asistencia?',
        'contact_admin': 'Contacte al Administrador de Mantenimiento',
        'error_invalid_credentials': 'Número de empleado o contraseña incorrectos.',
        'msg_welcome': '¡Bienvenido al sistema CMMS!',
        'msg_logged_out': 'Sesión cerrada correctamente.'
    },
    'en': {
        'app_title': 'CMMS',
        'auth_title': 'CMMS System Access',
        'auth_subtitle': 'Enter your employee credentials to continue',
        'employee_no': 'Employee Number',
        'employee_no_placeholder': 'E.g. 9999 or 2001',
        'pin_password': 'PIN / Password',
        'pin_placeholder': 'Enter your key',
        'enter_system': 'Enter System',
        'remember_me': 'Remember credentials',
        'forgot_pin': 'Forgot PIN or need assistance?',
        'contact_admin': 'Contact Maintenance Administrator',
        'error_invalid_credentials': 'Invalid employee number or password.',
        'msg_welcome': 'Welcome to the CMMS system!',
        'msg_logged_out': 'Logged out successfully.'
    }
}

import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'cmms-secret-key-super-safe-1234')
    DB_SERVER = 'localhost\\local'
    DB_NAME ='cmms_db'
    DB_USER='sa' 
    DB_PASSWORD='localdb26'   
    # Cadena de conexión completa para pyodbc
    CONN_STRING = os.environ.get('CONN_STRING', (
        f"Driver={{ODBC Driver 17 for SQL Server}};"
        f"Server={DB_SERVER};"
        f"Database={DB_NAME};"
        f"Uid={DB_USER};"
        f"Pwd={DB_PASSWORD};"
    ))
    
    # Ruta de red UNC o local compartida para almacenamiento de evidencias físicas
    STORAGE_PATH = os.environ.get('STORAGE_PATH', r'C:\PROYECTOS\RecursosCMMS')

    # URL base para visualización de evidencias desde el navegador web
    # Puede ser '/static/uploads' (servido por Flask) o una URL externa como 'https://IP/folder/folder2/mts/evidencia'
    STORAGE_URL_BASE = os.environ.get('STORAGE_URL_BASE', '/static/uploads')

    # Optimización de caché HTTP para librerías y recursos estáticos (1 año en segundos)
    SEND_FILE_MAX_AGE_DEFAULT = 31536000

import time
import os
from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app, jsonify
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from app.blueprints.db import run_query
from werkzeug.security import generate_password_hash

catalogo_bp = Blueprint('catalogo', __name__, template_folder='templates')

# ---------------------------------------------------------
# 1. RUTAS DE VISTAS INDEPENDIENTES PARA CADA CATÁLOGO
# ---------------------------------------------------------

@catalogo_bp.route('/areas', methods=['GET'])
@login_required
def listar_areas():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('auth.login'))
    try:
        areas = run_query("SELECT ID, Nombre, Descripcion FROM CatAreas WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    except Exception as e:
        current_app.logger.error(f"Error al cargar áreas: {str(e)}")
        areas = []
        flash("Error al cargar la base de datos.", "danger")
    return render_template('catalogo/areas.html', areas=areas)


@catalogo_bp.route('/lineas', methods=['GET'])
@login_required
def listar_lineas():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('auth.login'))
    try:
        lineas = run_query("""
            SELECT l.ID, l.Nombre, a.Nombre AS Area, l.AreaID
            FROM CatLineas l
            INNER JOIN CatAreas a ON l.AreaID = a.ID
            WHERE l.activo = 1
            ORDER BY a.Nombre, l.Nombre
        """, query_type='SELECT')
        areas = run_query("SELECT ID, Nombre FROM CatAreas WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    except Exception as e:
        current_app.logger.error(f"Error al cargar líneas: {str(e)}")
        lineas, areas = [], []
        flash("Error al cargar la base de datos.", "danger")
    return render_template('catalogo/lineas.html', lineas=lineas, areas=areas)


def make_unique_qr(base_qr, linea_id):
    candidate = f"{base_qr}-{linea_id}"
    res = run_query("SELECT ID FROM CatEstaciones WHERE CodigoQR = ?", (candidate,), 'SELECT')
    if not res:
        return candidate
    idx = 1
    while True:
        candidate = f"{base_qr}-{linea_id}-{idx}"
        res = run_query("SELECT ID FROM CatEstaciones WHERE CodigoQR = ?", (candidate,), 'SELECT')
        if not res:
            return candidate
        idx += 1


@catalogo_bp.route('/estaciones', methods=['GET'])
@login_required
def listar_estaciones():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('auth.login'))
    try:
        estaciones = run_query("""
            SELECT e.ID, e.Nombre, e.CodigoQR, l.Nombre AS Linea, a.Nombre AS Area, e.LineaID
            FROM CatEstaciones e
            INNER JOIN CatLineas l ON e.LineaID = l.ID
            INNER JOIN CatAreas a ON l.AreaID = a.ID
            WHERE e.activo = 1
            ORDER BY a.Nombre, l.Nombre, e.Nombre
        """, query_type='SELECT')
        lineas = run_query("""
            SELECT ID, Nombre, AreaID
            FROM CatLineas
            WHERE activo = 1
            ORDER BY Nombre
        """, query_type='SELECT')
        areas = run_query("""
            SELECT ID, Nombre
            FROM CatAreas
            WHERE activo = 1
            ORDER BY Nombre
        """, query_type='SELECT')
    except Exception as e:
        current_app.logger.error(f"Error al cargar estaciones: {str(e)}")
        estaciones, lineas, areas = [], [], []
        flash("Error al cargar la base de datos.", "danger")
    return render_template('catalogo/estaciones.html', estaciones=estaciones, lineas=lineas, areas=areas)


@catalogo_bp.route('/equipos', methods=['GET'])
@login_required
def listar_equipos():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('auth.login'))
    try:
        equipos = run_query("""
            SELECT e.ID AS EquipoID, e.Nombre AS Equipo, e.Modelo, e.NumeroSerie, e.CodigoQR, te.Nombre AS Tipo, 
                   est.Nombre AS Estacion, lin.Nombre AS Linea, ar.Nombre AS Area,
                   e.EstacionID, e.TipoEquipoID
            FROM CatEquipos e
            INNER JOIN CatTiposEquipo te ON e.TipoEquipoID = te.ID
            INNER JOIN CatEstaciones est ON e.EstacionID = est.ID
            INNER JOIN CatLineas lin ON est.LineaID = lin.ID
            INNER JOIN CatAreas ar ON lin.AreaID = ar.ID
            WHERE e.activo = 1 AND est.activo = 1
            ORDER BY ar.Nombre, lin.Nombre, est.Nombre, e.Nombre
        """, query_type='SELECT')
        estaciones = run_query("""
            SELECT e.ID, CONCAT(a.Nombre, ' - ', l.Nombre, ' - ', e.Nombre) AS NombreCompleto
            FROM CatEstaciones e INNER JOIN CatLineas l ON e.LineaID = l.ID
            INNER JOIN CatAreas a ON l.AreaID = a.ID WHERE e.activo = 1 ORDER BY a.Nombre, l.Nombre, e.Nombre
        """, query_type='SELECT')
        tipos_equipo = run_query("SELECT ID, Nombre FROM CatTiposEquipo WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    except Exception as e:
        current_app.logger.error(f"Error al cargar equipos: {str(e)}")
        equipos, estaciones, tipos_equipo = [], [], []
        flash("Error al cargar la base de datos.", "danger")
    return render_template('catalogo/equipos.html', equipos=equipos, estaciones=estaciones, tipos_equipo=tipos_equipo)


@catalogo_bp.route('/fallas', methods=['GET'])
@login_required
def listar_fallas():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('auth.login'))
    try:
        fallas = run_query("""
            SELECT f.ID, te.Nombre AS TipoEquipo, f.CodigoFalla, f.Nombre, f.Descripcion, f.TipoEquipoID
            FROM CatModosFallaReal f
            INNER JOIN CatTiposEquipo te ON f.TipoEquipoID = te.ID
            WHERE f.activo = 1
            ORDER BY te.Nombre, f.Nombre
        """, query_type='SELECT')
        tipos_equipo = run_query("SELECT ID, Nombre FROM CatTiposEquipo WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    except Exception as e:
        current_app.logger.error(f"Error al cargar fallas: {str(e)}")
        fallas, tipos_equipo = [], []
        flash(f"Error al cargar la base de datos. {str(e)}", "danger")
    return render_template('catalogo/fallas.html', fallas=fallas, tipos_equipo=tipos_equipo)


@catalogo_bp.route('/usuarios', methods=['GET'])
@login_required
def listar_usuarios():
    if current_user.rol != 'Administrador':
        flash('Acceso denegado: Se requiere rol de Administrador.', 'danger')
        return redirect(url_for('auth.login'))
    try:
        usuarios = run_query("""
            SELECT u.ID, u.NoEmpleado, u.Nombre, u.Correo, r.Nombre AS Rol, a.Nombre AS Area, t.Nombre AS Turno,
                   u.RolID, u.AreaID, u.TurnoID
            FROM CatUsuarios u
            INNER JOIN CatRoles r ON u.RolID = r.ID
            INNER JOIN CatAreas a ON u.AreaID = a.ID
            INNER JOIN CatTurnos t ON u.TurnoID = t.ID
            WHERE u.activo = 1
            ORDER BY u.Nombre
        """, query_type='SELECT')
        roles = run_query("SELECT ID, Nombre FROM CatRoles WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
        areas = run_query("SELECT ID, Nombre FROM CatAreas WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
        turnos = run_query("SELECT ID, Nombre FROM CatTurnos WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    except Exception as e:
        current_app.logger.error(f"Error al cargar usuarios: {str(e)}")
        usuarios, roles, areas, turnos = [], [], [], []
        flash("Error al cargar la base de datos.", "danger")
    return render_template('catalogo/usuarios.html', usuarios=usuarios, roles=roles, areas=areas, turnos=turnos)


@catalogo_bp.route('/turnos', methods=['GET'])
@login_required
def listar_turnos():
    if current_user.rol != 'Administrador':
        flash('Acceso denegado: Se requiere rol de Administrador.', 'danger')
        return redirect(url_for('auth.login'))
    try:
        turnos = run_query("SELECT ID, Nombre, HoraInicio, HoraFin FROM CatTurnos WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    except Exception as e:
        current_app.logger.error(f"Error al cargar turnos: {str(e)}")
        turnos = []
        flash("Error al cargar la base de datos.", "danger")
    return render_template('catalogo/turnos.html', turnos=turnos)


@catalogo_bp.route('/roles', methods=['GET'])
@login_required
def listar_roles():
    if current_user.rol != 'Administrador':
        flash('Acceso denegado: Se requiere rol de Administrador.', 'danger')
        return redirect(url_for('auth.login'))
    try:
        roles = run_query("SELECT ID, Nombre, Descripcion FROM CatRoles WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    except Exception as e:
        current_app.logger.error(f"Error al cargar roles: {str(e)}")
        roles = []
        flash("Error al cargar la base de datos.", "danger")
    return render_template('catalogo/roles.html', roles=roles)


@catalogo_bp.route('/tipos-equipos', methods=['GET'])
@login_required
def listar_tipos_equipo():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('auth.login'))
    try:
        tipos = run_query("SELECT ID, Nombre, Descripcion FROM CatTiposEquipo WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    except Exception as e:
        current_app.logger.error(f"Error al cargar tipos de equipos: {str(e)}")
        tipos = []
        flash("Error al cargar la base de datos.", "danger")
    return render_template('catalogo/tipos_equipos.html', tipos=tipos)


@catalogo_bp.route('/fallas-comunes', methods=['GET'])
@login_required
def listar_fallas_comunes():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('auth.login'))
    try:
        fallas = run_query("""
            SELECT f.ID, te.Nombre AS TipoEquipo, f.CodigoFalla, f.Nombre, f.Descripcion, f.TipoEquipoID
            FROM CatFallasComunes f
            INNER JOIN CatTiposEquipo te ON f.TipoEquipoID = te.ID
            WHERE f.activo = 1
            ORDER BY te.Nombre, f.Nombre
        """, query_type='SELECT')
        tipos_equipo = run_query("SELECT ID, Nombre FROM CatTiposEquipo WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    except Exception as e:
        current_app.logger.error(f"Error al cargar fallas comunes: {str(e)}")
        fallas, tipos_equipo = [], []
        flash("Error al cargar la base de datos.", "danger")
    return render_template('catalogo/fallas_comunes.html', fallas=fallas, tipos_equipo=tipos_equipo)


@catalogo_bp.route('/soluciones-comunes', methods=['GET'])
@login_required
def listar_soluciones_comunes():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('auth.login'))
    try:
        soluciones = run_query("""
            SELECT s.ID, CONCAT(f.CodigoFalla, ' - ', f.Nombre) AS FallaComun, s.Nombre, s.Descripcion, s.FallaComunID
            FROM CatSolucionesComunes s
            INNER JOIN CatFallasComunes f ON s.FallaComunID = f.ID
            WHERE s.activo = 1 AND f.activo = 1
            ORDER BY f.CodigoFalla, s.Nombre
        """, query_type='SELECT')
        fallas_comunes = run_query("""
            SELECT ID, CONCAT(CodigoFalla, ' - ', Nombre) AS NombreCompleto
            FROM CatFallasComunes
            WHERE activo = 1
            ORDER BY CodigoFalla
        """, query_type='SELECT')
    except Exception as e:
        current_app.logger.error(f"Error al cargar soluciones comunes: {str(e)}")
        soluciones, fallas_comunes = [], []
        flash("Error al cargar la base de datos.", "danger")
    return render_template('catalogo/soluciones_comunes.html', soluciones=soluciones, fallas_comunes=fallas_comunes)


@catalogo_bp.route('/recursos-soporte', methods=['GET'])
@login_required
def listar_recursos_soporte():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('auth.login'))
    try:
        recursos = run_query("""
            SELECT r.ID, r.Nombre, r.TipoRecurso, r.PathArchivo, te.Nombre AS TipoEquipo,
                   CONCAT(f.CodigoFalla, ' - ', f.Nombre) AS FallaComun, r.TipoEquipoID, r.FallaComunID
            FROM RecursosSoporte r
            INNER JOIN CatTiposEquipo te ON r.TipoEquipoID = te.ID
            LEFT JOIN CatFallasComunes f ON r.FallaComunID = f.ID
            WHERE r.activo = 1
            ORDER BY te.Nombre, r.Nombre
        """, query_type='SELECT')
        tipos_equipo = run_query("SELECT ID, Nombre FROM CatTiposEquipo WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
        fallas_comunes = run_query("""
            SELECT ID, CONCAT(CodigoFalla, ' - ', Nombre) AS NombreCompleto, TipoEquipoID
            FROM CatFallasComunes
            WHERE activo = 1
            ORDER BY CodigoFalla
        """, query_type='SELECT')
    except Exception as e:
        current_app.logger.error(f"Error al cargar recursos de soporte: {str(e)}")
        recursos, tipos_equipo, fallas_comunes = [], [], []
        flash("Error al cargar la base de datos.", "danger")
    return render_template('catalogo/recursos_soporte.html', recursos=recursos, tipos_equipo=tipos_equipo, fallas_comunes=fallas_comunes)


# ---------------------------------------------------------
# 2. ENDPOINT API JSON DE CONSULTA RÁPIDA (Edición dinámica)
# ---------------------------------------------------------
@catalogo_bp.route('/api/<string:item>/<int:id>', methods=['GET'])
@login_required
def obtener_item_api(item, id):
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        return jsonify({"success": False, "error": "Acceso denegado"}), 403

    item_map = {
        'area': 'area', 'areas': 'area',
        'linea': 'linea', 'lineas': 'linea',
        'estacion': 'estacion', 'estaciones': 'estacion',
        'equipo': 'equipo', 'equipos': 'equipo',
        'tipo_equipo': 'tipo_equipo', 'tipo-equipo': 'tipo_equipo',
        'tipos_equipo': 'tipo_equipo', 'tipos-equipo': 'tipo_equipo',
        'tipos_equipos': 'tipo_equipo', 'tipos-equipos': 'tipo_equipo',
        'usuario': 'usuario', 'usuarios': 'usuario',
        'turno': 'turno', 'turnos': 'turno',
        'rol': 'rol', 'roles': 'rol',
        'falla': 'falla', 'fallas': 'falla',
        'falla_comun': 'falla_comun', 'falla-comun': 'falla_comun',
        'fallas_comunes': 'falla_comun', 'fallas-comunes': 'falla_comun',
        'solucion_comun': 'solucion_comun', 'solucion-comun': 'solucion_comun',
        'soluciones_comunes': 'solucion_comun', 'soluciones-comunes': 'solucion_comun',
        'recurso_soporte': 'recurso_soporte', 'recurso-soporte': 'recurso_soporte',
        'recursos_soporte': 'recurso_soporte', 'recursos-soporte': 'recurso_soporte'
    }
    normalized_item = item_map.get(item.lower().strip(), item)

    try:
        if normalized_item == 'area':
            res = run_query("SELECT ID, Nombre, Descripcion FROM CatAreas WHERE ID = ?", (id,), 'SELECT')
            if res:
                return jsonify({"success": True, "data": {"id": res[0]['ID'], "nombre": res[0]['Nombre'], "descripcion": res[0]['Descripcion'] or ''}})
        
        elif normalized_item == 'tipo_equipo':
            res = run_query("SELECT ID, Nombre, Descripcion FROM CatTiposEquipo WHERE ID = ?", (id,), 'SELECT')
            if res:
                return jsonify({"success": True, "data": {"id": res[0]['ID'], "nombre": res[0]['Nombre'], "descripcion": res[0]['Descripcion'] or ''}})
        
        elif normalized_item == 'linea':
            res = run_query("SELECT ID, AreaID, Nombre FROM CatLineas WHERE ID = ?", (id,), 'SELECT')
            if res:
                return jsonify({"success": True, "data": {"id": res[0]['ID'], "area_id": res[0]['AreaID'], "nombre": res[0]['Nombre']}})
        
        elif normalized_item == 'estacion':
            res = run_query("SELECT ID, LineaID, Nombre, CodigoQR FROM CatEstaciones WHERE ID = ?", (id,), 'SELECT')
            if res:
                return jsonify({"success": True, "data": {"id": res[0]['ID'], "linea_id": res[0]['LineaID'], "nombre": res[0]['Nombre'], "codigo_qr": res[0]['CodigoQR']}})
        
        elif normalized_item == 'equipo':
            res = run_query("SELECT ID, EstacionID, TipoEquipoID, Nombre, Modelo, NumeroSerie, CodigoQR FROM CatEquipos WHERE ID = ?", (id,), 'SELECT')
            if res:
                return jsonify({"success": True, "data": {
                    "id": res[0]['ID'], "estacion_id": res[0]['EstacionID'], "tipo_equipo_id": res[0]['TipoEquipoID'],
                    "nombre": res[0]['Nombre'], "modelo": res[0]['Modelo'] or '', "no_serie": res[0]['NumeroSerie'] or '',
                    "codigo_qr": res[0]['CodigoQR'] or ''
                }})
        
        elif normalized_item == 'usuario':
            if current_user.rol != 'Administrador':
                return jsonify({"success": False, "error": "Requiere rol Administrador"}), 403
            res = run_query("SELECT ID, NoEmpleado, Nombre, Correo, RolID, AreaID, TurnoID FROM CatUsuarios WHERE ID = ?", (id,), 'SELECT')
            if res:
                return jsonify({"success": True, "data": {
                    "id": res[0]['ID'], "no_empleado": res[0]['NoEmpleado'], "nombre": res[0]['Nombre'],
                    "correo": res[0]['Correo'] or '', "rol_id": res[0]['RolID'], "area_id": res[0]['AreaID'], "turno_id": res[0]['TurnoID']
                }})
        
        elif normalized_item == 'turno':
            if current_user.rol != 'Administrador':
                return jsonify({"success": False, "error": "Requiere rol Administrador"}), 403
            res = run_query("SELECT ID, Nombre, HoraInicio, HoraFin FROM CatTurnos WHERE ID = ?", (id,), 'SELECT')
            if res:
                h_inicio = res[0]['HoraInicio']
                h_fin = res[0]['HoraFin']
                if hasattr(h_inicio, 'strftime'):
                    h_inicio = h_inicio.strftime('%H:%M')
                if hasattr(h_fin, 'strftime'):
                    h_fin = h_fin.strftime('%H:%M')
                return jsonify({"success": True, "data": {"id": res[0]['ID'], "nombre": res[0]['Nombre'], "hora_inicio": h_inicio, "hora_fin": h_fin}})
        
        elif normalized_item == 'rol':
            if current_user.rol != 'Administrador':
                return jsonify({"success": False, "error": "Requiere rol Administrador"}), 403
            res = run_query("SELECT ID, Nombre, Descripcion FROM CatRoles WHERE ID = ?", (id,), 'SELECT')
            if res:
                return jsonify({"success": True, "data": {"id": res[0]['ID'], "nombre": res[0]['Nombre'], "descripcion": res[0]['Descripcion'] or ''}})
        
        elif normalized_item == 'falla':
            res = run_query("SELECT ID, TipoEquipoID, CodigoFalla, Nombre, Descripcion FROM CatModosFallaReal WHERE ID = ?", (id,), 'SELECT')
            if res:
                return jsonify({"success": True, "data": {
                    "id": res[0]['ID'], "tipo_equipo_id": res[0]['TipoEquipoID'], "codigo_falla": res[0]['CodigoFalla'],
                    "nombre": res[0]['Nombre'], "descripcion": res[0]['Descripcion'] or ''
                }})
        
        elif normalized_item == 'falla_comun':
            res = run_query("SELECT ID, TipoEquipoID, CodigoFalla, Nombre, Descripcion FROM CatFallasComunes WHERE ID = ?", (id,), 'SELECT')
            if res:
                return jsonify({"success": True, "data": {
                    "id": res[0]['ID'], "tipo_equipo_id": res[0]['TipoEquipoID'], "codigo_falla": res[0]['CodigoFalla'],
                    "nombre": res[0]['Nombre'], "descripcion": res[0]['Descripcion'] or ''
                }})
        
        elif normalized_item == 'solucion_comun':
            res = run_query("SELECT ID, FallaComunID, Nombre, Descripcion FROM CatSolucionesComunes WHERE ID = ?", (id,), 'SELECT')
            if res:
                return jsonify({"success": True, "data": {
                    "id": res[0]['ID'], "falla_comun_id": res[0]['FallaComunID'],
                    "nombre": res[0]['Nombre'], "descripcion": res[0]['Descripcion'] or ''
                }})

        elif normalized_item == 'recurso_soporte':
            res = run_query("SELECT ID, TipoEquipoID, FallaComunID, Nombre, TipoRecurso, PathArchivo FROM RecursosSoporte WHERE ID = ?", (id,), 'SELECT')
            if res:
                return jsonify({"success": True, "data": {
                    "id": res[0]['ID'], "tipo_equipo_id": res[0]['TipoEquipoID'], "falla_comun_id": res[0]['FallaComunID'],
                    "nombre": res[0]['Nombre'], "tipo_recurso": res[0]['TipoRecurso'], "path_archivo": res[0]['PathArchivo']
                }})

        return jsonify({"success": False, "error": "Registro no encontrado"}), 404
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


# ---------------------------------------------------------
# 3. ENDPOINTS POST DE GUARDADO ÚNICO (INSERT / UPDATE)
# ---------------------------------------------------------
@catalogo_bp.route('/area/guardar', methods=['POST'])
@login_required
def guardar_area():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('catalogo.listar_areas'))

    reg_id = request.form.get('id')
    nombre = request.form.get('nombre')
    descripcion = request.form.get('descripcion', '')

    try:
        if reg_id and reg_id.strip() != "":
            run_query("UPDATE CatAreas SET Nombre = ?, Descripcion = ? WHERE ID = ?", (nombre, descripcion, int(reg_id)), 'UPDATE')
            current_app.logger.info(f"Área ID {reg_id} modificada por {current_user.nombre}.")
            flash(f'Área "{nombre}" actualizada correctamente.', 'success')
        else:
            run_query("INSERT INTO CatAreas (Nombre, Descripcion, UsuarioRegistroID) VALUES (?, ?, ?)", (nombre, descripcion, current_user.id), 'INSERT')
            current_app.logger.info(f"Área '{nombre}' registrada por {current_user.nombre}.")
            flash(f'Área "{nombre}" registrada exitosamente.', 'success')
    except Exception as e:
        current_app.logger.error(f"Error al guardar área '{nombre}': {str(e)}")
        flash(f'Error al procesar: {str(e)}', 'danger')

    return redirect(url_for('catalogo.listar_areas'))


@catalogo_bp.route('/linea/guardar', methods=['POST'])
@login_required
def guardar_linea():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('catalogo.listar_lineas'))

    reg_id = request.form.get('id')
    area_id = request.form.get('area_id')
    nombre = request.form.get('nombre')

    try:
        area_id = int(area_id)
        if reg_id and reg_id.strip() != "":
            run_query("UPDATE CatLineas SET AreaID = ?, Nombre = ? WHERE ID = ?", (area_id, nombre, int(reg_id)), 'UPDATE')
            current_app.logger.info(f"Línea ID {reg_id} modificada por {current_user.nombre}.")
            flash(f'Línea "{nombre}" actualizada correctamente.', 'success')
        else:
            run_query("INSERT INTO CatLineas (AreaID, Nombre, UsuarioRegistroID) VALUES (?, ?, ?)", (area_id, nombre, current_user.id), 'INSERT')
            current_app.logger.info(f"Línea '{nombre}' registrada por {current_user.nombre}.")
            flash(f'Línea "{nombre}" registrada exitosamente.', 'success')
    except Exception as e:
        current_app.logger.error(f"Error al guardar línea '{nombre}': {str(e)}")
        flash(f'Error al procesar: {str(e)}', 'danger')

    return redirect(url_for('catalogo.listar_lineas'))


@catalogo_bp.route('/estacion/guardar', methods=['POST'])
@login_required
def guardar_estacion():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('catalogo.listar_estaciones'))

    reg_id = request.form.get('id')
    lineas_ids = request.form.getlist('lineas_seleccionadas')
    nombre = request.form.get('nombre')
    codigo_qr = request.form.get('codigo_qr')

    try:
        if reg_id and reg_id.strip() != "":
            # UPDATE mode (updates the single existing station)
            if not lineas_ids:
                flash('Debe seleccionar al menos una línea.', 'danger')
                return redirect(url_for('catalogo.listar_estaciones'))
            
            linea_id = int(lineas_ids[0])
            run_query("UPDATE CatEstaciones SET LineaID = ?, Nombre = ?, CodigoQR = ? WHERE ID = ?", (linea_id, nombre, codigo_qr, int(reg_id)), 'UPDATE')
            current_app.logger.info(f"Estación ID {reg_id} modificada por {current_user.nombre}.")
            flash(f'Estación "{nombre}" actualizada correctamente.', 'success')
        else:
            # INSERT mode (batch inserts one per line)
            if not lineas_ids:
                flash('Debe seleccionar al menos una línea.', 'danger')
                return redirect(url_for('catalogo.listar_estaciones'))
            
            inserted_count = 0
            for l_id in lineas_ids:
                linea_id = int(l_id)
                unique_qr = make_unique_qr(codigo_qr, linea_id)
                run_query("INSERT INTO CatEstaciones (LineaID, Nombre, CodigoQR, UsuarioRegistroID) VALUES (?, ?, ?, ?)", (linea_id, nombre, unique_qr, current_user.id), 'INSERT')
                inserted_count += 1
                
            current_app.logger.info(f"{inserted_count} estaciones '{nombre}' registradas por {current_user.nombre}.")
            flash(f'{inserted_count} estaciones "{nombre}" registradas exitosamente.', 'success')
    except Exception as e:
        current_app.logger.error(f"Error al guardar estación '{nombre}': {str(e)}")
        flash(f'Error al procesar: {str(e)}', 'danger')

    return redirect(url_for('catalogo.listar_estaciones'))


@catalogo_bp.route('/equipo/guardar', methods=['POST'])
@login_required
def guardar_equipo():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('catalogo.listar_equipos'))

    reg_id = request.form.get('id')
    estacion_id = request.form.get('estacion_id')
    tipo_equipo_id = request.form.get('tipo_equipo_id')
    nombre = request.form.get('nombre')
    modelo = request.form.get('modelo', '')
    no_serie = request.form.get('no_serie', '')
    codigo_qr = request.form.get('codigo_qr', '')

    try:
        estacion_id = int(estacion_id)
        tipo_equipo_id = int(tipo_equipo_id)
        codigo_qr = codigo_qr.strip() if codigo_qr and codigo_qr.strip() else None

        if reg_id and reg_id.strip() != "":
            run_query("""
                UPDATE CatEquipos SET EstacionID = ?, TipoEquipoID = ?, Nombre = ?, Modelo = ?, NumeroSerie = ?, CodigoQR = ? WHERE ID = ?
            """, (estacion_id, tipo_equipo_id, nombre, modelo, no_serie, codigo_qr, int(reg_id)), 'UPDATE')
            current_app.logger.info(f"Equipo ID {reg_id} modificado por {current_user.nombre}.")
            flash(f'Equipo "{nombre}" actualizado correctamente.', 'success')
        else:
            run_query("""
                INSERT INTO CatEquipos (EstacionID, TipoEquipoID, Nombre, Modelo, NumeroSerie, CodigoQR, UsuarioRegistroID)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (estacion_id, tipo_equipo_id, nombre, modelo, no_serie, codigo_qr, current_user.id), 'INSERT')
            current_app.logger.info(f"Equipo '{nombre}' registrado por {current_user.nombre}.")
            flash(f'Equipo "{nombre}" registrado exitosamente.', 'success')
    except Exception as e:
        current_app.logger.error(f"Error al guardar equipo '{nombre}': {str(e)}")
        flash(f'Error al procesar: {str(e)}', 'danger')

    return redirect(url_for('catalogo.listar_equipos'))


@catalogo_bp.route('/usuario/guardar', methods=['POST'])
@login_required
def guardar_usuario():
    if current_user.rol not in ['Administrador']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('catalogo.listar_usuarios'))

    reg_id = request.form.get('id')
    no_empleado = request.form.get('no_empleado')
    nombre = request.form.get('nombre')
    correo = request.form.get('correo')
    rol_id = request.form.get('rol_id')
    area_id = request.form.get('area_id')
    turno_id = request.form.get('turno_id')
    pin = request.form.get('pin')

    try:
        rol_id = int(rol_id)
        area_id = int(area_id)
        turno_id = int(turno_id)

        if reg_id and reg_id.strip() != "":
            if pin and pin.strip() != "":
                pin_hash = generate_password_hash(pin)
                run_query("""
                    UPDATE CatUsuarios SET NoEmpleado = ?, Nombre = ?, Correo = ?, 
                                           RolID = ?, AreaID = ?, TurnoID = ?, PasswordHash = ? WHERE ID = ?
                """, (no_empleado, nombre, correo, rol_id, area_id, turno_id, pin_hash, int(reg_id)), 'UPDATE')
            else:
                run_query("""
                    UPDATE CatUsuarios SET NoEmpleado = ?, Nombre = ?, Correo = ?, 
                                           RolID = ?, AreaID = ?, TurnoID = ? WHERE ID = ?
                """, (no_empleado, nombre, correo, rol_id, area_id, turno_id, int(reg_id)), 'UPDATE')
            current_app.logger.info(f"Usuario ID {reg_id} modificado por {current_user.nombre}.")
            flash(f'Usuario "{nombre}" actualizado correctamente.', 'success')
        else:
            pin_hash = generate_password_hash(pin)
            run_query("""
                INSERT INTO CatUsuarios (NoEmpleado, Nombre, Correo, RolID, AreaID, TurnoID, PasswordHash, UsuarioRegistroID)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (no_empleado, nombre, correo, rol_id, area_id, turno_id, pin_hash, current_user.id), 'INSERT')
            current_app.logger.info(f"Usuario '{nombre}' registrado por {current_user.nombre}.")
            flash(f'Usuario "{nombre}" registrado exitosamente.', 'success')
    except Exception as e:
        current_app.logger.error(f"Error al guardar usuario: {str(e)}")
        flash(f'Error al procesar: {str(e)}', 'danger')

    return redirect(url_for('catalogo.listar_usuarios'))


@catalogo_bp.route('/turno/guardar', methods=['POST'])
@login_required
def guardar_turno():
    if current_user.rol not in ['Administrador']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('catalogo.listar_turnos'))

    reg_id = request.form.get('id')
    nombre = request.form.get('nombre')
    hora_inicio = request.form.get('hora_inicio')
    hora_fin = request.form.get('hora_fin')

    try:
        if reg_id and reg_id.strip() != "":
            run_query("""
                UPDATE CatTurnos SET Nombre = ?, HoraInicio = ?, HoraFin = ? WHERE ID = ?
            """, (nombre, hora_inicio, hora_fin, int(reg_id)), 'UPDATE')
            current_app.logger.info(f"Turno ID {reg_id} modificado por {current_user.nombre}.")
            flash(f'Turno "{nombre}" actualizado correctamente.', 'success')
        else:
            run_query("""
                INSERT INTO CatTurnos (Nombre, HoraInicio, HoraFin, UsuarioRegistroID)
                VALUES (?, ?, ?, ?)
            """, (nombre, hora_inicio, hora_fin, current_user.id), 'INSERT')
            current_app.logger.info(f"Turno '{nombre}' registrado por {current_user.nombre}.")
            flash(f'Turno "{nombre}" registrado exitosamente.', 'success')
    except Exception as e:
        current_app.logger.error(f"Error al guardar turno: {str(e)}")
        flash(f'Error al procesar: {str(e)}', 'danger')

    return redirect(url_for('catalogo.listar_turnos'))


@catalogo_bp.route('/rol/guardar', methods=['POST'])
@login_required
def guardar_rol():
    if current_user.rol not in ['Administrador']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('catalogo.listar_roles'))

    reg_id = request.form.get('id')
    nombre = request.form.get('nombre')
    descripcion = request.form.get('descripcion', '')

    try:
        if reg_id and reg_id.strip() != "":
            run_query("UPDATE CatRoles SET Nombre = ?, Descripcion = ? WHERE ID = ?", (nombre, descripcion, int(reg_id)), 'UPDATE')
            current_app.logger.info(f"Rol ID {reg_id} modificado por {current_user.nombre}.")
            flash(f'Rol "{nombre}" actualizado correctamente.', 'success')
        else:
            run_query("INSERT INTO CatRoles (Nombre, Descripcion, UsuarioRegistroID) VALUES (?, ?, ?)", (nombre, descripcion, current_user.id), 'INSERT')
            current_app.logger.info(f"Rol '{nombre}' registrado por {current_user.nombre}.")
            flash(f'Rol "{nombre}" registrado exitosamente.', 'success')
    except Exception as e:
        current_app.logger.error(f"Error al guardar rol: {str(e)}")
        flash(f'Error al procesar: {str(e)}', 'danger')

    return redirect(url_for('catalogo.listar_roles'))


@catalogo_bp.route('/tipo-equipo/guardar', methods=['POST'])
@catalogo_bp.route('/tipo_equipo/guardar', methods=['POST'])
@login_required
def guardar_tipo_equipo():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('catalogo.listar_tipos_equipo'))

    reg_id = request.form.get('id')
    nombre = request.form.get('nombre')
    descripcion = request.form.get('descripcion', '')

    try:
        if reg_id and reg_id.strip() != "":
            run_query("UPDATE CatTiposEquipo SET Nombre = ?, Descripcion = ? WHERE ID = ?", (nombre, descripcion, int(reg_id)), 'UPDATE')
            current_app.logger.info(f"Tipo de Equipo ID {reg_id} modificado por {current_user.nombre}.")
            flash(f'Tipo de Equipo "{nombre}" actualizado correctamente.', 'success')
        else:
            run_query("INSERT INTO CatTiposEquipo (Nombre, Descripcion, UsuarioRegistroID) VALUES (?, ?, ?)", (nombre, descripcion, current_user.id), 'INSERT')
            current_app.logger.info(f"Tipo de Equipo '{nombre}' registrado por {current_user.nombre}.")
            flash(f'Tipo de Equipo "{nombre}" registrado exitosamente.', 'success')
    except Exception as e:
        current_app.logger.error(f"Error al guardar tipo de equipo '{nombre}': {str(e)}")
        flash(f'Error al procesar: {str(e)}', 'danger')

    return redirect(url_for('catalogo.listar_tipos_equipo'))


@catalogo_bp.route('/falla/guardar', methods=['POST'])
@login_required
def guardar_falla():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('catalogo.listar_fallas'))

    reg_id = request.form.get('id')
    tipo_equipo_id = request.form.get('tipo_equipo_id')
    codigo_falla = request.form.get('codigo_falla')
    nombre = request.form.get('nombre')
    descripcion = request.form.get('descripcion', '')

    try:
        tipo_equipo_id = int(tipo_equipo_id)
        if reg_id and reg_id.strip() != "":
            run_query("""
                UPDATE CatModosFallaReal SET TipoEquipoID = ?, CodigoFalla = ?, Nombre = ?, Descripcion = ? WHERE ID = ?
            """, (tipo_equipo_id, codigo_falla, nombre, descripcion, int(reg_id)), 'UPDATE')
            current_app.logger.info(f"Falla ID {reg_id} modificada por {current_user.nombre}.")
            flash(f'Modo de Falla "{nombre}" actualizado correctamente.', 'success')
        else:
            run_query("""
                INSERT INTO CatModosFallaReal (TipoEquipoID, CodigoFalla, Nombre, Descripcion, UsuarioRegistroID)
                VALUES (?, ?, ?, ?, ?)
            """, (tipo_equipo_id, codigo_falla, nombre, descripcion, current_user.id), 'INSERT')
            current_app.logger.info(f"Falla '{nombre}' registrada por {current_user.nombre}.")
            flash(f'Modo de Falla "{nombre}" registrado exitosamente.', 'success')
    except Exception as e:
        current_app.logger.error(f"Error al guardar falla: {str(e)}")
        flash(f'Error al procesar: {str(e)}', 'danger')

    return redirect(url_for('catalogo.listar_fallas'))


@catalogo_bp.route('/falla-comun/guardar', methods=['POST'])
@catalogo_bp.route('/falla_comun/guardar', methods=['POST'])
@login_required
def guardar_falla_comun():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('catalogo.listar_fallas_comunes'))

    reg_id = request.form.get('id')
    tipo_equipo_id = request.form.get('tipo_equipo_id')
    codigo_falla = request.form.get('codigo_falla')
    nombre = request.form.get('nombre')
    descripcion = request.form.get('descripcion', '')

    try:
        tipo_equipo_id = int(tipo_equipo_id)
        if reg_id and reg_id.strip() != "":
            run_query("""
                UPDATE CatFallasComunes SET TipoEquipoID = ?, CodigoFalla = ?, Nombre = ?, Descripcion = ? WHERE ID = ?
            """, (tipo_equipo_id, codigo_falla, nombre, descripcion, int(reg_id)), 'UPDATE')
            current_app.logger.info(f"Falla Común ID {reg_id} modificada por {current_user.nombre}.")
            flash(f'Falla Común "{nombre}" actualizada correctamente.', 'success')
        else:
            run_query("""
                INSERT INTO CatFallasComunes (TipoEquipoID, CodigoFalla, Nombre, Descripcion, UsuarioRegistroID)
                VALUES (?, ?, ?, ?, ?)
            """, (tipo_equipo_id, codigo_falla, nombre, descripcion, current_user.id), 'INSERT')
            current_app.logger.info(f"Falla Común '{nombre}' registrada por {current_user.nombre}.")
            flash(f'Falla Común "{nombre}" registrada exitosamente.', 'success')
    except Exception as e:
        current_app.logger.error(f"Error al guardar falla común: {str(e)}")
        flash(f'Error al procesar: {str(e)}', 'danger')

    return redirect(url_for('catalogo.listar_fallas_comunes'))


@catalogo_bp.route('/solucion-comun/guardar', methods=['POST'])
@catalogo_bp.route('/solucion_comun/guardar', methods=['POST'])
@login_required
def guardar_solucion_comun():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('catalogo.listar_soluciones_comunes'))

    reg_id = request.form.get('id')
    falla_comun_id = request.form.get('falla_comun_id')
    nombre = request.form.get('nombre')
    descripcion = request.form.get('descripcion', '')

    try:
        falla_comun_id = int(falla_comun_id)
        if reg_id and reg_id.strip() != "":
            run_query("""
                UPDATE CatSolucionesComunes SET FallaComunID = ?, Nombre = ?, Descripcion = ? WHERE ID = ?
            """, (falla_comun_id, nombre, descripcion, int(reg_id)), 'UPDATE')
            current_app.logger.info(f"Solución Común ID {reg_id} modificada por {current_user.nombre}.")
            flash(f'Solución Común "{nombre}" actualizada correctamente.', 'success')
        else:
            run_query("""
                INSERT INTO CatSolucionesComunes (FallaComunID, Nombre, Descripcion, UsuarioRegistroID)
                VALUES (?, ?, ?, ?)
            """, (falla_comun_id, nombre, descripcion, current_user.id), 'INSERT')
            current_app.logger.info(f"Solución Común '{nombre}' registrada por {current_user.nombre}.")
            flash(f'Solución Común "{nombre}" registrada exitosamente.', 'success')
    except Exception as e:
        current_app.logger.error(f"Error al guardar solución común: {str(e)}")
        flash(f'Error al procesar: {str(e)}', 'danger')

    return redirect(url_for('catalogo.listar_soluciones_comunes'))


@catalogo_bp.route('/recurso-soporte/guardar', methods=['POST'])
@catalogo_bp.route('/recurso_soporte/guardar', methods=['POST'])
@login_required
def guardar_recurso_soporte():

    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('catalogo.listar_recursos_soporte'))

    reg_id = request.form.get('id')
    nombre = request.form.get('nombre')
    tipo_recurso = request.form.get('tipo_recurso')
    tipos_equipo_ids = request.form.getlist('tipos_equipo_seleccionados')
    fallas_ids = request.form.getlist('fallas_seleccionadas')
    
    # Manejar archivo subido
    file = request.files.get('archivo')
    path_archivo = None
    
    try:
        # Si es un UPDATE
        if reg_id and reg_id.strip() != "":
            # Obtener el registro existente para conservar el PathArchivo actual por defecto
            existing = run_query("SELECT PathArchivo, TipoEquipoID, FallaComunID FROM RecursosSoporte WHERE ID = ?", (int(reg_id),), 'SELECT')
            if existing:
                path_archivo = existing[0]['PathArchivo']
                
            if file and file.filename != "":
                # Se subió un archivo nuevo, guardarlo y actualizar el nombre
                storage_path = current_app.config.get('STORAGE_PATH')
                if not storage_path:
                    flash("STORAGE_PATH no configurado en el sistema.", "danger")
                    return redirect(url_for('catalogo.listar_recursos_soporte'))
                try:
                    if not os.path.exists(storage_path):
                        os.makedirs(storage_path, exist_ok=True)
                    filename = secure_filename(file.filename)
                    unique_filename = f"{int(time.time())}_{filename}"
                    file.save(os.path.join(storage_path, unique_filename))
                    path_archivo = unique_filename
                except PermissionError as pe:
                    current_app.logger.error(f"Error de permisos al guardar en UNC/Storage '{storage_path}': {pe}")
                    flash(f"Error de permisos al guardar archivo en ruta de red ({storage_path}). Verifique los permisos de IIS.", "danger")
                    return redirect(url_for('catalogo.listar_recursos_soporte'))
            
            # Durante el UPDATE, solo modificamos el registro único con ese ID
            tipo_equipo_id = int(tipos_equipo_ids[0]) if tipos_equipo_ids else (existing[0]['TipoEquipoID'] if existing else 0)
            falla_comun_id = int(fallas_ids[0]) if fallas_ids else None
            
            run_query("""
                UPDATE RecursosSoporte 
                SET TipoEquipoID = ?, FallaComunID = ?, Nombre = ?, TipoRecurso = ?, PathArchivo = ? 
                WHERE ID = ?
            """, (tipo_equipo_id, falla_comun_id, nombre, tipo_recurso, path_archivo, int(reg_id)), 'UPDATE')
            
            current_app.logger.info(f"Recurso de Soporte ID {reg_id} modificado por {current_user.nombre}.")
            flash(f'Recurso de Soporte "{nombre}" actualizado correctamente.', 'success')
        else:
            # Si es un INSERT
            if not file or file.filename == "":
                flash('Debe subir un archivo para el recurso.', 'danger')
                return redirect(url_for('catalogo.listar_recursos_soporte'))
                
            storage_path = current_app.config.get('STORAGE_PATH')
            if not storage_path:
                flash("STORAGE_PATH no configurado en el sistema.", "danger")
                return redirect(url_for('catalogo.listar_recursos_soporte'))
            try:
                if not os.path.exists(storage_path):
                    os.makedirs(storage_path, exist_ok=True)
                filename = secure_filename(file.filename)
                unique_filename = f"{int(time.time())}_{filename}"
                file.save(os.path.join(storage_path, unique_filename))
                path_archivo = unique_filename
            except PermissionError as pe:
                current_app.logger.error(f"Error de permisos al guardar en UNC/Storage '{storage_path}': {pe}")
                flash(f"Error de permisos al guardar archivo en ruta de red ({storage_path}). Verifique la identidad del Application Pool en IIS.", "danger")
                return redirect(url_for('catalogo.listar_recursos_soporte'))
            
            # Hacemos un registro para cada selección
            inserted_count = 0
            if fallas_ids:
                for f_id in fallas_ids:
                    falla_comun_id = int(f_id)
                    # Buscar el TipoEquipoID asociado a esta falla común
                    falla_data = run_query("SELECT TipoEquipoID FROM CatFallasComunes WHERE ID = ?", (falla_comun_id,), 'SELECT')
                    if falla_data:
                        tipo_equipo_id = falla_data[0]['TipoEquipoID']
                        run_query("""
                            INSERT INTO RecursosSoporte (TipoEquipoID, FallaComunID, Nombre, TipoRecurso, PathArchivo, UsuarioRegistroID)
                            VALUES (?, ?, ?, ?, ?, ?)
                        """, (tipo_equipo_id, falla_comun_id, nombre, tipo_recurso, path_archivo, current_user.id), 'INSERT')
                        inserted_count += 1
            else:
                # Si no hay fallas comunes seleccionadas, pero sí tipos de equipo:
                for te_id in tipos_equipo_ids:
                    tipo_equipo_id = int(te_id)
                    run_query("""
                        INSERT INTO RecursosSoporte (TipoEquipoID, FallaComunID, Nombre, TipoRecurso, PathArchivo, UsuarioRegistroID)
                        VALUES (?, NULL, ?, ?, ?, ?)
                    """, (tipo_equipo_id, nombre, tipo_recurso, path_archivo, current_user.id), 'INSERT')
                    inserted_count += 1
                    
            if inserted_count == 0:
                # Si no se seleccionó nada de checkboxes (validación preventiva)
                flash('Debe seleccionar al menos un tipo de equipo o una falla común.', 'danger')
                return redirect(url_for('catalogo.listar_recursos_soporte'))
                
            current_app.logger.info(f"{inserted_count} registros de recurso de soporte '{nombre}' creados por {current_user.nombre}.")
            flash(f'{inserted_count} registros de recurso de soporte registrados exitosamente.', 'success')
            
    except Exception as e:
        current_app.logger.error(f"Error al guardar recurso de soporte: {str(e)}")
        flash(f'Error al procesar: {str(e)}', 'danger')

    return redirect(url_for('catalogo.listar_recursos_soporte'))


# ---------------------------------------------------------
# 4. ENDPOINTS POST DE DESACTIVACIÓN LÓGICA
# ---------------------------------------------------------
@catalogo_bp.route('/area/desactivar/<int:id>', methods=['POST'])
@login_required
def desactivar_area(id):
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        return jsonify({"success": False, "error": "Acceso denegado"}), 403
    try:
        run_query("UPDATE CatAreas SET activo = 0 WHERE ID = ?", (id,), 'UPDATE')
        current_app.logger.info(f"Área ID {id} desactivada por {current_user.nombre}.")
        return jsonify({"success": True, "message": "Área desactivada."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@catalogo_bp.route('/linea/desactivar/<int:id>', methods=['POST'])
@login_required
def desactivar_linea(id):
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        return jsonify({"success": False, "error": "Acceso denegado"}), 403
    try:
        run_query("UPDATE CatLineas SET activo = 0 WHERE ID = ?", (id,), 'UPDATE')
        current_app.logger.info(f"Línea ID {id} desactivada por {current_user.nombre}.")
        return jsonify({"success": True, "message": "Línea desactivada."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@catalogo_bp.route('/estacion/desactivar/<int:id>', methods=['POST'])
@login_required
def desactivar_estacion(id):
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        return jsonify({"success": False, "error": "Acceso denegado"}), 403
    try:
        run_query("UPDATE CatEstaciones SET activo = 0 WHERE ID = ?", (id,), 'UPDATE')
        current_app.logger.info(f"Estación ID {id} desactivada por {current_user.nombre}.")
        return jsonify({"success": True, "message": "Estación desactivada."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@catalogo_bp.route('/equipo/desactivar/<int:id>', methods=['POST'])
@login_required
def desactivar_equipo(id):
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        return jsonify({"success": False, "error": "Acceso denegado"}), 403
    try:
        run_query("UPDATE CatEquipos SET activo = 0 WHERE ID = ?", (id,), 'UPDATE')
        current_app.logger.info(f"Equipo ID {id} desactivado por {current_user.nombre}.")
        return jsonify({"success": True, "message": "Equipo desactivado."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@catalogo_bp.route('/usuario/desactivar/<int:id>', methods=['POST'])
@login_required
def desactivar_usuario(id):
    if current_user.rol not in ['Administrador']:
        return jsonify({"success": False, "error": "Acceso denegado"}), 403
    try:
        run_query("UPDATE CatUsuarios SET activo = 0 WHERE ID = ?", (id,), 'UPDATE')
        current_app.logger.info(f"Usuario ID {id} desactivado por {current_user.nombre}.")
        return jsonify({"success": True, "message": "Usuario desactivado."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@catalogo_bp.route('/turno/desactivar/<int:id>', methods=['POST'])
@login_required
def desactivar_turno(id):
    if current_user.rol not in ['Administrador']:
        return jsonify({"success": False, "error": "Acceso denegado"}), 403
    try:
        run_query("UPDATE CatTurnos SET activo = 0 WHERE ID = ?", (id,), 'UPDATE')
        current_app.logger.info(f"Turno ID {id} desactivado por {current_user.nombre}.")
        return jsonify({"success": True, "message": "Turno desactivado."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@catalogo_bp.route('/rol/desactivar/<int:id>', methods=['POST'])
@login_required
def desactivar_rol(id):
    if current_user.rol not in ['Administrador']:
        return jsonify({"success": False, "error": "Acceso denegado"}), 403
    try:
        run_query("UPDATE CatRoles SET activo = 0 WHERE ID = ?", (id,), 'UPDATE')
        current_app.logger.info(f"Rol ID {id} desactivado por {current_user.nombre}.")
        return jsonify({"success": True, "message": "Rol desactivado."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@catalogo_bp.route('/tipo-equipo/desactivar/<int:id>', methods=['POST'])
@catalogo_bp.route('/tipo_equipo/desactivar/<int:id>', methods=['POST'])
@login_required
def desactivar_tipo_equipo(id):
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        return jsonify({"success": False, "error": "Acceso denegado"}), 403
    try:
        run_query("UPDATE CatTiposEquipo SET activo = 0 WHERE ID = ?", (id,), 'UPDATE')
        current_app.logger.info(f"Tipo de Equipo ID {id} desactivado por {current_user.nombre}.")
        return jsonify({"success": True, "message": "Tipo de equipo desactivado."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@catalogo_bp.route('/falla/desactivar/<int:id>', methods=['POST'])
@login_required
def desactivar_falla(id):
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        return jsonify({"success": False, "error": "Acceso denegado"}), 403
    try:
        run_query("UPDATE CatModosFallaReal SET activo = 0 WHERE ID = ?", (id,), 'UPDATE')
        current_app.logger.info(f"Falla ID {id} desactivada por {current_user.nombre}.")
        return jsonify({"success": True, "message": "Falla desactivada."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@catalogo_bp.route('/falla-comun/desactivar/<int:id>', methods=['POST'])
@catalogo_bp.route('/falla_comun/desactivar/<int:id>', methods=['POST'])
@login_required
def desactivar_falla_comun(id):
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        return jsonify({"success": False, "error": "Acceso denegado"}), 403
    try:
        run_query("UPDATE CatFallasComunes SET activo = 0 WHERE ID = ?", (id,), 'UPDATE')
        current_app.logger.info(f"Falla Común ID {id} desactivada por {current_user.nombre}.")
        return jsonify({"success": True, "message": "Falla común desactivada."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@catalogo_bp.route('/solucion-comun/desactivar/<int:id>', methods=['POST'])
@catalogo_bp.route('/solucion_comun/desactivar/<int:id>', methods=['POST'])
@login_required
def desactivar_solucion_comun(id):
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        return jsonify({"success": False, "error": "Acceso denegado"}), 403
    try:
        run_query("UPDATE CatSolucionesComunes SET activo = 0 WHERE ID = ?", (id,), 'UPDATE')
        current_app.logger.info(f"Solución Común ID {id} desactivada por {current_user.nombre}.")
        return jsonify({"success": True, "message": "Solución común desactivada."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@catalogo_bp.route('/recurso-soporte/desactivar/<int:id>', methods=['POST'])
@catalogo_bp.route('/recurso_soporte/desactivar/<int:id>', methods=['POST'])
@login_required
def desactivar_recurso_soporte(id):
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        return jsonify({"success": False, "error": "Acceso denegado"}), 403
    try:
        run_query("UPDATE RecursosSoporte SET activo = 0 WHERE ID = ?", (id,), 'UPDATE')
        current_app.logger.info(f"Recurso de Soporte ID {id} desactivado por {current_user.nombre}.")
        return jsonify({"success": True, "message": "Recurso de soporte desactivado."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


import pyodbc
from flask import Blueprint, jsonify, current_app, g, has_app_context
from app.config import Config

db_bp = Blueprint('db', __name__)

def get_db_connection():
    """
    Establece y retorna una conexión pyodbc a SQL Server.
    Si está dentro del contexto de una petición HTTP (has_app_context), reutiliza la conexión en `g.db_conn`
    eliminando la sobrecarga de múltiples handshakes TCP y autenticaciones por cada vista/renderizado.
    """
    if has_app_context():
        if 'db_conn' not in g or g.db_conn is None:
            try:
                conn_str = current_app.config['CONN_STRING']
            except RuntimeError:
                conn_str = Config.CONN_STRING
            g.db_conn = pyodbc.connect(conn_str)
        return g.db_conn

    # Conexión directa para scripts independientes o ejecución fuera de contexto Flask
    return pyodbc.connect(Config.CONN_STRING)

def close_db_connection(e=None):
    """Cierra de manera limpia la conexión de base de datos al finalizar la petición HTTP."""
    db_conn = g.pop('db_conn', None)
    if db_conn is not None:
        try:
            db_conn.close()
        except Exception:
            pass

def run_query(query, params=None, query_type='SELECT'):
    """
    Ejecuta una consulta SQL en SQL Server mediante pyodbc.
    Garantiza el correcto cierre de cursores y el manejo de transacciones.
    Reutiliza la conexión de la petición activa para máxima velocidad en la LAN.
    
    :param query: Consulta SQL o comando T-SQL (ej: "SELECT ...", "EXEC sp_...")
    :param params: Parámetros opcionales para la consulta (lista o tupla)
    :param query_type: Tipo de operación ('SELECT', 'INSERT', 'UPDATE', 'DELETE', 'SP')
    :return: Lista de diccionarios para consultas que retornan registros, de lo contrario una lista vacía.
    """
    if params is None:
        params = ()
        
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute(query, params)
        
        # Operaciones de lectura (SELECT o Stored Procedures que devuelven registros)
        if query_type.upper() in ['SELECT', 'SP']:
            if cursor.description:
                columns = [column[0] for column in cursor.description]
                results = []
                for row in cursor.fetchall():
                    results.append(dict(zip(columns, row)))
                if query_type.upper() == 'SP':
                    conn.commit()
                return results
            else:
                conn.commit()
                return []
                
        # Operaciones de escritura (INSERT, UPDATE, DELETE)
        else:
            results = []
            if cursor.description:
                columns = [column[0] for column in cursor.description]
                for row in cursor.fetchall():
                    results.append(dict(zip(columns, row)))
            conn.commit()
            return results
            
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        cursor.close()
        if not has_app_context():
            conn.close()

@db_bp.route('/status', methods=['GET'])
def db_status():
    """Endpoint API para validar asíncronamente el estado de la conexión a la base de datos."""
    try:
        conn = get_db_connection()
        return jsonify({"connected": True, "message": "Conexión a SQL Server activa."})
    except Exception as e:
        return jsonify({"connected": False, "error": str(e)}), 500


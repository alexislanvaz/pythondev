# Real_time_emotion_recognition  
Dataset:https://www.kaggle.com/msambare/fer2013?select=train  
YouTube:https://youtu.be/30oWdzWcA0M

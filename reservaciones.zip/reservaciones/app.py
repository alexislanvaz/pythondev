from flask import Flask, render_template, request, jsonify
import csv
from datetime import datetime

app = Flask(__name__)

@app.route('/')
def index():
    reservaciones = []
    try:
        with open('reservaciones.csv', 'r') as f:
            reader = csv.reader(f)
            next(reader)  # Saltar la fila del encabezado
            for row in reader:
                if len(row) == 5:  # Asegurarte de que hay 5 columnas
                    reservaciones.append({
                        'room': row[0],
                        'date': row[1],
                        'time': row[2],
                        'endTime': row[3],  # Cambiar a endTime
                        'description': row[4]
                    })
    except FileNotFoundError:
        pass

    return render_template('index.html', reservaciones=reservaciones)

@app.route('/get_salas')
def get_salas():
    salas = []
    with open('salas.csv', 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            salas.append(row)

    return jsonify(salas)


from datetime import datetime

@app.route('/reservar', methods=['POST'])
def reservar():
    room = request.form['room']
    date = request.form['date']
    time = request.form['time']
    endTime = request.form['endTime']
    description = request.form['description']

    start_datetime = datetime.strptime(date + ' ' + time, '%Y-%m-%d %H:%M')
    end_datetime = datetime.strptime(date + ' ' + endTime, '%Y-%m-%d %H:%M')

    # Leer las reservaciones existentes
    reservaciones = []
    with open('reservaciones.csv', 'r') as f:
        reader = csv.reader(f)
        next(reader)  # Saltar el encabezado
        for row in reader:
            if len(row) == 5:
                if row[0] == room:  # Solo considerar las reservaciones para la misma sala
                    existing_start = datetime.strptime(row[1] + ' ' + row[2], '%Y-%m-%d %H:%M')
                    existing_end = datetime.strptime(row[1] + ' ' + row[3], '%Y-%m-%d %H:%M')
                    if existing_start < end_datetime and existing_end > start_datetime:  # Si hay superposición
                        return 'La sala ya está reservada para ese horario', 400  # Retorna un error

    # Si no hay conflicto, guarda la reserva
    with open('reservaciones.csv', 'a') as f:
        writer = csv.writer(f)
        writer.writerow([room, date, time, endTime, description])

    return 'Reservación exitosa'


# @app.route('/reservar', methods=['POST'])
# def reservar():
#     room = request.form['room']
#     date = request.form['date']
#     time = request.form['time']
#     # endDate = request.form['endDate']  
#     endTime = request.form['endTime'] 
#     description = request.form['description']

    
#     with open('reservaciones.csv', 'a') as f:
#         writer = csv.writer(f)
#         writer.writerow([room, date, time, endTime, description])

#     return 'Reservación exitosa'



if __name__ == '__main__':
    app.run(debug=True)

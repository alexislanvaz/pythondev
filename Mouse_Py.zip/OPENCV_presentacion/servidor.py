import pywhatkit
import flask
import pyautogui


pywhatkit.start_server()
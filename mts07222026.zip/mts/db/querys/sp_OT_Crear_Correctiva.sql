ALTER PROCEDURE sp_OT_Crear_Correctiva    
    @EstacionID INT,    
    @LiderID INT,    
    @SintomaFallaLiderID INT,    
    @ClasificacionFallaLiderID INT,    
    @Causa4MID INT,    
    @AreaAfectadaImpacto VARCHAR(150),    
    @EmpleadosAfectados INT,    
    @ComentarioLider VARCHAR(1000),    
    @UsuarioRegistroID INT = NULL,
    @TurnoID INT = NULL,
    @FechaReporte DATETIME = NULL
AS    
BEGIN    
    SET NOCOUNT ON;    
    BEGIN TRY    
        BEGIN TRANSACTION;    
    
        DECLARE @EstadoCreadaID INT;    
        DECLARE @FinalTurnoID INT = @TurnoID;    
        DECLARE @FinalFechaReporte DATETIME = ISNULL(@FechaReporte, GETDATE());
        DECLARE @HoraActual TIME = CONVERT(TIME, @FinalFechaReporte);    
    
        SELECT TOP 1 @EstadoCreadaID = ID FROM CatEstadosOT WHERE Nombre = 'CREATED' AND activo = 1;    
    
        IF @FinalTurnoID IS NULL
        BEGIN
            SELECT TOP 1 @FinalTurnoID = ID     
            FROM CatTurnos     
            WHERE activo = 1     
              AND (    
                (HoraInicio <= HoraFin AND @HoraActual BETWEEN HoraInicio AND HoraFin) OR    
                (HoraInicio > HoraFin AND (@HoraActual >= HoraInicio OR @HoraActual <= HoraFin))    
              );    
        
            IF @FinalTurnoID IS NULL    
                SELECT @FinalTurnoID = TurnoID FROM CatUsuarios WHERE ID = @LiderID;    
        END
    
        DECLARE @NuevaOTID INT;    
        INSERT INTO OrdenesTrabajo (    
            EstacionID, EstadoID, LiderReportaID, TurnoID,     
            SintomaFallaLiderID, ClasificacionFallaLiderID, Causa4MID,     
            AreaAfectadaImpacto, EmpleadosAfectados, ComentarioLider,     
            FechaReporte, TipoMantenimiento, UsuarioRegistroID    
        )    
        VALUES (    
            @EstacionID, @EstadoCreadaID, @LiderID, @FinalTurnoID,    
            @SintomaFallaLiderID, @ClasificacionFallaLiderID, @Causa4MID,    
            @AreaAfectadaImpacto, @EmpleadosAfectados, @ComentarioLider,     
            @FinalFechaReporte, 'CORRECTIVO', @UsuarioRegistroID    
        );    
    
        SET @NuevaOTID = SCOPE_IDENTITY();    
    
        INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, Comentario)    
        VALUES (@NuevaOTID, NULL, @EstadoCreadaID, @LiderID, 'OT Correctiva creada.');    
    
        COMMIT TRANSACTION;    
        SELECT @NuevaOTID AS OrdenTrabajoID;    
    END TRY    
    BEGIN CATCH    
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;    
        THROW;    
    END CATCH;    
END;
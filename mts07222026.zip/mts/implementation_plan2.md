# Plan de Implementación: Estructura del Proyecto Web CMMS (Flask)

Este documento detalla el plan para crear y configurar la estructura inicial del proyecto web CMMS en Python utilizando el micro-framework **Flask**, bajo las especificaciones técnicas definidas en el proyecto de manufactura.

---

## 1. Decisiones de Diseño Acordadas

*   **Acceso a Base de Datos**: Uso de `pyodbc` puro para ejecutar sentencias T-SQL directas e invocar procedimientos almacenados transaccionales en **SQL Server 2017 (v14.0)**, sin ORM (SQLAlchemy).
*   **Autenticación**: Autenticación rápida integrada mediante **Flask-Login**, validando el número de empleado (`NoEmpleado`) y un código PIN o contraseña simple.
*   **Estructura Modular**: Implementación de **Blueprints** independientes para separar la lógica de negocio por roles y APIs.
*   **Gestión de Logs**: Logging rotativo basado en archivos físicos de 10MB (`RotatingFileHandler`) guardados en una carpeta `/logs`.
*   **Descargas de Archivos**: Acceso controlado a manuales, videos y evidencias de fallas a través de un endpoint en Flask que valida la sesión activa antes de transmitir los archivos desde la ruta de red UNC.

---

## 2. Nuevos Requerimientos de Interfaz y Localización

### A. Diseño Visual (CSS Claro Minimalista con Colores Pastel)
El archivo `app/static/css/main.css` se diseñará bajo una paleta clara y minimalista para evitar la fatiga visual en pantallas de laptops y tablets en el piso de manufactura, utilizando toques de colores pastel para diferenciar estados y prioridades sin saturar la pantalla.
*   **Fondo Base**: Blanco suave / Gris muy claro (`#f8f9fa` / `#ffffff`).
*   **Texto Principal**: Gris oscuro neutro (`#2d3748`).
*   **Toques de Color Pastel (Semáforos y Estados)**:
    *   *Verde Menta* (`#e6fffa`, texto `#0d9488`): Indica estado "Completada" o sistema en línea operativa.
    *   *Azul Bebé* (`#ebf8ff`, texto `#3182ce`): Indica estado "En Proceso" o elementos informativos.
    *   *Amarillo Pastel* (`#fefcbf`, texto `#b7791f`): Indica estado "Pausada".
    *   *Rojo Coral/Salmón* (`#fff5f5`, texto `#e53e3e`): Indica estado "Creada" (correctivo abierto) o fallas de alto impacto en línea.
    *   *Lavanda Pastel* (`#faf5ff`, texto `#805ad5`): Utilizado para mantenimiento preventivo.
*   **Adaptabilidad Táctil (Tablets)**: Botones interactivos con un área mínima de contacto de 48px por 48px y padding amplio para evitar errores de selección en pantallas táctiles industriales.

### B. Sistema Multi-idioma (Inglés / Español)
Para permitir el cambio de idioma rápido entre español e inglés de forma consistente en todos los menús e interfaces, implementaremos un sistema ligero basado en sesión (`session['lang']`) y un helper de traducción centralizado en Python sin dependencias de compilación complejas (evitando problemas de instalación de Babel en sistemas Windows):
1.  **Diccionario de Traducciones (`app/translations.py`)**: Archivo que contiene los textos localizados en estructuras de diccionarios Python para ambos idiomas.
2.  **Context Processor de Flask**: Registraremos una función global en Jinja2 que tome una llave de texto y retorne el valor traducido de acuerdo al idioma almacenado en la sesión del usuario (por defecto `'es'`).
3.  **Endpoint `/change-lang/<lang_code>`**: Permite cambiar el idioma en la sesión y redirigir inmediatamente a la página de origen.

---

## 3. Estructura de Directorios Detallada (Con Carpetas de Templates por Blueprint)

El proyecto se estructurará de la siguiente manera:

```
proyecto_cmms/
│
├── run.py                      # Punto de entrada para iniciar la aplicación Flask
├── requirements.txt            # Dependencias del proyecto (Flask, pyodbc, Flask-Login, python-dotenv)
│
├── app/                        # Paquete principal de la aplicación
│   ├── __init__.py             # Inicialización de Flask, Logging, LoginManager, Localización y Blueprints
│   ├── config.py               # Variables de entorno y configuración de conexión ODBC
│   ├── db.py                   # Manejador de conexiones seguras a SQL Server con pyodbc
│   ├── models.py               # Definición de la clase User para el soporte de Flask-Login
│   ├── translations.py         # Diccionarios de textos en Español e Inglés (Multi-idioma)
│   │
│   ├── blueprints/             # Módulos y controladores de negocio (Blueprints)
│   │   ├── auth/routes.py      # Rutas de login, logout y cambio de PIN
│   │   ├── lider/routes.py     # Interfaz para líderes (Creación de OTs y Down Time)
│   │   ├── tecnico/routes.py   # Interfaz móvil para tablets (QR, pausas, handovers)
│   │   ├── ingenieria/routes.py# Dashboard de KPIs y calendario de preventivos
│   │   ├── catalogo/routes.py  # CRUDs para administración de activos de planta
│   │   └── api/routes.py       # Endpoints JSON (AJAX, carga de fotos, lector QR)
│   │
│   ├── static/                 # Recursos públicos en el cliente web
│   │   ├── css/
│   │   │   └── main.css        # Estilos responsivos (Pastel Minimalist Style)
│   │   ├── js/
│   │   │   └── main.js         # Lógicas JS cliente (Cámara, lectura de QR, Fetch requests)
│   │   └── vendor/             # Librerías open-source (html5-qrcode, chart.js, fullcalendar, datatables)
│   │
│   ├── templates/              # Plantillas HTML procesadas por Jinja2
│   │   ├── base.html           # Estructura base común con selector de idioma en el Header
│   │   │
│   │   ├── auth/
│   │   │   └── login.html      # Pantalla táctil de inicio de sesión
│   │   │
│   │   ├── lider/
│   │   │   └── crear_ot.html   # Formulario estructurado para reporte de paros
│   │   │
│   │   ├── tecnico/
│   │   │   ├── panel.html      # Bandeja de OTs pendientes para técnicos
│   │   │   └── atencion.html   # Interfaz de atención (cámara, checklist, materiales, manuales)
│   │   │
│   │   ├── ingenieria/
│   │   │   ├── dashboard.html  # Métricas de Down Time y gráficos de KPIs
│   │   │   └── calendario.html # Calendario mensual FullCalendar para preventivos
│   │   │
│   │   └── catalogo/
│   │       └── listar.html     # Listado CRUD de equipos y estaciones (con DataTables)
│   │
│   └── logs/                   # Carpeta para archivos de trazas operativas
│       └── app.log
```

---

## 4. Estructura de Archivos Base y Localización

### A. Diccionario de Traducción (`app/translations.py`)
```python
TRANSLATIONS = {
    'es': {
        'app_title': 'Sistema CMMS - Control de Paros',
        'login': 'Iniciar Sesión',
        'employee_no': 'Número de Empleado',
        'pin': 'PIN / Contraseña',
        'enter': 'Ingresar',
        'logout': 'Cerrar Sesión',
        'lang_en': 'English',
        'lang_es': 'Español',
        'corrective_ot': 'Orden Correctiva',
        'preventive_ot': 'Orden Preventiva',
        'create_ot': 'Reportar Falla',
        'station': 'Estación',
        'symptom': 'Síntoma',
        'impact': 'Impacto',
        'employees_affected': 'Empleados Afectados',
        'comments': 'Comentarios',
        'save': 'Guardar',
        'status_created': 'Creada',
        'status_process': 'En Proceso',
        'status_paused': 'Pausada',
        'status_completed': 'Completada',
        'downtime': 'Tiempo Perdido',
        'kpi_dashboard': 'Panel de KPIs'
    },
    'en': {
        'app_title': 'CMMS System - Down Time Control',
        'login': 'Log In',
        'employee_no': 'Employee Number',
        'pin': 'PIN / Password',
        'enter': 'Enter',
        'logout': 'Log Out',
        'lang_en': 'English',
        'lang_es': 'Español',
        'corrective_ot': 'Corrective WO',
        'preventive_ot': 'Preventive WO',
        'create_ot': 'Report Failure',
        'station': 'Station',
        'symptom': 'Symptom',
        'impact': 'Impact',
        'employees_affected': 'Employees Affected',
        'comments': 'Comments',
        'save': 'Save',
        'status_created': 'Created',
        'status_process': 'In Process',
        'status_paused': 'Paused',
        'status_completed': 'Completed',
        'downtime': 'Down Time',
        'kpi_dashboard': 'KPI Dashboard'
    }
}
```

### B. Inicialización de la Aplicación y Localización (`app/__init__.py`)
Añadimos el control de sesión y el inyector de traducciones para Jinja2:
```python
import os
import logging
from logging.handlers import RotatingFileHandler
from flask import Flask, session, request
from flask_login import LoginManager
from app.config import Config
from app.db import get_db_connection
from app.models import User
from app.translations import TRANSLATIONS

login_manager = LoginManager()
login_manager.login_view = 'auth.login'

@login_manager.user_loader
def load_user(user_id):
    conn = get_db_connection()
    user = User.get(int(user_id), conn)
    conn.close()
    return user

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # 1. Logger rotativo
    if not os.path.exists('app/logs'):
        os.makedirs('app/logs')
    file_handler = RotatingFileHandler('app/logs/app.log', maxBytes=10*1024*1024, backupCount=5)
    file_handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s: %(message)s'))
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)

    login_manager.init_app(app)

    # 2. Inyector global de Traducciones a Jinja2
    @app.context_processor
    def inject_translations():
        # Obtener idioma preferido de la sesión (por defecto 'es')
        lang = session.get('lang', 'es')
        # Función de traducción utilizable en templates como {{ _('app_title') }}
        def translate(key):
            return TRANSLATIONS.get(lang, TRANSLATIONS['es']).get(key, key)
        return dict(_=translate, current_lang=lang)

    # 3. Ruta para cambiar de idioma
    @app.route('/change-lang/<lang_code>')
    def change_language(lang_code):
        if lang_code in ['es', 'en']:
            session['lang'] = lang_code
        # Redirigir a la página previa o al index
        return redirect(request.referrer or url_for('index'))

    # 4. Registrar Blueprints
    from app.blueprints.auth.routes import auth_bp
    from app.blueprints.lider.routes import lider_bp
    from app.blueprints.tecnico.routes import tecnico_bp
    from app.blueprints.ingenieria.routes import ingenieria_bp
    from app.blueprints.catalogo.routes import catalogo_bp
    from app.blueprints.api.routes import api_bp

    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(lider_bp, url_prefix='/lider')
    app.register_blueprint(tecnico_bp, url_prefix='/tecnico')
    app.register_blueprint(ingenieria_bp, url_prefix='/ingenieria')
    app.register_blueprint(catalogo_bp, url_prefix='/catalogo')
    app.register_blueprint(api_bp, url_prefix='/api')

    return app
```

### C. Plantilla Base Maestra `app/templates/base.html`
Definición estructural con la paleta de colores claros, toques pastel responsivos y el switch de traducción en el header.
```html
<!DOCTYPE html>
<html lang="{{ current_lang }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ _('app_title') }}</title>
    <!-- CSS Estilos Claros / Pasteles -->
    <link rel="stylesheet" href="{{ url_for('static', filename='css/main.css') }}">
    {% block head %}{% endblock %}
</head>
<body>
    <header class="navbar">
        <div class="navbar-brand">
            <h1>{{ _('app_title') }}</h1>
        </div>
        <nav class="navbar-menu">
            {% if current_user.is_authenticated %}
                <span class="user-info">{{ current_user.nombre }} ({{ current_user.rol }})</span>
                <a href="{{ url_for('auth.logout') }}" class="nav-link">{{ _('logout') }}</a>
            {% endif %}
            
            <!-- Selector de Idioma -->
            <div class="lang-selector">
                {% if current_lang == 'es' %}
                    <a href="/change-lang/en" class="lang-link">🇬🇧 {{ _('lang_en') }}</a>
                {% else %}
                    <a href="/change-lang/es" class="lang-link">🇲🇽 {{ _('lang_es') }}</a>
                {% endif %}
            </div>
        </nav>
    </header>

    <main class="container">
        <!-- Notificaciones Flash -->
        {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                <div class="flash-messages">
                    {% for category, message in messages %}
                        <div class="flash flash-{{ category }}">{{ message }}</div>
                    {% endfor %}
                </div>
            {% endif %}
        {% endwith %}

        {% block content %}{% endblock %}
    </main>

    <footer class="footer">
        <p>&copy; 2026 CMMS Planta MTS. All rights reserved.</p>
    </footer>
    
    {% block scripts %}{% endblock %}
</body>
</html>
```

---

## 5. Plan de Verificación

1.  **Ejecución del Servidor**: Arrancar el servidor en local mediante `python run.py` y comprobar que no existan errores de importación circular en los Blueprints.
2.  **Verificación de Traducción**: Entrar a la app, hacer clic en el botón de cambio de idioma en el header, y comprobar que el título de la página y las etiquetas flash cambien correctamente al idioma seleccionado a través del inyector `_()`.
3.  **Comprobación de Estilos CSS Responsivos**: Visualizar la aplicación en modo tablet (resolución de 768px y 1024px) a través de las herramientas de desarrollo del navegador y verificar que la barra de navegación colapse correctamente y que los botones de llamada a la acción mantengan un padding de fácil tacto.

# Especificación Técnica y Diseño de Base de Datos para Sistema CMMS
**Enfoque**: Mantenimiento a Equipos de Manufactura, Órdenes de Trabajo (OT) y Soporte a Líneas de Producción
**Motor de Base de Datos**: SQL Server 2017 (versión 14.0)

---

## 1. Arquitectura de Negocio y Flujo de Trabajo

El sistema está diseñado para operar en una planta de manufactura estructurada por Áreas, Líneas, Estaciones y Equipos. Permite la interacción ágil entre Líderes de Línea y Técnicos a través de dispositivos móviles/tablets con escaneo de códigos QR.

### Registro Inicial del Líder (Análisis de Paros / Down Time)
Para medir adecuadamente el tiempo perdido y alimentar reportes de eficiencia, el líder de línea no solo escribe un comentario abierto al reportar la falla de una estación. Ahora captura campos estructurados que facilitan el análisis de causas raíz y costos de paro:
1.  **Síntoma de Falla**: Selección de una lista estandarizada de lo que observa (ej. "Robot atorado", "PC no enciende", "Fuga de aire").
2.  **Causa de las 4Ms**: Clasificación inicial bajo los pilares de manufactura: *Mano de Obra (Manpower)*, *Maquinaria (Machine)*, *Material (Material)* o *Método (Method)*.
3.  **Clasificación de Falla**: Selección estructurada (Calidad, Falta de Material, Operación, Problema de Partes/Componentes, Otros).
4.  **Impacto**: Área o nivel de afectación (Línea Completa detenida, Estación Cuello de Botella detenida, Estación Regular detenida).
5.  **Empleados Afectados**: Cantidad de operadores detenidos o reasignados temporalmente debido al paro en la estación.

### Roles de Usuario
*   **Líder de Línea**: Reporta la falla a nivel de estación seleccionando parámetros estructurados (4Ms, Síntomas, Empleados Afectados, Impacto) e inicia la Orden de Trabajo (OT).
*   **Técnico**: Atiende los reportes, escanea el código QR de la estación para marcar arribo, diagnostica la falla a nivel de equipo específico, consulta fallas/soluciones comunes de ese tipo de equipo, consume refacciones y registra la solución cargando evidencias. El técnico introduce el "Problema Real" (modo de falla técnico), lo que permite cruzar la percepción del líder contra el diagnóstico técnico final.
*   **Ingeniero de Mantenimiento / Administrador**: Administra catálogos de equipos, analiza tiempos de respuesta (MTTR, MTBF), evalúa la exactitud del reporte inicial del líder y reporta el Down Time acumulado por las 4Ms.

```mermaid
graph TD
    A[Líder detecta falla] --> B[Captura formulario OT: Sintoma, 4Ms, Clasificación, Emp. Afectados, Impacto]
    B --> C[Notificación a Técnicos con prioridad segun Impacto]
    C --> D[Técnico llega a Estación y escanea QR]
    D --> E[Sistema registra Arribo QR e inicia timer de atención]
    E --> G[Técnico diagnostica el Equipo específico de esa Estación]
    G --> F[Sistema muestra Fallas/Soluciones Comunes y Recursos]
    F --> H[Técnico aplica solución, toma fotos y usa refacciones]
    H --> I[Técnico cierra OT registrando Falla Real y Solución Aplicada]
    I --> J[Cálculo de KPIs: MTTR, MTBF, Down Time y Exactitud del Reporte]
```

---

## 2. Diagrama de Entidad-Relación (Mermaid)

El modelo lógico-relacional extendido para soportar la clasificación 4Ms, síntomas de líderes y métricas de impacto en línea.

```mermaid
erDiagram
    CatAreas ||--o{ CatLineas : "tiene"
    CatLineas ||--o{ CatEstaciones : "contiene"
    CatEstaciones ||--o{ CatEquipos : "contiene"
    CatTiposEquipo ||--o{ CatEquipos : "clasifica"
    CatTiposEquipo ||--o{ CatFallasComunes : "tiene"
    CatFallasComunes ||--o{ CatSolucionesComunes : "resuelve"
    CatTiposEquipo ||--o{ RecursosSoporte : "tiene"

    CatRoles ||--o{ CatUsuarios : "asigna"
    CatAreas ||--o{ CatUsuarios : "pertenece"
    CatTurnos ||--o{ CatUsuarios : "asigna"

    CatEstadosOT ||--o{ OrdenesTrabajo : "clasifica"
    CatEstaciones ||--o{ OrdenesTrabajo : "ocurre_en"
    CatEquipos ||--o{ OrdenesTrabajo : "afecta"
    CatUsuarios ||--o{ OrdenesTrabajo : "reportada_por"
    CatTurnos ||--o{ OrdenesTrabajo : "ocurre_en_turno"
    CatSintomasFallaLider ||--o{ OrdenesTrabajo : "reportado_como"
    CatClasificacionesFallaLider ||--o{ OrdenesTrabajo : "clasificado_como"
    CatCausas4M ||--o{ OrdenesTrabajo : "causa_inicial"

    OrdenesTrabajo ||--o{ DetalleTecnicosOT : "atendida_por"
    CatUsuarios ||--o{ DetalleTecnicosOT : "ejecuta"

    OrdenesTrabajo ||--o{ BitacoraEstadosOT : "registra"
    CatUsuarios ||--o{ BitacoraEstadosOT : "cambiado_por"

    OrdenesTrabajo ||--o{ EvidenciasOT : "tiene"
    CatUsuarios ||--o{ EvidenciasOT : "subida_por"

    OrdenesTrabajo ||--o{ MaterialesOT : "utiliza"
    CatMateriales ||--o{ MaterialesOT : "es_usado"
```

---

## 3. Diccionario de Datos

Cada tabla cuenta con los campos estándar de auditoría y estado lógico:
*   `activo BIT DEFAULT 1`: Permite inhabilitar registros de manera lógica.
*   `fecharegistro DATETIME DEFAULT GETDATE()`: Fecha y hora automática de registro en SQL Server.

### Nuevas Tablas de Clasificación del Líder (Down Time)

#### 1. `CatSintomasFallaLider`
Catálogo estandarizado de problemas observables por personal no técnico (Líderes).
*   `ID` (INT, PK, Identity)
*   `Nombre` (VARCHAR(150)): Ej. "Robot no cicla", "PC congelada", "Tornillo barrido", "Fuga de aire visible", "Sobrecalentamiento".
*   `Descripcion` (VARCHAR(250))

#### 2. `CatClasificacionesFallaLider`
Categorización operacional del paro inicial.
*   `ID` (INT, PK, Identity)
*   `Nombre` (VARCHAR(100)): Problema de Partes, Falta de Material, Calidad, Operación, Otros.
*   `Descripcion` (VARCHAR(250))

#### 3. `CatCausas4M`
Estructura clásica de manufactura para causa raíz (Mano de Obra, Maquinaria, Material, Método).
*   `ID` (INT, PK, Identity)
*   `Nombre` (VARCHAR(50)): Manpower (Mano de Obra), Machine (Maquinaria), Material (Material), Method (Método).
*   `Descripcion` (VARCHAR(250))

---

### Tablas Modificadas y Resto de Catálogos

#### 4. `CatTurnos`
*   `ID` (INT, PK, Identity), `Nombre` (VARCHAR(50)), `HoraInicio` (TIME), `HoraFin` (TIME).

#### 5. `CatAreas`
*   `ID` (INT, PK, Identity), `Nombre` (VARCHAR(100)), `Descripcion` (VARCHAR(250)).

#### 6. `CatLineas`
*   `ID` (INT, PK, Identity), `AreaID` (INT, FK -> CatAreas.ID), `Nombre` (VARCHAR(100)).

#### 7. `CatEstaciones`
*   `ID` (INT, PK, Identity), `LineaID` (INT, FK -> CatLineas.ID), `Nombre` (VARCHAR(100)), `CodigoQR` (VARCHAR(150), Unique).

#### 8. `CatTiposEquipo`
*   `ID` (INT, PK, Identity), `Nombre` (VARCHAR(100)), `Descripcion` (VARCHAR(250)).

#### 9. `CatEquipos`
*   `ID` (INT, PK, Identity), `EstacionID` (INT, FK -> CatEstaciones.ID), `TipoEquipoID` (INT, FK -> CatTiposEquipo.ID), `Nombre` (VARCHAR(100)), `Modelo` (VARCHAR(100)), `NumeroSerie` (VARCHAR(100)).

#### 10. `CatUsuarios`
*   `ID` (INT, PK, Identity), `NoEmpleado` (VARCHAR(20), Unique), `Nombre` (VARCHAR(150)), `Correo` (VARCHAR(100)), `RolID` (INT, FK -> CatRoles.ID), `AreaID` (INT, FK -> CatAreas.ID), `TurnoID` (INT, FK -> CatTurnos.ID).

#### 11. `CatFallasComunes` (Modo de Falla Técnico)
*   `ID` (INT, PK, Identity), `TipoEquipoID` (INT, FK -> CatTiposEquipo.ID), `CodigoFalla` (VARCHAR(20), Unique), `Nombre` (VARCHAR(150)), `Descripcion` (VARCHAR(500)).

#### 12. `CatSolucionesComunes`
*   `ID` (INT, PK, Identity), `FallaComunID` (INT, FK -> CatFallasComunes.ID), `Nombre` (VARCHAR(150)), `Descripcion` (VARCHAR(500)).

#### 13. `RecursosSoporte`
*   `ID` (INT, PK, Identity), `TipoEquipoID` (INT, FK -> CatTiposEquipo.ID), `FallaComunID` (INT, FK -> CatFallasComunes.ID, Nullable), `Nombre` (VARCHAR(150)), `TipoRecurso` (VARCHAR(50)), `PathArchivo` (VARCHAR(500)).

---

### Tablas de Órdenes de Trabajo y Transacciones

#### 14. `CatEstadosOT`
*   `ID` (INT, PK, Identity), `Nombre` (VARCHAR(50)), `Descripcion` (VARCHAR(250)).
    *   *Estados*: Creada, En Proceso, Pausada, Sin Solución, Cancelada, Completada, Deshabilitada.

#### 15. `OrdenesTrabajo` (Estructura Actualizada)
*   `ID` (INT, PK, Identity)
*   `EstacionID` (INT, FK -> CatEstaciones.ID)
*   `EquipoID` (INT, FK -> CatEquipos.ID, Nullable): Diagnosticado por el técnico.
*   `FallaRealID` (INT, FK -> CatFallasComunes.ID, Nullable): El modo de falla técnica real diagnosticada.
*   `EstadoID` (INT, FK -> CatEstadosOT.ID)
*   `LiderReportaID` (INT, FK -> CatUsuarios.ID)
*   `TurnoID` (INT, FK -> CatTurnos.ID)
*   `SintomaFallaLiderID` (INT, FK -> CatSintomasFallaLider.ID): Selección del síntoma de la lista.
*   `ClasificacionFallaLiderID` (INT, FK -> CatClasificacionesFallaLider.ID): Clasificación seleccionada.
*   `Causa4MID` (INT, FK -> CatCausas4M.ID): Categoría de las 4Ms.
*   `AreaAfectadaImpacto` (VARCHAR(150)): Ej. "LINEA_COMPLETA", "ESTACION_CUELLO_BOTELLA", "ESTACION_REGULAR".
*   `EmpleadosAfectados` (INT): Empleados parados o desviados.
*   `ComentarioLider` (VARCHAR(1000)): Comentarios u observaciones adicionales del líder (abierto).
*   `FechaReporte` (DATETIME): Fecha y hora del reporte inicial del líder.

#### 16. `DetalleTecnicosOT`
*   `ID` (INT, PK, Identity), `OrdenTrabajoID` (INT, FK -> OrdenesTrabajo.ID), `TecnicoID` (INT, FK -> CatUsuarios.ID), `FechaAsignacion` (DATETIME), `FechaArriboQR` (DATETIME, Nullable), `FechaFinActividad` (DATETIME, Nullable).

#### 17. `BitacoraEstadosOT`
*   `ID` (INT, PK, Identity), `OrdenTrabajoID` (INT, FK -> OrdenesTrabajo.ID), `EstadoAnteriorID` (INT, FK -> CatEstadosOT.ID, Nullable), `EstadoNuevoID` (INT, FK -> CatEstadosOT.ID), `UsuarioID` (INT, FK -> CatUsuarios.ID), `FechaCambio` (DATETIME), `Comentario` (VARCHAR(500)).

#### 18. `EvidenciasOT`
*   `ID` (INT, PK, Identity), `OrdenTrabajoID` (INT, FK -> OrdenesTrabajo.ID), `UsuarioID` (INT, FK -> CatUsuarios.ID), `TipoEvidencia` (VARCHAR(20)), `PathArchivo` (VARCHAR(500)).

#### 19. `CatMateriales`
*   `ID` (INT, PK, Identity), `NumeroParte` (VARCHAR(100), Unique), `Nombre` (VARCHAR(150)), `Stock` (DECIMAL(18,2)), `UnidadMedida` (VARCHAR(20)).

#### 20. `MaterialesOT`
*   `ID` (INT, PK, Identity), `OrdenTrabajoID` (INT, FK -> OrdenesTrabajo.ID), `MaterialID` (INT, FK -> CatMateriales.ID), `Cantidad` (DECIMAL(18,2)), `UsuarioID` (INT, FK -> CatUsuarios.ID).

---

## 4. Script DDL para SQL Server 2017 (14.0)

Script SQL optimizado que incorpora las nuevas tablas de Down Time y la estructura renovada de `OrdenesTrabajo`.

```sql
-- =========================================================================
-- SCRIPT DE CREACION DE BASE DE DATOS CMMS ACTUALIZADO
-- SQL Server 2017 (14.0)
-- =========================================================================

CREATE DATABASE CMMS_Db;
GO

USE CMMS_Db;
GO

-- 1. CatTurnos
CREATE TABLE CatTurnos (
    ID INT IDENTITY(1,1) NOT NULL,
    Nombre VARCHAR(50) NOT NULL,
    HoraInicio TIME NOT NULL,
    HoraFin TIME NOT NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatTurnos_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatTurnos_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatTurnos PRIMARY KEY CLUSTERED (ID)
);

-- 2. CatAreas
CREATE TABLE CatAreas (
    ID INT IDENTITY(1,1) NOT NULL,
    Nombre VARCHAR(100) NOT NULL,
    Descripcion VARCHAR(250) NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatAreas_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatAreas_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatAreas PRIMARY KEY CLUSTERED (ID)
);

-- 3. CatLineas
CREATE TABLE CatLineas (
    ID INT IDENTITY(1,1) NOT NULL,
    AreaID INT NOT NULL,
    Nombre VARCHAR(100) NOT NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatLineas_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatLineas_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatLineas PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_CatLineas_CatAreas FOREIGN KEY (AreaID) REFERENCES CatAreas(ID)
);

-- 4. CatEstaciones
CREATE TABLE CatEstaciones (
    ID INT IDENTITY(1,1) NOT NULL,
    LineaID INT NOT NULL,
    Nombre VARCHAR(100) NOT NULL,
    CodigoQR VARCHAR(150) NOT NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatEstaciones_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatEstaciones_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatEstaciones PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT UQ_CatEstaciones_CodigoQR UNIQUE (CodigoQR),
    CONSTRAINT FK_CatEstaciones_CatLineas FOREIGN KEY (LineaID) REFERENCES CatLineas(ID)
);

-- 5. CatTiposEquipo
CREATE TABLE CatTiposEquipo (
    ID INT IDENTITY(1,1) NOT NULL,
    Nombre VARCHAR(100) NOT NULL,
    Descripcion VARCHAR(250) NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatTiposEquipo_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatTiposEquipo_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatTiposEquipo PRIMARY KEY CLUSTERED (ID)
);

-- 6. CatEquipos
CREATE TABLE CatEquipos (
    ID INT IDENTITY(1,1) NOT NULL,
    EstacionID INT NOT NULL,
    TipoEquipoID INT NOT NULL,
    Nombre VARCHAR(100) NOT NULL,
    Modelo VARCHAR(100) NULL,
    NumeroSerie VARCHAR(100) NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatEquipos_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatEquipos_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatEquipos PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_CatEquipos_CatEstaciones FOREIGN KEY (EstacionID) REFERENCES CatEstaciones(ID),
    CONSTRAINT FK_CatEquipos_CatTiposEquipo FOREIGN KEY (TipoEquipoID) REFERENCES CatTiposEquipo(ID)
);

-- 7. CatRoles
CREATE TABLE CatRoles (
    ID INT IDENTITY(1,1) NOT NULL,
    Nombre VARCHAR(50) NOT NULL,
    Descripcion VARCHAR(250) NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatRoles_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatRoles_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatRoles PRIMARY KEY CLUSTERED (ID)
);

-- 8. CatUsuarios
CREATE TABLE CatUsuarios (
    ID INT IDENTITY(1,1) NOT NULL,
    NoEmpleado VARCHAR(20) NOT NULL,
    Nombre VARCHAR(150) NOT NULL,
    Correo VARCHAR(100) NULL,
    RolID INT NOT NULL,
    AreaID INT NOT NULL,
    TurnoID INT NOT NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatUsuarios_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatUsuarios_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatUsuarios PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT UQ_CatUsuarios_NoEmpleado UNIQUE (NoEmpleado),
    CONSTRAINT FK_CatUsuarios_CatRoles FOREIGN KEY (RolID) REFERENCES CatRoles(ID),
    CONSTRAINT FK_CatUsuarios_CatAreas FOREIGN KEY (AreaID) REFERENCES CatAreas(ID),
    CONSTRAINT FK_CatUsuarios_CatTurnos FOREIGN KEY (TurnoID) REFERENCES CatTurnos(ID)
);

-- 9. CatSintomasFallaLider
CREATE TABLE CatSintomasFallaLider (
    ID INT IDENTITY(1,1) NOT NULL,
    Nombre VARCHAR(150) NOT NULL,
    Descripcion VARCHAR(250) NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatSintomasFallaLider_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatSintomasFallaLider_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatSintomasFallaLider PRIMARY KEY CLUSTERED (ID)
);

-- 10. CatClasificacionesFallaLider
CREATE TABLE CatClasificacionesFallaLider (
    ID INT IDENTITY(1,1) NOT NULL,
    Nombre VARCHAR(100) NOT NULL,
    Descripcion VARCHAR(250) NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatClasificacionesFallaLider_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatClasificacionesFallaLider_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatClasificacionesFallaLider PRIMARY KEY CLUSTERED (ID)
);

-- 11. CatCausas4M
CREATE TABLE CatCausas4M (
    ID INT IDENTITY(1,1) NOT NULL,
    Nombre VARCHAR(50) NOT NULL,
    Descripcion VARCHAR(250) NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatCausas4M_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatCausas4M_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatCausas4M PRIMARY KEY CLUSTERED (ID)
);

-- 12. CatFallasComunes (Modos de falla tecnicos)
CREATE TABLE CatFallasComunes (
    ID INT IDENTITY(1,1) NOT NULL,
    TipoEquipoID INT NOT NULL,
    CodigoFalla VARCHAR(20) NOT NULL,
    Nombre VARCHAR(150) NOT NULL,
    Descripcion VARCHAR(500) NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatFallasComunes_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatFallasComunes_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatFallasComunes PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT UQ_CatFallasComunes_CodigoFalla UNIQUE (CodigoFalla),
    CONSTRAINT FK_CatFallasComunes_CatTiposEquipo FOREIGN KEY (TipoEquipoID) REFERENCES CatTiposEquipo(ID)
);

-- 13. CatSolucionesComunes
CREATE TABLE CatSolucionesComunes (
    ID INT IDENTITY(1,1) NOT NULL,
    FallaComunID INT NOT NULL,
    Nombre VARCHAR(150) NOT NULL,
    Descripcion VARCHAR(500) NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatSolucionesComunes_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatSolucionesComunes_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatSolucionesComunes PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_CatSolucionesComunes_CatFallasComunes FOREIGN KEY (FallaComunID) REFERENCES CatFallasComunes(ID)
);

-- 14. RecursosSoporte
CREATE TABLE RecursosSoporte (
    ID INT IDENTITY(1,1) NOT NULL,
    TipoEquipoID INT NOT NULL,
    FallaComunID INT NULL,
    Nombre VARCHAR(150) NOT NULL,
    TipoRecurso VARCHAR(50) NOT NULL, -- MANUAL, TUTORIAL, VIDEO, IMAGEN
    PathArchivo VARCHAR(500) NOT NULL, -- Ruta logica o UNC
    activo BIT NOT NULL CONSTRAINT DF_RecursosSoporte_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_RecursosSoporte_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_RecursosSoporte PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_RecursosSoporte_CatTiposEquipo FOREIGN KEY (TipoEquipoID) REFERENCES CatTiposEquipo(ID),
    CONSTRAINT FK_RecursosSoporte_CatFallasComunes FOREIGN KEY (FallaComunID) REFERENCES CatFallasComunes(ID)
);

-- 15. CatEstadosOT
CREATE TABLE CatEstadosOT (
    ID INT IDENTITY(1,1) NOT NULL,
    Nombre VARCHAR(50) NOT NULL,
    Descripcion VARCHAR(250) NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatEstadosOT_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatEstadosOT_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatEstadosOT PRIMARY KEY CLUSTERED (ID)
);

-- 16. OrdenesTrabajo
CREATE TABLE OrdenesTrabajo (
    ID INT IDENTITY(1,1) NOT NULL,
    EstacionID INT NOT NULL,
    EquipoID INT NULL, -- NULL al inicio; diagnosticado por el tecnico despues
    FallaRealID INT NULL, -- FK de Falla Tecnica final
    EstadoID INT NOT NULL,
    LiderReportaID INT NOT NULL,
    TurnoID INT NOT NULL,
    SintomaFallaLiderID INT NOT NULL, -- Sintoma de la lista
    ClasificacionFallaLiderID INT NOT NULL, -- Calidad, falta material, partes, etc.
    Causa4MID INT NOT NULL, -- Machine, Manpower, etc.
    AreaAfectadaImpacto VARCHAR(150) NOT NULL, -- LINEA_COMPLETA, ESTACION_REGULAR, etc.
    EmpleadosAfectados INT NOT NULL CONSTRAINT DF_OrdenesTrabajo_EmpAfectados DEFAULT 0,
    ComentarioLider VARCHAR(1000) NULL,
    FechaReporte DATETIME NOT NULL CONSTRAINT DF_OrdenesTrabajo_FechaReporte DEFAULT GETDATE(),
    activo BIT NOT NULL CONSTRAINT DF_OrdenesTrabajo_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_OrdenesTrabajo_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_OrdenesTrabajo PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_OrdenesTrabajo_CatEstaciones FOREIGN KEY (EstacionID) REFERENCES CatEstaciones(ID),
    CONSTRAINT FK_OrdenesTrabajo_CatEquipos FOREIGN KEY (EquipoID) REFERENCES CatEquipos(ID),
    CONSTRAINT FK_OrdenesTrabajo_CatFallasComunes FOREIGN KEY (FallaRealID) REFERENCES CatFallasComunes(ID),
    CONSTRAINT FK_OrdenesTrabajo_CatEstadosOT FOREIGN KEY (EstadoID) REFERENCES CatEstadosOT(ID),
    CONSTRAINT FK_OrdenesTrabajo_CatUsuarios FOREIGN KEY (LiderReportaID) REFERENCES CatUsuarios(ID),
    CONSTRAINT FK_OrdenesTrabajo_CatTurnos FOREIGN KEY (TurnoID) REFERENCES CatTurnos(ID),
    CONSTRAINT FK_OrdenesTrabajo_CatSintomas FOREIGN KEY (SintomaFallaLiderID) REFERENCES CatSintomasFallaLider(ID),
    CONSTRAINT FK_OrdenesTrabajo_CatClasificaciones FOREIGN KEY (ClasificacionFallaLiderID) REFERENCES CatClasificacionesFallaLider(ID),
    CONSTRAINT FK_OrdenesTrabajo_CatCausas4M FOREIGN KEY (Causa4MID) REFERENCES CatCausas4M(ID)
);

-- 17. DetalleTecnicosOT
CREATE TABLE DetalleTecnicosOT (
    ID INT IDENTITY(1,1) NOT NULL,
    OrdenTrabajoID INT NOT NULL,
    TecnicoID INT NOT NULL,
    FechaAsignacion DATETIME NOT NULL CONSTRAINT DF_DetalleTecnicosOT_FechaAsignacion DEFAULT GETDATE(),
    FechaArriboQR DATETIME NULL,
    FechaFinActividad DATETIME NULL,
    activo BIT NOT NULL CONSTRAINT DF_DetalleTecnicosOT_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_DetalleTecnicosOT_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_DetalleTecnicosOT PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_DetalleTecnicosOT_OrdenesTrabajo FOREIGN KEY (OrdenTrabajoID) REFERENCES OrdenesTrabajo(ID),
    CONSTRAINT FK_DetalleTecnicosOT_CatUsuarios FOREIGN KEY (TecnicoID) REFERENCES CatUsuarios(ID)
);

-- 18. BitacoraEstadosOT
CREATE TABLE BitacoraEstadosOT (
    ID INT IDENTITY(1,1) NOT NULL,
    OrdenTrabajoID INT NOT NULL,
    EstadoAnteriorID INT NULL,
    EstadoNuevoID INT NOT NULL,
    UsuarioID INT NOT NULL,
    FechaCambio DATETIME NOT NULL CONSTRAINT DF_BitacoraEstadosOT_FechaCambio DEFAULT GETDATE(),
    Comentario VARCHAR(500) NULL,
    activo BIT NOT NULL CONSTRAINT DF_BitacoraEstadosOT_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_BitacoraEstadosOT_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_BitacoraEstadosOT PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_BitacoraEstadosOT_OrdenesTrabajo FOREIGN KEY (OrdenTrabajoID) REFERENCES OrdenesTrabajo(ID),
    CONSTRAINT FK_BitacoraEstadosOT_CatEstadosOT_Ant FOREIGN KEY (EstadoAnteriorID) REFERENCES CatEstadosOT(ID),
    CONSTRAINT FK_BitacoraEstadosOT_CatEstadosOT_Nvo FOREIGN KEY (EstadoNuevoID) REFERENCES CatEstadosOT(ID),
    CONSTRAINT FK_BitacoraEstadosOT_CatUsuarios FOREIGN KEY (UsuarioID) REFERENCES CatUsuarios(ID)
);

-- 19. EvidenciasOT
CREATE TABLE EvidenciasOT (
    ID INT IDENTITY(1,1) NOT NULL,
    OrdenTrabajoID INT NOT NULL,
    UsuarioID INT NOT NULL,
    TipoEvidencia VARCHAR(20) NOT NULL, -- FALLA, SOLUCION
    PathArchivo VARCHAR(500) NOT NULL,
    activo BIT NOT NULL CONSTRAINT DF_EvidenciasOT_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_EvidenciasOT_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_EvidenciasOT PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_EvidenciasOT_OrdenesTrabajo FOREIGN KEY (OrdenTrabajoID) REFERENCES OrdenesTrabajo(ID),
    CONSTRAINT FK_EvidenciasOT_CatUsuarios FOREIGN KEY (UsuarioID) REFERENCES CatUsuarios(ID),
    CONSTRAINT CK_EvidenciasOT_Tipo CHECK (TipoEvidencia IN ('FALLA', 'SOLUCION'))
);

-- 20. CatMateriales
CREATE TABLE CatMateriales (
    ID INT IDENTITY(1,1) NOT NULL,
    NumeroParte VARCHAR(100) NOT NULL,
    Nombre VARCHAR(150) NOT NULL,
    Stock DECIMAL(18,2) NOT NULL CONSTRAINT DF_CatMateriales_Stock DEFAULT 0,
    UnidadMedida VARCHAR(20) NOT NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatMateriales_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatMateriales_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatMateriales PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT UQ_CatMateriales_NumeroParte UNIQUE (NumeroParte)
);

-- 21. MaterialesOT
CREATE TABLE MaterialesOT (
    ID INT IDENTITY(1,1) NOT NULL,
    OrdenTrabajoID INT NOT NULL,
    MaterialID INT NOT NULL,
    Cantidad DECIMAL(18,2) NOT NULL,
    UsuarioID INT NOT NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatMaterialesOT_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatMaterialesOT_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_MaterialesOT PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_MaterialesOT_OrdenesTrabajo FOREIGN KEY (OrdenTrabajoID) REFERENCES OrdenesTrabajo(ID),
    CONSTRAINT FK_MaterialesOT_CatMateriales FOREIGN KEY (MaterialID) REFERENCES CatMateriales(ID),
    CONSTRAINT FK_MaterialesOT_CatUsuarios FOREIGN KEY (UsuarioID) REFERENCES CatUsuarios(ID)
);
GO

-- =========================================================================
-- INDICES PARA OPTIMIZAR EL RENDIMIENTO
-- =========================================================================
CREATE UNIQUE NONCLUSTERED INDEX IX_CatEstaciones_CodigoQR 
ON CatEstaciones (CodigoQR) WHERE activo = 1;

CREATE NONCLUSTERED INDEX IX_CatEquipos_EstacionID 
ON CatEquipos (EstacionID) WHERE activo = 1;

CREATE UNIQUE NONCLUSTERED INDEX IX_CatUsuarios_NoEmpleado 
ON CatUsuarios (NoEmpleado) WHERE activo = 1;

CREATE NONCLUSTERED INDEX IX_OrdenesTrabajo_EstadoID_FechaReporte 
ON OrdenesTrabajo (EstadoID, FechaReporte) 
INCLUDE (EstacionID, EquipoID, SintomaFallaLiderID, Causa4MID);

CREATE NONCLUSTERED INDEX IX_DetalleTecnicosOT_OrdenTrabajoID 
ON DetalleTecnicosOT (OrdenTrabajoID) 
INCLUDE (TecnicoID, FechaArriboQR, FechaFinActividad);
GO
```

---

## 5. Procedimientos Almacenados (Flujo Actualizado)

### A. Apertura de Orden de Trabajo (Líder de Línea)
Permite al líder registrar de forma obligatoria los nuevos parámetros de Down Time.

```sql
CREATE PROCEDURE sp_OT_Crear_V2
    @EstacionID INT,
    @LiderID INT,
    @SintomaFallaLiderID INT,
    @ClasificacionFallaLiderID INT,
    @Causa4MID INT,
    @AreaAfectadaImpacto VARCHAR(150),
    @EmpleadosAfectados INT,
    @ComentarioLider VARCHAR(1000)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @EstadoCreadaID INT;
        DECLARE @TurnoID INT;
        DECLARE @HoraActual TIME = CONVERT(TIME, GETDATE());

        -- Obtener ID del estado 'Creada'
        SELECT TOP 1 @EstadoCreadaID = ID FROM CatEstadosOT WHERE Nombre = 'Creada' AND activo = 1;

        -- Determinar Turno en base a hora actual
        SELECT TOP 1 @TurnoID = ID 
        FROM CatTurnos 
        WHERE activo = 1 
          AND (
            (@HoraInicio <= @HoraFin AND @HoraActual BETWEEN HoraInicio AND HoraFin) OR
            (@HoraInicio > @HoraFin AND (@HoraActual >= HoraInicio OR @HoraActual <= HoraFin))
          );

        -- Turno por defecto si la hora falla
        IF @TurnoID IS NULL
            SELECT @TurnoID = TurnoID FROM CatUsuarios WHERE ID = @LiderID;

        -- Insertar Orden de Trabajo con la clasificacion de Down Time
        DECLARE @NuevaOTID INT;
        INSERT INTO OrdenesTrabajo (
            EstacionID, EstadoID, LiderReportaID, TurnoID, 
            SintomaFallaLiderID, ClasificacionFallaLiderID, Causa4MID, 
            AreaAfectadaImpacto, EmpleadosAfectados, ComentarioLider, FechaReporte
        )
        VALUES (
            @EstacionID, @EstadoCreadaID, @LiderID, @TurnoID,
            @SintomaFallaLiderID, @ClasificacionFallaLiderID, @Causa4MID,
            @AreaAfectadaImpacto, @EmpleadosAfectados, @ComentarioLider, GETDATE()
        );

        SET @NuevaOTID = SCOPE_IDENTITY();

        -- Insertar Bitacora
        INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, Comentario)
        VALUES (@NuevaOTID, NULL, @EstadoCreadaID, @LiderID, 'OT inicial con reporte de Down Time y clasificación por líder.');

        COMMIT TRANSACTION;
        SELECT @NuevaOTID AS OrdenTrabajoID;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH;
END;
GO
```

### B. Cierre de Orden de Trabajo (Técnico Diagnostica y Cierra)
El técnico asocia el `EquipoID` específico y el modo de `FallaRealID` (diagnóstico técnico real).

```sql
CREATE PROCEDURE sp_OT_Completar_V2
    @OrdenTrabajoID INT,
    @EquipoID INT, 
    @FallaRealID INT, -- Falla Técnica Real diagnosticada
    @TecnicoID INT,
    @ComentariosSolucion VARCHAR(500)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @EstadoCompletadaID INT;
        DECLARE @EstadoActualID INT;
        
        SELECT TOP 1 @EstadoCompletadaID = ID FROM CatEstadosOT WHERE Nombre = 'Completada' AND activo = 1;
        SELECT @EstadoActualID = EstadoID FROM OrdenesTrabajo WHERE ID = @OrdenTrabajoID;

        -- 1. Actualizar orden principal
        UPDATE OrdenesTrabajo
        SET EstadoID = @EstadoCompletadaID,
            EquipoID = @EquipoID,
            FallaRealID = @FallaRealID
        WHERE ID = @OrdenTrabajoID;

        -- 2. Registrar fin del tecnico firmante
        UPDATE DetalleTecnicosOT
        SET FechaFinActividad = GETDATE()
        WHERE OrdenTrabajoID = @OrdenTrabajoID && TecnicoID = @TecnicoID && activo = 1;

        -- 3. Bitacora
        INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, Comentario)
        VALUES (@OrdenTrabajoID, @EstadoActualID, @EstadoCompletadaID, @TecnicoID, @ComentariosSolucion);

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH;
END;
GO
```

---

## 6. Consultas Analíticas (Down Time e Ingeniería)

### A. Reporte de Down Time Neto y Horas-Hombre Perdidas por 4Ms
Esta métrica calcula el impacto productivo real del paro multiplicando el tiempo del paro (desde el reporte inicial hasta la conclusión) por el número de operadores afectados.

$$Horas\ Hombre\ Perdidas = \sum \left( \frac{Tiempo\ Paro\ (Minutos) \times Empleados\ Afectados}{60} \right)$$

```sql
SELECT 
    c4.Nombre AS Causa4M,
    COUNT(ot.ID) AS TotalIncidentes,
    -- Suma de minutos totales de la línea inactiva
    SUM(DATEDIFF(MINUTE, ot.FechaReporte, dt.FechaFinActividad)) AS MinutosParoTotal,
    -- Horas Hombre Perdidas = (Minutos Paro * Empleados Afectados) / 60
    SUM(CAST(DATEDIFF(MINUTE, ot.FechaReporte, dt.FechaFinActividad) AS DECIMAL(10,2)) * ot.EmpleadosAfectados) / 60.0 AS HorasHombrePerdidas
FROM OrdenesTrabajo ot
INNER JOIN CatCausas4M c4 ON ot.Causa4MID = c4.ID
-- Buscar el técnico que cerró para determinar el fin del paro
INNER JOIN DetalleTecnicosOT dt ON dt.OrdenTrabajoID = ot.ID AND dt.FechaFinActividad IS NOT NULL
INNER JOIN CatEstadosOT est ON ot.EstadoID = est.ID
WHERE est.Nombre = 'Completada'
  AND ot.activo = 1
GROUP BY c4.Nombre;
```

### B. Análisis de Discrepancia: Percepción de Líder vs Diagnóstico Real
Reporte crítico para evaluar qué tan bien clasifican los líderes y si las soluciones comunes de autoservicio están funcionando. Compara el `SintomaFallaLider` frente al `Equipo` y la `FallaReal` reportada por el técnico.

```sql
SELECT 
    sfl.Nombre AS SintomaReportadoLider,
    cfl.Nombre AS ClasificacionLider,
    eq.Nombre AS EquipoRealAfectado,
    fc.Nombre AS FallaRealTecnico,
    COUNT(ot.ID) AS FrecuenciaCoincidencia,
    AVG(DATEDIFF(MINUTE, ot.FechaReporte, ot.fecharegistro)) AS PromedioMinutosSolucion
FROM OrdenesTrabajo ot
INNER JOIN CatSintomasFallaLider sfl ON ot.SintomaFallaLiderID = sfl.ID
INNER JOIN CatClasificacionesFallaLider cfl ON ot.ClasificacionFallaLiderID = cfl.ID
INNER JOIN CatEquipos eq ON ot.EquipoID = eq.ID
INNER JOIN CatFallasComunes fc ON ot.FallaRealID = fc.ID
WHERE ot.EstadoID = (SELECT ID FROM CatEstadosOT WHERE Nombre = 'Completada')
GROUP BY sfl.Nombre, cfl.Nombre, eq.Nombre, fc.Nombre
ORDER BY FrecuenciaCoincidencia DESC;
```

---

## 7. Fórmulas de KPIs de Tiempos Actualizadas

### MTTR (Mean Time to Repair)
Mide el tiempo transcurrido desde que el técnico **marca arribo escaneando el QR** hasta que **finaliza** el trabajo.

$$MTTR = \frac{\sum (FechaFinActividad - FechaArriboQR)}{Número\ de\ Órdenes\ Completadas}$$

### MTBF (Mean Time Between Failures)
Calcula el intervalo promedio de tiempo en días que opera un equipo entre fallas técnicas reales reportadas.

$$MTBF = \frac{\sum (FechaReporte\_Actual - FechaReporte\_Anterior)}{Número\ de\ Fallas\ del\ Equipo}$$

### Down Time (Tiempo Muerto Promedio)
Mide el tiempo completo de indisponibilidad de la celda de manufactura (desde el reporte inicial del líder hasta la solución del técnico).

$$Down\ Time\ Promedio = \frac{\sum (FechaFinActividad - FechaReporte)}{Número\ de\ Paros}$$

# Especificación Técnica y Diseño de Base de Datos para Sistema CMMS
**Enfoque**: Mantenimiento a Equipos de Manufactura, Órdenes de Trabajo (OT) y Soporte a Líneas de Producción
**Motor de Base de Datos**: SQL Server 2017 (versión 14.0)

---

## 1. Arquitectura de Negocio y Flujo de Trabajo

El sistema está diseñado para operar en una planta de manufactura estructurada por Áreas, Líneas, Estaciones y Equipos. Permite la interacción ágil entre Líderes de Línea y Técnicos a través de dispositivos móviles/tablets con escaneo de códigos QR.

### Roles de Usuario
*   **Líder de Línea**: Reporta fallas en estaciones de trabajo e inicia el flujo de la orden de trabajo (OT).
*   **Técnico**: Atiende los reportes, escanea el código QR de la estación para marcar arribo, diagnostica la falla a nivel de equipo específico, consulta fallas/soluciones comunes, visualiza recursos multimedia (manuales/videos), consume refacciones y registra la solución cargando evidencias.
*   **Ingeniero de Mantenimiento / Administrador**: Administra catálogos de equipos, analiza tiempos de respuesta (KPIs como MTTR y MTBF), define planes de mantenimiento preventivo y carga recursos de soporte.

```mermaid
graph TD
    A[Líder detecta falla] --> B[Crea OT en Estación]
    B --> C[Notificación a Técnicos]
    C --> D[Técnico llega a Estación y escanea QR]
    D --> E[Sistema registra Arribo QR]
    E --> G[Técnico diagnostica el Equipo de esa Estación]
    G --> F[Sistema muestra Fallas/Soluciones Comunes del Tipo de Equipo y Recursos]
    F --> H[Técnico aplica solución, toma fotos y usa refacciones]
    H --> I[Técnico cierra OT]
    I --> J[Cálculo automático de KPIs: MTTR, MTBF]
```

---

## 2. Diagrama de Entidad-Relación (Mermaid)

El siguiente modelo lógico-relacional cumple con las especificaciones de escalabilidad, normalización y soporte multi-técnico para las órdenes de trabajo.

```mermaid
erDiagram
    CatAreas ||--o{ CatLineas : "tiene"
    CatLineas ||--o{ CatEstaciones : "contiene"
    CatEstaciones ||--o{ CatEquipos : "contiene"
    CatTiposEquipo ||--o{ CatEquipos : "clasifica"
    CatTiposEquipo ||--o{ CatFallasComunes : "tiene"
    CatFallasComunes ||--o{ CatSolucionesComunes : "resuelve"
    CatTiposEquipo ||--o{ RecursosSoporte : "tiene"

    CatRoles ||--o{ CatUsuarios : "asigna"
    CatAreas ||--o{ CatUsuarios : "pertenece"
    CatTurnos ||--o{ CatUsuarios : "asigna"

    CatEstadosOT ||--o{ OrdenesTrabajo : "clasifica"
    CatEstaciones ||--o{ OrdenesTrabajo : "ocurre_en"
    CatEquipos ||--o{ OrdenesTrabajo : "afecta"
    CatUsuarios ||--o{ OrdenesTrabajo : "reportada_por"
    CatTurnos ||--o{ OrdenesTrabajo : "ocurre_en_turno"

    OrdenesTrabajo ||--o{ DetalleTecnicosOT : "atendida_por"
    CatUsuarios ||--o{ DetalleTecnicosOT : "ejecuta"

    OrdenesTrabajo ||--o{ BitacoraEstadosOT : "registra"
    CatUsuarios ||--o{ BitacoraEstadosOT : "cambiado_por"

    OrdenesTrabajo ||--o{ EvidenciasOT : "tiene"
    CatUsuarios ||--o{ EvidenciasOT : "subida_por"

    OrdenesTrabajo ||--o{ MaterialesOT : "utiliza"
    CatMateriales ||--o{ MaterialesOT : "es_usado"
```

---

## 3. Diccionario de Datos

Cada tabla del sistema cuenta de forma obligatoria con los campos de auditoría y control de estado físico:
*   `activo BIT DEFAULT 1`: Permite inhabilitar lógicamente registros sin romper la integridad referencial histórica.
*   `fecharegistro DATETIME DEFAULT GETDATE()`: Registra la fecha y hora exacta del sistema SQL Server al insertar el registro.

### Tablas de Estructura Organizacional y Activos

#### 1. `CatTurnos`
Almacena los turnos de operación de la planta.
*   `ID` (INT, PK, Identity)
*   `Nombre` (VARCHAR(50)): Turno 1, Turno 2, Turno Nocturno, etc.
*   `HoraInicio` (TIME)
*   `HoraFin` (TIME)

#### 2. `CatAreas`
Almacena las áreas de la planta de producción.
*   `ID` (INT, PK, Identity)
*   `Nombre` (VARCHAR(100)): SMT, Ensamble Final, Inyección de Plásticos, etc.
*   `Descripcion` (VARCHAR(250))

#### 3. `CatLineas`
Líneas de producción dentro de un área.
*   `ID` (INT, PK, Identity)
*   `AreaID` (INT, FK -> CatAreas.ID)
*   `Nombre` (VARCHAR(100)): Línea A, Línea B, etc.

#### 4. `CatEstaciones`
Estaciones que componen cada línea de producción.
*   `ID` (INT, PK, Identity)
*   `LineaID` (INT, FK -> CatLineas.ID)
*   `Nombre` (VARCHAR(100)): Estación de Atornillado, Celda de Soldadura, Inspección Visual, etc.
*   `CodigoQR` (VARCHAR(150), Unique): Identificador único codificado en la etiqueta QR de la estación.

#### 5. `CatTiposEquipo`
Agrupaciones genéricas de equipos con fallas y soluciones comunes similares.
*   `ID` (INT, PK, Identity)
*   `Nombre` (VARCHAR(100)): Robot Atornillador, Computadora Industrial, PLC Allen Bradley, Atornillador Neumático, etc.
*   `Descripcion` (VARCHAR(250))

#### 6. `CatEquipos`
Equipos físicos individuales ubicados en las estaciones de trabajo.
*   `ID` (INT, PK, Identity)
*   `EstacionID` (INT, FK -> CatEstaciones.ID)
*   `TipoEquipoID` (INT, FK -> CatTiposEquipo.ID)
*   `Nombre` (VARCHAR(100)): Robot Atornillador Deprag 1, PC Dell Optiplex Linea A, etc.
*   `Modelo` (VARCHAR(100))
*   `NumeroSerie` (VARCHAR(100))

---

### Tablas de Personal y Seguridad

#### 7. `CatRoles`
Roles de sistema.
*   `ID` (INT, PK, Identity)
*   `Nombre` (VARCHAR(50)): Lider de Linea, Tecnico, Ingeniero, Administrador.
*   `Descripcion` (VARCHAR(250))

#### 8. `CatUsuarios`
Personal operativo y administrativo.
*   `ID` (INT, PK, Identity)
*   `NoEmpleado` (VARCHAR(20), Unique)
*   `Nombre` (VARCHAR(150))
*   `Correo` (VARCHAR(100))
*   `RolID` (INT, FK -> CatRoles.ID)
*   `AreaID` (INT, FK -> CatAreas.ID)
*   `TurnoID` (INT, FK -> CatTurnos.ID)

---

### Tablas de Modos de Falla, Soluciones y Recursos

#### 9. `CatFallasComunes`
Catálogo de modos de falla por tipo de equipo.
*   `ID` (INT, PK, Identity)
*   `TipoEquipoID` (INT, FK -> CatTiposEquipo.ID)
*   `CodigoFalla` (VARCHAR(20), Unique): Ej. FAL-001, FAL-002.
*   `Nombre` (VARCHAR(150)): Ej. "Falta de Torque", "Pantalla Azul OS", "Pérdida de Comunicación".
*   `Descripcion` (VARCHAR(500))

#### 10. `CatSolucionesComunes`
Acciones correctivas comunes asociadas a una falla.
*   `ID` (INT, PK, Identity)
*   `FallaComunID` (INT, FK -> CatFallasComunes.ID)
*   `Nombre` (VARCHAR(150)): Ej. "Recalibración de Transductor", "Reinicio de Servicio OS", "Reemplazo de Cable RJ45".
*   `Descripcion` (VARCHAR(500))

#### 11. `RecursosSoporte`
Rutas físicas (UNC o URL) de manuales, videos y tutoriales asociados a tipos de equipo o fallas específicas.
*   `ID` (INT, PK, Identity)
*   `TipoEquipoID` (INT, FK -> CatTiposEquipo.ID)
*   `FallaComunID` (INT, FK -> CatFallasComunes.ID, Nullable): Si es nulo, aplica al equipo en general.
*   `Nombre` (VARCHAR(150))
*   `TipoRecurso` (VARCHAR(50)): MANUAL, TUTORIAL, VIDEO, IMAGEN.
*   `PathArchivo` (VARCHAR(500)): Ruta UNC en el servidor de archivos (Ej: `\\file-server\cmms\manuals\deprag_calibration.pdf`).

---

### Tablas de Órdenes de Trabajo y Transacciones

#### 12. `CatEstadosOT`
Catálogo de estados de una Orden de Trabajo.
*   `ID` (INT, PK, Identity)
*   `Nombre` (VARCHAR(50)): Creada, En Proceso, Pausada, Sin Solución, Cancelada, Completada, Deshabilitada.
*   `Descripcion` (VARCHAR(250))

#### 13. `OrdenesTrabajo`
Encabezado de la Orden de Trabajo. El líder la abre a nivel de estación; el técnico la diagnostica a nivel de equipo.
*   `ID` (INT, PK, Identity)
*   `EstacionID` (INT, FK -> CatEstaciones.ID)
*   `EquipoID` (INT, FK -> CatEquipos.ID, Nullable): Inicialmente NULL. El técnico lo define al escanear y diagnosticar cuál equipo falló.
*   `EstadoID` (INT, FK -> CatEstadosOT.ID)
*   `LiderReportaID` (INT, FK -> CatUsuarios.ID)
*   `TurnoID` (INT, FK -> CatTurnos.ID): Turno en el que se reporta el incidente.
*   `DescripcionFalla` (VARCHAR(1000)): Descripción abierta del problema provista por el líder.
*   `FechaReporte` (DATETIME): Fecha y hora del reporte inicial del líder.

#### 14. `DetalleTecnicosOT`
Maneja la relación de uno a muchos técnicos asignados o autodeclarados para atender una orden de trabajo.
Permite medir los tiempos específicos de cada técnico.
*   `ID` (INT, PK, Identity)
*   `OrdenTrabajoID` (INT, FK -> OrdenesTrabajo.ID)
*   `TecnicoID` (INT, FK -> CatUsuarios.ID)
*   `FechaAsignacion` (DATETIME): Hora en la que se le asigna el trabajo.
*   `FechaArriboQR` (DATETIME, Nullable): Fecha y hora exacta en la que el técnico escaneó el código QR físicamente en la estación.
*   `FechaFinActividad` (DATETIME, Nullable): Fecha y hora en la que el técnico concluye sus labores individuales en la OT.

#### 15. `BitacoraEstadosOT`
Historial de auditoría para rastrear quién cambió los estados de la orden y calcular el tiempo neto de paros (por ejemplo, descontando el tiempo en estado "Pausada").
*   `ID` (INT, PK, Identity)
*   `OrdenTrabajoID` (INT, FK -> OrdenesTrabajo.ID)
*   `EstadoAnteriorID` (INT, FK -> CatEstadosOT.ID, Nullable)
*   `EstadoNuevoID` (INT, FK -> CatEstadosOT.ID)
*   `UsuarioID` (INT, FK -> CatUsuarios.ID): Usuario que realiza la acción.
*   `FechaCambio` (DATETIME): Registrará `GETDATE()`.
*   `Comentario` (VARCHAR(500)): Motivo del cambio (por ejemplo, justificación de una pausa por falta de refacción).

#### 16. `EvidenciasOT`
Almacena las rutas de fotos tomadas por los técnicos (Falla / Solución).
*   `ID` (INT, PK, Identity)
*   `OrdenTrabajoID` (INT, FK -> OrdenesTrabajo.ID)
*   `UsuarioID` (INT, FK -> CatUsuarios.ID)
*   `TipoEvidencia` (VARCHAR(20)): FALLA, SOLUCION.
*   `PathArchivo` (VARCHAR(500)): Ruta física del archivo guardado en el servidor.

---

### Tablas de Inventario y Refacciones

#### 17. `CatMateriales`
Catálogo maestro de materiales e insumos de mantenimiento.
*   `ID` (INT, PK, Identity)
*   `NumeroParte` (VARCHAR(100), Unique)
*   `Nombre` (VARCHAR(150))
*   `Stock` (DECIMAL(18,2))
*   `UnidadMedida` (VARCHAR(20)): Pza, Metro, Litro, etc.

#### 18. `MaterialesOT`
Registro de materiales utilizados en la resolución de una orden de trabajo.
*   `ID` (INT, PK, Identity)
*   `OrdenTrabajoID` (INT, FK -> OrdenesTrabajo.ID)
*   `MaterialID` (INT, FK -> CatMateriales.ID)
*   `Cantidad` (DECIMAL(18,2))
*   `UsuarioID` (INT, FK -> CatUsuarios.ID): Técnico que registró el uso del material.

---

## 4. Script DDL para SQL Server 2017 (14.0)

Este script crea toda la estructura de la base de datos de manera secuencial, configurando llaves primarias, foráneas, restricciones de unicidad, y campos por defecto.

```sql
-- =========================================================================
-- SCRIPT DE CREACION DE BASE DE DATOS CMMS
-- SQL Server 2017 (14.0)
-- =========================================================================

CREATE DATABASE CMMS_Db;
GO

USE CMMS_Db;
GO

-- 1. CatTurnos
CREATE TABLE CatTurnos (
    ID INT IDENTITY(1,1) NOT NULL,
    Nombre VARCHAR(50) NOT NULL,
    HoraInicio TIME NOT NULL,
    HoraFin TIME NOT NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatTurnos_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatTurnos_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatTurnos PRIMARY KEY CLUSTERED (ID)
);

-- 2. CatAreas
CREATE TABLE CatAreas (
    ID INT IDENTITY(1,1) NOT NULL,
    Nombre VARCHAR(100) NOT NULL,
    Descripcion VARCHAR(250) NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatAreas_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatAreas_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatAreas PRIMARY KEY CLUSTERED (ID)
);

-- 3. CatLineas
CREATE TABLE CatLineas (
    ID INT IDENTITY(1,1) NOT NULL,
    AreaID INT NOT NULL,
    Nombre VARCHAR(100) NOT NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatLineas_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatLineas_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatLineas PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_CatLineas_CatAreas FOREIGN KEY (AreaID) REFERENCES CatAreas(ID)
);

-- 4. CatEstaciones
CREATE TABLE CatEstaciones (
    ID INT IDENTITY(1,1) NOT NULL,
    LineaID INT NOT NULL,
    Nombre VARCHAR(100) NOT NULL,
    CodigoQR VARCHAR(150) NOT NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatEstaciones_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatEstaciones_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatEstaciones PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT UQ_CatEstaciones_CodigoQR UNIQUE (CodigoQR),
    CONSTRAINT FK_CatEstaciones_CatLineas FOREIGN KEY (LineaID) REFERENCES CatLineas(ID)
);

-- 5. CatTiposEquipo
CREATE TABLE CatTiposEquipo (
    ID INT IDENTITY(1,1) NOT NULL,
    Nombre VARCHAR(100) NOT NULL,
    Descripcion VARCHAR(250) NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatTiposEquipo_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatTiposEquipo_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatTiposEquipo PRIMARY KEY CLUSTERED (ID)
);

-- 6. CatEquipos
CREATE TABLE CatEquipos (
    ID INT IDENTITY(1,1) NOT NULL,
    EstacionID INT NOT NULL,
    TipoEquipoID INT NOT NULL,
    Nombre VARCHAR(100) NOT NULL,
    Modelo VARCHAR(100) NULL,
    NumeroSerie VARCHAR(100) NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatEquipos_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatEquipos_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatEquipos PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_CatEquipos_CatEstaciones FOREIGN KEY (EstacionID) REFERENCES CatEstaciones(ID),
    CONSTRAINT FK_CatEquipos_CatTiposEquipo FOREIGN KEY (TipoEquipoID) REFERENCES CatTiposEquipo(ID)
);

-- 7. CatRoles
CREATE TABLE CatRoles (
    ID INT IDENTITY(1,1) NOT NULL,
    Nombre VARCHAR(50) NOT NULL,
    Descripcion VARCHAR(250) NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatRoles_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatRoles_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatRoles PRIMARY KEY CLUSTERED (ID)
);

-- 8. CatUsuarios
CREATE TABLE CatUsuarios (
    ID INT IDENTITY(1,1) NOT NULL,
    NoEmpleado VARCHAR(20) NOT NULL,
    Nombre VARCHAR(150) NOT NULL,
    Correo VARCHAR(100) NULL,
    RolID INT NOT NULL,
    AreaID INT NOT NULL,
    TurnoID INT NOT NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatUsuarios_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatUsuarios_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatUsuarios PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT UQ_CatUsuarios_NoEmpleado UNIQUE (NoEmpleado),
    CONSTRAINT FK_CatUsuarios_CatRoles FOREIGN KEY (RolID) REFERENCES CatRoles(ID),
    CONSTRAINT FK_CatUsuarios_CatAreas FOREIGN KEY (AreaID) REFERENCES CatAreas(ID),
    CONSTRAINT FK_CatUsuarios_CatTurnos FOREIGN KEY (TurnoID) REFERENCES CatTurnos(ID)
);

-- 9. CatFallasComunes
CREATE TABLE CatFallasComunes (
    ID INT IDENTITY(1,1) NOT NULL,
    TipoEquipoID INT NOT NULL,
    CodigoFalla VARCHAR(20) NOT NULL,
    Nombre VARCHAR(150) NOT NULL,
    Descripcion VARCHAR(500) NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatFallasComunes_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatFallasComunes_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatFallasComunes PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT UQ_CatFallasComunes_CodigoFalla UNIQUE (CodigoFalla),
    CONSTRAINT FK_CatFallasComunes_CatTiposEquipo FOREIGN KEY (TipoEquipoID) REFERENCES CatTiposEquipo(ID)
);

-- 10. CatSolucionesComunes
CREATE TABLE CatSolucionesComunes (
    ID INT IDENTITY(1,1) NOT NULL,
    FallaComunID INT NOT NULL,
    Nombre VARCHAR(150) NOT NULL,
    Descripcion VARCHAR(500) NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatSolucionesComunes_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatSolucionesComunes_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatSolucionesComunes PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_CatSolucionesComunes_CatFallasComunes FOREIGN KEY (FallaComunID) REFERENCES CatFallasComunes(ID)
);

-- 11. RecursosSoporte
CREATE TABLE RecursosSoporte (
    ID INT IDENTITY(1,1) NOT NULL,
    TipoEquipoID INT NOT NULL,
    FallaComunID INT NULL,
    Nombre VARCHAR(150) NOT NULL,
    TipoRecurso VARCHAR(50) NOT NULL, -- MANUAL, TUTORIAL, VIDEO, IMAGEN
    PathArchivo VARCHAR(500) NOT NULL, -- Ruta lógica o UNC al servidor de archivos
    activo BIT NOT NULL CONSTRAINT DF_RecursosSoporte_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_RecursosSoporte_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_RecursosSoporte PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_RecursosSoporte_CatTiposEquipo FOREIGN KEY (TipoEquipoID) REFERENCES CatTiposEquipo(ID),
    CONSTRAINT FK_RecursosSoporte_CatFallasComunes FOREIGN KEY (FallaComunID) REFERENCES CatFallasComunes(ID)
);

-- 12. CatEstadosOT
CREATE TABLE CatEstadosOT (
    ID INT IDENTITY(1,1) NOT NULL,
    Nombre VARCHAR(50) NOT NULL,
    Descripcion VARCHAR(250) NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatEstadosOT_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatEstadosOT_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatEstadosOT PRIMARY KEY CLUSTERED (ID)
);

-- 13. OrdenesTrabajo
CREATE TABLE OrdenesTrabajo (
    ID INT IDENTITY(1,1) NOT NULL,
    EstacionID INT NOT NULL,
    EquipoID INT NULL, -- NULL cuando el Líder reporta a nivel de estación; se actualiza en diagnóstico
    EstadoID INT NOT NULL,
    LiderReportaID INT NOT NULL,
    TurnoID INT NOT NULL,
    DescripcionFalla VARCHAR(1000) NOT NULL,
    FechaReporte DATETIME NOT NULL CONSTRAINT DF_OrdenesTrabajo_FechaReporte DEFAULT GETDATE(),
    activo BIT NOT NULL CONSTRAINT DF_OrdenesTrabajo_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_OrdenesTrabajo_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_OrdenesTrabajo PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_OrdenesTrabajo_CatEstaciones FOREIGN KEY (EstacionID) REFERENCES CatEstaciones(ID),
    CONSTRAINT FK_OrdenesTrabajo_CatEquipos FOREIGN KEY (EquipoID) REFERENCES CatEquipos(ID),
    CONSTRAINT FK_OrdenesTrabajo_CatEstadosOT FOREIGN KEY (EstadoID) REFERENCES CatEstadosOT(ID),
    CONSTRAINT FK_OrdenesTrabajo_CatUsuarios FOREIGN KEY (LiderReportaID) REFERENCES CatUsuarios(ID),
    CONSTRAINT FK_OrdenesTrabajo_CatTurnos FOREIGN KEY (TurnoID) REFERENCES CatTurnos(ID)
);

-- 14. DetalleTecnicosOT
CREATE TABLE DetalleTecnicosOT (
    ID INT IDENTITY(1,1) NOT NULL,
    OrdenTrabajoID INT NOT NULL,
    TecnicoID INT NOT NULL,
    FechaAsignacion DATETIME NOT NULL CONSTRAINT DF_DetalleTecnicosOT_FechaAsignacion DEFAULT GETDATE(),
    FechaArriboQR DATETIME NULL, -- Registrado cuando escanea el QR en sitio
    FechaFinActividad DATETIME NULL, -- Termina su participación
    activo BIT NOT NULL CONSTRAINT DF_DetalleTecnicosOT_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_DetalleTecnicosOT_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_DetalleTecnicosOT PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_DetalleTecnicosOT_OrdenesTrabajo FOREIGN KEY (OrdenTrabajoID) REFERENCES OrdenesTrabajo(ID),
    CONSTRAINT FK_DetalleTecnicosOT_CatUsuarios FOREIGN KEY (TecnicoID) REFERENCES CatUsuarios(ID)
);

-- 15. BitacoraEstadosOT
CREATE TABLE BitacoraEstadosOT (
    ID INT IDENTITY(1,1) NOT NULL,
    OrdenTrabajoID INT NOT NULL,
    EstadoAnteriorID INT NULL,
    EstadoNuevoID INT NOT NULL,
    UsuarioID INT NOT NULL,
    FechaCambio DATETIME NOT NULL CONSTRAINT DF_BitacoraEstadosOT_FechaCambio DEFAULT GETDATE(),
    Comentario VARCHAR(500) NULL,
    activo BIT NOT NULL CONSTRAINT DF_BitacoraEstadosOT_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_BitacoraEstadosOT_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_BitacoraEstadosOT PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_BitacoraEstadosOT_OrdenesTrabajo FOREIGN KEY (OrdenTrabajoID) REFERENCES OrdenesTrabajo(ID),
    CONSTRAINT FK_BitacoraEstadosOT_CatEstadosOT_Ant FOREIGN KEY (EstadoAnteriorID) REFERENCES CatEstadosOT(ID),
    CONSTRAINT FK_BitacoraEstadosOT_CatEstadosOT_Nvo FOREIGN KEY (EstadoNuevoID) REFERENCES CatEstadosOT(ID),
    CONSTRAINT FK_BitacoraEstadosOT_CatUsuarios FOREIGN KEY (UsuarioID) REFERENCES CatUsuarios(ID)
);

-- 16. EvidenciasOT
CREATE TABLE EvidenciasOT (
    ID INT IDENTITY(1,1) NOT NULL,
    OrdenTrabajoID INT NOT NULL,
    UsuarioID INT NOT NULL,
    TipoEvidencia VARCHAR(20) NOT NULL, -- FALLA, SOLUCION
    PathArchivo VARCHAR(500) NOT NULL, -- Ej: \\servidor\evidencias\ot_105_falla.jpg
    activo BIT NOT NULL CONSTRAINT DF_EvidenciasOT_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_EvidenciasOT_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_EvidenciasOT PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_EvidenciasOT_OrdenesTrabajo FOREIGN KEY (OrdenTrabajoID) REFERENCES OrdenesTrabajo(ID),
    CONSTRAINT FK_EvidenciasOT_CatUsuarios FOREIGN KEY (UsuarioID) REFERENCES CatUsuarios(ID),
    CONSTRAINT CK_EvidenciasOT_Tipo CHECK (TipoEvidencia IN ('FALLA', 'SOLUCION'))
);

-- 17. CatMateriales
CREATE TABLE CatMateriales (
    ID INT IDENTITY(1,1) NOT NULL,
    NumeroParte VARCHAR(100) NOT NULL,
    Nombre VARCHAR(150) NOT NULL,
    Stock DECIMAL(18,2) NOT NULL CONSTRAINT DF_CatMateriales_Stock DEFAULT 0,
    UnidadMedida VARCHAR(20) NOT NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatMateriales_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatMateriales_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_CatMateriales PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT UQ_CatMateriales_NumeroParte UNIQUE (NumeroParte)
);

-- 18. MaterialesOT
CREATE TABLE MaterialesOT (
    ID INT IDENTITY(1,1) NOT NULL,
    OrdenTrabajoID INT NOT NULL,
    MaterialID INT NOT NULL,
    Cantidad DECIMAL(18,2) NOT NULL,
    UsuarioID INT NOT NULL,
    activo BIT NOT NULL CONSTRAINT DF_CatMaterialesOT_activo DEFAULT 1,
    fecharegistro DATETIME NOT NULL CONSTRAINT DF_CatMaterialesOT_fecharegistro DEFAULT GETDATE(),
    CONSTRAINT PK_MaterialesOT PRIMARY KEY CLUSTERED (ID),
    CONSTRAINT FK_MaterialesOT_OrdenesTrabajo FOREIGN KEY (OrdenTrabajoID) REFERENCES OrdenesTrabajo(ID),
    CONSTRAINT FK_MaterialesOT_CatMateriales FOREIGN KEY (MaterialID) REFERENCES CatMateriales(ID),
    CONSTRAINT FK_MaterialesOT_CatUsuarios FOREIGN KEY (UsuarioID) REFERENCES CatUsuarios(ID)
);
GO

-- =========================================================================
-- INDICES PARA OPTIMIZAR EL RENDIMIENTO (Escalabilidad)
-- =========================================================================

-- Busquedas rapidas de la estacion por escaneo de QR
CREATE UNIQUE NONCLUSTERED INDEX IX_CatEstaciones_CodigoQR 
ON CatEstaciones (CodigoQR) 
WHERE activo = 1;

-- Listar equipos asociados a una estacion de forma instantanea
CREATE NONCLUSTERED INDEX IX_CatEquipos_EstacionID 
ON CatEquipos (EstacionID) 
WHERE activo = 1;

-- Busqueda rapida de usuarios por NoEmpleado en el login o escaneo
CREATE UNIQUE NONCLUSTERED INDEX IX_CatUsuarios_NoEmpleado 
ON CatUsuarios (NoEmpleado) 
WHERE activo = 1;

-- Desempeño al listar OTs activas por estado
CREATE NONCLUSTERED INDEX IX_OrdenesTrabajo_EstadoID_FechaReporte 
ON OrdenesTrabajo (EstadoID, FechaReporte) 
INCLUDE (EstacionID, EquipoID);

-- Control de tiempos en el flujo de trabajo
CREATE NONCLUSTERED INDEX IX_DetalleTecnicosOT_OrdenTrabajoID 
ON DetalleTecnicosOT (OrdenTrabajoID) 
INCLUDE (TecnicoID, FechaArriboQR, FechaFinActividad);
GO
```

---

## 5. Procedimientos Almacenados (Transacciones Clave)

Para garantizar consistencia en la base de datos y facilitar el desarrollo de la API o capa de negocio, se proponen los siguientes Stored Procedures escritos bajo estándares de SQL Server 2017.

### A. Apertura de Orden de Trabajo (Líder de Línea)
Crea una OT a nivel de Estación, define el turno correspondiente y registra la bitácora de estados en una sola transacción segura.

```sql
CREATE PROCEDURE sp_OT_Crear
    @EstacionID INT,
    @LiderID INT,
    @DescripcionFalla VARCHAR(1000)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @EstadoCreadaID INT;
        DECLARE @TurnoID INT;
        DECLARE @HoraActual TIME = CONVERT(TIME, GETDATE());

        -- Obtener ID del estado 'Creada'
        SELECT TOP 1 @EstadoCreadaID = ID FROM CatEstadosOT WHERE Nombre = 'Creada' AND activo = 1;

        -- Determinar el Turno en base a la hora actual
        SELECT TOP 1 @TurnoID = ID 
        FROM CatTurnos 
        WHERE activo = 1 
          AND (
            (@HoraInicio <= @HoraFin AND @HoraActual BETWEEN HoraInicio AND HoraFin) OR
            (@HoraInicio > @HoraFin AND (@HoraActual >= HoraInicio OR @HoraActual <= HoraFin))
          );

        -- Si no se encuentra turno por hora, asignar el turno del líder
        IF @TurnoID IS NULL
            SELECT @TurnoID = TurnoID FROM CatUsuarios WHERE ID = @LiderID;

        -- Insertar Orden de Trabajo
        DECLARE @NuevaOTID INT;
        INSERT INTO OrdenesTrabajo (EstacionID, EstadoID, LiderReportaID, TurnoID, DescripcionFalla, FechaReporte)
        VALUES (@EstacionID, @EstadoCreadaID, @LiderID, @TurnoID, @DescripcionFalla, GETDATE());

        SET @NuevaOTID = SCOPE_IDENTITY();

        -- Insertar Registro de Bitacora
        INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, Comentario)
        VALUES (@NuevaOTID, NULL, @EstadoCreadaID, @LiderID, 'Orden de trabajo inicial creada por el líder de línea.');

        COMMIT TRANSACTION;
        
        -- Retornar el ID generado
        SELECT @NuevaOTID AS OrdenTrabajoID;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH;
END;
GO
```

### B. Arribo del Técnico y Escaneo QR
Registra cuando el técnico llega a la estación físicamente y escanea el QR. Cambia la OT a "En Proceso" (si era su estado inicial) y marca su hora de arribo para el cálculo de respuesta.

```sql
CREATE PROCEDURE sp_OT_RegistrarArriboQR
    @OrdenTrabajoID INT,
    @TecnicoID INT,
    @CodigoQR VARCHAR(150)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        -- Verificar que el QR corresponda a la estación de la OT
        IF NOT EXISTS (
            SELECT 1 
            FROM OrdenesTrabajo ot
            INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
            WHERE ot.ID = @OrdenTrabajoID AND est.CodigoQR = @CodigoQR AND ot.activo = 1
        )
        BEGIN
            THROW 50001, 'El código QR escaneado no corresponde a la estación de esta orden de trabajo.', 1;
        END

        DECLARE @EstadoEnProcesoID INT;
        DECLARE @EstadoActualID INT;
        SELECT TOP 1 @EstadoEnProcesoID = ID FROM CatEstadosOT WHERE Nombre = 'En Proceso' AND activo = 1;
        SELECT @EstadoActualID = EstadoID FROM OrdenesTrabajo WHERE ID = @OrdenTrabajoID;

        -- Si el estado actual es 'Creada', actualizar la OT a 'En Proceso'
        IF EXISTS (SELECT 1 FROM CatEstadosOT WHERE ID = @EstadoActualID AND Nombre = 'Creada')
        BEGIN
            UPDATE OrdenesTrabajo
            SET EstadoID = @EstadoEnProcesoID
            WHERE ID = @OrdenTrabajoID;

            -- Registrar cambio en Bitacora
            INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, Comentario)
            VALUES (@OrdenTrabajoID, @EstadoActualID, @EstadoEnProcesoID, @TecnicoID, 'Arribo de técnico. Estado cambiado a En Proceso.');
        END

        -- Insertar o actualizar el arribo en la tabla de asignación de técnicos
        IF EXISTS (SELECT 1 FROM DetalleTecnicosOT WHERE OrdenTrabajoID = @OrdenTrabajoID AND TecnicoID = @TecnicoID AND activo = 1)
        BEGIN
            UPDATE DetalleTecnicosOT
            SET FechaArriboQR = GETDATE()
            WHERE OrdenTrabajoID = @OrdenTrabajoID AND TecnicoID = @TecnicoID AND activo = 1;
        END
        ELSE
        BEGIN
            INSERT INTO DetalleTecnicosOT (OrdenTrabajoID, TecnicoID, FechaAsignacion, FechaArriboQR)
            VALUES (@OrdenTrabajoID, @TecnicoID, GETDATE(), GETDATE());
        END

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH;
END;
GO
```

### C. Cierre de Orden de Trabajo
Finaliza la OT, asociando el equipo específico que el técnico determinó que falló, y registra los tiempos de fin para el técnico.

```sql
CREATE PROCEDURE sp_OT_Completar
    @OrdenTrabajoID INT,
    @EquipoID INT, -- Equipo específico diagnosticado
    @TecnicoID INT,
    @ComentariosSolucion VARCHAR(500)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @EstadoCompletadaID INT;
        DECLARE @EstadoActualID INT;
        
        SELECT TOP 1 @EstadoCompletadaID = ID FROM CatEstadosOT WHERE Nombre = 'Completada' AND activo = 1;
        SELECT @EstadoActualID = EstadoID FROM OrdenesTrabajo WHERE ID = @OrdenTrabajoID;

        -- 1. Actualizar orden principal
        UPDATE OrdenesTrabajo
        SET EstadoID = @EstadoCompletadaID,
            EquipoID = @EquipoID
        WHERE ID = @OrdenTrabajoID;

        -- 2. Actualizar el tiempo del técnico firmante
        UPDATE DetalleTecnicosOT
        SET FechaFinActividad = GETDATE()
        WHERE OrdenTrabajoID = @OrdenTrabajoID AND TecnicoID = @TecnicoID AND activo = 1;

        -- 3. Bitácora de Auditoría
        INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, Comentario)
        VALUES (@OrdenTrabajoID, @EstadoActualID, @EstadoCompletadaID, @TecnicoID, @ComentariosSolucion);

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH;
END;
GO
```

---

## 6. Consulta de Soporte al Técnico (Tablet QR Flow)

Cuando un técnico escanea el código QR de una estación, el software debe buscar qué equipos están en esa estación y traer sus **fallas comunes**, **soluciones comunes** y **recursos de soporte** estructurados.

```sql
-- Ejemplo de consulta para el despliegue del menú de soporte en la Tablet del técnico
-- @CodigoQR = Codigo leido por la camara de la tablet

SELECT 
    est.Nombre AS EstacionNombre,
    eq.ID AS EquipoID,
    eq.Nombre AS EquipoNombre,
    teq.Nombre AS TipoEquipoNombre,
    fc.CodigoFalla,
    fc.Nombre AS FallaComunNombre,
    sc.Nombre AS SolucionSugerida,
    rs.Nombre AS RecursoNombre,
    rs.TipoRecurso,
    rs.PathArchivo AS PathRecurso
FROM CatEstaciones est
INNER JOIN CatEquipos eq ON eq.EstacionID = est.ID AND eq.activo = 1
INNER JOIN CatTiposEquipo teq ON eq.TipoEquipoID = teq.ID AND teq.activo = 1
LEFT JOIN CatFallasComunes fc ON fc.TipoEquipoID = teq.ID AND fc.activo = 1
LEFT JOIN CatSolucionesComunes sc ON sc.FallaComunID = fc.ID AND sc.activo = 1
LEFT JOIN RecursosSoporte rs ON rs.TipoEquipoID = teq.ID 
                            AND (rs.FallaComunID = fc.ID OR rs.FallaComunID IS NULL) 
                            AND rs.activo = 1
WHERE est.CodigoQR = 'EST-SMT-ATORNILLADO-01' -- Código QR Escaneado
  AND est.activo = 1
ORDER BY eq.Nombre, fc.CodigoFalla;
```

---

## 7. Métricas y KPIs de Tiempos (MTTR & MTBF)

Una parte crítica requerida por el equipo de ingeniería es evaluar el desempeño mediante análisis de tiempos en SQL Server.

### A. MTTR (Tiempo Medio para Reparar / Mean Time to Repair)
Calcula el tiempo promedio desde que el técnico **arriba físicamente a la estación (QR)** hasta que **concluye la actividad** (OT Completada).

$$MTTR = \frac{\sum (FechaFinActividad - FechaArriboQR)}{Número\ de\ Órdenes\ Completadas}$$

```sql
-- Consulta SQL para obtener el MTTR por Equipo en minutos
SELECT 
    eq.ID AS EquipoID,
    eq.Nombre AS EquipoNombre,
    COUNT(ot.ID) AS TotalFallasAtendidas,
    -- Promedio de la diferencia en minutos entre el escaneo QR y el fin de actividad
    AVG(DATEDIFF(MINUTE, dt.FechaArriboQR, dt.FechaFinActividad)) AS MTTR_Minutos
FROM OrdenesTrabajo ot
INNER JOIN CatEquipos eq ON ot.EquipoID = eq.ID
INNER JOIN DetalleTecnicosOT dt ON dt.OrdenTrabajoID = ot.ID AND dt.FechaArriboQR IS NOT NULL AND dt.FechaFinActividad IS NOT NULL
INNER JOIN CatEstadosOT est ON ot.EstadoID = est.ID
WHERE est.Nombre = 'Completada'
  AND ot.activo = 1
GROUP BY eq.ID, eq.Nombre;
```

### B. MTBF (Tiempo Medio Entre Fallas / Mean Time Between Failures)
Calcula el tiempo promedio operativo transcurrido entre fallas sucesivas de un equipo individual.

$$MTBF = \frac{Tiempo\ Operativo\ Total\ - Tiempo\ Total\ Inactivo}{Número\ de\ Fallas}$$

```sql
-- Consulta SQL para calcular el MTBF de los equipos (en días)
WITH HistoricoFallas AS (
    SELECT 
        EquipoID,
        FechaReporte,
        LAG(FechaReporte) OVER (PARTITION BY EquipoID ORDER BY FechaReporte ASC) AS FechaFallaAnterior
    FROM OrdenesTrabajo
    WHERE EquipoID IS NOT NULL 
      AND activo = 1
)
SELECT 
    eq.ID AS EquipoID,
    eq.Nombre AS EquipoNombre,
    COUNT(hf.FechaReporte) AS TotalFallas,
    -- Promedio de días transcurridos entre fallas consecutivas
    AVG(CONVERT(DECIMAL(10,2), DATEDIFF(HOUR, hf.FechaFallaAnterior, hf.FechaReporte)) / 24.0) AS MTBF_Dias
FROM HistoricoFallas hf
INNER JOIN CatEquipos eq ON hf.EquipoID = eq.ID
WHERE hf.FechaFallaAnterior IS NOT NULL
GROUP BY eq.ID, eq.Nombre;
```

### C. Tiempo de Respuesta del Técnico (Response Time)
Mide cuánto tarda el departamento de mantenimiento en acudir a la línea a partir del reporte del líder (FechaReporte vs FechaArriboQR).

```sql
SELECT 
    ot.ID AS OrdenTrabajoID,
    est.Nombre AS Estacion,
    ot.FechaReporte,
    MIN(dt.FechaArriboQR) AS PrimerArriboTecnico,
    -- Minutos transcurridos hasta la llegada del primer técnico
    DATEDIFF(MINUTE, ot.FechaReporte, MIN(dt.FechaArriboQR)) AS TiempoRespuestaMinutos
FROM OrdenesTrabajo ot
INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
INNER JOIN DetalleTecnicosOT dt ON dt.OrdenTrabajoID = ot.ID
WHERE dt.FechaArriboQR IS NOT NULL
  AND ot.activo = 1
GROUP BY ot.ID, est.Nombre, ot.FechaReporte;
```

---

## 8. Consideraciones de Escalabilidad para el Futuro
1. **Particionamiento Histórico**: Cuando la tabla `BitacoraEstadosOT` y `OrdenesTrabajo` superen el millón de registros, se sugiere realizar un particionamiento de tabla en SQL Server por rango de fechas (`FechaReporte`).
2. **Servidor de Archivos Desacoplado**: Las tablas `EvidenciasOT` y `RecursosSoporte` utilizan la ruta lógica física (`PathArchivo`). Esto previene el desbordamiento de la base de datos SQL Server y facilita migrar el backend en el futuro a servicios Cloud (ej. AWS S3, Azure Blob Storage) simplemente cambiando las rutas de red por URLs.
3. **Indexación**: Todos los índices clave se configuran como filtrados (`WHERE activo = 1`), lo cual reduce el tamaño físico de los índices no agrupados de SQL Server y acelera las consultas en tiempo de ejecución.

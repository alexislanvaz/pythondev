from flask import Blueprint, render_template, request, flash, redirect, url_for, current_app
from flask_login import login_required, current_user
from app.blueprints.db import run_query

lider_bp = Blueprint('lider', __name__, template_folder='templates')

import datetime

@lider_bp.route('/crear-ot', methods=['GET', 'POST'])
@login_required
def crear_orden_trabajo():
    if current_user.rol not in ['Lider de Linea', 'Administrador']:
        flash('Acceso denegado: Se requiere rol de Líder.', 'danger')
        return redirect(url_for('auth.login'))

    # flash('Modulo bajo desarrollo', 'danger')
    # return redirect(url_for('index'))

    if request.method == 'POST':
        estacion_id = request.form.get('estacion_id')
        sintoma_id = request.form.get('sintoma_id')
        clasificacion_id = request.form.get('clasificacion_id')
        causa_4m_id = request.form.get('causa_4m_id')
        impacto = request.form.get('impacto')
        empleados_afectados = request.form.get('empleados_afectados', '0')
        comentario = request.form.get('comentario_lider', '')
        
        # Nuevos campos
        turno_id = request.form.get('turno_id')
        hora_falla = request.form.get('hora_falla')

        try:
            estacion_id = int(estacion_id)
            sintoma_id = int(sintoma_id)
            clasificacion_id = int(clasificacion_id)
            causa_4m_id = int(causa_4m_id)
            empleados_afectados = int(empleados_afectados)

            # Armar fecha reporte si se especificó hora
            fecha_reporte = None
            if hora_falla:
                try:
                    h, m = map(int, hora_falla.split(':'))
                    fecha_reporte = datetime.datetime.now().replace(hour=h, minute=m, second=0, microsecond=0)
                    fecha_reporte = fecha_reporte.strftime("%Y-%m-%d %H:%M")
                except Exception:
                    pass

            turno_val = int(turno_id) if turno_id else None

            # Ejecutar Stored Procedure de creación de OT con 11 parámetros
            result = run_query("""
                EXEC sp_OT_Crear_Correctiva ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
            """, (
                estacion_id, current_user.id, sintoma_id, 
                clasificacion_id, causa_4m_id, impacto, 
                empleados_afectados, comentario, current_user.id,
                turno_val, fecha_reporte
            ), 'SP')
            
            if result:
                nueva_ot_id = result[0]['OrdenTrabajoID']
                current_app.logger.info(f"Líder {current_user.nombre} ha creado la OT #{nueva_ot_id} exitosamente.")
                flash(f'Orden de Trabajo #{nueva_ot_id} creada con éxito.', 'success')
            else:
                current_app.logger.info(f"Líder {current_user.nombre} ha creado una OT exitosamente.")
                flash('Orden de Trabajo creada correctamente.', 'success')
                
            return redirect(url_for('lider.crear_orden_trabajo'))
            
        except Exception as e:
            current_app.logger.error(f"Error al crear Orden de Trabajo por el Líder {current_user.nombre}: {str(e)}")
            flash(f'Error al crear la orden: {str(e)}', 'danger')

    # Obtener catálogos para los menús desplegables
    try:
        estaciones = run_query("SELECT ID, Nombre, LineaID FROM CatEstaciones WHERE activo = 1 ORDER BY Nombre")
        lineas = run_query("SELECT ID, Nombre FROM CatLineas WHERE activo = 1 ORDER BY Nombre")
        turnos = run_query("SELECT ID, Nombre FROM CatTurnos WHERE activo = 1 ORDER BY Nombre")
        sintomas = run_query("SELECT ID, Nombre FROM CatFallasComunes WHERE activo = 1 ORDER BY Nombre")
        clasificaciones = run_query("SELECT ID, Nombre, Causa4MsID FROM CatClasificacionesFallaLider WHERE activo = 1 ORDER BY Nombre")
        causas_4m = run_query("SELECT ID, Nombre FROM CatCausas4M WHERE activo = 1 ORDER BY Nombre")
    except Exception as e:
        current_app.logger.error(f"Error al cargar catálogos en formulario de OTs: {str(e)}")
        estaciones, lineas, turnos, sintomas, clasificaciones, causas_4m = [], [], [], [], [], []
        flash("Error al conectar con la base de datos de catálogos.", "danger")

    return render_template(
        'lider/crear_ot.html',
        estaciones=estaciones,
        lineas=lineas,
        turnos=turnos,
        sintomas=sintomas,
        clasificaciones=clasificaciones,
        causas_4m=causas_4m
    )

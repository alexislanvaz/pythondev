import os
from flask import Blueprint, request, jsonify, current_app
from flask_login import login_required, current_user
from app.blueprints.db import run_query
import pyodbc

api_bp = Blueprint('api', __name__, template_folder='templates')

@api_bp.route('/ot/arribo', methods=['POST'])
@login_required
def api_arribo_qr():
    data = request.get_json() or {}
    ot_id = data.get('ot_id')
    codigo_qr = data.get('codigo_qr')

    if not ot_id or not codigo_qr:
        return jsonify({"success": False, "error": "Parámetros insuficientes."}), 400

    try:
        # Ejecutar stored procedure de arribo QR
        run_query("EXEC sp_OT_RegistrarArriboQR ?, ?, ?", (ot_id, current_user.id, codigo_qr), 'SP')
        current_app.logger.info(f"Técnico {current_user.nombre} ha registrado su arribo en la OT #{ot_id} con QR '{codigo_qr}'.")
        return jsonify({"success": True, "message": "Arribo en sitio registrado exitosamente."})
    except pyodbc.Error as e:
        msg = e.args[1] if len(e.args) > 1 else str(e)
        current_app.logger.error(f"Error de base de datos en arribo QR para OT #{ot_id}: {msg}")
        return jsonify({"success": False, "error": msg}), 400
    except Exception as e:
        current_app.logger.error(f"Error inesperado en arribo QR para OT #{ot_id}: {str(e)}")
        return jsonify({"success": False, "error": str(e)}), 500

@api_bp.route('/ot/pausar', methods=['POST'])
@login_required
def api_pausar():
    data = request.get_json() or {}
    ot_id = data.get('ot_id')
    motivo_id = data.get('motivo_id')
    comentario = data.get('comentario', '')

    if not ot_id or not motivo_id:
        return jsonify({"success": False, "error": "Parámetros insuficientes."}), 400

    try:
        run_query("EXEC sp_OT_Pausar ?, ?, ?, ?", (ot_id, motivo_id, current_user.id, comentario), 'SP')
        current_app.logger.info(f"Técnico {current_user.nombre} ha pausado la OT #{ot_id} por motivo ID {motivo_id}.")
        return jsonify({"success": True, "message": "Orden de trabajo pausada correctamente."})
    except Exception as e:
        current_app.logger.error(f"Error al pausar la OT #{ot_id}: {str(e)}")
        return jsonify({"success": False, "error": str(e)}), 400

@api_bp.route('/ot/reanudar', methods=['POST'])
@login_required
def api_reanudar():
    data = request.get_json() or {}
    ot_id = data.get('ot_id')
    codigo_qr = data.get('codigo_qr', '')
    if isinstance(codigo_qr, str):
        codigo_qr = codigo_qr.strip()

    if not ot_id or not codigo_qr:
        return jsonify({"success": False, "error": "Parámetros insuficientes."}), 400

    try:
        # 1. Obtener la OT y los datos de su estación y equipo asignado
        ot_rows = run_query("""
            SELECT ot.EstacionID, est.Nombre AS EstacionNombre, est.CodigoQR AS EstacionQR,
                   ot.EquipoID, eq.Nombre AS EquipoNombre, eq.CodigoQR AS EquipoQR
            FROM OrdenesTrabajo ot
            INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
            LEFT JOIN CatEquipos eq ON ot.EquipoID = eq.ID
            WHERE ot.ID = ? AND ot.activo = 1
        """, (ot_id,), 'SELECT')

        if not ot_rows:
            return jsonify({"success": False, "error": "Orden de trabajo no encontrada."}), 404
        ot_info = ot_rows[0]

        # 2. Validar el QR escaneado
        # A. ¿Es el QR de la estación de la OT?
        is_valid = False
        if ot_info['EstacionQR'] and ot_info['EstacionQR'].strip().lower() == codigo_qr.lower():
            is_valid = True
        # B. ¿Es el QR del equipo asignado a la OT?
        elif ot_info['EquipoQR'] and ot_info['EquipoQR'].strip().lower() == codigo_qr.lower():
            is_valid = True
        # C. ¿Es el QR de cualquier otro equipo de esta estación?
        if not is_valid:
            eq_match = run_query("""
                SELECT 1 FROM CatEquipos
                WHERE CodigoQR = ? AND EstacionID = ? AND activo = 1
            """, (codigo_qr, ot_info['EstacionID']), 'SELECT')
            if eq_match:
                is_valid = True

        # Si el código QR escaneado no es válido para esta OT:
        if not is_valid:
            # Buscar si el QR pertenece a otro equipo o estación para dar un mensaje específico
            eq_anywhere = run_query("""
                SELECT e.Nombre, est.Nombre AS EstacionNombre
                FROM CatEquipos e
                INNER JOIN CatEstaciones est ON e.EstacionID = est.ID
                WHERE e.CodigoQR = ? AND e.activo = 1
            """, (codigo_qr,), 'SELECT')

            est_anywhere = run_query("""
                SELECT Nombre FROM CatEstaciones WHERE CodigoQR = ? AND activo = 1
            """, (codigo_qr,), 'SELECT')

            if eq_anywhere:
                info = eq_anywhere[0]
                return jsonify({
                    "success": False,
                    "error": f"QR Incorrecto. El equipo escaneado '{info['Nombre']}' pertenece a la estación '{info['EstacionNombre']}', "
                             f"pero esta orden de trabajo debe reanudarse con el código de la estación '{ot_info['EstacionNombre']}'."
                }), 400
            elif est_anywhere:
                info = est_anywhere[0]
                return jsonify({
                    "success": False,
                    "error": f"QR Incorrecto. Escaneó la estación '{info['Nombre']}', "
                             f"pero esta orden de trabajo está registrada en la estación '{ot_info['EstacionNombre']}'."
                }), 400
            else:
                return jsonify({
                    "success": False,
                    "error": f"QR Incorrecto. El código escaneado no corresponde a la estación '{ot_info['EstacionNombre']}' "
                             f"ni a ninguno de sus equipos."
                }), 400

        # 3. Invocar stored procedure
        run_query("EXEC sp_OT_Reanudar ?, ?, ?", (ot_id, current_user.id, codigo_qr), 'SP')
        current_app.logger.info(f"Técnico {current_user.nombre} ha reanudado la OT #{ot_id} con QR '{codigo_qr}'.")
        return jsonify({"success": True, "message": "Orden de trabajo reanudada."})
    except Exception as e:
        current_app.logger.error(f"Error al reanudar la OT #{ot_id}: {str(e)}")
        return jsonify({"success": False, "error": str(e)}), 400

@api_bp.route('/ot/transferir', methods=['POST'])
@login_required
def api_transferir():
    data = request.get_json() or {}
    ot_id = data.get('ot_id')
    tecnico_entrante_id = data.get('tecnico_entrante_id')
    comentario_handover = data.get('comentario_handover', '')

    if not ot_id or not tecnico_entrante_id:
        return jsonify({"success": False, "error": "Parámetros insuficientes."}), 400

    try:
        run_query("EXEC sp_OT_TransferirTurno ?, ?, ?, ?", 
                  (ot_id, current_user.id, tecnico_entrante_id, comentario_handover), 'SP')
        current_app.logger.info(f"Técnico {current_user.nombre} ha transferido la OT #{ot_id} al Técnico ID {tecnico_entrante_id}.")
        return jsonify({"success": True, "message": "Orden transferida correctamente."})
    except Exception as e:
        current_app.logger.error(f"Error en transferencia de turno para OT #{ot_id}: {str(e)}")
        return jsonify({"success": False, "error": str(e)}), 400

@api_bp.route('/ot/iniciar-soporte', methods=['POST'])
@login_required
def api_iniciar_soporte():
    data = request.get_json() or {}
    ot_id = data.get('ot_id')
    equipo_id = data.get('equipo_id')
    
    if not ot_id or not equipo_id:
        return jsonify({"success": False, "error": "Parámetros insuficientes."}), 400
        
    try:
        run_query("EXEC sp_OT_IniciarSoporte ?, ?, ?", (ot_id, current_user.id, equipo_id), 'SP')
        eq_details = run_query("SELECT ID, Nombre, Modelo, NumeroSerie FROM CatEquipos WHERE ID = ?", (equipo_id,), 'SELECT')
        eq_info = eq_details[0] if eq_details else {}
        return jsonify({"success": True, "message": "Soporte iniciado.", "equipo": eq_info})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400

@api_bp.route('/ot/qr-equipo', methods=['POST'])
@login_required
def api_qr_equipo():
    data = request.get_json() or {}
    ot_id = data.get('ot_id')
    codigo_qr = data.get('codigo_qr')
    if isinstance(codigo_qr, str):
        codigo_qr = codigo_qr.strip()
    
    if not ot_id or not codigo_qr:
        return jsonify({"success": False, "error": "Parámetros insuficientes."}), 400
        
    try:
        # 1. Obtener la estación de la Orden de Trabajo
        ot_rows = run_query("""
            SELECT ot.EstacionID, est.Nombre AS EstacionNombre 
            FROM OrdenesTrabajo ot
            INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
            WHERE ot.ID = ? AND ot.activo = 1
        """, (ot_id,), 'SELECT')
        
        if not ot_rows:
            return jsonify({"success": False, "error": "Orden de trabajo no encontrada."}), 404
        ot_info = ot_rows[0]
        
        # 2. Obtener el equipo escaneado
        eq_rows = run_query("""
            SELECT e.ID, e.Nombre, e.Modelo, e.NumeroSerie, e.EstacionID, est.Nombre AS EstacionNombre 
            FROM CatEquipos e
            INNER JOIN CatEstaciones est ON e.EstacionID = est.ID
            WHERE e.CodigoQR = ? AND e.activo = 1
        """, (codigo_qr,), 'SELECT')
        
        if not eq_rows:
            return jsonify({"success": False, "error": "El código QR escaneado no corresponde a ningún equipo registrado."}), 404
        equipo = eq_rows[0]
        
        # 3. Validar que el equipo corresponda a la estación de la OT
        if equipo['EstacionID'] != ot_info['EstacionID']:
            return jsonify({
                "success": False,
                "error": f"El equipo escaneado '{equipo['Nombre']}' pertenece a la estación '{equipo['EstacionNombre']}', "
                         f"pero esta orden de trabajo está registrada para la estación '{ot_info['EstacionNombre']}'."
            }), 400

        # 4. Iniciar el soporte
        run_query("EXEC sp_OT_IniciarSoporte ?, ?, ?", (ot_id, current_user.id, equipo['ID']), 'SP')
        return jsonify({"success": True, "message": "Equipo identificado y soporte iniciado.", "equipo": equipo})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400

@api_bp.route('/ot/linea-estaciones/<int:linea_id>', methods=['GET'])
@login_required
def api_linea_estaciones(linea_id):
    try:
        estaciones = run_query("""
            SELECT ID, Nombre FROM CatEstaciones
            WHERE LineaID = ? AND activo = 1
            ORDER BY Nombre
        """, (linea_id,), 'SELECT')
        return jsonify({"success": True, "estaciones": estaciones})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@api_bp.route('/ot/estacion-equipos/<int:estacion_id>', methods=['GET'])
@login_required
def api_estacion_equipos(estacion_id):
    try:
        equipos = run_query("""
            SELECT e.ID, e.Nombre, e.Modelo, e.NumeroSerie
            FROM CatEquipos e
            WHERE e.EstacionID = ? AND e.activo = 1
            ORDER BY e.Nombre
        """, (estacion_id,), 'SELECT')
        return jsonify({"success": True, "equipos": equipos})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@api_bp.route('/ot/crear-atender-ondemand', methods=['POST'])
@login_required
def api_crear_atender_ondemand():
    data = request.get_json() or {}
    equipo_id = data.get('equipo_id')
    codigo_qr = data.get('codigo_qr')
    
    if not equipo_id and not codigo_qr:
        return jsonify({"success": False, "error": "Parámetros insuficientes."}), 400
        
    try:
        # 1. Obtener la estación a la que pertenece el equipo
        if equipo_id:
            eq_rows = run_query("SELECT ID, Nombre, EstacionID FROM CatEquipos WHERE ID = ? AND activo = 1", (equipo_id,), 'SELECT')
        else:
            codigo_qr = codigo_qr.strip()
            eq_rows = run_query("SELECT ID, Nombre, EstacionID FROM CatEquipos WHERE CodigoQR = ? AND activo = 1", (codigo_qr,), 'SELECT')
            
        if not eq_rows:
            return jsonify({"success": False, "error": "El equipo no se encuentra registrado o activo."}), 404
        equipo = eq_rows[0]
        
        # 2. Ejecutar el SP que crea la OT y registra el inicio del soporte
        res = run_query("EXEC sp_OT_CrearYAtenderOnDemand ?, ?, ?", (equipo['EstacionID'], current_user.id, equipo['ID']), 'SP')
        
        nueva_ot_id = None
        if res:
            nueva_ot_id = res[0].get('OrdenTrabajoID')
            
        if not nueva_ot_id:
            # Fallback
            last_ot = run_query("""
                SELECT TOP 1 ID FROM OrdenesTrabajo 
                WHERE EstacionID = ? AND UsuarioRegistroID = ? AND EstadoID = (SELECT ID FROM CatEstadosOT WHERE Nombre = 'ONGOING')
                ORDER BY ID DESC
            """, (equipo['EstacionID'], current_user.id), 'SELECT')
            if last_ot:
                nueva_ot_id = last_ot[0]['ID']
        
        if not nueva_ot_id:
            return jsonify({"success": False, "error": "No se pudo recuperar el ID de la orden de trabajo creada."}), 500
            
        return jsonify({"success": True, "ot_id": nueva_ot_id})
    except Exception as e:
        current_app.logger.error(f"Error al iniciar soporte on-demand: {str(e)}")
        return jsonify({"success": False, "error": str(e)}), 400

@api_bp.route('/ot/fallas-comunes/<int:equipo_id>', methods=['GET'])
@login_required
def api_fallas_comunes(equipo_id):
    try:
        eq_rows = run_query("SELECT TipoEquipoID FROM CatEquipos WHERE ID = ?", (equipo_id,), 'SELECT')
        if not eq_rows:
            return jsonify({"success": False, "error": "Equipo no encontrado."}), 404
        tipo_id = eq_rows[0]['TipoEquipoID']
        
        fallas = run_query("SELECT ID, Nombre, CodigoFalla FROM CatFallasComunes WHERE TipoEquipoID = ? AND activo = 1 ORDER BY Nombre", (tipo_id,), 'SELECT')
        return jsonify({"success": True, "fallas": fallas})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@api_bp.route('/ot/soluciones-comunes/<int:falla_id>', methods=['GET'])
@login_required
def api_soluciones_comunes(falla_id):
    try:
        soluciones = run_query("SELECT ID, Nombre FROM CatSolucionesComunes WHERE FallaComunID = ? AND activo = 1 ORDER BY Nombre", (falla_id,), 'SELECT')
        return jsonify({"success": True, "soluciones": soluciones})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@api_bp.route('/ot/soporte-recursos/<int:equipo_id>', methods=['GET'])
@login_required
def api_soporte_recursos(equipo_id):
    try:
        eq_rows = run_query("SELECT TipoEquipoID FROM CatEquipos WHERE ID = ?", (equipo_id,), 'SELECT')
        if not eq_rows:
            return jsonify({"success": False, "error": "Equipo no encontrado."}), 404
        tipo_id = eq_rows[0]['TipoEquipoID']
        
        recursos = run_query("""
            SELECT ID, Nombre, TipoRecurso, PathArchivo 
            FROM RecursosSoporte 
            WHERE TipoEquipoID = ? AND activo = 1 
            ORDER BY Nombre
        """, (tipo_id,), 'SELECT')
        return jsonify({"success": True, "recursos": recursos})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@api_bp.route('/ot/completar', methods=['POST'])
@login_required
def api_completar():
    data = request.get_json() or {}
    ot_id = data.get('ot_id')
    equipo_id = data.get('equipo_id')
    falla_real_id = data.get('falla_real_id')
    comentarios_solucion = data.get('comentarios_solucion', '')
    solucion_nueva = data.get('solucion_nueva')

    if not ot_id or not equipo_id or not falla_real_id:
        return jsonify({"success": False, "error": "Campos obligatorios incompletos."}), 400

    try:
        if solucion_nueva and solucion_nueva.strip():
            run_query("""
                INSERT INTO CatSolucionesComunes (FallaComunID, Nombre, Descripcion)
                VALUES (?, ?, ?)
            """, (falla_real_id, solucion_nueva, solucion_nueva), 'INSERT')
            comentarios_solucion = solucion_nueva

        run_query("EXEC sp_OT_Completar_V2 ?, ?, ?, ?, ?", 
                  (ot_id, equipo_id, falla_real_id, current_user.id, comentarios_solucion), 'SP')
        current_app.logger.info(f"Técnico {current_user.nombre} ha completado y cerrado la OT #{ot_id} para Equipo ID {equipo_id}.")
        
        # Actualización de Mantenimiento Preventivo (PM) si la OT proviene de una programación
        pm_rows = run_query("""
            SELECT ID, FrecuenciaDias, EstacionID, EquipoID, LineaID, RutinaPreventivaID, TecnicoID, Titulo, Comentario, HoraInicio
            FROM ProgramacionPreventivos
            WHERE OrdenTrabajoID = ? AND activo = 1
        """, (ot_id,), 'SELECT')
        
        if pm_rows:
            pm = pm_rows[0]
            # 1. Marcar el PM actual como COMPLETADA
            run_query("""
                UPDATE ProgramacionPreventivos 
                SET Estado = 'COMPLETADA', FechaUltimaEjecucion = GETDATE()
                WHERE ID = ?
            """, (pm['ID'],), 'UPDATE')
            
            # 2. Si es recurrente (FrecuenciaDias > 0), auto-programar el siguiente ciclo
            if pm['FrecuenciaDias'] and pm['FrecuenciaDias'] > 0:
                frec = pm['FrecuenciaDias']
                next_date_rows = run_query("SELECT CONVERT(VARCHAR(10), DATEADD(DAY, ?, GETDATE()), 120) AS NextDate", (frec,), 'SELECT')
                next_date = next_date_rows[0]['NextDate'] if next_date_rows else None
                
                if next_date:
                    # Crear nuevo registro de PM programado
                    pm_res = run_query("""
                        INSERT INTO ProgramacionPreventivos (
                            LineaID, EstacionID, EquipoID, RutinaPreventivaID, TecnicoID,
                            FechaProximaEjecucion, FrecuenciaDias, HoraInicio, Estado, Titulo, Comentario, activo, fecharegistro, UsuarioRegistroID
                        ) 
                        OUTPUT INSERTED.ID
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PROGRAMADA', ?, ?, 1, GETDATE(), ?)
                    """, (pm['LineaID'], pm['EstacionID'], pm['EquipoID'], pm['RutinaPreventivaID'], pm['TecnicoID'],
                          next_date, frec, pm['HoraInicio'] or '08:00', pm['Titulo'], pm['Comentario'], current_user.id), 'INSERT')
                    
                    new_pm_id = pm_res[0]['ID']
                    
                    # Estado de OT para la nueva programación
                    estado_created = run_query("SELECT ID FROM CatEstadosOT WHERE Nombre = 'CREATED'", query_type='SELECT')[0]['ID']
                    turno_id = getattr(current_user, 'turno_id', 1) or 1
                    
                    comentario_ot = f"[PM RECURRENTE] {pm['Titulo'] or 'Mantenimiento Preventivo Recurrente'}. {pm['Comentario'] or ''}"
                    
                    ot_res = run_query("""
                        INSERT INTO OrdenesTrabajo (
                            EstacionID, EquipoID, EstadoID, LiderReportaID, TurnoID, FechaReporte,
                            TipoMantenimiento, RutinaPreventivaID, ComentarioLider, EmpleadosAfectados, activo, fecharegistro, UsuarioRegistroID
                        ) 
                        OUTPUT INSERTED.ID
                        VALUES (?, ?, ?, ?, ?, ?, 'PREVENTIVO', ?, ?, 0, 1, GETDATE(), ?)
                    """, (pm['EstacionID'], pm['EquipoID'], estado_created, current_user.id, turno_id,
                          f"{next_date} {pm['HoraInicio'] or '08:00'}:00", pm['RutinaPreventivaID'], comentario_ot, current_user.id), 'INSERT')
                    
                    new_ot_id = ot_res[0]['ID']
                    
                    run_query("UPDATE ProgramacionPreventivos SET OrdenTrabajoID = ? WHERE ID = ?", (new_ot_id, new_pm_id), 'UPDATE')
                    
                    if pm['TecnicoID']:
                        run_query("""
                            INSERT INTO DetalleTecnicosOT (OrdenTrabajoID, TecnicoID, FechaAsignacion, activo, fecharegistro)
                            VALUES (?, ?, GETDATE(), 1, GETDATE())
                        """, (new_ot_id, pm['TecnicoID']), 'INSERT')

        return jsonify({"success": True, "message": "Orden de trabajo completada y ciclo de PM actualizado."})
    except Exception as e:
        current_app.logger.error(f"Error al completar la OT #{ot_id}: {str(e)}")
        return jsonify({"success": False, "error": str(e)}), 400

@api_bp.route('/ot/<int:ot_id>/evidencia', methods=['POST'])
@login_required
def api_subir_evidencia(ot_id):
    if 'foto' not in request.files:
        return jsonify({"success": False, "error": "No se envió ningún archivo de imagen."}), 400
        
    tipo = request.form.get('tipo', 'FALLA')
    archivo = request.files['foto']
    
    try:
        filename = f"ot_{ot_id}_{tipo.lower()}_{archivo.filename}"
        storage_dir = current_app.config['STORAGE_PATH']
        
        if not os.path.exists(storage_dir):
            try:
                os.makedirs(storage_dir)
            except Exception:
                storage_dir = os.path.join(current_app.root_path, 'static', 'uploads')
                if not os.path.exists(storage_dir):
                    os.makedirs(storage_dir)

        filepath = os.path.join(storage_dir, filename)
        archivo.save(filepath)

        # Inserción usando run_query (guardando solo el nombre simple)
        run_query("""
            INSERT INTO EvidenciasOT (OrdenTrabajoID, UsuarioID, TipoEvidencia, PathArchivo)
            VALUES (?, ?, ?, ?)
        """, (ot_id, current_user.id, tipo, filename), 'INSERT')

        current_app.logger.info(f"Evidencia fotográfica ({tipo}) para OT #{ot_id} subida exitosamente a '{filename}' por {current_user.nombre}.")
        return jsonify({"success": True, "filepath": filename})
    except Exception as e:
        current_app.logger.error(f"Error al subir evidencia para la OT #{ot_id}: {str(e)}")
        return jsonify({"success": False, "error": str(e)}), 500

# ---------------------------------------------------------
# APIS PARA COMPONENTES FRONTEND
# ---------------------------------------------------------

@api_bp.route('/kpi/downtime-data')
@login_required
def api_kpi_downtime():
    try:
        rows = run_query("""
            SELECT c4.Nombre AS Causa4M,
                   SUM(DATEDIFF(MINUTE, ot.FechaReporte, dt.FechaFinActividad)) / 60.0 AS HorasDownTime
            FROM OrdenesTrabajo ot
            INNER JOIN CatCausas4M c4 ON ot.Causa4MID = c4.ID
            INNER JOIN DetalleTecnicosOT dt ON dt.OrdenTrabajoID = ot.ID AND dt.FechaFinActividad IS NOT NULL
            WHERE ot.EstadoID = (SELECT ID FROM CatEstadosOT WHERE Nombre = 'Completada')
              AND ot.activo = 1
            GROUP BY c4.Nombre
        """, query_type='SELECT')
        
        labels = [row['Causa4M'] for row in rows]
        valores = [float(row['HorasDownTime']) for row in rows]
        
        return jsonify({"labels": labels, "data": valores})
    except Exception as e:
        current_app.logger.error(f"Error en endpoint KPI downtime-data: {str(e)}")
        return jsonify({"error": str(e)}), 500

@api_bp.route('/preventivos/eventos')
@login_required
def api_preventivos_eventos():
    try:
        linea_id = request.args.get('linea_id', type=int)
        tecnico_id = request.args.get('tecnico_id', type=int)
        estado = request.args.get('estado')

        sql = """
            SELECT 
                pp.ID, pp.Titulo, pp.Comentario, pp.FechaProximaEjecucion, pp.HoraInicio,
                pp.FrecuenciaDias, pp.Estado, pp.OrdenTrabajoID,
                pp.LineaID, lin.Nombre AS LineaNombre,
                pp.EstacionID, est.Nombre AS EstacionNombre,
                pp.EquipoID, eq.Nombre AS EquipoNombre,
                pp.RutinaPreventivaID, rp.Nombre AS RutinaNombre,
                pp.TecnicoID, tec.Nombre AS TecnicoNombre
            FROM ProgramacionPreventivos pp
            LEFT JOIN CatLineas lin ON pp.LineaID = lin.ID
            LEFT JOIN CatEstaciones est ON pp.EstacionID = est.ID
            LEFT JOIN CatEquipos eq ON pp.EquipoID = eq.ID
            LEFT JOIN CatRutinasPreventivas rp ON pp.RutinaPreventivaID = rp.ID
            LEFT JOIN CatUsuarios tec ON pp.TecnicoID = tec.ID
            WHERE pp.activo = 1
        """
        params = []
        if linea_id:
            sql += " AND (pp.LineaID = ? OR est.LineaID = ?)"
            params.extend([linea_id, linea_id])
        if tecnico_id:
            sql += " AND pp.TecnicoID = ?"
            params.append(tecnico_id)
        if estado:
            sql += " AND pp.Estado = ?"
            params.append(estado)

        rows = run_query(sql, tuple(params), 'SELECT')
        
        eventos = []
        for r in rows:
            st = r['Estado'] or 'PROGRAMADA'
            # Asignar código de color por estado
            color = "#3b82f6" # Azul - Programada
            if st == 'EN_PROCESO':
                color = "#f59e0b" # Naranja - En Proceso
            elif st == 'COMPLETADA':
                color = "#10b981" # Verde - Completada
            elif st == 'CANCELADA':
                color = "#ef4444" # Rojo - Cancelada
                
            ubicacion = r['EquipoNombre'] or r['EstacionNombre'] or r['LineaNombre'] or 'Planta'
            titulo_clean = r['Titulo'] or r['RutinaNombre'] or 'Mantenimiento Preventivo'
            
            fecha_str = r['FechaProximaEjecucion'].strftime('%Y-%m-%d') if r['FechaProximaEjecucion'] else None
            hora_str = r['HoraInicio'] or '08:00'
            start_iso = f"{fecha_str}T{hora_str}:00" if fecha_str else None
            
            eventos.append({
                "id": str(r['ID']),
                "title": f"PM: {titulo_clean} ({ubicacion})",
                "start": start_iso,
                "color": color,
                "extendedProps": {
                    "pm_id": r['ID'],
                    "titulo": r['Titulo'],
                    "comentario": r['Comentario'],
                    "linea_id": r['LineaID'],
                    "linea_nombre": r['LineaNombre'],
                    "estacion_id": r['EstacionID'],
                    "estacion_nombre": r['EstacionNombre'],
                    "equipo_id": r['EquipoID'],
                    "equipo_nombre": r['EquipoNombre'],
                    "rutina_id": r['RutinaPreventivaID'],
                    "rutina_nombre": r['RutinaNombre'],
                    "tecnico_id": r['TecnicoID'],
                    "tecnico_nombre": r['TecnicoNombre'],
                    "estado": st,
                    "ot_id": r['OrdenTrabajoID'],
                    "frecuencia_dias": r['FrecuenciaDias'],
                    "hora_inicio": hora_str,
                    "fecha_proxima": fecha_str
                }
            })
            
        return jsonify(eventos)
    except Exception as e:
        current_app.logger.error(f"Error en endpoint preventivos eventos: {str(e)}")
        return jsonify([]), 500

@api_bp.route('/preventivos/guardar', methods=['POST'])
@login_required
def api_preventivos_guardar():
    data = request.get_json() or {}
    pm_id = data.get('id')
    linea_id = data.get('linea_id')
    estacion_id = data.get('estacion_id')
    equipo_id = data.get('equipo_id')
    rutina_id = data.get('rutina_id')
    titulo = data.get('titulo')
    tecnico_id = data.get('tecnico_id')
    fecha_proxima = data.get('fecha_proxima')
    hora_inicio = data.get('hora_inicio', '08:00')
    frecuencia_dias = data.get('frecuencia_dias', 0)
    comentario = data.get('comentario', '')

    if not fecha_proxima:
        return jsonify({"success": False, "error": "Debe especificar la fecha de ejecución."}), 400

    try:
        # Resolver EstacionID si solo se seleccionó Línea
        estacion_final_id = estacion_id
        if not estacion_final_id and equipo_id:
            eq_res = run_query("SELECT EstacionID FROM CatEquipos WHERE ID = ?", (equipo_id,), 'SELECT')
            if eq_res:
                estacion_final_id = eq_res[0]['EstacionID']
                
        if not estacion_final_id and linea_id:
            est_res = run_query("SELECT TOP 1 ID FROM CatEstaciones WHERE LineaID = ? AND activo = 1", (linea_id,), 'SELECT')
            if est_res:
                estacion_final_id = est_res[0]['ID']

        if not estacion_final_id:
            # Fallback a estación 1 si no hay coincidencia
            est_default = run_query("SELECT TOP 1 ID FROM CatEstaciones WHERE activo = 1", query_type='SELECT')
            if est_default:
                estacion_final_id = est_default[0]['ID']

        if pm_id:
            # EDITAR PM EXISTENTE
            run_query("""
                UPDATE ProgramacionPreventivos
                SET LineaID = ?, EstacionID = ?, EquipoID = ?, RutinaPreventivaID = ?, TecnicoID = ?,
                    FechaProximaEjecucion = ?, HoraInicio = ?, FrecuenciaDias = ?, Titulo = ?, Comentario = ?
                WHERE ID = ?
            """, (linea_id, estacion_final_id, equipo_id, rutina_id, tecnico_id,
                  fecha_proxima, hora_inicio, frecuencia_dias, titulo, comentario, pm_id), 'UPDATE')
            
            # Actualizar la OT vinculada si existe
            pm_row = run_query("SELECT OrdenTrabajoID FROM ProgramacionPreventivos WHERE ID = ?", (pm_id,), 'SELECT')
            if pm_row and pm_row[0]['OrdenTrabajoID']:
                ot_id = pm_row[0]['OrdenTrabajoID']
                comentario_ot = f"[PM PROGRAMADO] {titulo or 'Rutina de Mantenimiento Preventivo'}. {comentario or ''}"
                fecha_rep = f"{fecha_proxima} {hora_inicio}:00"
                run_query("""
                    UPDATE OrdenesTrabajo 
                    SET EstacionID = ?, EquipoID = ?, RutinaPreventivaID = ?, ComentarioLider = ?, FechaReporte = ?
                    WHERE ID = ?
                """, (estacion_final_id, equipo_id, rutina_id, comentario_ot, fecha_rep, ot_id), 'UPDATE')
                
                if tecnico_id:
                    # Actualizar o insertar técnico asignado
                    run_query("UPDATE DetalleTecnicosOT SET activo = 0 WHERE OrdenTrabajoID = ?", (ot_id,), 'UPDATE')
                    run_query("""
                        INSERT INTO DetalleTecnicosOT (OrdenTrabajoID, TecnicoID, FechaAsignacion, activo, fecharegistro)
                        VALUES (?, ?, GETDATE(), 1, GETDATE())
                    """, (ot_id, tecnico_id), 'INSERT')

            return jsonify({"success": True, "message": "Programación actualizada con éxito."})

        else:
            # CREAR NUEVA PROGRAMACIÓN PM
            pm_res = run_query("""
                INSERT INTO ProgramacionPreventivos (
                    LineaID, EstacionID, EquipoID, RutinaPreventivaID, TecnicoID,
                    FechaProximaEjecucion, FrecuenciaDias, HoraInicio, Estado, Titulo, Comentario, activo, fecharegistro, UsuarioRegistroID
                ) 
                OUTPUT INSERTED.ID
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PROGRAMADA', ?, ?, 1, GETDATE(), ?)
            """, (linea_id, estacion_final_id, equipo_id, rutina_id, tecnico_id,
                  fecha_proxima, frecuencia_dias, hora_inicio, titulo, comentario, current_user.id), 'INSERT')
            
            new_pm_id = pm_res[0]['ID']
            
            # Generar OT de Tipo Mantenimiento PREVENTIVO
            estado_created = run_query("SELECT ID FROM CatEstadosOT WHERE Nombre = 'CREATED'", query_type='SELECT')[0]['ID']
            turno_id = getattr(current_user, 'turno_id', 1) or 1
            comentario_ot = f"[PM PROGRAMADO] {titulo or 'Rutina de Mantenimiento Preventivo'}. {comentario or ''}"
            fecha_rep = f"{fecha_proxima} {hora_inicio}:00"

            ot_res = run_query("""
                INSERT INTO OrdenesTrabajo (
                    EstacionID, EquipoID, EstadoID, LiderReportaID, TurnoID, FechaReporte,
                    TipoMantenimiento, RutinaPreventivaID, ComentarioLider, EmpleadosAfectados, activo, fecharegistro, UsuarioRegistroID
                ) 
                OUTPUT INSERTED.ID
                VALUES (?, ?, ?, ?, ?, ?, 'PREVENTIVO', ?, ?, 0, 1, GETDATE(), ?)
            """, (estacion_final_id, equipo_id, estado_created, current_user.id, turno_id,
                  fecha_rep, rutina_id, comentario_ot, current_user.id), 'INSERT')
            
            new_ot_id = ot_res[0]['ID']
            
            # Vincular la OT con el PM
            run_query("UPDATE ProgramacionPreventivos SET OrdenTrabajoID = ? WHERE ID = ?", (new_ot_id, new_pm_id), 'UPDATE')
            
            # Asignar al técnico si se especificó
            if tecnico_id:
                run_query("""
                    INSERT INTO DetalleTecnicosOT (OrdenTrabajoID, TecnicoID, FechaAsignacion, activo, fecharegistro)
                    VALUES (?, ?, GETDATE(), 1, GETDATE())
                """, (new_ot_id, tecnico_id), 'INSERT')

            return jsonify({"success": True, "message": "Mantenimiento Preventivo programado y OT generada con éxito.", "pm_id": new_pm_id, "ot_id": new_ot_id})

    except Exception as e:
        current_app.logger.error(f"Error al guardar preventivo: {str(e)}")
        return jsonify({"success": False, "error": str(e)}), 400

@api_bp.route('/preventivos/eliminar/<int:pm_id>', methods=['POST'])
@login_required
def api_preventivos_eliminar(pm_id):
    try:
        pm_rows = run_query("SELECT OrdenTrabajoID FROM ProgramacionPreventivos WHERE ID = ?", (pm_id,), 'SELECT')
        if not pm_rows:
            return jsonify({"success": False, "error": "Programación no encontrada."}), 404
            
        ot_id = pm_rows[0]['OrdenTrabajoID']
        
        # Desactivar / Cancelar PM
        run_query("UPDATE ProgramacionPreventivos SET activo = 0, Estado = 'CANCELADA' WHERE ID = ?", (pm_id,), 'UPDATE')
        
        # Desactivar OT asociada si existe
        if ot_id:
            run_query("UPDATE OrdenesTrabajo SET activo = 0 WHERE ID = ?", (ot_id,), 'UPDATE')

        return jsonify({"success": True, "message": "Programación preventiva eliminada con éxito."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400

@api_bp.route('/preventivos/mover', methods=['POST'])
@login_required
def api_preventivos_mover():
    data = request.get_json() or {}
    pm_id = data.get('id')
    nueva_fecha = data.get('nueva_fecha')
    
    if not pm_id or not nueva_fecha:
        return jsonify({"success": False, "error": "Parámetros insuficientes."}), 400
        
    try:
        # Actualizar fecha de la programación
        run_query("UPDATE ProgramacionPreventivos SET FechaProximaEjecucion = ? WHERE ID = ?", (nueva_fecha, pm_id), 'UPDATE')
        
        # Actualizar fecha de reporte en la OT si existe
        pm_rows = run_query("SELECT OrdenTrabajoID, HoraInicio FROM ProgramacionPreventivos WHERE ID = ?", (pm_id,), 'SELECT')
        if pm_rows and pm_rows[0]['OrdenTrabajoID']:
            ot_id = pm_rows[0]['OrdenTrabajoID']
            hora_inicio = pm_rows[0]['HoraInicio'] or '08:00'
            fecha_rep = f"{nueva_fecha} {hora_inicio}:00"
            run_query("UPDATE OrdenesTrabajo SET FechaReporte = ? WHERE ID = ?", (fecha_rep, ot_id), 'UPDATE')

        return jsonify({"success": True, "message": "Fecha reprogramada."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400

@api_bp.route('/preventivos/tecnicos', methods=['GET'])
@login_required
def api_preventivos_tecnicos():
    try:
        tecnicos = run_query("""
            SELECT u.ID, u.Nombre 
            FROM CatUsuarios u
            INNER JOIN CatRoles r ON u.RolID = r.ID
            WHERE r.Nombre IN ('Tecnico', 'Técnico', 'Mantenimiento') AND u.activo = 1
            ORDER BY u.Nombre
        """, query_type='SELECT')
        return jsonify({"success": True, "tecnicos": tecnicos})
    except Exception as e:
        # Fallback a todos los usuarios activos si los roles varían
        tecnicos = run_query("SELECT ID, Nombre FROM CatUsuarios WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
        return jsonify({"success": True, "tecnicos": tecnicos})

@api_bp.route('/preventivos/rutinas', methods=['GET'])
@login_required
def api_preventivos_rutinas():
    try:
        rutinas = run_query("SELECT ID, Nombre, Descripcion, FrecuenciaDias FROM CatRutinasPreventivas WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
        return jsonify({"success": True, "rutinas": rutinas})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


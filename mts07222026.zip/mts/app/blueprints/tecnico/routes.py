from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from app.blueprints.db import run_query

tecnico_bp = Blueprint('tecnico', __name__, template_folder='templates')

@tecnico_bp.route('/panel')
@login_required
def panel_tareas():
    if current_user.rol not in ['Tecnico', 'Administrador']:
        flash('Acceso denegado: Se requiere rol de Técnico.', 'danger')
        return redirect(url_for('auth.login'))

    # Listar OTs activas usando run_query (retorna lista de diccionarios)
    tareas_activas = run_query("""
        SELECT ot.ID, lin.Nombre AS Linea, est.Nombre AS Estacion, eo.Nombre AS Estado, 
               ot.FechaReporte, ot.TipoMantenimiento, sfl.Nombre AS Sintoma,
               lid.Nombre AS LiderNombre
        FROM OrdenesTrabajo ot
        INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
        INNER JOIN CatLineas lin ON est.LineaID = lin.ID
        INNER JOIN CatEstadosOT eo ON ot.EstadoID = eo.ID
        LEFT JOIN CatFallasComunes sfl ON ot.SintomaFallaLiderID = sfl.ID
        LEFT JOIN CatUsuarios lid ON ot.LiderReportaID = lid.ID
        WHERE eo.Nombre IN ('CREATED', 'ONGOING', 'STOPPED')
          AND ot.activo = 1
        ORDER BY ot.FechaReporte DESC
    """, query_type='SELECT')

    return render_template('tecnico/panel.html', tareas=tareas_activas)

@tecnico_bp.route('/on-demand')
@login_required
def soporte_on_demand():
    if current_user.rol not in ['Tecnico', 'Administrador']:
        flash('Acceso denegado: Se requiere rol de Técnico.', 'danger')
        return redirect(url_for('auth.login'))

    # Cargar las líneas para la selección manual
    lineas = run_query("SELECT ID, Nombre FROM CatLineas WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    return render_template('tecnico/soporte_on_demand.html', lineas=lineas)

@tecnico_bp.route('/atencion/<int:ot_id>')
@login_required
def atender_ot(ot_id):
    if current_user.rol not in ['Tecnico', 'Administrador']:
        flash('Acceso denegado: Se requiere rol de Técnico.', 'danger')
        return redirect(url_for('auth.login'))

    # Obtener detalles de la Orden de Trabajo
    ot_rows = run_query("""
        SELECT ot.ID, est.Nombre AS Estacion, est.CodigoQR, eo.Nombre AS Estado, 
               ot.FechaReporte, ot.TipoMantenimiento, ot.EmpleadosAfectados,
               sfl.Nombre AS Sintoma, ot.ComentarioLider, ot.EstacionID,
               ot.FechaInicioSoporte, ot.EquipoID, eq.Nombre AS EquipoNombre
        FROM OrdenesTrabajo ot
        INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
        INNER JOIN CatEstadosOT eo ON ot.EstadoID = eo.ID
        LEFT JOIN CatFallasComunes sfl ON ot.SintomaFallaLiderID = sfl.ID
        LEFT JOIN CatEquipos eq ON ot.EquipoID = eq.ID
        WHERE ot.ID = ? AND ot.activo = 1
    """, (ot_id,), 'SELECT')

    if not ot_rows:
        flash('Orden de trabajo no encontrada.', 'danger')
        return redirect(url_for('tecnico.panel_tareas'))

    ot = ot_rows[0]
    estacion_id = ot['EstacionID']

    # Obtener equipos presentes en la estación
    equipos = run_query("""
        SELECT e.ID, e.Nombre, te.Nombre AS Tipo
        FROM CatEquipos e
        INNER JOIN CatTiposEquipo te ON e.TipoEquipoID = te.ID
        WHERE e.EstacionID = ? AND e.activo = 1
    """, (estacion_id,), 'SELECT')

    # Obtener líneas para la selección de backup
    lineas = run_query("SELECT ID, Nombre FROM CatLineas WHERE activo = 1 ORDER BY Nombre")

    # Obtener motivos de pausa para el modal
    motivos_pausa = run_query("SELECT ID, Nombre FROM CatMotivosPausa WHERE activo = 1 ORDER BY Nombre")

    # Obtener personal técnico activo para transferencias (handover)
    tecnicos_disponibles = run_query("""
        SELECT u.ID, u.Nombre 
        FROM CatUsuarios u
        INNER JOIN CatRoles r ON u.RolID = r.ID
        WHERE r.Nombre = 'Tecnico' AND u.ID <> ? AND u.activo = 1
    """, (current_user.id,), 'SELECT')

    return render_template(
        'tecnico/atencion.html',
        ot=ot,
        equipos=equipos,
        lineas=lineas,
        motivos_pausa=motivos_pausa,
        tecnicos=tecnicos_disponibles
    )

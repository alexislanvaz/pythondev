from flask import Blueprint, render_template, redirect, url_for, request, flash, current_app
from flask_login import login_user, logout_user, login_required, current_user
from app.models import User
from app.translations import TRANSLATIONS

auth_bp = Blueprint('auth', __name__, template_folder='templates')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect_by_role()

    if request.method == 'POST':
        no_empleado = request.form.get('no_empleado')
        pin = request.form.get('pin')
        lang = request.form.get('lang', 'es')

        try:
            # Verificar credenciales en SQL Server
            if User.verify_pin(no_empleado, pin):
                user = User.get_by_no_empleado(no_empleado)
                if user:
                    login_user(user)
                    current_app.logger.info(f"Usuario {no_empleado} ha iniciado sesión con éxito.")
                    flash(TRANSLATIONS[lang].get('msg_welcome', '¡Bienvenido!'), 'success')
                    return redirect_by_role()
            
            current_app.logger.warning(f"Intento fallido de inicio de sesión para el empleado: {no_empleado}.")
            flash(TRANSLATIONS[lang].get('error_invalid_credentials', 'Credenciales inválidas.'), 'danger')
            
        except Exception as e:
            current_app.logger.error(f"Error crítico en login para empleado {no_empleado}: {str(e)}")
            flash(f"Error de sistema: {str(e)}", 'danger')

    return render_template('auth/login.html')

@auth_bp.route('/logout')
@login_required
def logout():
    lang = request.args.get('lang', 'es')
    no_empleado = current_user.no_empleado
    try:
        logout_user()
        current_app.logger.info(f"Usuario {no_empleado} ha cerrado sesión.")
        flash(TRANSLATIONS[lang].get('msg_logged_out', 'Sesión cerrada.'), 'success')
    except Exception as e:
        current_app.logger.error(f"Error al cerrar sesión para {no_empleado}: {str(e)}")
        flash("Error al cerrar sesión.", "danger")
    return redirect(url_for('auth.login'))

def redirect_by_role():
    """Redirige al usuario al menú central del CMMS."""
    return redirect(url_for('index'))

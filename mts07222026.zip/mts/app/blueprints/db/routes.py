import pyodbc
from flask import Blueprint, jsonify, current_app
from app.config import Config

db_bp = Blueprint('db', __name__)

def get_db_connection():
    """Establece y retorna una conexión pyodbc directa a SQL Server."""
    try:
        conn_str = current_app.config['CONN_STRING']
    except RuntimeError:
        conn_str = Config.CONN_STRING
    return pyodbc.connect(conn_str)

def run_query(query, params=None, query_type='SELECT'):
    """
    Ejecuta una consulta SQL en SQL Server mediante pyodbc.
    Garantiza el correcto cierre de cursores/conexiones y el manejo de transacciones.
    
    :param query: Consulta SQL o comando T-SQL (ej: "SELECT ...", "EXEC sp_...")
    :param params: Parámetros opcionales para la consulta (lista o tupla)
    :param query_type: Tipo de operación ('SELECT', 'INSERT', 'UPDATE', 'DELETE', 'SP')
    :return: Lista de diccionarios para consultas que retornan registros, de lo contrario una lista vacía.
    """
    if params is None:
        params = ()
        
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute(query, params)
        
        # Operaciones de lectura (SELECT o Stored Procedures que devuelven registros)
        if query_type.upper() in ['SELECT', 'SP']:
            if cursor.description:
                columns = [column[0] for column in cursor.description]
                results = []
                for row in cursor.fetchall():
                    results.append(dict(zip(columns, row)))
                if query_type.upper() == 'SP':
                    conn.commit()
                return results
            else:
                conn.commit()
                return []
                
        # Operaciones de escritura (INSERT, UPDATE, DELETE)
        else:
            results = []
            if cursor.description:
                columns = [column[0] for column in cursor.description]
                for row in cursor.fetchall():
                    results.append(dict(zip(columns, row)))
            conn.commit()
            return results
            
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        cursor.close()
        conn.close()

@db_bp.route('/status', methods=['GET'])
def db_status():
    """Endpoint API para validar asíncronamente el estado de la conexión a la base de datos."""
    try:
        conn = get_db_connection()
        conn.close()
        return jsonify({"connected": True, "message": "Conexión a SQL Server activa."})
    except Exception as e:
        return jsonify({"connected": False, "error": str(e)}), 500

from flask_login import UserMixin
from werkzeug.security import check_password_hash
from app.blueprints.db import run_query

class User(UserMixin):
    def __init__(self, user_id, no_empleado, nombre, rol_nombre, area_id, turno_id):
        self.id = user_id
        self.no_empleado = no_empleado
        self.nombre = nombre
        self.rol = rol_nombre
        self.area_id = area_id
        self.turno_id = turno_id

    @staticmethod
    def get(user_id):
        """Recupera un usuario de la base de datos por su ID único de registro."""
        rows = run_query("""
            SELECT u.ID, u.NoEmpleado, u.Nombre, r.Nombre AS RolNombre, u.AreaID, u.TurnoID 
            FROM CatUsuarios u
            INNER JOIN CatRoles r ON u.RolID = r.ID
            WHERE u.ID = ? AND u.activo = 1
        """, (user_id,), 'SELECT')
        
        if rows:
            row = rows[0]
            return User(row['ID'], row['NoEmpleado'], row['Nombre'], row['RolNombre'], row['AreaID'], row['TurnoID'])
        return None

    @staticmethod
    def get_by_no_empleado(no_empleado):
        """Recupera un usuario de la base de datos por su número de empleado."""
        rows = run_query("""
            SELECT u.ID, u.NoEmpleado, u.Nombre, r.Nombre AS RolNombre, u.AreaID, u.TurnoID 
            FROM CatUsuarios u
            INNER JOIN CatRoles r ON u.RolID = r.ID
            WHERE u.NoEmpleado = ? AND u.activo = 1
        """, (no_empleado,), 'SELECT')
        
        if rows:
            row = rows[0]
            return User(row['ID'], row['NoEmpleado'], row['Nombre'], row['RolNombre'], row['AreaID'], row['TurnoID'])
        return None

    @staticmethod
    def verify_pin(no_empleado, input_pin):
        """
        Valida las credenciales (PIN o Contraseña) del empleado contra la base de datos SQL Server.
        """
        rows = run_query("""
            SELECT PasswordHash FROM CatUsuarios 
            WHERE NoEmpleado = ? AND activo = 1
        """, (no_empleado,), 'SELECT')
        
        if rows and rows[0]['PasswordHash']:
            return check_password_hash(rows[0]['PasswordHash'], input_pin)
        return False

import os
import logging
from logging.handlers import RotatingFileHandler
from flask import Flask, session, request, redirect, url_for, render_template
from flask_login import LoginManager, login_required
from app.config import Config
from app.models import User
from app.translations import TRANSLATIONS

# Instanciar LoginManager
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message_category = 'warning'

@login_manager.user_loader
def load_user(user_id):
    """Carga un usuario de la sesión mediante pyodbc y run_query."""
    return User.get(int(user_id))

def create_app():
    """Factoría de aplicación Flask."""
    app = Flask(__name__)
    app.config.from_object(Config)

    # 1. Configuración de Logging Rotativo en Carpeta Física
    log_dir = os.path.join(app.root_path, 'logs')
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
        
    file_handler = RotatingFileHandler(
        os.path.join(log_dir, 'app.log'), 
        maxBytes=10*1024*1024, # 10MB
        backupCount=5,
        encoding='utf-8'
    )
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
    ))
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
    app.logger.setLevel(logging.INFO)
    app.logger.info('Servidor CMMS iniciado exitosamente.')

    # 2. Inicializar Login Manager
    login_manager.init_app(app)

    # 3. Context Processor Global de Traducciones para Jinja2
    @app.context_processor
    def inject_translations():
        lang = session.get('lang', 'es')
        def translate(key):
            return TRANSLATIONS.get(lang, TRANSLATIONS['es']).get(key, key)
        return dict(_=translate, current_lang=lang)

    # 4. Ruta Global para cambiar el idioma
    @app.route('/change-lang/<lang_code>')
    def change_language(lang_code):
        if lang_code in ['es', 'en']:
            session['lang'] = lang_code
        # Redirigir de regreso a la página anterior o al index por defecto
        return redirect(request.referrer or url_for('index'))

    # 5. Registro de Blueprints
    from app.blueprints.db import db_bp
    from app.blueprints.auth.routes import auth_bp
    from app.blueprints.lider.routes import lider_bp
    from app.blueprints.tecnico.routes import tecnico_bp
    from app.blueprints.ingenieria.routes import ingenieria_bp
    from app.blueprints.catalogo.routes import catalogo_bp
    from app.blueprints.api.routes import api_bp

    app.register_blueprint(db_bp, url_prefix='/db')
    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(lider_bp, url_prefix='/lider')
    app.register_blueprint(tecnico_bp, url_prefix='/tecnico')
    app.register_blueprint(ingenieria_bp, url_prefix='/ingenieria')
    app.register_blueprint(catalogo_bp, url_prefix='/catalogo')
    app.register_blueprint(api_bp, url_prefix='/api')

    # Ruta raíz principal (Menú Central / Hub)
    @app.route('/')
    @login_required
    def index():
        return render_template('home.html')

    return app

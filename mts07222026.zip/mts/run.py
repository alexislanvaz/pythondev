import os
from dotenv import load_dotenv
from app import create_app

# Cargar variables de entorno desde el archivo .env si existe
load_dotenv()

app = create_app()

if __name__ == '__main__':
    # Ejecutar servidor Flask en el puerto 5000 visible en la red local
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)

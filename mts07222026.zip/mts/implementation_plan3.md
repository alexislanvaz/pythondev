# Plan de Implementación: Operaciones CRUD Completas para Catálogos (CMMS)

Este documento detalla el plan técnico y de diseño de experiencia de usuario (UX) para dotar a todos los catálogos del sistema con capacidades completas de **Creación, Lectura, Actualización y Desactivación Lógica** (CRUD).

---

## 1. Experiencia de Usuario (UX) Diseñada para Planta

*   **Pestañas Unificadas en Panel de Activos (`listar.html`)**:
    *   Se expandirá la vista principal a 5 pestañas organizadas:
        1.  *Usuarios*: Lista a todo el personal, su rol, área y turno. (Exclusivo Admin).
        2.  *Activos Físicos*: Lista Áreas, Líneas, Estaciones y Equipos.
        3.  *Modos de Falla*: Modos de falla real comunes por tipo de equipo.
        4.  *Turnos*: Horarios de turnos operativos en planta. (Exclusivo Admin).
        5.  *Roles*: Nombres y descripciones de puestos. (Exclusivo Admin).
*   **Acciones en Tabla (Acceso Táctil)**:
    *   Cada fila activa de las tablas tendrá una columna final de **Acciones** con dos botones minimalistas pastel:
        *   **Editar** (Lápiz): Redirige de inmediato a la ruta de edición correspondiente.
        *   **Desactivar** (Papelera/X): En lugar de realizar un borrado físico destructivo, se integra un modal asertivo de **SweetAlert2** ("¿Estás seguro de que deseas desactivar a ...?"). Al confirmar, realiza un Fetch/POST AJAX asíncrono que desactiva el registro (`activo = 0`) en SQL Server y remueve la fila de la tabla en tiempo real con una animación suave de desvanecimiento, desplegando un Toast de éxito.
*   **Formularios Duales Reutilizables (DRY)**:
    *   Para evitar la proliferación de archivos HTML, se modificarán las plantillas de alta actuales (`alta_area.html`, `alta_usuario.html`, etc.) para soportar edición de forma dual:
        *   Si se provee un objeto `registro` al renderizar, el formulario se auto-poblará con los datos de SQL Server, el título cambiará a "Modificar [Catálogo]" y el botón de submit dirá "Guardar Cambios". De lo contrario, se comportará como un formulario de alta vacío tradicional.

---

## 2. Definición de Endpoints e Inserciones en `catalogo/routes.py`

Se implementarán las siguientes acciones lógicas para los 8 catálogos maestros:

### Áreas (`CatAreas`)
*   `POST /catalogo/area/desactivar/<id>`: Desactivación lógica (`activo = 0`).
*   `GET/POST /catalogo/area/editar/<id>`: Modifica nombre y descripción.

### Líneas (`CatLineas`)
*   `POST /catalogo/linea/desactivar/<id>`: Desactivación lógica.
*   `GET/POST /catalogo/linea/editar/<id>`: Modifica área de pertenencia y nombre.

### Estaciones (`CatEstaciones`)
*   `POST /catalogo/estacion/desactivar/<id>`: Desactivación lógica.
*   `GET/POST /catalogo/estacion/editar/<id>`: Modifica línea de pertenencia, nombre y código QR.

### Equipos (`CatEquipos`)
*   `POST /catalogo/equipo/desactivar/<id>`: Desactivación lógica.
*   `GET/POST /catalogo/equipo/editar/<id>`: Modifica estación, tipo, nombre, modelo y número de serie.

### Usuarios (`CatUsuarios`)
*   `POST /catalogo/usuario/desactivar/<id>`: Desactivación lógica.
*   `GET/POST /catalogo/usuario/editar/<id>`: Modifica no. de empleado, nombre, correo, rol, área, turno y actualiza opcionalmente el PIN si se ingresa uno nuevo (resguardando el hash de seguridad).

### Turnos (`CatTurnos`)
*   `POST /catalogo/turno/desactivar/<id>`: Desactivación lógica.
*   `GET/POST /catalogo/turno/editar/<id>`: Modifica nombre, hora de inicio y fin.

### Roles (`CatRoles`)
*   `POST /catalogo/rol/desactivar/<id>`: Desactivación lógica.
*   `GET/POST /catalogo/rol/editar/<id>`: Modifica nombre y descripción.

### Fallas Comunes (`CatModosFallaReal`)
*   `POST /catalogo/falla/desactivar/<id>`: Desactivación lógica.
*   `GET/POST /catalogo/falla/editar/<id>`: Modifica tipo de equipo, código de falla, nombre y descripción.

---

## 3. Plan de Verificación

1.  **Validación de Rutas de Edición**: Probar de forma individual la carga de la vista de edición para cada catálogo, verificando que los inputs y selectores se pre-seleccionen correctamente con la información existente de la base de datos.
2.  **Verificación de Desactivación AJAX**: En la vista de listado, hacer clic en desactivar, confirmar en el diálogo de SweetAlert2 y comprobar que la fila desaparezca y que el campo `activo` se registre como `0` en la tabla física de SQL Server.
3.  **Gobernación de Roles**: Acceder con un usuario con rol de **Ingeniero** y confirmar que no pueda ver la pestaña de usuarios, turnos o roles, ni forzar el acceso a las rutas `/catalogo/usuario/editar` o desactivar, recibiendo redirección inmediata.

# Plan de Implementación: Estructura del Proyecto Web CMMS (Flask)

Este documento detalla el plan para crear y configurar la estructura inicial del proyecto web CMMS en Python utilizando el micro-framework **Flask**, bajo las especificaciones técnicas definidas en el proyecto de manufactura.

---

## 1. Decisiones de Diseño Acordadas

*   **Acceso a Base de Datos**: Uso de `pyodbc` puro para ejecutar sentencias T-SQL directas e invocar procedimientos almacenados transaccionales en **SQL Server 2017 (v14.0)**, sin ORM (SQLAlchemy).
*   **Autenticación**: Autenticación rápida integrada mediante **Flask-Login**, validando el número de empleado (`NoEmpleado`) y un código PIN o contraseña simple.
*   **Estructura Modular**: Implementación de **Blueprints** independientes para separar la lógica de negocio por roles y APIs.
*   **Gestión de Logs**: Logging rotativo basado en archivos físicos de 10MB (`RotatingFileHandler`) guardados en una carpeta `/logs`.
*   **Descargas de Archivos**: Acceso controlado a manuales, videos y evidencias de fallas a través de un endpoint en Flask que valida la sesión activa antes de transmitir los archivos desde la ruta de red UNC.

---

## 2. Estructura de Directorios Propuesta

El proyecto se estructurará siguiendo el patrón **Application Factory** para garantizar modularidad y escalabilidad:

```
proyecto_cmms/
│
├── run.py                      # Punto de entrada para iniciar la aplicación Flask
├── requirements.txt            # Dependencias del proyecto (Flask, pyodbc, Flask-Login, cryptography)
│
├── app/                        # Paquete principal de la aplicación
│   ├── __init__.py             # Inicialización de Flask, Logging, LoginManager y Blueprints
│   ├── config.py               # Variables de entorno y configuración de conexión ODBC
│   ├── db.py                   # Manejador de conexiones seguras a SQL Server con pyodbc
│   ├── models.py               # Definición de la clase User para el soporte de Flask-Login
│   │
│   ├── blueprints/             # Módulos y controladores de negocio (Blueprints)
│   │   ├── auth/               # Inicio de sesión (NoEmpleado y PIN)
│   │   │   ├── __init__.py
│   │   │   └── routes.py
│   │   ├── lider/              # Interfaz para líderes (Creación de OTs y Down Time inicial)
│   │   │   ├── __init__.py
│   │   │   └── routes.py
│   │   ├── tecnico/            # Interfaz móvil para tablets (QR, pausas, handovers)
│   │   │   ├── __init__.py
│   │   │   └── routes.py
│   │   ├── ingenieria/         # Dashboard de KPIs (MTTR, MTBF) y calendario FullCalendar
│   │   │   ├── __init__.py
│   │   │   └── routes.py
│   │   ├── catalogo/           # Pantallas CRUD para administración de activos de planta
│   │   │   ├── __init__.py
│   │   │   └── routes.py
│   │   └── api/                # Endpoints JSON para llamadas dinámicas (Fetch/AJAX, subida de fotos)
│   │       ├── __init__.py
│   │       └── routes.py
│   │
│   ├── static/                 # Recursos públicos en el cliente web
│   │   ├── css/
│   │   │   └── main.css        # Estilos responsivos adaptados para tablets industriales
│   │   ├── js/
│   │   │   └── main.js         # Lógicas JS (PWA, scanner, manejadores AJAX)
│   │   └── vendor/             # Librerías open-source (html5-qrcode, chart.js, fullcalendar, datatables)
│   │
│   ├── templates/              # Plantillas HTML procesadas por el motor Jinja2
│   │   ├── base.html           # Estructura común del sitio (Navbar, scripts del vendor, alertas flash)
│   │   ├── auth/
│   │   │   └── login.html      # Pantalla táctil de inicio de sesión
│   │   ├── lider/
│   │   │   └── crear_ot.html   # Formulario con clasificaciones de Down Time y 4Ms
│   │   ├── tecnico/
│   │   │   ├── panel.html      # Bandeja de OTs pendientes
│   │   │   └── atencion.html   # Panel de soporte con scanner, manuales y evidencias
│   │   └── ingenieria/
│   │       ├── dashboard.html  # Métricas de Down Time y gráficos de KPIs
│   │       └── calendario.html # Calendario interactivo de preventivos programados
│   │
│   └── logs/                   # Almacenamiento de archivos de trazas operativas
│       └── app.log
```

---

## 3. Detalle de Archivos de Configuración y Clases Core

A continuación, se define la estructura lógica recomendada para los archivos principales de inicialización:

### A. Archivo `requirements.txt`
```text
Flask==2.3.3
Flask-Login==0.6.2
pyodbc==4.0.39
Werkzeug==2.3.7
cryptography==41.0.3
python-dotenv==1.0.0
```

### B. Clase de Usuario en `app/models.py`
Para integrar **Flask-Login** sin un ORM, mapeamos manualmente los registros retornados de la base de datos a una clase de usuario personalizada:
```python
from flask_login import UserMixin

class User(UserMixin):
    def __init__(self, user_id, no_empleado, nombre, rol_nombre, area_id, turno_id):
        self.id = user_id
        self.no_empleado = no_empleado
        self.nombre = nombre
        self.rol = rol_nombre
        self.area_id = area_id
        self.turno_id = turno_id

    @staticmethod
    def get(user_id, conn):
        """Busca el usuario en SQL Server mediante pyodbc"""
        cursor = conn.cursor()
        cursor.execute("""
            SELECT u.ID, u.NoEmpleado, u.Nombre, r.Nombre AS RolNombre, u.AreaID, u.TurnoID 
            FROM CatUsuarios u
            INNER JOIN CatRoles r ON u.RolID = r.ID
            WHERE u.ID = ? AND u.activo = 1
        """, (user_id,))
        row = cursor.fetchone()
        if row:
            return User(row[0], row[1], row[2], row[3], row[4], row[5])
        return None
```

### C. Factoría de Aplicación `app/__init__.py`
Configuración del logger rotativo, inicialización del manager de sesión, registro de Blueprints y el cargador de usuario:
```python
import os
import logging
from logging.handlers import RotatingFileHandler
from flask import Flask
from flask_login import LoginManager
from app.config import Config
from app.db import get_db_connection
from app.models import User

login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message_category = 'warning'

@login_manager.user_loader
def load_user(user_id):
    conn = get_db_connection()
    user = User.get(int(user_id), conn)
    conn.close()
    return user

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # 1. Configuración de Logging Rotativo
    if not os.path.exists('app/logs'):
        os.makedirs('app/logs')
        
    file_handler = RotatingFileHandler(
        'app/logs/app.log', maxBytes=10*1024*1024, backupCount=5, encoding='utf-8'
    )
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
    ))
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
    app.logger.setLevel(logging.INFO)
    app.logger.info('Inicio de la aplicación CMMS')

    # 2. Inicializar Login Manager
    login_manager.init_app(app)

    # 3. Registrar Blueprints
    from app.blueprints.auth.routes import auth_bp
    from app.blueprints.lider.routes import lider_bp
    from app.blueprints.tecnico.routes import tecnico_bp
    from app.blueprints.ingenieria.routes import ingenieria_bp
    from app.blueprints.catalogo.routes import catalogo_bp
    from app.blueprints.api.routes import api_bp

    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(lider_bp, url_prefix='/lider')
    app.register_blueprint(tecnico_bp, url_prefix='/tecnico')
    app.register_blueprint(ingenieria_bp, url_prefix='/ingenieria')
    app.register_blueprint(catalogo_bp, url_prefix='/catalogo')
    app.register_blueprint(api_bp, url_prefix='/api')

    return app
```

---

## 4. Plan de Verificación

Para corroborar la correcta creación e integración del andamiaje del proyecto web, se realizarán las siguientes pruebas una vez creados los archivos:
1.  **Ejecución del Servidor**: Arrancar el servidor en local mediante `python run.py` y verificar en consola la salida del puerto de desarrollo (5000) y que no existan errores de importación circular en los Blueprints.
2.  **Verificación del Log**: Corroborar la generación automática de la carpeta `app/logs` y el archivo `app.log` con la traza inicial del sistema.
3.  **Comprobación de Rutas Base**: Realizar peticiones HTTP GET a las rutas `/auth/login` y `/api/ot/pendientes` para comprobar que los Blueprints estén correctamente ruteados y protegidos según corresponda.

-- ============================================================
-- Project Management Application
-- SQLite Compatible Schema
-- Converted from SQL Server 2016+
-- ============================================================

PRAGMA foreign_keys = ON;

-- ============================================================
-- 1. ROLES
-- ============================================================

DROP TABLE IF EXISTS roles;

CREATE TABLE roles (
    id               INTEGER        NOT NULL PRIMARY KEY AUTOINCREMENT,
    name             TEXT           NOT NULL,
    description      TEXT           NULL,
    permissions_json TEXT           NULL,
    created_at       TEXT           NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),

    CONSTRAINT UQ_roles_name UNIQUE (name)
);

-- ============================================================
-- 2. USERS
-- ============================================================

DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id            INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
    username      TEXT     NOT NULL,
    email         TEXT     NOT NULL,
    password_hash TEXT     NOT NULL,
    full_name     TEXT     NULL,
    avatar_url    TEXT     NULL,
    role_id       INTEGER  NOT NULL,
    is_active     INTEGER  NOT NULL DEFAULT 1,  -- 0=false, 1=true
    last_login    TEXT     NULL,
    created_at    TEXT     NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at    TEXT     NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),

    CONSTRAINT UQ_users_username UNIQUE (username),
    CONSTRAINT UQ_users_email    UNIQUE (email),
    CONSTRAINT FK_users_role     FOREIGN KEY (role_id) REFERENCES roles(id)
);

CREATE INDEX IX_users_role_id   ON users (role_id);
CREATE INDEX IX_users_email     ON users (email);
CREATE INDEX IX_users_is_active ON users (is_active);

-- ============================================================
-- 3. WORKSPACES
-- ============================================================

DROP TABLE IF EXISTS workspaces;

CREATE TABLE workspaces (
    id          INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
    name        TEXT     NOT NULL,
    slug        TEXT     NOT NULL,
    description TEXT     NULL,
    owner_id    INTEGER  NOT NULL,
    created_at  TEXT     NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at  TEXT     NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),

    CONSTRAINT UQ_workspaces_slug  UNIQUE (slug),
    CONSTRAINT FK_workspaces_owner FOREIGN KEY (owner_id) REFERENCES users(id)
);

CREATE INDEX IX_workspaces_owner_id ON workspaces (owner_id);
CREATE INDEX IX_workspaces_slug     ON workspaces (slug);

-- ============================================================
-- 4. WORKSPACE MEMBERS
-- ============================================================

DROP TABLE IF EXISTS workspace_members;

CREATE TABLE workspace_members (
    id           INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
    workspace_id INTEGER  NOT NULL,
    user_id      INTEGER  NOT NULL,
    role_id      INTEGER  NOT NULL,
    joined_at    TEXT     NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),

    CONSTRAINT UQ_workspace_members_pair UNIQUE (workspace_id, user_id),
    CONSTRAINT FK_wm_workspace FOREIGN KEY (workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE,
    CONSTRAINT FK_wm_user      FOREIGN KEY (user_id)      REFERENCES users(id)      ON DELETE NO ACTION,
    CONSTRAINT FK_wm_role      FOREIGN KEY (role_id)      REFERENCES roles(id)      ON DELETE NO ACTION
);

CREATE INDEX IX_wm_workspace_id ON workspace_members (workspace_id);
CREATE INDEX IX_wm_user_id      ON workspace_members (user_id);

-- ============================================================
-- 5. PROJECTS
-- ============================================================

DROP TABLE IF EXISTS projects;

CREATE TABLE projects (
    id               INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
    workspace_id     INTEGER  NOT NULL,
    name             TEXT     NOT NULL,
    slug             TEXT     NOT NULL,
    description      TEXT     NULL,
    status           TEXT     NOT NULL DEFAULT 'planning',
    priority         TEXT     NOT NULL DEFAULT 'medium',
    start_date       TEXT     NULL,  -- stored as 'YYYY-MM-DD'
    end_date         TEXT     NULL,  -- stored as 'YYYY-MM-DD'
    progress_percent REAL     NOT NULL DEFAULT 0.00,
    owner_id         INTEGER  NOT NULL,
    color_hex        TEXT     NOT NULL DEFAULT '#20808D',
    created_at       TEXT     NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at       TEXT     NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),

    CONSTRAINT UQ_projects_workspace_slug UNIQUE (workspace_id, slug),
    CONSTRAINT FK_projects_workspace FOREIGN KEY (workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE,
    CONSTRAINT FK_projects_owner     FOREIGN KEY (owner_id)     REFERENCES users(id)      ON DELETE NO ACTION,
    CONSTRAINT CK_projects_status    CHECK (status   IN ('planning', 'active', 'on_hold', 'completed', 'cancelled')),
    CONSTRAINT CK_projects_priority  CHECK (priority IN ('low', 'medium', 'high', 'critical')),
    CONSTRAINT CK_projects_progress  CHECK (progress_percent BETWEEN 0.00 AND 100.00)
);

CREATE INDEX IX_projects_workspace_id ON projects (workspace_id);
CREATE INDEX IX_projects_owner_id     ON projects (owner_id);
CREATE INDEX IX_projects_status       ON projects (status);
CREATE INDEX IX_projects_priority     ON projects (priority);

-- ============================================================
-- 6. PROJECT MEMBERS
-- ============================================================

DROP TABLE IF EXISTS project_members;

CREATE TABLE project_members (
    id          INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
    project_id  INTEGER  NOT NULL,
    user_id     INTEGER  NOT NULL,
    role_id     INTEGER  NOT NULL,
    assigned_at TEXT     NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),

    CONSTRAINT UQ_project_members_pair UNIQUE (project_id, user_id),
    CONSTRAINT FK_pm_project FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    CONSTRAINT FK_pm_user    FOREIGN KEY (user_id)    REFERENCES users(id)    ON DELETE NO ACTION,
    CONSTRAINT FK_pm_role    FOREIGN KEY (role_id)    REFERENCES roles(id)    ON DELETE NO ACTION
);

CREATE INDEX IX_pm_project_id ON project_members (project_id);
CREATE INDEX IX_pm_user_id    ON project_members (user_id);

-- ============================================================
-- 7. EPICS
-- ============================================================

DROP TABLE IF EXISTS epics;

CREATE TABLE epics (
    id          INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
    project_id  INTEGER  NOT NULL,
    name        TEXT     NOT NULL,
    description TEXT     NULL,
    status      TEXT     NOT NULL DEFAULT 'planning',
    start_date  TEXT     NULL,
    end_date    TEXT     NULL,
    color_hex   TEXT     NOT NULL DEFAULT '#7A39BB',
    created_at  TEXT     NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),

    CONSTRAINT FK_epics_project FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    CONSTRAINT CK_epics_status  CHECK (status IN ('planning', 'active', 'on_hold', 'completed', 'cancelled'))
);

CREATE INDEX IX_epics_project_id ON epics (project_id);
CREATE INDEX IX_epics_status     ON epics (status);

-- ============================================================
-- 8. SPRINTS
-- ============================================================

DROP TABLE IF EXISTS sprints;

CREATE TABLE sprints (
    id         INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER  NOT NULL,
    name       TEXT     NOT NULL,
    goal       TEXT     NULL,
    status     TEXT     NOT NULL DEFAULT 'planned',
    start_date TEXT     NULL,
    end_date   TEXT     NULL,
    created_at TEXT     NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),

    CONSTRAINT FK_sprints_project FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    CONSTRAINT CK_sprints_status  CHECK (status IN ('planned', 'active', 'completed'))
);

CREATE INDEX IX_sprints_project_id ON sprints (project_id);
CREATE INDEX IX_sprints_status     ON sprints (status);

-- ============================================================
-- 9. TASK STATUSES
-- ============================================================

DROP TABLE IF EXISTS task_statuses;

CREATE TABLE task_statuses (
    id          INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
    project_id  INTEGER  NOT NULL,
    name        TEXT     NOT NULL,
    color_hex   TEXT     NOT NULL DEFAULT '#BAB9B4',
    order_index INTEGER  NOT NULL DEFAULT 0,
    is_default  INTEGER  NOT NULL DEFAULT 0,  -- 0=false, 1=true
    category    TEXT     NOT NULL DEFAULT 'todo',

    CONSTRAINT UQ_task_statuses_pair        UNIQUE (project_id, name),
    CONSTRAINT FK_task_statuses_project     FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    CONSTRAINT CK_task_statuses_category    CHECK (category IN ('todo', 'in_progress', 'done'))
);

CREATE INDEX IX_task_statuses_project_id ON task_statuses (project_id);
CREATE INDEX IX_task_statuses_category   ON task_statuses (category);

-- ============================================================
-- 10. TASKS
-- ============================================================

DROP TABLE IF EXISTS tasks;

CREATE TABLE tasks (
    id              INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
    project_id      INTEGER  NOT NULL,
    epic_id         INTEGER  NULL,
    sprint_id       INTEGER  NULL,
    parent_task_id  INTEGER  NULL,
    title           TEXT     NOT NULL,
    description     TEXT     NULL,
    type            TEXT     NOT NULL DEFAULT 'task',
    status_id       INTEGER  NOT NULL,
    priority        TEXT     NOT NULL DEFAULT 'medium',
    assignee_id     INTEGER  NULL,
    reporter_id     INTEGER  NOT NULL,
    estimated_hours REAL     NULL,
    actual_hours    REAL     NOT NULL DEFAULT 0.00,
    due_date        TEXT     NULL,
    start_date      TEXT     NULL,
    order_index     INTEGER  NOT NULL DEFAULT 0,
    created_at      TEXT     NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at      TEXT     NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),

    CONSTRAINT FK_tasks_project  FOREIGN KEY (project_id)     REFERENCES projects(id)      ON DELETE CASCADE,
    CONSTRAINT FK_tasks_epic     FOREIGN KEY (epic_id)        REFERENCES epics(id)         ON DELETE NO ACTION,
    CONSTRAINT FK_tasks_sprint   FOREIGN KEY (sprint_id)      REFERENCES sprints(id)       ON DELETE NO ACTION,
    CONSTRAINT FK_tasks_parent   FOREIGN KEY (parent_task_id) REFERENCES tasks(id)         ON DELETE NO ACTION,
    CONSTRAINT FK_tasks_status   FOREIGN KEY (status_id)      REFERENCES task_statuses(id) ON DELETE NO ACTION,
    CONSTRAINT FK_tasks_assignee FOREIGN KEY (assignee_id)    REFERENCES users(id)         ON DELETE NO ACTION,
    CONSTRAINT FK_tasks_reporter FOREIGN KEY (reporter_id)    REFERENCES users(id)         ON DELETE NO ACTION,
    CONSTRAINT CK_tasks_type     CHECK (type     IN ('task', 'bug', 'feature', 'story')),
    CONSTRAINT CK_tasks_priority CHECK (priority IN ('low', 'medium', 'high', 'critical'))
);

CREATE INDEX IX_tasks_project_id     ON tasks (project_id);
CREATE INDEX IX_tasks_epic_id        ON tasks (epic_id);
CREATE INDEX IX_tasks_sprint_id      ON tasks (sprint_id);
CREATE INDEX IX_tasks_status_id      ON tasks (status_id);
CREATE INDEX IX_tasks_assignee_id    ON tasks (assignee_id);
CREATE INDEX IX_tasks_reporter_id    ON tasks (reporter_id);
CREATE INDEX IX_tasks_parent_task_id ON tasks (parent_task_id);
CREATE INDEX IX_tasks_priority       ON tasks (priority);
CREATE INDEX IX_tasks_due_date       ON tasks (due_date);
CREATE INDEX IX_tasks_type           ON tasks (type);

-- ============================================================
-- 11. TASK LABELS
-- ============================================================

DROP TABLE IF EXISTS task_labels;

CREATE TABLE task_labels (
    id         INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
    name       TEXT     NOT NULL,
    color_hex  TEXT     NOT NULL DEFAULT '#20808D',
    project_id INTEGER  NOT NULL,

    CONSTRAINT UQ_task_labels_pair     UNIQUE (project_id, name),
    CONSTRAINT FK_task_labels_project  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

CREATE INDEX IX_task_labels_project_id ON task_labels (project_id);

-- ============================================================
-- 12. TASK LABEL MAP
-- ============================================================

DROP TABLE IF EXISTS task_label_map;

CREATE TABLE task_label_map (
    task_id  INTEGER NOT NULL,
    label_id INTEGER NOT NULL,

    CONSTRAINT PK_task_label_map PRIMARY KEY (task_id, label_id),
    CONSTRAINT FK_tlm_task  FOREIGN KEY (task_id)  REFERENCES tasks(id)       ON DELETE CASCADE,
    CONSTRAINT FK_tlm_label FOREIGN KEY (label_id) REFERENCES task_labels(id) ON DELETE NO ACTION
);

CREATE INDEX IX_tlm_label_id ON task_label_map (label_id);

-- ============================================================
-- 13. TASK DEPENDENCIES
-- ============================================================

DROP TABLE IF EXISTS task_dependencies;

CREATE TABLE task_dependencies (
    id                 INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
    task_id            INTEGER  NOT NULL,
    depends_on_task_id INTEGER  NOT NULL,
    dependency_type    TEXT     NOT NULL DEFAULT 'finish_to_start',

    CONSTRAINT UQ_task_dep_pair  UNIQUE (task_id, depends_on_task_id),
    CONSTRAINT FK_td_task        FOREIGN KEY (task_id)            REFERENCES tasks(id) ON DELETE CASCADE,
    CONSTRAINT FK_td_depends_on  FOREIGN KEY (depends_on_task_id) REFERENCES tasks(id) ON DELETE NO ACTION,
    CONSTRAINT CK_td_type        CHECK (dependency_type IN (
        'finish_to_start', 'start_to_start', 'finish_to_finish', 'start_to_finish'
    )),
    CONSTRAINT CK_td_no_self     CHECK (task_id <> depends_on_task_id)
);

CREATE INDEX IX_td_task_id            ON task_dependencies (task_id);
CREATE INDEX IX_td_depends_on_task_id ON task_dependencies (depends_on_task_id);

-- ============================================================
-- 14. TASK WATCHERS
-- ============================================================

DROP TABLE IF EXISTS task_watchers;

CREATE TABLE task_watchers (
    task_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,

    CONSTRAINT PK_task_watchers PRIMARY KEY (task_id, user_id),
    CONSTRAINT FK_tw_task FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE,
    CONSTRAINT FK_tw_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE NO ACTION
);

CREATE INDEX IX_tw_user_id ON task_watchers (user_id);

-- ============================================================
-- 15. COMMENTS
-- ============================================================

DROP TABLE IF EXISTS comments;

CREATE TABLE comments (
    id                INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
    task_id           INTEGER  NOT NULL,
    user_id           INTEGER  NOT NULL,
    content           TEXT     NOT NULL,
    parent_comment_id INTEGER  NULL,
    created_at        TEXT     NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at        TEXT     NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    is_deleted        INTEGER  NOT NULL DEFAULT 0,  -- 0=false, 1=true

    CONSTRAINT FK_comments_task   FOREIGN KEY (task_id)           REFERENCES tasks(id)    ON DELETE CASCADE,
    CONSTRAINT FK_comments_user   FOREIGN KEY (user_id)           REFERENCES users(id)    ON DELETE NO ACTION,
    CONSTRAINT FK_comments_parent FOREIGN KEY (parent_comment_id) REFERENCES comments(id) ON DELETE NO ACTION
);

CREATE INDEX IX_comments_task_id           ON comments (task_id);
CREATE INDEX IX_comments_user_id           ON comments (user_id);
CREATE INDEX IX_comments_parent_comment_id ON comments (parent_comment_id);
CREATE INDEX IX_comments_is_deleted        ON comments (is_deleted);

-- ============================================================
-- 16. ACTIVITY LOG
-- ============================================================

DROP TABLE IF EXISTS activity_log;

CREATE TABLE activity_log (
    id          INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
    entity_type TEXT     NOT NULL,
    entity_id   INTEGER  NOT NULL,
    user_id     INTEGER  NOT NULL,
    action      TEXT     NOT NULL,
    old_value   TEXT     NULL,
    new_value   TEXT     NULL,
    created_at  TEXT     NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),

    CONSTRAINT FK_al_user          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE NO ACTION,
    CONSTRAINT CK_al_entity_type   CHECK (entity_type IN ('task', 'project', 'sprint', 'epic', 'workspace'))
);

CREATE INDEX IX_al_entity     ON activity_log (entity_type, entity_id);
CREATE INDEX IX_al_user_id    ON activity_log (user_id);
CREATE INDEX IX_al_created_at ON activity_log (created_at DESC);

-- ============================================================
-- 17. ATTACHMENTS
-- ============================================================

DROP TABLE IF EXISTS attachments;

CREATE TABLE attachments (
    id         INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
    task_id    INTEGER  NOT NULL,
    user_id    INTEGER  NOT NULL,
    filename   TEXT     NOT NULL,
    file_path  TEXT     NOT NULL,
    file_size  INTEGER  NOT NULL DEFAULT 0,
    mime_type  TEXT     NULL,
    created_at TEXT     NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),

    CONSTRAINT FK_att_task FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE,
    CONSTRAINT FK_att_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE NO ACTION
);

CREATE INDEX IX_att_task_id ON attachments (task_id);
CREATE INDEX IX_att_user_id ON attachments (user_id);

-- ============================================================
-- 18. TIME LOGS
-- ============================================================

DROP TABLE IF EXISTS time_logs;

CREATE TABLE time_logs (
    id          INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
    task_id     INTEGER  NOT NULL,
    user_id     INTEGER  NOT NULL,
    description TEXT     NULL,
    hours       REAL     NOT NULL,
    logged_date TEXT     NOT NULL,  -- stored as 'YYYY-MM-DD'
    created_at  TEXT     NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),

    CONSTRAINT FK_tl_task  FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE,
    CONSTRAINT FK_tl_user  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE NO ACTION,
    CONSTRAINT CK_tl_hours CHECK (hours > 0 AND hours <= 24)
);

CREATE INDEX IX_tl_task_id     ON time_logs (task_id);
CREATE INDEX IX_tl_user_id     ON time_logs (user_id);
CREATE INDEX IX_tl_logged_date ON time_logs (logged_date DESC);

-- ============================================================
-- 19. NOTIFICATIONS
-- ============================================================

DROP TABLE IF EXISTS notifications;

CREATE TABLE notifications (
    id          INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER  NOT NULL,
    type        TEXT     NOT NULL,
    title       TEXT     NOT NULL,
    message     TEXT     NOT NULL,
    entity_type TEXT     NULL,
    entity_id   INTEGER  NULL,
    is_read     INTEGER  NOT NULL DEFAULT 0,  -- 0=false, 1=true
    created_at  TEXT     NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),

    CONSTRAINT FK_notif_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IX_notif_user_id ON notifications (user_id);
CREATE INDEX IX_notif_is_read ON notifications (user_id, is_read);
CREATE INDEX IX_notif_created ON notifications (created_at DESC);

-- ============================================================
-- SEED DATA
-- ============================================================

-- Roles
INSERT INTO roles (id, name, description, permissions_json) VALUES
(1, 'admin', 'Full system access', '{"all": true}'),
(2, 'project_manager', 'Manage projects, assign tasks, manage sprints',
    '{"projects": ["create","read","update","delete"], "tasks": ["create","read","update","delete"], "sprints": ["create","read","update","delete"], "members": ["add","remove"], "reports": ["read"]}'),
(3, 'developer', 'Work on assigned tasks, log time, comment',
    '{"projects": ["read"], "tasks": ["create","read","update"], "sprints": ["read"], "time_logs": ["create","read","update","delete"], "comments": ["create","read","update","delete"]}'),
(4, 'viewer', 'Read-only access to assigned projects',
    '{"projects": ["read"], "tasks": ["read"], "sprints": ["read"], "comments": ["read"]}');

-- Admin user (password: Admin123! - bcrypt hash placeholder)
INSERT INTO users (id, username, email, password_hash, full_name, role_id, is_active) VALUES
(1, 'admin', 'admin@pm-app.local',
    '$2b$12$placeholder_replace_with_real_bcrypt_hash_admin',
    'System Admin', 1, 1);

-- Default workspace
INSERT INTO workspaces (id, name, slug, description, owner_id) VALUES
(1, 'Default Workspace', 'default', 'Default workspace created on setup', 1);

-- Admin as workspace member
INSERT INTO workspace_members (workspace_id, user_id, role_id) VALUES (1, 1, 1);

-- Sample project
INSERT INTO projects (id, workspace_id, name, slug, description, status, priority, owner_id, color_hex) VALUES
(1, 1, 'Sample Project', 'sample-project', 'Initial demo project', 'active', 'medium', 1, '#20808D');

-- Default task statuses for sample project
INSERT INTO task_statuses (project_id, name, color_hex, order_index, is_default, category) VALUES
(1, 'Backlog',     '#BAB9B4', 0, 0, 'todo'),
(1, 'To Do',       '#006494', 1, 1, 'todo'),
(1, 'In Progress', '#DA7101', 2, 0, 'in_progress'),
(1, 'In Review',   '#7A39BB', 3, 0, 'in_progress'),
(1, 'Done',        '#437A22', 4, 0, 'done');

-- Admin as project member
INSERT INTO project_members (project_id, user_id, role_id) VALUES (1, 1, 1);

SELECT 'Schema created and seed data inserted successfully.' AS result;

"""
Epics HTML routes.
All routes require authentication via @login_required.
"""

from flask import render_template, abort
from flask_login import current_user, login_required

from app.database.models import Epic, Project, ProjectMember, Task, TaskStatus
from app.extensions import db
from app.epics import epics_bp


# ------------------------------------------------------------------ #
# Helpers
# ------------------------------------------------------------------ #

def _get_project_or_403(project_id):
    """Return project if current user is a member, else abort 403."""
    project = Project.query.get_or_404(project_id)
    member = ProjectMember.query.filter_by(
        project_id=project_id, user_id=current_user.id
    ).first()
    if not member:
        abort(403)
    return project, member


def _get_epic_or_403(epic_id):
    """Return (epic, project, member) or abort."""
    epic    = Epic.query.get_or_404(epic_id)
    project = Project.query.get_or_404(epic.project_id)
    member  = ProjectMember.query.filter_by(
        project_id=epic.project_id, user_id=current_user.id
    ).first()
    if not member:
        abort(403)
    return epic, project, member


def _is_manager(member):
    role = member.role.name.lower() if member and member.role else ""
    return role in ("project_manager", "admin", "owner")


def _epic_stats_for_template(epic):
    """Return stats dict for a single epic."""
    all_tasks = epic.tasks.all()
    total = len(all_tasks)
    done = sum(
        1 for t in all_tasks if t.status and t.status.category == "done"
    )
    progress = round((done / total * 100), 1) if total else 0.0
    total_estimated = sum(
        float(t.estimated_hours) for t in all_tasks if t.estimated_hours
    )
    total_actual = sum(float(t.actual_hours) for t in all_tasks)
    return {
        "total":             total,
        "done":              done,
        "progress":          progress,
        "total_estimated":   round(total_estimated, 2),
        "total_actual":      round(total_actual, 2),
    }


# ------------------------------------------------------------------ #
# GET /projects/<project_id>/epics
# ------------------------------------------------------------------ #

@epics_bp.get("/projects/<int:project_id>/epics")
@login_required
def list_epics(project_id):
    project, member = _get_project_or_403(project_id)
    print(f"DATO: PROJECT - TIPO DE DATO: {type(project)}\nDATO: MEMBER - TIPO DE DATO: {type(member)}")    
    epics = (
        Epic.query
        .filter_by(project_id=project_id)
        .order_by(
            db.case(
                (Epic.start_date.is_(None), 1),
                else_=0
            ),
            Epic.start_date.asc(),
            Epic.id.asc(),
        )
        .all()
    )
    print(f"DATO: EPICS - {epics} -TIPO DE DATO: {type(epics)}")
    epics_with_stats = []
    for e in epics:
        stats = _epic_stats_for_template(e)
        epics_with_stats.append({"epic": e, "stats": stats})
    print(f"DATO: EPICS_WITH_STATS - TIPO DE DATO: {type(epics_with_stats)}")
    return render_template(
        "epics/list.html",
        project=project,
        epics_with_stats=epics_with_stats,
        is_manager=_is_manager(member),
    )


# ------------------------------------------------------------------ #
# GET /epics/<epic_id>
# ------------------------------------------------------------------ #

@epics_bp.get("/epics/<int:epic_id>")
@login_required
def epic_detail(epic_id):
    epic, project, member = _get_epic_or_403(epic_id)

    statuses = (
        TaskStatus.query
        .filter_by(project_id=project.id)
        .order_by(TaskStatus.order_index.asc())
        .all()
    )

    stats = _epic_stats_for_template(epic)

    return render_template(
        "epics/detail.html",
        epic=epic,
        project=project,
        statuses=statuses,
        stats=stats,
        is_manager=_is_manager(member),
    )

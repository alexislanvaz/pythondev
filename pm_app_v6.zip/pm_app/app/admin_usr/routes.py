"""
Admin Users HTML routes.
All routes restricted to role 'admin'.
"""

from flask import render_template, abort
from flask_login import current_user, login_required

from app.database.models import Role
from app.admin_usr import admin_usr_bp


def _require_admin():
    if not (
        current_user.is_authenticated
        and current_user.role
        and current_user.role.name.lower() == "admin"
    ):
        abort(403)


# ------------------------------------------------------------------ #
# GET /admin/users/
# ------------------------------------------------------------------ #

@admin_usr_bp.get("/")
@login_required
def user_list():
    _require_admin()
    roles = Role.query.order_by(Role.name).all()
    return render_template("admin_usr/list.html", roles=roles)

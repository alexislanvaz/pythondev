"""
Admin Users blueprint package.
Only accessible to users with role 'admin'.
"""

from flask import Blueprint

admin_usr_bp = Blueprint(
    "admin_usr",
    __name__,
    template_folder="templates",
    url_prefix="/admin/users",
)

from app.admin_usr import routes  # noqa: E402,F401

"""
Sprints HTML routes.
All routes require authentication via @login_required.
"""

from flask import render_template, abort
from flask_login import current_user, login_required

from app.database.models import Project, ProjectMember, Sprint, Task, TaskStatus
from app.extensions import db
from app.sprints import sprints_bp


# ------------------------------------------------------------------ #
# Helper
# ------------------------------------------------------------------ #

def _get_project_or_403(project_id):
    """Return project if current_user is a member, else abort 403."""
    project = Project.query.get_or_404(project_id)
    member = ProjectMember.query.filter_by(
        project_id=project_id, user_id=current_user.id
    ).first()
    if not member:
        abort(403)
    return project


def _get_sprint_or_403(sprint_id):
    """Return (sprint, project, member) or abort."""
    sprint  = Sprint.query.get_or_404(sprint_id)
    project = Project.query.get_or_404(sprint.project_id)
    member  = ProjectMember.query.filter_by(
        project_id=sprint.project_id, user_id=current_user.id
    ).first()
    if not member:
        abort(403)
    return sprint, project, member


def _is_manager(member):
    role = member.role.name.lower() if member and member.role else ""
    return role in ("project_manager", "admin", "owner")


def _sprint_stats(sprint):
    """Return a stats dict for a single sprint."""
    all_tasks   = sprint.tasks.all()
    total       = len(all_tasks)
    completed   = sum(
        1 for t in all_tasks if t.status and t.status.category == "done"
    )
    incomplete  = total - completed
    rate        = round((completed / total * 100), 1) if total else 0.0
    return {
        "total":           total,
        "completed":       completed,
        "incomplete":      incomplete,
        "completion_rate": rate,
    }


# ------------------------------------------------------------------ #
# GET /projects/<project_id>/sprints
# ------------------------------------------------------------------ #

@sprints_bp.get("/projects/<int:project_id>/sprints")
@login_required
def list_sprints(project_id):
    project = _get_project_or_403(project_id)

    member = ProjectMember.query.filter_by(
        project_id=project_id, user_id=current_user.id
    ).first()

    sprints = (
        Sprint.query
        .filter_by(project_id=project_id)
        .order_by(
            db.case(
                (Sprint.start_date.is_(None), 1),
                else_=0
            ),
            Sprint.start_date.asc(),
            Sprint.created_at.asc(),
        )
        .all()
    )

    active_sprint = next(
        (s for s in sprints if s.status == "active"),
        None
    )

    # Attach task-count stats to each sprint (avoids N+1 in template)
    sprints_with_stats = []
    for s in sprints:
        total    = s.tasks.count()
        done_cnt = (
            s.tasks
            .join(Task.status)
            .filter(TaskStatus.category == "done")
            .count()
        )
        progress = round((done_cnt / total * 100), 1) if total else 0.0
        sprints_with_stats.append({
            "sprint":   s,
            "total":    total,
            "done":     done_cnt,
            "progress": progress,
        })

    return render_template(
        "sprints/list.html",
        project=project,
        sprints_with_stats=sprints_with_stats,
        active_sprint=active_sprint,
        is_manager=_is_manager(member),
    )


# ------------------------------------------------------------------ #
# GET /sprints/<sprint_id>
# ------------------------------------------------------------------ #

@sprints_bp.get("/sprints/<int:sprint_id>")
@login_required
def sprint_board(sprint_id):
    sprint, project, member = _get_sprint_or_403(sprint_id)

    statuses = (
        TaskStatus.query
        .filter_by(project_id=project.id)
        .order_by(TaskStatus.order_index.asc())
        .all()
    )
    statuses_data = [s.to_dict() for s in statuses]
    return render_template(
        "sprints/board.html",
        sprint=sprint,
        project=project,
        statuses=statuses_data,
        is_manager=_is_manager(member),
    )


# ------------------------------------------------------------------ #
# GET /sprints/<sprint_id>/report
# ------------------------------------------------------------------ #

@sprints_bp.get("/sprints/<int:sprint_id>/report")
@login_required
def sprint_report(sprint_id):
    sprint, project, member = _get_sprint_or_403(sprint_id)

    if sprint.status != "completed":
        abort(404)

    stats    = _sprint_stats(sprint)
    all_tasks = sprint.tasks.all()
    completed_tasks   = [t for t in all_tasks if t.status and t.status.category == "done"]
    incomplete_tasks  = [t for t in all_tasks if not (t.status and t.status.category == "done")]

    # Duration in days
    duration = None
    if sprint.start_date and sprint.end_date:
        duration = (sprint.end_date - sprint.start_date).days

    return render_template(
        "sprints/report.html",
        sprint=sprint,
        project=project,
        stats=stats,
        completed_tasks=completed_tasks,
        incomplete_tasks=incomplete_tasks,
        duration=duration,
    )

"""
Projects API blueprint.
Prefix: /api/v1/projects  (registered via api_bp)
"""

from datetime import datetime
from flask import Blueprint, request, jsonify
from flask_login import current_user, login_required
from sqlalchemy import func

try:
    from slugify import slugify
except ImportError:
    import re
    def slugify(text):
        text = text.lower().strip()
        text = re.sub(r"[^\w\s-]", "", text)
        text = re.sub(r"[\s_-]+", "-", text)
        return re.sub(r"^-+|-+$", "", text)

from app.extensions import db
from app.database.models import (
    Project,
    ProjectMember,
    TaskStatus,
    TaskLabel,
    Task,
    Sprint,
    Epic,
    User,
)

projects_api_bp = Blueprint("projects_api", __name__, url_prefix="/v1/projects")


# ------------------------------------------------------------------ #
# Helpers
# ------------------------------------------------------------------ #

def _ok(data, meta=None):
    return jsonify({"data": data, "error": None, "meta": meta or {}})


def _err(message, status=400):
    return jsonify({"data": None, "error": message, "meta": {}}), status


def _is_member(project_id, user_id=None):
    uid = user_id or current_user.id
    return ProjectMember.query.filter_by(project_id=project_id, user_id=uid).first() is not None


def _member_role(project_id, user_id=None):
    uid = user_id or current_user.id
    pm = ProjectMember.query.filter_by(project_id=project_id, user_id=uid).first()
    return pm.role.name.lower() if pm and pm.role else None


def _project_summary(project):
    member_count = project.members.count()
    task_count   = project.tasks.count()
    owner = project.owner
    return {
        "id":               project.id,
        "name":             project.name,
        "slug":             project.slug,
        "status":           project.status,
        "priority":         project.priority,
        "progress_percent": float(project.progress_percent),
        "color_hex":        project.color_hex,
        "start_date":       project.start_date.isoformat() if project.start_date else None,
        "end_date":         project.end_date.isoformat()   if project.end_date   else None,
        "owner": {
            "id":   owner.id,
            "name": owner.full_name or owner.username,
        } if owner else None,
        "member_count": member_count,
        "task_count":   task_count,
    }


def _default_statuses():
    return [
        {"name": "Backlog",      "color_hex": "#7b80a0", "order_index": 0, "is_default": True,  "category": "todo"},
        {"name": "To Do",        "color_hex": "#4f6ef7", "order_index": 1, "is_default": False, "category": "todo"},
        {"name": "In Progress",  "color_hex": "#f0a429", "order_index": 2, "is_default": False, "category": "in_progress"},
        {"name": "In Review",    "color_hex": "#9b59b6", "order_index": 3, "is_default": False, "category": "in_progress"},
        {"name": "Done",         "color_hex": "#3ecf8e", "order_index": 4, "is_default": False, "category": "done"},
    ]


# ------------------------------------------------------------------ #
# GET /api/v1/projects
# ------------------------------------------------------------------ #

@projects_api_bp.get("")
@login_required
def list_projects():
    workspace_id = request.args.get("workspace_id", type=int)

    memberships = ProjectMember.query.filter_by(user_id=current_user.id).all()
    project_ids = [m.project_id for m in memberships]

    q = Project.query.filter(Project.id.in_(project_ids))
    if workspace_id:
        q = q.filter_by(workspace_id=workspace_id)

    projects = q.order_by(Project.name.asc()).all()
    return _ok([_project_summary(p) for p in projects])


# ------------------------------------------------------------------ #
# POST /api/v1/projects
# ------------------------------------------------------------------ #

@projects_api_bp.post("")
@login_required
def create_project():
    body = request.get_json(silent=True) or {}

    workspace_id = body.get("workspace_id")
    name         = (body.get("name") or "").strip()
    if not workspace_id or not name:
        return _err("workspace_id and name are required")

    base_slug = slugify(name)
    slug      = base_slug
    counter   = 1
    while Project.query.filter_by(workspace_id=workspace_id, slug=slug).first():
        slug = f"{base_slug}-{counter}"
        counter += 1

    project = Project(
        workspace_id=workspace_id,
        name=name,
        slug=slug,
        description=body.get("description"),
        status=body.get("status", "planning"),
        priority=body.get("priority", "medium"),
        start_date=_parse_date(body.get("start_date")),
        end_date=_parse_date(body.get("end_date")),
        color_hex=body.get("color_hex", "#4f6ef7"),
        owner_id=current_user.id,
    )
    db.session.add(project)
    db.session.flush()

    member = ProjectMember(
        project_id=project.id,
        user_id=current_user.id,
        role_id=current_user.role_id,
    )
    db.session.add(member)

    for s in _default_statuses():
        ts = TaskStatus(
            project_id=project.id,
            name=s["name"],
            color_hex=s["color_hex"],
            order_index=s["order_index"],
            is_default=s["is_default"],
            category=s["category"],
        )
        db.session.add(ts)

    db.session.commit()
    return _ok(_project_summary(project)), 201


def _parse_date(value):
    if not value:
        return None
    try:
        from datetime import date
        return date.fromisoformat(value)
    except (ValueError, TypeError):
        return None


# ------------------------------------------------------------------ #
# GET /api/v1/projects/<project_id>
# ------------------------------------------------------------------ #

@projects_api_bp.get("/<int:project_id>")
@login_required
def get_project(project_id):
    project = Project.query.get_or_404(project_id)
    if not _is_member(project_id):
        return _err("Forbidden", 403)

    members = [
        {
            "id":        pm.id,
            "user_id":   pm.user_id,
            "role_id":   pm.role_id,
            "role_name":  pm.role.name if pm.role else None,
            "full_name":  pm.user.full_name if pm.user else None,
            "avatar_url": pm.user.avatar_url if pm.user else None,
            "assigned_at": pm.assigned_at.isoformat(),
        }
        for pm in project.members.all()
    ]

    statuses = [s.to_dict() for s in
                project.task_statuses.order_by(TaskStatus.order_index.asc()).all()]

    active_sprints = [
        sp.to_dict()
        for sp in project.sprints.filter_by(status="active").all()
    ]

    epics = [e.to_dict() for e in project.epics.all()]

    data = project.to_dict()
    data["members"]        = members
    data["statuses"]       = statuses
    data["active_sprints"] = active_sprints
    data["epics"]          = epics

    return _ok(data)


# ------------------------------------------------------------------ #
# PATCH /api/v1/projects/<project_id>
# ------------------------------------------------------------------ #

@projects_api_bp.patch("/<int:project_id>")
@login_required
def update_project(project_id):
    project = Project.query.get_or_404(project_id)
    if not _is_member(project_id):
        return _err("Forbidden", 403)

    body = request.get_json(silent=True) or {}
    editable = {
        "name", "description", "status", "priority",
        "start_date", "end_date", "color_hex", "progress_percent",
    }
    for field in editable:
        if field not in body:
            continue
        if field in ("start_date", "end_date"):
            setattr(project, field, _parse_date(body[field]))
        else:
            setattr(project, field, body[field])

    project.updated_at = datetime.utcnow()
    db.session.commit()
    return _ok(_project_summary(project))


# ------------------------------------------------------------------ #
# GET /api/v1/projects/<project_id>/stats
# ------------------------------------------------------------------ #

@projects_api_bp.get("/<int:project_id>/stats")
@login_required
def project_stats(project_id):
    project = Project.query.get_or_404(project_id)
    if not _is_member(project_id):
        return _err("Forbidden", 403)

    from datetime import date
    today = date.today()

    rows = (
        db.session.query(
            TaskStatus.name,
            TaskStatus.color_hex,
            func.count(Task.id).label("count"),
        )
        .join(Task, Task.status_id == TaskStatus.id)
        .filter(Task.project_id == project_id)
        .group_by(TaskStatus.name, TaskStatus.color_hex)
        .all()
    )
    tasks_by_status = [
        {"status_name": r.name, "color": r.color_hex, "count": r.count}
        for r in rows
    ]

    rows2 = (
        db.session.query(Task.priority, func.count(Task.id).label("count"))
        .filter_by(project_id=project_id)
        .group_by(Task.priority)
        .all()
    )
    tasks_by_priority = [{"priority": r.priority, "count": r.count} for r in rows2]

    rows3 = (
        db.session.query(
            User.id,
            User.full_name,
            func.count(Task.id).label("count"),
        )
        .join(Task, Task.assignee_id == User.id)
        .filter(Task.project_id == project_id)
        .group_by(User.id, User.full_name)
        .all()
    )
    tasks_by_assignee = [
        {"user_id": r.id, "full_name": r.full_name, "count": r.count}
        for r in rows3
    ]

    overdue_count = (
        Task.query
        .join(TaskStatus, Task.status_id == TaskStatus.id)
        .filter(
            Task.project_id == project_id,
            Task.due_date < today,
            TaskStatus.category != "done",
        )
        .count()
    )

    hours = (
        db.session.query(
            func.sum(Task.estimated_hours).label("estimated"),
            func.sum(Task.actual_hours).label("actual"),
        )
        .filter(Task.project_id == project_id)
        .first()
    )

    return _ok({
        "tasks_by_status":       tasks_by_status,
        "tasks_by_priority":     tasks_by_priority,
        "tasks_by_assignee":     tasks_by_assignee,
        "overdue_count":         overdue_count,
        "total_estimated_hours": float(hours.estimated or 0),
        "total_actual_hours":    float(hours.actual or 0),
    })


# ================================================================== #
# STATUSES  /api/v1/projects/<project_id>/statuses
# ================================================================== #

@projects_api_bp.get("/<int:project_id>/statuses")
@login_required
def list_statuses(project_id):
    if not _is_member(project_id):
        return _err("Forbidden", 403)
    statuses = (
        TaskStatus.query
        .filter_by(project_id=project_id)
        .order_by(TaskStatus.order_index.asc())
        .all()
    )
    return _ok([s.to_dict() for s in statuses])


@projects_api_bp.post("/<int:project_id>/statuses")
@login_required
def create_status(project_id):
    if not _is_member(project_id):
        return _err("Forbidden", 403)

    body = request.get_json(silent=True) or {}
    name = (body.get("name") or "").strip()
    if not name:
        return _err("name is required")

    # Duplicate name check within the project
    exists = TaskStatus.query.filter_by(project_id=project_id, name=name).first()
    if exists:
        return _err(f'A status named "{name}" already exists in this project')

    # Place at end
    max_idx = db.session.query(func.max(TaskStatus.order_index))\
                        .filter_by(project_id=project_id).scalar() or -1

    status = TaskStatus(
        project_id  = project_id,
        name        = name,
        color_hex   = body.get("color_hex", "#4f6ef7"),
        category    = body.get("category", "todo"),
        is_default  = bool(body.get("is_default", False)),
        order_index = max_idx + 1,
    )
    db.session.add(status)

    # Only one status can be default
    if status.is_default:
        TaskStatus.query\
            .filter(TaskStatus.project_id == project_id,
                    TaskStatus.id != status.id)\
            .update({"is_default": False})

    db.session.commit()
    return _ok(status.to_dict()), 201


@projects_api_bp.patch("/<int:project_id>/statuses/<int:status_id>")
@login_required
def update_status(project_id, status_id):
    if not _is_member(project_id):
        return _err("Forbidden", 403)

    status = TaskStatus.query.filter_by(id=status_id, project_id=project_id).first_or_404()
    body   = request.get_json(silent=True) or {}

    name = (body.get("name") or "").strip()
    if name and name != status.name:
        exists = TaskStatus.query.filter_by(project_id=project_id, name=name).first()
        if exists:
            return _err(f'A status named "{name}" already exists in this project')
        status.name = name

    if "color_hex" in body:
        status.color_hex = body["color_hex"]
    if "category" in body and body["category"] in ("todo", "in_progress", "done"):
        status.category = body["category"]
    if "is_default" in body:
        status.is_default = bool(body["is_default"])
        if status.is_default:
            TaskStatus.query\
                .filter(TaskStatus.project_id == project_id,
                        TaskStatus.id != status_id)\
                .update({"is_default": False})

    db.session.commit()
    return _ok(status.to_dict())


@projects_api_bp.patch("/<int:project_id>/statuses/reorder")
@login_required
def reorder_statuses(project_id):
    if not _is_member(project_id):
        return _err("Forbidden", 403)

    body    = request.get_json(silent=True) or {}
    updates = body.get("updates", [])  # [{id, order_index}, ...]

    ids = [u["id"] for u in updates if "id" in u]
    statuses = TaskStatus.query.filter(
        TaskStatus.id.in_(ids),
        TaskStatus.project_id == project_id,
    ).all()
    status_map = {s.id: s for s in statuses}

    for u in updates:
        sid = u.get("id")
        if sid and sid in status_map:
            status_map[sid].order_index = u["order_index"]

    db.session.commit()
    return _ok({"reordered": len(statuses)})


@projects_api_bp.delete("/<int:project_id>/statuses/<int:status_id>")
@login_required
def delete_status(project_id, status_id):
    if not _is_member(project_id):
        return _err("Forbidden", 403)

    status = TaskStatus.query.filter_by(id=status_id, project_id=project_id).first_or_404()

    # Prevent deleting if tasks still reference this status
    task_count = Task.query.filter_by(status_id=status_id).count()
    if task_count > 0:
        return _err(
            f'Cannot delete — {task_count} task(s) still use this status. '
            'Reassign them first.', 409
        )

    db.session.delete(status)
    db.session.commit()
    return _ok({"deleted": status_id})


# ================================================================== #
# LABELS  /api/v1/projects/<project_id>/labels
# ================================================================== #

@projects_api_bp.get("/<int:project_id>/labels")
@login_required
def list_labels(project_id):
    if not _is_member(project_id):
        return _err("Forbidden", 403)
    labels = (
        TaskLabel.query
        .filter_by(project_id=project_id)
        .order_by(TaskLabel.name.asc())
        .all()
    )
    return _ok([l.to_dict() for l in labels])


@projects_api_bp.post("/<int:project_id>/labels")
@login_required
def create_label(project_id):
    if not _is_member(project_id):
        return _err("Forbidden", 403)

    body = request.get_json(silent=True) or {}
    name = (body.get("name") or "").strip()
    if not name:
        return _err("name is required")

    exists = TaskLabel.query.filter_by(project_id=project_id, name=name).first()
    if exists:
        return _err(f'A label named "{name}" already exists in this project')

    label = TaskLabel(
        project_id = project_id,
        name       = name,
        color_hex  = body.get("color_hex", "#4f6ef7"),
    )
    db.session.add(label)
    db.session.commit()
    return _ok(label.to_dict()), 201


@projects_api_bp.patch("/<int:project_id>/labels/<int:label_id>")
@login_required
def update_label(project_id, label_id):
    if not _is_member(project_id):
        return _err("Forbidden", 403)

    label = TaskLabel.query.filter_by(id=label_id, project_id=project_id).first_or_404()
    body  = request.get_json(silent=True) or {}

    name = (body.get("name") or "").strip()
    if name and name != label.name:
        exists = TaskLabel.query.filter_by(project_id=project_id, name=name).first()
        if exists:
            return _err(f'A label named "{name}" already exists in this project')
        label.name = name

    if "color_hex" in body:
        label.color_hex = body["color_hex"]

    db.session.commit()
    return _ok(label.to_dict())


@projects_api_bp.delete("/<int:project_id>/labels/<int:label_id>")
@login_required
def delete_label(project_id, label_id):
    if not _is_member(project_id):
        return _err("Forbidden", 403)

    label = TaskLabel.query.filter_by(id=label_id, project_id=project_id).first_or_404()
    db.session.delete(label)
    db.session.commit()
    return _ok({"deleted": label_id})

"""
API blueprint package.
All sub-blueprints are registered here under /api/v1.
"""

from flask import Blueprint

api_bp = Blueprint("api", __name__)

from app.api import tasks          # noqa: E402,F401
from app.api import projects       # noqa: E402,F401
from app.api import users          # noqa: E402,F401
from app.api import notifications  # noqa: E402,F401
from app.api import gantt          # noqa: E402,F401
from app.api import dashboard      # noqa: E402,F401
from app.api import sprints        # noqa: E402,F401
from app.api import epics          # noqa: E402,F401
from app.api import attachments    # noqa: E402,F401
# from app.api.admin_usr import admin_usr_api_bp
from app.api import admin_usr
api_bp.register_blueprint(admin_usr.admin_usr_api_bp)
api_bp.register_blueprint(tasks.tasks_bp)
api_bp.register_blueprint(projects.projects_api_bp)
api_bp.register_blueprint(users.users_bp)
api_bp.register_blueprint(notifications.notif_bp)
api_bp.register_blueprint(gantt.gantt_bp)
api_bp.register_blueprint(dashboard.dashboard_api_bp)
api_bp.register_blueprint(sprints.sprints_api_bp)
api_bp.register_blueprint(epics.epics_api_bp)
api_bp.register_blueprint(attachments.attachments_bp)

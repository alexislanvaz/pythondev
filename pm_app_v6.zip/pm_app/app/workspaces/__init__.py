"""
Workspaces blueprint package.
"""

from flask import Blueprint

workspaces_bp = Blueprint(
    "workspaces",
    __name__,
    template_folder="templates",
    url_prefix="/workspaces",
)

from app.workspaces import routes  # noqa: E402,F401
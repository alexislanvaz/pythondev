"""
Workspaces HTML + JSON routes.
All workspace data manipulation lives here (no separate api/workspaces.py needed
unless you want to split later).
"""

from flask import (
    render_template, redirect, url_for, abort,
    request, session, jsonify, flash,
)
from flask_login import current_user, login_required

try:
    from slugify import slugify
except ImportError:
    import re
    def slugify(text):
        text = text.lower().strip()
        text = re.sub(r"[^\w\s-]", "", text)
        text = re.sub(r"[\s_-]+", "-", text)
        return re.sub(r"^-+|-+$", "", text)

from app.extensions import db
from app.database.models import Workspace, WorkspaceMember, User, Role, Project, ProjectMember
from app.workspaces import workspaces_bp


# ------------------------------------------------------------------ #
# Helpers
# ------------------------------------------------------------------ #

def _get_workspace_or_403(workspace_id):
    ws = Workspace.query.get_or_404(workspace_id)
    member = WorkspaceMember.query.filter_by(
        workspace_id=workspace_id, user_id=current_user.id
    ).first()
    if not member:
        abort(403)
    return ws, member


def _is_owner(workspace, member):
    """Owner or admin role in this workspace."""
    return workspace.owner_id == current_user.id or (
        member and member.role and member.role.name in ("admin", "project_manager")
    )


def _ok(data, meta=None):
    return jsonify({"data": data, "error": None, "meta": meta or {}})


def _err(message, status=400):
    return jsonify({"data": None, "error": message, "meta": {}}), status


# ------------------------------------------------------------------ #
# GET /workspaces/                — list + sidebar active workspace
# ------------------------------------------------------------------ #

@workspaces_bp.get("/")
@login_required
def list_workspaces():
    memberships = (
        WorkspaceMember.query
        .filter_by(user_id=current_user.id)
        .all()
    )
    workspace_ids = [m.workspace_id for m in memberships]
    workspaces = (
        Workspace.query
        .filter(Workspace.id.in_(workspace_ids))
        .order_by(Workspace.name.asc())
        .all()
    )

    # Auto-set active workspace if not set
    if workspace_ids and not session.get("active_workspace_id"):
        session["active_workspace_id"] = workspace_ids[0]

    active_id = session.get("active_workspace_id")

    return render_template(
        "workspaces/list.html",
        workspaces=workspaces,
        active_id=active_id,
    )


# ------------------------------------------------------------------ #
# POST /workspaces/activate/<id>  — set active workspace (AJAX)
# ------------------------------------------------------------------ #

@workspaces_bp.post("/activate/<int:workspace_id>")
@login_required
def activate(workspace_id):
    member = WorkspaceMember.query.filter_by(
        workspace_id=workspace_id, user_id=current_user.id
    ).first()
    if not member:
        return _err("Forbidden", 403)
    session["active_workspace_id"] = workspace_id
    return _ok({"active_workspace_id": workspace_id})


# ------------------------------------------------------------------ #
# GET  /workspaces/new            — create form
# POST /workspaces/new            — create submit
# ------------------------------------------------------------------ #

@workspaces_bp.get("/new")
@login_required
def new_workspace():
    return render_template("workspaces/new.html")


@workspaces_bp.post("/new")
@login_required
def create_workspace():
    name = (request.form.get("name") or "").strip()
    description = (request.form.get("description") or "").strip()

    if not name:
        flash("Workspace name is required.", "danger")
        return redirect(url_for("workspaces.new_workspace"))

    base_slug = slugify(name)
    slug = base_slug
    counter = 1
    while Workspace.query.filter_by(slug=slug).first():
        slug = f"{base_slug}-{counter}"
        counter += 1

    ws = Workspace(
        name=name,
        slug=slug,
        description=description or None,
        owner_id=current_user.id,
    )
    db.session.add(ws)
    db.session.flush()

    # Creator becomes a member with their current role
    member = WorkspaceMember(
        workspace_id=ws.id,
        user_id=current_user.id,
        role_id=current_user.role_id,
    )
    db.session.add(member)
    db.session.commit()

    session["active_workspace_id"] = ws.id
    flash(f'Workspace "{ws.name}" created.', "success")
    return redirect(url_for("workspaces.detail", workspace_id=ws.id))


# ------------------------------------------------------------------ #
# GET /workspaces/<id>            — workspace detail / overview
# ------------------------------------------------------------------ #

@workspaces_bp.get("/<int:workspace_id>")
@login_required
def detail(workspace_id):
    ws, member = _get_workspace_or_403(workspace_id)
    session["active_workspace_id"] = workspace_id  # visiting = activating

    # Projects in this workspace the user belongs to
    memberships = ProjectMember.query.filter_by(user_id=current_user.id).all()
    project_ids = [m.project_id for m in memberships]
    projects = (
        Project.query
        .filter(Project.id.in_(project_ids), Project.workspace_id == workspace_id)
        .order_by(Project.name.asc())
        .all()
    )

    members = (
        WorkspaceMember.query
        .filter_by(workspace_id=workspace_id)
        .all()
    )

    return render_template(
        "workspaces/detail.html",
        workspace=ws,
        member=member,
        projects=projects,
        members=members,
        is_owner=_is_owner(ws, member),
    )


# ------------------------------------------------------------------ #
# GET /workspaces/<id>/settings   — settings page (owner/admin only)
# ------------------------------------------------------------------ #

@workspaces_bp.get("/<int:workspace_id>/settings")
@login_required
def settings(workspace_id):
    ws, member = _get_workspace_or_403(workspace_id)
    if not _is_owner(ws, member):
        abort(403)

    all_roles = Role.query.order_by(Role.name).all()
    members = (
        WorkspaceMember.query
        .filter_by(workspace_id=workspace_id)
        .all()
    )

    return render_template(
        "workspaces/settings.html",
        workspace=ws,
        members=members,
        all_roles=all_roles,
        is_owner=_is_owner(ws, member),
    )


# ------------------------------------------------------------------ #
# PATCH /workspaces/<id>          — update general info (JSON)
# ------------------------------------------------------------------ #

@workspaces_bp.patch("/<int:workspace_id>")
@login_required
def update_workspace(workspace_id):
    ws, member = _get_workspace_or_403(workspace_id)
    if not _is_owner(ws, member):
        return _err("Forbidden", 403)

    body = request.get_json(silent=True) or {}
    name = (body.get("name") or "").strip()
    if not name:
        return _err("name is required")

    ws.name = name
    ws.description = (body.get("description") or "").strip() or None
    db.session.commit()
    return _ok({"id": ws.id, "name": ws.name, "description": ws.description})


# ------------------------------------------------------------------ #
# DELETE /workspaces/<id>         — delete workspace (owner only)
# ------------------------------------------------------------------ #

@workspaces_bp.delete("/<int:workspace_id>")
@login_required
def delete_workspace(workspace_id):
    ws, member = _get_workspace_or_403(workspace_id)
    if ws.owner_id != current_user.id:
        return _err("Only the owner can delete this workspace", 403)

    db.session.delete(ws)
    db.session.commit()

    if session.get("active_workspace_id") == workspace_id:
        session.pop("active_workspace_id", None)

    return _ok({"deleted": workspace_id})


# ------------------------------------------------------------------ #
# POST /workspaces/<id>/members   — invite member (JSON)
# ------------------------------------------------------------------ #

@workspaces_bp.post("/<int:workspace_id>/members")
@login_required
def add_member(workspace_id):
    ws, member = _get_workspace_or_403(workspace_id)
    if not _is_owner(ws, member):
        return _err("Forbidden", 403)

    body = request.get_json(silent=True) or {}
    email = (body.get("email") or "").strip().lower()
    role_id = body.get("role_id")

    if not email or not role_id:
        return _err("email and role_id are required")

    user = User.query.filter_by(email=email).first()
    if not user:
        return _err(f'No user found with email "{email}"')

    already = WorkspaceMember.query.filter_by(
        workspace_id=workspace_id, user_id=user.id
    ).first()
    if already:
        return _err(f'"{user.full_name or user.username}" is already a member')

    role = Role.query.get(role_id)
    if not role:
        return _err("Invalid role")

    new_member = WorkspaceMember(
        workspace_id=workspace_id,
        user_id=user.id,
        role_id=role_id,
    )
    db.session.add(new_member)
    db.session.commit()

    return _ok({
        "id":        new_member.id,
        "user_id":   user.id,
        "full_name": user.full_name or user.username,
        "email":     user.email,
        "role_id":   role_id,
        "role_name": role.name,
    }), 201


# ------------------------------------------------------------------ #
# PATCH /workspaces/<id>/members/<member_id>  — change role (JSON)
# ------------------------------------------------------------------ #

@workspaces_bp.patch("/<int:workspace_id>/members/<int:member_id>")
@login_required
def update_member(workspace_id, member_id):
    ws, my_membership = _get_workspace_or_403(workspace_id)
    if not _is_owner(ws, my_membership):
        return _err("Forbidden", 403)

    target = WorkspaceMember.query.filter_by(
        id=member_id, workspace_id=workspace_id
    ).first_or_404()

    # Prevent owner from losing their own membership role
    if target.user_id == ws.owner_id:
        return _err("Cannot change the owner's role")

    body = request.get_json(silent=True) or {}
    role_id = body.get("role_id")
    if not role_id:
        return _err("role_id is required")

    role = Role.query.get(role_id)
    if not role:
        return _err("Invalid role")

    target.role_id = role_id
    db.session.commit()
    return _ok({"id": target.id, "role_id": role_id, "role_name": role.name})


# ------------------------------------------------------------------ #
# DELETE /workspaces/<id>/members/<member_id>  — remove member (JSON)
# ------------------------------------------------------------------ #

@workspaces_bp.delete("/<int:workspace_id>/members/<int:member_id>")
@login_required
def remove_member(workspace_id, member_id):
    ws, my_membership = _get_workspace_or_403(workspace_id)
    if not _is_owner(ws, my_membership):
        return _err("Forbidden", 403)

    target = WorkspaceMember.query.filter_by(
        id=member_id, workspace_id=workspace_id
    ).first_or_404()

    if target.user_id == ws.owner_id:
        return _err("Cannot remove the workspace owner")

    db.session.delete(target)
    db.session.commit()
    return _ok({"deleted": member_id})

"""
Application configuration classes.
Load the appropriate class via create_app(config_name).
"""

import os


def _build_sqlserver_uri() -> str:
    """Build the SQL Server connection URI from environment variables."""
    template = (
        "mssql+pyodbc://%(user)s:%(pw)s@%(host)s/%(db)s"
        "?driver=ODBC+Driver+17+for+SQL+Server"
    )
    return template % {
        "user": os.environ.get("DB_USER", "itadmin"),
        "pw":   os.environ.get("DB_PASSWORD", "4dmin1T"),
        "host": os.environ.get("DB_HOST", "172.20.106.32"),
        "db":   os.environ.get("DB_NAME", "pm_app"),
    }


class BaseConfig:
    # Security
    SECRET_KEY = os.environ.get("SECRET_KEY", "change-me-before-production")

    # File uploads
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB
    UPLOAD_FOLDER = os.environ.get("UPLOAD_FOLDER", "\\\\172.20.96.4\\Vol15\\MIS\\Beep\\ProjectManagement")

    # SQLAlchemy
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ECHO = False

    # Database connection parts (available as individual env vars)
    DB_USER     = os.environ.get("DB_USER", "itadmin")
    DB_PASSWORD = os.environ.get("DB_PASSWORD", "4dmin1T")
    DB_HOST     = os.environ.get("DB_HOST", "172.20.106.32")
    DB_NAME     = os.environ.get("DB_NAME", "pm_app")

    SQLALCHEMY_DATABASE_URI = _build_sqlserver_uri()

    # WTForms / CSRF
    WTF_CSRF_ENABLED  = True
    WTF_CSRF_TIME_LIMIT = 3600  # 1 hour


class DevelopmentConfig(BaseConfig):
    DEBUG = True
    SQLALCHEMY_ECHO = True


class ProductionConfig(BaseConfig):
    DEBUG   = False
    TESTING = False


class TestingConfig(BaseConfig):
    TESTING             = True
    DEBUG               = True
    WTF_CSRF_ENABLED    = False
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"


config_map = {
    "development": DevelopmentConfig,
    "production":  ProductionConfig,
    "testing":     TestingConfig,
}

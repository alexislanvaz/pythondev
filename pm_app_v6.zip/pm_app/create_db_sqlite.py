from sqlalchemy import create_engine, text

engine = create_engine("sqlite:///pm_app.db")  # genera pm_app.db en la carpeta actual

with engine.connect() as conn:
    with open("./schema_sqlite.sql", "r") as f:
        sql = f.read()
    for statement in sql.split(";"):
        stmt = statement.strip()
        if stmt:
            conn.execute(text(stmt))
    conn.commit()

print("Base de datos creada exitosamente.")
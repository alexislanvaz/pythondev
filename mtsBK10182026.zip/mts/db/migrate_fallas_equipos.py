import re
import unicodedata
from app.blueprints.db import run_query

def clean_segment(text, max_len=8, remove_prefix=None):
    if not text:
        return "NA"
    # Normalize accents
    t = unicodedata.normalize('NFKD', str(text)).encode('ASCII', 'ignore').decode('ASCII').upper().strip()
    if remove_prefix:
        p = unicodedata.normalize('NFKD', str(remove_prefix)).encode('ASCII', 'ignore').decode('ASCII').upper().strip()
        if t.startswith(p):
            t = t[len(p):].strip(" -_")
    # Remove generic prefix words like EQUIPO if followed by line/station
    t_alnum = re.sub(r'[^A-Z0-9]', '', t)
    if not t_alnum:
        return "EQ"
    return t_alnum[:max_len]

def build_failure_qr(linea_nombre, estacion_nombre, equipo_nombre, seq_num):
    lin_code = clean_segment(linea_nombre, max_len=8)
    est_code = clean_segment(estacion_nombre, max_len=8, remove_prefix=linea_nombre)
    eq_code = clean_segment(equipo_nombre, max_len=8)
    return f"{lin_code}-{est_code}-{eq_code}-{seq_num:03d}"

def migrate():
    print("1. Actualizando estructura de CatFallasComunes...")
    # 1. Drop UQ constraint if exists to alter column length
    run_query("""
        IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UQ_CatFallasComunes_CodigoFalla]') AND type = 'UQ')
        BEGIN
            ALTER TABLE [dbo].[CatFallasComunes] DROP CONSTRAINT [UQ_CatFallasComunes_CodigoFalla];
        END
    """, query_type='UPDATE')

    # 2. Alter CodigoFalla to VARCHAR(150) and TipoEquipoID to NULLable
    run_query("""
        ALTER TABLE [dbo].[CatFallasComunes] ALTER COLUMN [CodigoFalla] VARCHAR(150) NOT NULL;
    """, query_type='UPDATE')

    run_query("""
        ALTER TABLE [dbo].[CatFallasComunes] ALTER COLUMN [TipoEquipoID] INT NULL;
    """, query_type='UPDATE')

    # 3. Re-add UQ constraint on CodigoFalla
    run_query("""
        IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UQ_CatFallasComunes_CodigoFalla]') AND type = 'UQ')
        BEGIN
            ALTER TABLE [dbo].[CatFallasComunes] ADD CONSTRAINT [UQ_CatFallasComunes_CodigoFalla] UNIQUE NONCLUSTERED ([CodigoFalla] ASC);
        END
    """, query_type='UPDATE')

    # 4. Add EquipoID column and FK if not exists
    run_query("""
        IF COL_LENGTH('dbo.CatFallasComunes', 'EquipoID') IS NULL
        BEGIN
            ALTER TABLE [dbo].[CatFallasComunes] ADD [EquipoID] INT NULL;
            ALTER TABLE [dbo].[CatFallasComunes] WITH CHECK ADD CONSTRAINT [FK_CatFallasComunes_CatEquipos]
                FOREIGN KEY([EquipoID]) REFERENCES [dbo].[CatEquipos] ([ID]);
        END
    """, query_type='UPDATE')

    print("2. Migrando registros existentes en CatFallasComunes...")
    fallas = run_query("SELECT ID, TipoEquipoID, EquipoID, CodigoFalla, Nombre FROM CatFallasComunes", query_type='SELECT')
    for f in fallas:
        if f.get('EquipoID') is None:
            # Buscar el primer equipo activo con ese TipoEquipoID
            eq_rows = run_query("""
                SELECT TOP 1 e.ID AS EquipoID, e.Nombre AS EquipoNombre, e.TipoEquipoID,
                       est.Nombre AS EstacionNombre, lin.Nombre AS LineaNombre
                FROM CatEquipos e
                INNER JOIN CatEstaciones est ON e.EstacionID = est.ID
                INNER JOIN CatLineas lin ON est.LineaID = lin.ID
                WHERE e.TipoEquipoID = ? AND e.activo = 1
                ORDER BY e.ID ASC
            """, (f['TipoEquipoID'],), query_type='SELECT')

            if not eq_rows:
                eq_rows = run_query("""
                    SELECT TOP 1 e.ID AS EquipoID, e.Nombre AS EquipoNombre, e.TipoEquipoID,
                           est.Nombre AS EstacionNombre, lin.Nombre AS LineaNombre
                    FROM CatEquipos e
                    INNER JOIN CatEstaciones est ON e.EstacionID = est.ID
                    INNER JOIN CatLineas lin ON est.LineaID = lin.ID
                    WHERE e.activo = 1
                    ORDER BY e.ID ASC
                """, query_type='SELECT')

            if eq_rows:
                eq = eq_rows[0]
                equipo_id = eq['EquipoID']
                # Contar cuántas fallas ya tiene asignadas este equipo
                cnt_rows = run_query("SELECT COUNT(*) AS Cnt FROM CatFallasComunes WHERE EquipoID = ?", (equipo_id,), query_type='SELECT')
                seq = (cnt_rows[0]['Cnt'] if cnt_rows else 0) + 1
                while True:
                    new_qr = build_failure_qr(eq['LineaNombre'], eq['EstacionNombre'], eq['EquipoNombre'], seq)
                    exists = run_query("SELECT ID FROM CatFallasComunes WHERE CodigoFalla = ? AND ID <> ?", (new_qr, f['ID']), query_type='SELECT')
                    if not exists:
                        break
                    seq += 1

                run_query("""
                    UPDATE CatFallasComunes
                    SET EquipoID = ?, CodigoFalla = ?
                    WHERE ID = ?
                """, (equipo_id, new_qr, f['ID']), query_type='UPDATE')
                print(f"  -> Falla ID {f['ID']} ('{f['Nombre']}') asignada a Equipo ID {equipo_id} ('{eq['EquipoNombre']}') con QR '{new_qr}'")

    print("Migración completada con éxito.")

if __name__ == '__main__':
    migrate()

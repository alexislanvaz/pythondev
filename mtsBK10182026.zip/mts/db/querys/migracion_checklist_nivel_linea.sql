/* =================================================================================
   SCRIPT DE MIGRACION: SOPORTE DE CHECKLIST GENERAL POR LINEA Y NIVELES DE PLANTILLA
   Archivo: db/querys/migracion_checklist_nivel_linea.sql
   Descripcion:
     1. Crea la tabla dbo.CatNivelesChecklist (LINEA, ESTACION, AMBOS).
     2. Agrega la columna NivelChecklistID a dbo.ChecklistTemplates con FK a CatNivelesChecklist.
     3. Actualiza las plantillas existentes con el nivel ESTACION.
     4. Agrega la columna LineaID INT NULL a dbo.ChecklistEjecuciones sin constraint FK.
     5. Realiza backfill de LineaID en dbo.ChecklistEjecuciones basado en CatEstaciones.LineaID.
   ================================================================================= */

SET NOCOUNT ON;
SET XACT_ABORT ON;

-- -----------------------------------------------------------------------------
-- 1. Tabla CatNivelesChecklist
-- -----------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.CatNivelesChecklist', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.CatNivelesChecklist (
        ID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        Codigo VARCHAR(50) NOT NULL UNIQUE,
        Nombre VARCHAR(100) NOT NULL,
        Descripcion VARCHAR(255) NULL,
        activo BIT NOT NULL DEFAULT 1,
        fecharegistro DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.CatNivelesChecklist WHERE Codigo = 'LINEA')
BEGIN
    INSERT INTO dbo.CatNivelesChecklist (Codigo, Nombre, Descripcion, activo, fecharegistro)
    VALUES ('LINEA', 'General de Linea', 'Aplica a toda la linea de produccion', 1, GETDATE());
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.CatNivelesChecklist WHERE Codigo = 'ESTACION')
BEGIN
    INSERT INTO dbo.CatNivelesChecklist (Codigo, Nombre, Descripcion, activo, fecharegistro)
    VALUES ('ESTACION', 'Por Estacion', 'Aplica a una estacion o equipo especifico', 1, GETDATE());
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.CatNivelesChecklist WHERE Codigo = 'AMBOS')
BEGIN
    INSERT INTO dbo.CatNivelesChecklist (Codigo, Nombre, Descripcion, activo, fecharegistro)
    VALUES ('AMBOS', 'Ambos', 'Aplica indistintamente para linea o estacion', 1, GETDATE());
END
GO

-- -----------------------------------------------------------------------------
-- 2. Agregar columna NivelChecklistID en ChecklistTemplates
-- -----------------------------------------------------------------------------
IF COL_LENGTH('dbo.ChecklistTemplates', 'NivelChecklistID') IS NULL
BEGIN
    ALTER TABLE dbo.ChecklistTemplates
    ADD NivelChecklistID INT NULL;
END
GO

-- -----------------------------------------------------------------------------
-- 3. Backfill de NivelChecklistID y restricciones
-- -----------------------------------------------------------------------------
DECLARE @EstacionNivelID INT;
SELECT TOP 1 @EstacionNivelID = ID FROM dbo.CatNivelesChecklist WHERE Codigo = 'ESTACION';

UPDATE dbo.ChecklistTemplates
SET NivelChecklistID = @EstacionNivelID
WHERE NivelChecklistID IS NULL;

ALTER TABLE dbo.ChecklistTemplates
ALTER COLUMN NivelChecklistID INT NOT NULL;

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys
    WHERE name = 'FK_ChecklistTemplates_CatNivelesChecklist'
      AND parent_object_id = OBJECT_ID('dbo.ChecklistTemplates')
)
BEGIN
    ALTER TABLE dbo.ChecklistTemplates
    ADD CONSTRAINT FK_ChecklistTemplates_CatNivelesChecklist
        FOREIGN KEY (NivelChecklistID) REFERENCES dbo.CatNivelesChecklist(ID);
END
GO

-- -----------------------------------------------------------------------------
-- 4. Columna LineaID en ChecklistEjecuciones (sin FK fisica)
-- -----------------------------------------------------------------------------
IF COL_LENGTH('dbo.ChecklistEjecuciones', 'LineaID') IS NULL
BEGIN
    ALTER TABLE dbo.ChecklistEjecuciones
    ADD LineaID INT NULL;
END
GO

-- -----------------------------------------------------------------------------
-- 5. Backfill de LineaID en ChecklistEjecuciones desde CatEstaciones
-- -----------------------------------------------------------------------------
UPDATE e
SET e.LineaID = est.LineaID
FROM dbo.ChecklistEjecuciones e
INNER JOIN dbo.CatEstaciones est ON e.EstacionID = est.ID
WHERE e.LineaID IS NULL;
GO

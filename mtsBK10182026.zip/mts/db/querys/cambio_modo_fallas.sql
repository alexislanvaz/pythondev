/* =================================================================================
   SCRIPT DE MIGRACIÓN A PRODUCCIÓN: CAMBIO EN CATÁLOGO DE MODOS DE FALLA POR EQUIPO
   Archivo: db/querys/cambio_modo_fallas.sql
   Descripción:
     1. Elimina dinámicamente el constraint UNIQUE sobre CatFallasComunes(CodigoFalla)
        para permitir ampliar la longitud de la columna.
     2. Amplía CatFallasComunes.CodigoFalla de VARCHAR(50) a VARCHAR(150) NOT NULL.
     3. Recrea el constraint UNIQUE UQ_CatFallasComunes_CodigoFalla sobre CodigoFalla.
     4. Convierte CatFallasComunes.TipoEquipoID en NULLable (INT NULL).
     5. Agrega la columna EquipoID INT NULL a CatFallasComunes y su Foreign Key
        FK_CatFallasComunes_CatEquipos hacia CatEquipos(ID).
     6. Crea un índice IX_CatFallasComunes_EquipoID para optimizar consultas de técnico.
     7. Migra registros existentes en CatFallasComunes que aún no tengan EquipoID
        asignado, vinculándolos a un equipo activo de su TipoEquipoID y generando
        su código QR con formato LINEA-ESTACION-EQUIPO-CONTADOR.
   ================================================================================= */

SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    BEGIN TRANSACTION;

    PRINT '=== INICIANDO MIGRACIÓN DE CatFallasComunes ===';

    /* -------------------------------------------------------------------------
       1. ELIMINAR CONSTRAINT UNIQUE ACTUAL EN CatFallasComunes.CodigoFalla
       ------------------------------------------------------------------------- */
    DECLARE @uqConstraintName NVARCHAR(256);
    DECLARE @dropUqSql NVARCHAR(MAX);

    SELECT TOP 1 @uqConstraintName = kc.name
    FROM sys.key_constraints kc
    INNER JOIN sys.index_columns ic
        ON kc.parent_object_id = ic.object_id
       AND kc.unique_index_id = ic.index_id
    INNER JOIN sys.columns c
        ON ic.object_id = c.object_id
       AND ic.column_id = c.column_id
    WHERE kc.parent_object_id = OBJECT_ID('dbo.CatFallasComunes')
      AND kc.type = 'UQ'
      AND c.name = 'CodigoFalla';

    IF @uqConstraintName IS NOT NULL
    BEGIN
        SET @dropUqSql = N'ALTER TABLE dbo.CatFallasComunes DROP CONSTRAINT ' + QUOTENAME(@uqConstraintName) + N';';
        EXEC sp_executesql @dropUqSql;
        PRINT 'Constraint UNIQUE eliminado: ' + @uqConstraintName;
    END

    /* -------------------------------------------------------------------------
       2. AMPLIAR LONGITUD DE CodigoFalla A VARCHAR(150) NOT NULL
       ------------------------------------------------------------------------- */
    ALTER TABLE dbo.CatFallasComunes
    ALTER COLUMN CodigoFalla VARCHAR(150) NOT NULL;
    PRINT 'Columna CatFallasComunes.CodigoFalla ampliada a VARCHAR(150) NOT NULL.';

    /* -------------------------------------------------------------------------
       3. RECREAR CONSTRAINT UNIQUE UQ_CatFallasComunes_CodigoFalla
       ------------------------------------------------------------------------- */
    IF NOT EXISTS (
        SELECT 1
        FROM sys.key_constraints
        WHERE name = 'UQ_CatFallasComunes_CodigoFalla'
          AND parent_object_id = OBJECT_ID('dbo.CatFallasComunes')
    )
    BEGIN
        ALTER TABLE dbo.CatFallasComunes
        ADD CONSTRAINT UQ_CatFallasComunes_CodigoFalla UNIQUE (CodigoFalla);
        PRINT 'Constraint UQ_CatFallasComunes_CodigoFalla creado correctamente.';
    END

    /* -------------------------------------------------------------------------
       4. HACER TipoEquipoID NULLABLE EN CatFallasComunes
       ------------------------------------------------------------------------- */
    ALTER TABLE dbo.CatFallasComunes
    ALTER COLUMN TipoEquipoID INT NULL;
    PRINT 'Columna CatFallasComunes.TipoEquipoID actualizada a INT NULL.';

    /* -------------------------------------------------------------------------
       5. AGREGAR COLUMNA EquipoID Y SU FOREIGN KEY HACIA CatEquipos(ID)
       ------------------------------------------------------------------------- */
    IF COL_LENGTH('dbo.CatFallasComunes', 'EquipoID') IS NULL
    BEGIN
        ALTER TABLE dbo.CatFallasComunes
        ADD EquipoID INT NULL;
        PRINT 'Columna CatFallasComunes.EquipoID agregada.';
    END

    IF NOT EXISTS (
        SELECT 1
        FROM sys.foreign_keys
        WHERE name = 'FK_CatFallasComunes_CatEquipos'
          AND parent_object_id = OBJECT_ID('dbo.CatFallasComunes')
    )
    BEGIN
        ALTER TABLE dbo.CatFallasComunes
        ADD CONSTRAINT FK_CatFallasComunes_CatEquipos
            FOREIGN KEY (EquipoID) REFERENCES dbo.CatEquipos(ID);
        PRINT 'Foreign Key FK_CatFallasComunes_CatEquipos creada correctamente.';
    END

    /* -------------------------------------------------------------------------
       6. CREAR ÍNDICES PARA BÚSQUEDA RÁPIDA EN FALLAS Y SOLUCIONES COMUNES
       ------------------------------------------------------------------------- */
    IF NOT EXISTS (
        SELECT 1
        FROM sys.indexes
        WHERE name = 'IX_CatFallasComunes_EquipoID'
          AND object_id = OBJECT_ID('dbo.CatFallasComunes')
    )
    BEGIN
        CREATE NONCLUSTERED INDEX IX_CatFallasComunes_EquipoID
        ON dbo.CatFallasComunes (EquipoID, activo)
        INCLUDE (CodigoFalla, Nombre, Descripcion, TipoEquipoID);
        PRINT 'Índice IX_CatFallasComunes_EquipoID creado correctamente.';
    END

    IF NOT EXISTS (
        SELECT 1
        FROM sys.indexes
        WHERE name = 'IX_CatSolucionesComunes_FallaComunID'
          AND object_id = OBJECT_ID('dbo.CatSolucionesComunes')
    )
    BEGIN
        CREATE NONCLUSTERED INDEX IX_CatSolucionesComunes_FallaComunID
        ON dbo.CatSolucionesComunes (FallaComunID, activo)
        INCLUDE (Nombre, Descripcion);
        PRINT 'Índice IX_CatSolucionesComunes_FallaComunID creado correctamente.';
    END

    COMMIT TRANSACTION;
    PRINT '=== CAMBIOS ESTRUCTURALES (DDL) APLICADOS EXITOSAMENTE ===';
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;

    DECLARE @ErrMsg NVARCHAR(4000) = ERROR_MESSAGE();
    DECLARE @ErrSeverity INT = ERROR_SEVERITY();
    DECLARE @ErrState INT = ERROR_STATE();
    RAISERROR(@ErrMsg, @ErrSeverity, @ErrState);
    RETURN;
END CATCH;
GO

/* =================================================================================
   7. MIGRACIÓN DE DATOS EXISTENTES (DML)
      Se ejecuta en un lote separado (después del GO) para que SQL Server reconozca
      la nueva columna EquipoID recién agregada en la tabla CatFallasComunes.
   ================================================================================= */
BEGIN TRY
    BEGIN TRANSACTION;

    -- 7.1 Asignar EquipoID a registros históricos que aún tengan EquipoID IS NULL
    UPDATE f
    SET f.EquipoID = COALESCE(
        (SELECT TOP 1 eq.ID
         FROM dbo.CatEquipos eq
         WHERE eq.TipoEquipoID = f.TipoEquipoID
           AND eq.activo = 1
         ORDER BY eq.ID),
        (SELECT TOP 1 eq.ID
         FROM dbo.CatEquipos eq
         WHERE eq.activo = 1
         ORDER BY eq.ID)
    )
    FROM dbo.CatFallasComunes f
    WHERE f.EquipoID IS NULL;

    -- 7.2 Actualizar CodigoFalla al formato LINEA-ESTACION-EQUIPO-CONTADOR
    --     para los registros que aún no tengan el formato con 3 guiones
    ;WITH CTE_FallasNumeradas AS (
        SELECT
            f.ID,
            f.CodigoFalla,
            UPPER(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(l.Nombre, 'LIN'))), ' ', ''), '-', '_'), '.', '')) AS SegLinea,
            UPPER(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(est.Nombre, 'EST'))), ' ', ''), '-', '_'), '.', '')) AS SegEstacion,
            UPPER(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(eq.Nombre, 'EQ'))), ' ', ''), '-', '_'), '.', '')) AS SegEquipo,
            ROW_NUMBER() OVER (PARTITION BY f.EquipoID ORDER BY f.ID) AS NumFallaEquipo
        FROM dbo.CatFallasComunes f
        INNER JOIN dbo.CatEquipos eq ON f.EquipoID = eq.ID
        INNER JOIN dbo.CatEstaciones est ON eq.EstacionID = est.ID
        INNER JOIN dbo.CatLineas l ON est.LineaID = l.ID
    )
    UPDATE f
    SET f.CodigoFalla = CONCAT(
        LEFT(c.SegLinea, 12), '-',
        LEFT(c.SegEstacion, 12), '-',
        LEFT(c.SegEquipo, 12), '-',
        RIGHT('000' + CAST(c.NumFallaEquipo AS VARCHAR(10)), 3)
    )
    FROM dbo.CatFallasComunes f
    INNER JOIN CTE_FallasNumeradas c ON f.ID = c.ID
    WHERE LEN(f.CodigoFalla) - LEN(REPLACE(f.CodigoFalla, '-', '')) < 3;

    COMMIT TRANSACTION;
    PRINT '=== MIGRACIÓN DE DATOS HISTÓRICOS COMPLETADA EXITOSAMENTE ===';
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;

    DECLARE @ErrMsg2 NVARCHAR(4000) = ERROR_MESSAGE();
    DECLARE @ErrSeverity2 INT = ERROR_SEVERITY();
    DECLARE @ErrState2 INT = ERROR_STATE();
    RAISERROR(@ErrMsg2, @ErrSeverity2, @ErrState2);
END CATCH;
GO

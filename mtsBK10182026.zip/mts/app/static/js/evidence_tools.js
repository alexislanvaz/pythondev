/**
 * MTS Enterprise - Evidence Tools & Multi-modal Utilities
 * 1. Voice-to-Text Dictation (Web Speech API in Spanish - es-MX/es-ES)
 * 2. Photo Annotation & Drawing Canvas (Touch, Stylus, Mouse with PointerEvents)
 * 3. Standardized Rear Camera Prioritization & Stream Helper
 */

(function (window) {
    'use strict';

    // =========================================================================
    // 1. DICTADO POR VOZ (SPEECH RECOGNITION EN ESPAÑOL)
    // =========================================================================
    const VoiceDictation = {
        recognition: null,
        isListening: false,
        activeTarget: null,
        activeButton: null,

        init() {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            if (!SpeechRecognition) {
                return false;
            }

            this.recognition = new SpeechRecognition();
            this.recognition.lang = 'es-MX';
            this.recognition.continuous = true;
            this.recognition.interimResults = true;

            this.recognition.onstart = () => {
                this.isListening = true;
                this.updateButtonUI(true);
            };

            this.recognition.onresult = (event) => {
                if (!this.activeTarget) return;

                let interimTranscript = '';
                let finalTranscript = '';

                for (let i = event.resultIndex; i < event.results.length; ++i) {
                    const transcript = event.results[i][0].transcript;
                    if (event.results[i].isFinal) {
                        finalTranscript += transcript;
                    } else {
                        interimTranscript += transcript;
                    }
                }

                if (finalTranscript) {
                    const currentVal = this.activeTarget.value;
                    const needsSpace = currentVal.length > 0 && !currentVal.endsWith(' ') && !currentVal.endsWith('\n');
                    this.activeTarget.value = currentVal + (needsSpace ? ' ' : '') + finalTranscript.trim() + ' ';
                    this.activeTarget.dispatchEvent(new Event('input', { bubbles: true }));
                }
            };

            this.recognition.onerror = (event) => {
                console.warn('VoiceDictation error:', event.error);
                if (event.error === 'not-allowed') {
                    if (window.Swal) {
                        Swal.fire({
                            icon: 'warning',
                            title: 'Permiso de Micrófono Denegado',
                            text: 'Por favor habilita los permisos de micrófono en tu navegador para usar el dictado por voz.',
                            confirmButtonColor: 'var(--primary-color)'
                        });
                    }
                }
                this.stop();
            };

            this.recognition.onend = () => {
                this.isListening = false;
                this.updateButtonUI(false);
            };

            return true;
        },

        toggle(targetElement, buttonElement) {
            if (!this.recognition && !this.init()) {
                if (window.Swal) {
                    Swal.fire({
                        icon: 'info',
                        title: 'Dictado no soportado',
                        text: 'Tu navegador actual no soporta la API de reconocimiento de voz. Te recomendamos usar Google Chrome o Edge.',
                        confirmButtonColor: 'var(--primary-color)'
                    });
                }
                return;
            }

            if (this.isListening) {
                if (this.activeTarget === targetElement) {
                    this.stop();
                    return;
                }
                this.stop();
            }

            this.activeTarget = typeof targetElement === 'string' ? document.getElementById(targetElement) : targetElement;
            this.activeButton = typeof buttonElement === 'string' ? document.getElementById(buttonElement) : buttonElement;

            try {
                this.recognition.start();
            } catch (e) {
                console.error('Error starting speech recognition:', e);
                this.stop();
            }
        },

        stop() {
            if (this.recognition && this.isListening) {
                try {
                    this.recognition.stop();
                } catch (e) {}
            }
            this.isListening = false;
            this.updateButtonUI(false);
        },

        updateButtonUI(listening) {
            if (!this.activeButton) return;
            if (listening) {
                this.activeButton.classList.add('voice-btn-active');
                this.activeButton.setAttribute('data-listening', 'true');
                const label = this.activeButton.querySelector('.voice-btn-label');
                if (label) label.textContent = 'Escuchando...';
                const icon = this.activeButton.querySelector('i');
                if (icon) icon.className = 'fa-solid fa-microphone-lines fa-fade text-danger';
            } else {
                this.activeButton.classList.remove('voice-btn-active');
                this.activeButton.removeAttribute('data-listening');
                const label = this.activeButton.querySelector('.voice-btn-label');
                if (label) label.textContent = 'Dictar por voz';
                const icon = this.activeButton.querySelector('i');
                if (icon) icon.className = 'fa-solid fa-microphone';
            }
        }
    };


    // =========================================================================
    // 2. GESTOR DE CÁMARA TRASERA ESTANDARIZADA
    // =========================================================================
    const CameraHelper = {
        async getVideoDevices() {
            if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
                return [];
            }
            const devices = await navigator.mediaDevices.enumerateDevices();
            const videoDevices = devices.filter(d => d.kind === 'videoinput');

            // Priorizar cámaras traseras (Back, Rear, Environment, Trasera, Posterior, 0)
            videoDevices.sort((a, b) => {
                const labelA = (a.label || '').toLowerCase();
                const labelB = (b.label || '').toLowerCase();
                const isBackA = labelA.includes('back') || labelA.includes('rear') || labelA.includes('environment') || labelA.includes('trasera') || labelA.includes('posterior') || labelA.includes('0');
                const isBackB = labelB.includes('back') || labelB.includes('rear') || labelB.includes('environment') || labelB.includes('trasera') || labelB.includes('posterior') || labelB.includes('0');
                if (isBackA && !isBackB) return -1;
                if (!isBackA && isBackB) return 1;
                return 0;
            });

            return videoDevices;
        },

        getCameraConstraints(deviceId) {
            if (deviceId) {
                return {
                    video: {
                        deviceId: { ideal: deviceId },
                        width: { ideal: 1920, max: 3840 },
                        height: { ideal: 1080, max: 2160 }
                    }
                };
            }
            return {
                video: {
                    facingMode: { ideal: 'environment' },
                    width: { ideal: 1920, max: 3840 },
                    height: { ideal: 1080, max: 2160 }
                }
            };
        }
    };


    // =========================================================================
    // 3. ANOTACIONES Y DIBUJO RÁPIDO SOBRE FOTOS (CANVAS HTML5 NATIVO)
    // =========================================================================
    const PhotoAnnotator = {
        modalEl: null,
        canvasEl: null,
        ctx: null,
        bgImage: null,
        isDrawing: false,
        currentTool: 'brush', // 'brush', 'arrow', 'circle', 'rect'
        currentColor: '#ef4444', // Red default
        currentLineWidth: 6,
        startX: 0,
        startY: 0,
        history: [],
        maxHistory: 15,
        onSaveCallback: null,
        originalFile: null,

        init() {
            if (this.modalEl) return;

            // Inyectar Estilos CSS del Editor
            const style = document.createElement('style');
            style.innerHTML = `
                .annotator-modal-backdrop {
                    display: none;
                    position: fixed;
                    inset: 0;
                    background: rgba(15, 23, 42, 0.88);
                    backdrop-filter: blur(6px);
                    -webkit-backdrop-filter: blur(6px);
                    z-index: 99999;
                    align-items: center;
                    justify-content: center;
                    padding: 0.75rem;
                }
                .annotator-modal-container {
                    background: var(--bg-card, #ffffff);
                    border: 1px solid var(--border-color, #e2e8f0);
                    border-radius: 16px;
                    width: 100%;
                    max-width: 900px;
                    max-height: 94vh;
                    display: flex;
                    flex-direction: column;
                    overflow: hidden;
                    box-shadow: 0 20px 40px rgba(0,0,0,0.35);
                    animation: annotatorPop 0.2s cubic-bezier(0.16, 1, 0.3, 1);
                }
                @keyframes annotatorPop {
                    from { transform: scale(0.95); opacity: 0; }
                    to { transform: scale(1); opacity: 1; }
                }
                .annotator-header {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    padding: 0.75rem 1.25rem;
                    border-bottom: 1px solid var(--border-color, #e2e8f0);
                    background: var(--bg-main, #f8fafc);
                }
                .annotator-title {
                    margin: 0;
                    font-size: 1rem;
                    font-weight: 700;
                    color: var(--primary-color, #0f766e);
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                }
                .annotator-toolbar {
                    display: flex;
                    flex-wrap: wrap;
                    align-items: center;
                    justify-content: space-between;
                    gap: 0.6rem;
                    padding: 0.6rem 1rem;
                    background: var(--bg-card, #ffffff);
                    border-bottom: 1px solid var(--border-color, #e2e8f0);
                }
                .annotator-tool-group {
                    display: inline-flex;
                    align-items: center;
                    gap: 0.35rem;
                    background: var(--bg-main, #f1f5f9);
                    padding: 0.25rem;
                    border-radius: 10px;
                    border: 1px solid var(--border-color, #e2e8f0);
                }
                .annotator-btn {
                    background: transparent;
                    border: none;
                    border-radius: 8px;
                    padding: 0.4rem 0.65rem;
                    font-size: 0.85rem;
                    font-weight: 600;
                    color: var(--text-secondary, #475569);
                    cursor: pointer;
                    display: inline-flex;
                    align-items: center;
                    gap: 0.35rem;
                    transition: all 0.15s ease;
                    touch-action: manipulation;
                    min-height: 36px;
                }
                .annotator-btn:hover {
                    background: rgba(0,0,0,0.05);
                    color: var(--text-primary, #0f172a);
                }
                .annotator-btn.active {
                    background: var(--primary-color, #0f766e);
                    color: #ffffff !important;
                    box-shadow: 0 2px 6px rgba(15, 118, 110, 0.25);
                }
                .annotator-color-swatch {
                    width: 24px;
                    height: 24px;
                    border-radius: 50%;
                    cursor: pointer;
                    border: 2px solid transparent;
                    transition: transform 0.15s, border-color 0.15s;
                    touch-action: manipulation;
                }
                .annotator-color-swatch:hover {
                    transform: scale(1.15);
                }
                .annotator-color-swatch.active {
                    transform: scale(1.2);
                    border-color: #ffffff;
                    box-shadow: 0 0 0 2px var(--primary-color, #0f766e);
                }
                .annotator-canvas-wrapper {
                    flex: 1;
                    min-height: 280px;
                    max-height: 60vh;
                    background: #0f172a;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    overflow: hidden;
                    position: relative;
                    padding: 0.5rem;
                }
                #annotator-canvas {
                    display: block;
                    max-width: 100%;
                    max-height: 100%;
                    border-radius: 8px;
                    box-shadow: 0 4px 14px rgba(0,0,0,0.5);
                    touch-action: none; /* Esencial para PointerEvents fluidos en touch/lápiz */
                    cursor: crosshair;
                }
                .annotator-footer {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    flex-wrap: wrap;
                    gap: 0.75rem;
                    padding: 0.75rem 1.25rem;
                    border-top: 1px solid var(--border-color, #e2e8f0);
                    background: var(--bg-main, #f8fafc);
                }
                .voice-btn-active {
                    background-color: #ef4444 !important;
                    color: #ffffff !important;
                    border-color: #ef4444 !important;
                    animation: pulseMicrophone 1.5s infinite;
                }
                @keyframes pulseMicrophone {
                    0% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.6); }
                    70% { box-shadow: 0 0 0 10px rgba(239, 68, 68, 0); }
                    100% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
                }
            `;
            document.head.appendChild(style);

            // Inyectar Estructura HTML del Modal
            const modalDiv = document.createElement('div');
            modalDiv.id = 'annotator-modal';
            modalDiv.className = 'annotator-modal-backdrop';
            modalDiv.innerHTML = `
                <div class="annotator-modal-container">
                    <div class="annotator-header">
                        <h3 class="annotator-title">
                            <i class="fa-solid fa-paintbrush"></i> Anotaciones y Marcado de Evidencia
                        </h3>
                        <button type="button" class="btn-close-annotator" onclick="PhotoAnnotator.close()" style="background: transparent; border: none; font-size: 1.25rem; color: var(--text-secondary); cursor: pointer;">
                            <i class="fa-solid fa-xmark"></i>
                        </button>
                    </div>

                    <!-- Toolbar de Herramientas, Colores y Acciones -->
                    <div class="annotator-toolbar">
                        <!-- Herramientas de Dibujo -->
                        <div class="annotator-tool-group">
                            <button type="button" class="annotator-btn active" data-tool="brush" onclick="PhotoAnnotator.setTool('brush', this)" title="Pincel a mano alzada">
                                <i class="fa-solid fa-pen"></i> <span class="d-none d-sm-inline">Pincel</span>
                            </button>
                            <button type="button" class="annotator-btn" data-tool="arrow" onclick="PhotoAnnotator.setTool('arrow', this)" title="Flecha indicadora">
                                <i class="fa-solid fa-arrow-right"></i> <span class="d-none d-sm-inline">Flecha</span>
                            </button>
                            <button type="button" class="annotator-btn" data-tool="circle" onclick="PhotoAnnotator.setTool('circle', this)" title="Círculo de resaltado">
                                <i class="fa-regular fa-circle"></i> <span class="d-none d-sm-inline">Círculo</span>
                            </button>
                            <button type="button" class="annotator-btn" data-tool="rect" onclick="PhotoAnnotator.setTool('rect', this)" title="Rectángulo">
                                <i class="fa-regular fa-square"></i> <span class="d-none d-sm-inline">Cuadro</span>
                            </button>
                        </div>

                        <!-- Paleta de Colores Rápidos -->
                        <div class="annotator-tool-group" style="padding: 0.35rem 0.6rem; gap: 0.5rem;">
                            <div class="annotator-color-swatch active" style="background-color: #ef4444;" onclick="PhotoAnnotator.setColor('#ef4444', this)" title="Rojo (Anomalía)"></div>
                            <div class="annotator-color-swatch" style="background-color: #eab308;" onclick="PhotoAnnotator.setColor('#eab308', this)" title="Amarillo (Precaución)"></div>
                            <div class="annotator-color-swatch" style="background-color: #10b981;" onclick="PhotoAnnotator.setColor('#10b981', this)" title="Verde (Correcto)"></div>
                            <div class="annotator-color-swatch" style="background-color: #3b82f6;" onclick="PhotoAnnotator.setColor('#3b82f6', this)" title="Azul"></div>
                            <div class="annotator-color-swatch" style="background-color: #ffffff;" onclick="PhotoAnnotator.setColor('#ffffff', this)" title="Blanco"></div>
                        </div>

                        <!-- Grosor de Trazo -->
                        <div class="annotator-tool-group">
                            <button type="button" class="annotator-btn" onclick="PhotoAnnotator.setLineWidth(3, this)" title="Fino">Fino</button>
                            <button type="button" class="annotator-btn active" onclick="PhotoAnnotator.setLineWidth(6, this)" title="Medio">Medio</button>
                            <button type="button" class="annotator-btn" onclick="PhotoAnnotator.setLineWidth(12, this)" title="Grueso">Grueso</button>
                        </div>

                        <!-- Deshacer y Limpiar -->
                        <div class="annotator-tool-group">
                            <button type="button" class="annotator-btn" onclick="PhotoAnnotator.undo()" title="Deshacer último trazo">
                                <i class="fa-solid fa-rotate-left"></i> Deshacer
                            </button>
                            <button type="button" class="annotator-btn" onclick="PhotoAnnotator.clearCanvas()" title="Borrar todas las anotaciones">
                                <i class="fa-solid fa-trash-can"></i> Limpiar
                            </button>
                        </div>
                    </div>

                    <!-- Lienzo Interactivo -->
                    <div class="annotator-canvas-wrapper">
                        <canvas id="annotator-canvas"></canvas>
                    </div>

                    <!-- Footer con Acciones de Guardado -->
                    <div class="annotator-footer">
                        <button type="button" class="btn btn-secondary" onclick="PhotoAnnotator.close()" style="min-height: 42px; font-weight: 600; padding: 0.4rem 1rem;">
                            Cancelar
                        </button>
                        <div style="display: flex; gap: 0.6rem; align-items: center;">
                            <button type="button" class="btn btn-secondary" onclick="PhotoAnnotator.saveOriginal()" style="min-height: 42px; font-weight: 600; font-size: 0.84rem; padding: 0.4rem 0.9rem;">
                                Guardar sin marcar
                            </button>
                            <button type="button" class="btn btn-primary" onclick="PhotoAnnotator.saveAnnotated()" style="min-height: 42px; font-weight: 700; font-size: 0.88rem; padding: 0.4rem 1.2rem; background-color: var(--primary-color); display: inline-flex; align-items: center; gap: 0.4rem;">
                                <i class="fa-solid fa-check"></i> Adjuntar Evidencia
                            </button>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(modalDiv);

            this.modalEl = modalDiv;
            this.canvasEl = document.getElementById('annotator-canvas');
            this.ctx = this.canvasEl.getContext('2d');

            this.bindEvents();
        },

        bindEvents() {
            // Unificado con PointerEvents (Mouse, Lápiz Óptico/Stylus y Touch sin lag)
            this.canvasEl.addEventListener('pointerdown', (e) => this.onPointerDown(e));
            this.canvasEl.addEventListener('pointermove', (e) => this.onPointerMove(e));
            this.canvasEl.addEventListener('pointerup', (e) => this.onPointerUp(e));
            this.canvasEl.addEventListener('pointercancel', (e) => this.onPointerUp(e));
        },

        getCanvasCoords(e) {
            const rect = this.canvasEl.getBoundingClientRect();
            const scaleX = this.canvasEl.width / rect.width;
            const scaleY = this.canvasEl.height / rect.height;
            return {
                x: (e.clientX - rect.left) * scaleX,
                y: (e.clientY - rect.top) * scaleY
            };
        },

        onPointerDown(e) {
            e.preventDefault();
            this.isDrawing = true;
            this.canvasEl.setPointerCapture(e.pointerId);

            const coords = this.getCanvasCoords(e);
            this.startX = coords.x;
            this.startY = coords.y;

            // Guardar estado previo para Undo o preview de formas
            this.saveStateToHistory();

            this.ctx.strokeStyle = this.currentColor;
            this.ctx.fillStyle = this.currentColor;
            this.ctx.lineWidth = this.currentLineWidth;
            this.ctx.lineCap = 'round';
            this.ctx.lineJoin = 'round';

            if (this.currentTool === 'brush') {
                this.ctx.beginPath();
                this.ctx.moveTo(this.startX, this.startY);
                this.ctx.lineTo(this.startX, this.startY);
                this.ctx.stroke();
            }
        },

        onPointerMove(e) {
            if (!this.isDrawing) return;
            e.preventDefault();

            const coords = this.getCanvasCoords(e);
            const currentX = coords.x;
            const currentY = coords.y;

            if (this.currentTool === 'brush') {
                this.ctx.lineTo(currentX, currentY);
                this.ctx.stroke();
            } else {
                // Para formas geométricas (Flecha, Círculo, Rectángulo), restauramos el último snapshot y previsualizamos
                this.restoreLatestSnapshot();
                this.ctx.strokeStyle = this.currentColor;
                this.ctx.fillStyle = this.currentColor;
                this.ctx.lineWidth = this.currentLineWidth;
                this.ctx.lineCap = 'round';
                this.ctx.lineJoin = 'round';

                if (this.currentTool === 'arrow') {
                    this.drawArrow(this.startX, this.startY, currentX, currentY);
                } else if (this.currentTool === 'rect') {
                    this.drawRect(this.startX, this.startY, currentX, currentY);
                } else if (this.currentTool === 'circle') {
                    this.drawCircle(this.startX, this.startY, currentX, currentY);
                }
            }
        },

        onPointerUp(e) {
            if (!this.isDrawing) return;
            e.preventDefault();
            this.isDrawing = false;
            try {
                this.canvasEl.releasePointerCapture(e.pointerId);
            } catch (err) {}

            if (this.currentTool === 'brush') {
                this.ctx.closePath();
            }
        },

        drawArrow(fromX, fromY, toX, toY) {
            const headlen = Math.max(14, this.currentLineWidth * 3.2);
            const angle = Math.atan2(toY - fromY, toX - fromX);

            // Línea del cuerpo
            this.ctx.beginPath();
            this.ctx.moveTo(fromX, fromY);
            this.ctx.lineTo(toX, toY);
            this.ctx.stroke();

            // Punta de la flecha
            this.ctx.beginPath();
            this.ctx.moveTo(toX, toY);
            this.ctx.lineTo(toX - headlen * Math.cos(angle - Math.PI / 6), toY - headlen * Math.sin(angle - Math.PI / 6));
            this.ctx.lineTo(toX - headlen * Math.cos(angle + Math.PI / 6), toY - headlen * Math.sin(angle + Math.PI / 6));
            this.ctx.closePath();
            this.ctx.fill();
        },

        drawRect(fromX, fromY, toX, toY) {
            const width = toX - fromX;
            const height = toY - fromY;
            this.ctx.beginPath();
            this.ctx.strokeRect(fromX, fromY, width, height);
        },

        drawCircle(fromX, fromY, toX, toY) {
            const radiusX = Math.abs(toX - fromX) / 2;
            const radiusY = Math.abs(toY - fromY) / 2;
            const centerX = fromX + (toX - fromX) / 2;
            const centerY = fromY + (toY - fromY) / 2;

            this.ctx.beginPath();
            this.ctx.ellipse(centerX, centerY, radiusX, radiusY, 0, 0, 2 * Math.PI);
            this.ctx.stroke();
        },

        saveStateToHistory() {
            if (this.history.length >= this.maxHistory) {
                this.history.shift();
            }
            this.history.push(this.ctx.getImageData(0, 0, this.canvasEl.width, this.canvasEl.height));
        },

        restoreLatestSnapshot() {
            if (this.history.length > 0) {
                const latest = this.history[this.history.length - 1];
                this.ctx.putImageData(latest, 0, 0);
            }
        },

        undo() {
            if (this.history.length > 1) {
                this.history.pop(); // Eliminar estado actual
                const prevState = this.history[this.history.length - 1];
                this.ctx.putImageData(prevState, 0, 0);
            } else if (this.history.length === 1) {
                this.clearCanvas();
            }
        },

        clearCanvas() {
            if (!this.bgImage) return;
            this.ctx.clearRect(0, 0, this.canvasEl.width, this.canvasEl.height);
            this.ctx.drawImage(this.bgImage, 0, 0, this.canvasEl.width, this.canvasEl.height);
            this.history = [this.ctx.getImageData(0, 0, this.canvasEl.width, this.canvasEl.height)];
        },

        setTool(toolName, btnElement) {
            this.currentTool = toolName;
            document.querySelectorAll('.annotator-toolbar [data-tool]').forEach(b => b.classList.remove('active'));
            if (btnElement) btnElement.classList.add('active');
        },

        setColor(colorHex, swatchElement) {
            this.currentColor = colorHex;
            document.querySelectorAll('.annotator-color-swatch').forEach(s => s.classList.remove('active'));
            if (swatchElement) swatchElement.classList.add('active');
        },

        setLineWidth(width, btnElement) {
            this.currentLineWidth = width;
            if (btnElement && btnElement.parentElement) {
                btnElement.parentElement.querySelectorAll('.annotator-btn').forEach(b => b.classList.remove('active'));
                btnElement.classList.add('active');
            }
        },

        /**
         * Abre el editor con la imagen provista (File, Blob, HTMLVideoElement, HTMLImageElement o URL)
         */
        open(imageSource, originalFile, onSave) {
            this.init();
            this.onSaveCallback = onSave;
            this.originalFile = originalFile || null;
            this.history = [];

            const processLoadedImage = (img) => {
                this.bgImage = img;

                // Redimensionar respetando aspect ratio con límite de resolución (máx 1600x1200 para fluidez en tablet)
                let width = img.videoWidth || img.naturalWidth || img.width || 1280;
                let height = img.videoHeight || img.naturalHeight || img.height || 720;
                const maxDim = 1600;

                if (width > maxDim || height > maxDim) {
                    if (width > height) {
                        height = Math.round((height * maxDim) / width);
                        width = maxDim;
                    } else {
                        width = Math.round((width * maxDim) / height);
                        height = maxDim;
                    }
                }

                this.canvasEl.width = width;
                this.canvasEl.height = height;

                this.ctx.drawImage(img, 0, 0, width, height);
                this.history = [this.ctx.getImageData(0, 0, width, height)];

                this.modalEl.style.display = 'flex';
            };

            if (imageSource instanceof HTMLVideoElement) {
                processLoadedImage(imageSource);
            } else if (imageSource instanceof HTMLImageElement && imageSource.complete) {
                processLoadedImage(imageSource);
            } else if (imageSource instanceof Blob || imageSource instanceof File) {
                const img = new Image();
                const url = URL.createObjectURL(imageSource);
                img.onload = () => {
                    processLoadedImage(img);
                    URL.revokeObjectURL(url);
                };
                img.src = url;
            } else if (typeof imageSource === 'string') {
                const img = new Image();
                img.crossOrigin = "anonymous";
                img.onload = () => {
                    processLoadedImage(img);
                };
                img.src = imageSource;
            }
        },

        close() {
            if (this.modalEl) {
                this.modalEl.style.display = 'none';
            }
            this.history = [];
            this.bgImage = null;
        },

        saveOriginal() {
            if (this.originalFile && this.onSaveCallback) {
                this.onSaveCallback(this.originalFile);
                this.close();
            } else {
                this.saveAnnotated();
            }
        },

        saveAnnotated() {
            if (!this.canvasEl || !this.onSaveCallback) return;

            this.canvasEl.toBlob((blob) => {
                const finalFile = new File([blob], "evidencia_anotada.jpg", { type: "image/jpeg" });
                this.onSaveCallback(finalFile);
                this.close();
            }, 'image/jpeg', 0.85);
        }
    };

    // =========================================================================
    // 4. MODAL DE CÁMARA PANTALLA COMPLETA + CONGELADO + EDICIÓN INMEDIATA
    // =========================================================================
    const EvidenceCameraModal = {
        modalEl: null,
        videoEl: null,
        canvasEl: null,
        ctx: null,
        cameraSelectEl: null,
        stream: null,
        currentState: 'live', // 'live' | 'frozen'
        onSaveCallback: null,
        bgImage: null,
        isDrawing: false,
        currentTool: 'brush', // 'brush', 'arrow', 'circle', 'rect'
        currentColor: '#ef4444',
        currentLineWidth: 8,
        startX: 0,
        startY: 0,
        history: [],
        maxHistory: 15,
        availableDevices: [],

        init() {
            if (this.modalEl) return;

            // Inyectar Estilos CSS del Modal de Cámara Completa
            const style = document.createElement('style');
            style.id = 'evidence-camera-modal-styles';
            style.innerHTML = `
                .evidence-cam-backdrop {
                    display: none;
                    position: fixed;
                    inset: 0;
                    background: rgba(15, 23, 42, 0.95);
                    backdrop-filter: blur(8px);
                    -webkit-backdrop-filter: blur(8px);
                    z-index: 100000;
                    align-items: center;
                    justify-content: center;
                    padding: 0.5rem;
                }
                .evidence-cam-container {
                    background: var(--bg-card, #ffffff);
                    border: 1px solid var(--border-color, #e2e8f0);
                    border-radius: 16px;
                    width: 96vw;
                    max-width: 1280px;
                    height: 92vh;
                    max-height: 92vh;
                    display: flex;
                    flex-direction: column;
                    overflow: hidden;
                    position: relative;
                    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.45);
                    animation: camModalPop 0.22s cubic-bezier(0.16, 1, 0.3, 1);
                }
                @keyframes camModalPop {
                    from { transform: scale(0.96); opacity: 0; }
                    to { transform: scale(1); opacity: 1; }
                }
                .evidence-cam-header {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    padding: 0.75rem 1.25rem;
                    border-bottom: 1px solid var(--border-color, #e2e8f0);
                    background: var(--bg-card, #ffffff);
                    color: var(--text-primary, #0f172a);
                    flex-shrink: 0;
                    gap: 0.75rem;
                    flex-wrap: wrap;
                    z-index: 20;
                }
                .evidence-cam-title {
                    margin: 0;
                    font-size: 1.05rem;
                    font-weight: 700;
                    color: var(--primary-color, #0f766e);
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                }
                .evidence-cam-selector-wrap {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    max-width: 380px;
                    flex: 1;
                }
                .evidence-cam-select {
                    background: var(--bg-main, #f8fafc);
                    color: var(--text-primary, #0f172a);
                    border: 1px solid var(--border-color, #cbd5e1);
                    border-radius: 8px;
                    padding: 0.35rem 0.65rem;
                    font-size: 0.82rem;
                    min-height: 36px;
                    width: 100%;
                }
                .btn-close-cam-modal {
                    background: transparent;
                    border: 1px solid var(--border-color, #cbd5e1);
                    border-radius: 8px;
                    color: var(--text-secondary, #64748b);
                    width: 36px;
                    height: 36px;
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    cursor: pointer;
                    font-size: 1.15rem;
                    transition: all 0.2s;
                }
                .btn-close-cam-modal:hover {
                    background: rgba(239, 68, 68, 0.15);
                    color: #ef4444;
                    border-color: #ef4444;
                }
                .evidence-cam-toolbar {
                    display: none;
                    flex-wrap: wrap;
                    align-items: center;
                    justify-content: space-between;
                    gap: 0.6rem;
                    padding: 0.55rem 1rem;
                    background: var(--bg-card, #ffffff);
                    border-bottom: 1px solid var(--border-color, #e2e8f0);
                    flex-shrink: 0;
                    z-index: 20;
                    animation: fadeIn 0.2s ease;
                }
                .evidence-cam-toolbar .annotator-tool-group {
                    display: inline-flex;
                    align-items: center;
                    gap: 0.25rem;
                    background: var(--bg-main, #f1f5f9);
                    padding: 0.25rem 0.35rem;
                    border-radius: 10px;
                    border: 1px solid var(--border-color, #e2e8f0);
                }
                .evidence-cam-toolbar .annotator-swatches-group {
                    padding: 0.3rem 0.65rem;
                    gap: 0.55rem;
                }
                .evidence-cam-toolbar .annotator-btn {
                    background: transparent;
                    border: 1px solid transparent;
                    border-radius: 7px;
                    padding: 0.35rem 0.65rem;
                    font-size: 0.82rem;
                    font-weight: 600;
                    color: var(--text-secondary, #475569);
                    cursor: pointer;
                    display: inline-flex;
                    align-items: center;
                    gap: 0.35rem;
                    transition: all 0.15s ease;
                    touch-action: manipulation;
                    min-height: 34px;
                    user-select: none;
                    -webkit-user-select: none;
                }
                .evidence-cam-toolbar .annotator-btn i {
                    font-size: 0.82rem;
                }
                .evidence-cam-toolbar .annotator-btn:hover {
                    background: rgba(0, 0, 0, 0.05);
                    color: var(--text-primary, #0f172a);
                }
                .evidence-cam-toolbar .annotator-btn.active {
                    background: var(--primary-color, #0f766e) !important;
                    border-color: var(--primary-color, #0f766e) !important;
                    color: #ffffff !important;
                    box-shadow: 0 2px 8px rgba(15, 118, 110, 0.35);
                }
                .evidence-cam-toolbar .annotator-btn:active {
                    transform: scale(0.96);
                }
                .evidence-cam-toolbar .annotator-btn-danger:hover {
                    background: rgba(239, 68, 68, 0.12) !important;
                    color: #ef4444 !important;
                    border-color: rgba(239, 68, 68, 0.3) !important;
                }
                .evidence-cam-toolbar .annotator-color-swatch {
                    width: 24px;
                    height: 24px;
                    border-radius: 50%;
                    cursor: pointer;
                    border: 2px solid rgba(255, 255, 255, 0.6);
                    transition: transform 0.15s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.15s;
                    touch-action: manipulation;
                    box-shadow: 0 1px 4px rgba(0, 0, 0, 0.25);
                }
                .evidence-cam-toolbar .annotator-color-swatch:hover {
                    transform: scale(1.2);
                }
                .evidence-cam-toolbar .annotator-color-swatch.active {
                    transform: scale(1.25);
                    border-color: #ffffff !important;
                    box-shadow: 0 0 0 2px #334155, 0 0 0 4px var(--primary-color, #0f766e) !important;
                }
                .line-thickness-indicator {
                    display: inline-block;
                    background-color: currentColor;
                    border-radius: 50%;
                    margin-right: 0.15rem;
                }
                .evidence-cam-viewport {
                    flex: 1 1 0px;
                    min-height: 0;
                    height: 0;
                    background: #000000;
                    position: relative;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    overflow: hidden;
                    width: 100%;
                }
                #evidence-modal-video {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    object-fit: contain;
                    display: block;
                    background: #000000;
                }
                #evidence-modal-canvas {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    object-fit: contain;
                    display: none;
                    touch-action: none;
                    cursor: crosshair;
                }
                .evidence-cam-framing-guide {
                    position: absolute;
                    inset: 8%;
                    border: 2px dashed rgba(255, 255, 255, 0.25);
                    border-radius: 12px;
                    pointer-events: none;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    z-index: 5;
                }
                .evidence-cam-framing-guide::before {
                    content: '';
                    width: 40px;
                    height: 40px;
                    border: 2px solid rgba(255, 255, 255, 0.4);
                    border-radius: 50%;
                }
                .evidence-cam-footer {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    padding: 0.75rem 1.25rem;
                    border-top: 1px solid var(--border-color, #e2e8f0);
                    background: var(--bg-card, #ffffff);
                    flex-shrink: 0;
                    min-height: 62px;
                    z-index: 20;
                    gap: 0.75rem;
                }
                .btn-shutter-trigger {
                    background: var(--primary-color, #0f766e);
                    color: #ffffff;
                    border: 3px solid rgba(255, 255, 255, 0.4);
                    border-radius: 50px;
                    padding: 0.65rem 2rem;
                    font-size: 1rem;
                    font-weight: 700;
                    cursor: pointer;
                    display: inline-flex;
                    align-items: center;
                    gap: 0.65rem;
                    box-shadow: 0 4px 14px rgba(15, 118, 110, 0.4);
                    transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
                    min-height: 48px;
                }
                .btn-shutter-trigger:hover {
                    transform: translateY(-1px);
                    box-shadow: 0 6px 20px rgba(15, 118, 110, 0.55);
                }
                .btn-shutter-trigger:active {
                    transform: translateY(1px);
                }

                @media (max-width: 768px) {
                    .evidence-cam-container {
                        width: 98vw;
                        height: 98vh;
                        max-height: 98vh;
                        border-radius: 12px;
                    }
                    .evidence-cam-header {
                        padding: 0.5rem 0.75rem;
                    }
                    .evidence-cam-title {
                        font-size: 0.92rem;
                    }
                    .evidence-cam-toolbar {
                        padding: 0.4rem 0.6rem;
                        gap: 0.35rem;
                        justify-content: center;
                    }
                    .evidence-cam-toolbar .annotator-btn {
                        padding: 0.3rem 0.5rem;
                        font-size: 0.76rem;
                        min-height: 32px;
                    }
                    .evidence-cam-toolbar .annotator-color-swatch {
                        width: 22px;
                        height: 22px;
                    }
                    .btn-shutter-trigger {
                        padding: 0.5rem 1.25rem;
                        font-size: 0.92rem;
                        min-height: 46px;
                    }
                }

                @media (max-width: 520px) {
                    .cam-tool-label {
                        display: none;
                    }
                    .evidence-cam-toolbar .annotator-btn {
                        padding: 0.35rem 0.55rem;
                    }
                }

                @media (max-height: 650px) {
                    .evidence-cam-container {
                        width: 99vw;
                        height: 98vh;
                        max-height: 98vh;
                        border-radius: 10px;
                    }
                    .evidence-cam-header {
                        padding: 0.35rem 0.75rem;
                    }
                    .evidence-cam-title {
                        font-size: 0.86rem;
                    }
                    .evidence-cam-toolbar {
                        padding: 0.25rem 0.5rem;
                        gap: 0.3rem;
                    }
                    .evidence-cam-toolbar .annotator-btn {
                        padding: 0.2rem 0.45rem;
                        font-size: 0.74rem;
                        min-height: 28px;
                    }
                    .evidence-cam-toolbar .annotator-color-swatch {
                        width: 19px;
                        height: 19px;
                    }
                    .evidence-cam-footer {
                        padding: 0.35rem 0.75rem;
                    }
                    .btn-shutter-trigger {
                        padding: 0.35rem 1.2rem;
                        font-size: 0.88rem;
                        min-height: 40px;
                    }
                }
            `;
            document.head.appendChild(style);

            // Inyectar HTML del Modal
            const modalDiv = document.createElement('div');
            modalDiv.id = 'evidence-cam-modal';
            modalDiv.className = 'evidence-cam-backdrop';
            modalDiv.innerHTML = `
                <div class="evidence-cam-container">
                    <div class="evidence-cam-header">
                        <h3 class="evidence-cam-title" id="evidence-modal-title">
                            <i class="fa-solid fa-camera"></i> Capturar Evidencia en Alta Calidad
                        </h3>
                        <div class="evidence-cam-selector-wrap" id="evidence-modal-selector-container">
                            <select id="evidence-modal-camera-select" class="evidence-cam-select" title="Cambiar Cámara"></select>
                        </div>
                        <button type="button" class="btn-close-cam-modal" onclick="EvidenceCameraModal.close()" title="Cerrar"><i class="fa-solid fa-xmark"></i></button>
                    </div>

                    <!-- Toolbar de Anotación (Visible solo al congelar) -->
                    <div class="evidence-cam-toolbar" id="evidence-modal-toolbar">
                        <div class="annotator-tool-group">
                            <button type="button" class="annotator-btn active" data-cam-tool="brush" onclick="EvidenceCameraModal.setTool('brush', this)" title="Pincel a mano alzada">
                                <i class="fa-solid fa-pen"></i> <span class="cam-tool-label">Pincel</span>
                            </button>
                            <button type="button" class="annotator-btn" data-cam-tool="arrow" onclick="EvidenceCameraModal.setTool('arrow', this)" title="Flecha indicadora">
                                <i class="fa-solid fa-arrow-right"></i> <span class="cam-tool-label">Flecha</span>
                            </button>
                            <button type="button" class="annotator-btn" data-cam-tool="circle" onclick="EvidenceCameraModal.setTool('circle', this)" title="Círculo de resaltado">
                                <i class="fa-regular fa-circle"></i> <span class="cam-tool-label">Círculo</span>
                            </button>
                            <button type="button" class="annotator-btn" data-cam-tool="rect" onclick="EvidenceCameraModal.setTool('rect', this)" title="Cuadro de enfoque">
                                <i class="fa-regular fa-square"></i> <span class="cam-tool-label">Cuadro</span>
                            </button>
                        </div>

                        <div class="annotator-tool-group annotator-swatches-group">
                            <div class="annotator-color-swatch active" style="background-color: #ef4444;" onclick="EvidenceCameraModal.setColor('#ef4444', this)" title="Rojo (Anomalía / Falla)"></div>
                            <div class="annotator-color-swatch" style="background-color: #eab308;" onclick="EvidenceCameraModal.setColor('#eab308', this)" title="Amarillo (Precaución)"></div>
                            <div class="annotator-color-swatch" style="background-color: #10b981;" onclick="EvidenceCameraModal.setColor('#10b981', this)" title="Verde (Correcto)"></div>
                            <div class="annotator-color-swatch" style="background-color: #3b82f6;" onclick="EvidenceCameraModal.setColor('#3b82f6', this)" title="Azul (Referencia)"></div>
                            <div class="annotator-color-swatch" style="background-color: #ffffff;" onclick="EvidenceCameraModal.setColor('#ffffff', this)" title="Blanco"></div>
                        </div>

                        <div class="annotator-tool-group">
                            <button type="button" class="annotator-btn" onclick="EvidenceCameraModal.setLineWidth(4, this)" title="Grosor fino">
                                <span class="line-thickness-indicator" style="width: 4px; height: 4px;"></span> Fino
                            </button>
                            <button type="button" class="annotator-btn active" onclick="EvidenceCameraModal.setLineWidth(8, this)" title="Grosor medio">
                                <span class="line-thickness-indicator" style="width: 7px; height: 7px;"></span> Medio
                            </button>
                            <button type="button" class="annotator-btn" onclick="EvidenceCameraModal.setLineWidth(16, this)" title="Grosor grueso">
                                <span class="line-thickness-indicator" style="width: 10px; height: 10px;"></span> Grueso
                            </button>
                        </div>

                        <div class="annotator-tool-group">
                            <button type="button" class="annotator-btn" onclick="EvidenceCameraModal.undo()" title="Deshacer último trazo">
                                <i class="fa-solid fa-rotate-left"></i> <span class="cam-tool-label">Deshacer</span>
                            </button>
                            <button type="button" class="annotator-btn annotator-btn-danger" onclick="EvidenceCameraModal.clearCanvas()" title="Borrar trazos">
                                <i class="fa-solid fa-trash-can"></i> <span class="cam-tool-label">Limpiar</span>
                            </button>
                        </div>
                    </div>

                    <!-- Viewport: Video en vivo o Canvas congelado -->
                    <div class="evidence-cam-viewport">
                        <video id="evidence-modal-video" autoplay playsinline muted></video>
                        <canvas id="evidence-modal-canvas"></canvas>
                        <div class="evidence-cam-framing-guide" id="evidence-modal-guide"></div>
                    </div>

                    <!-- Footer: Botones según estado -->
                    <div class="evidence-cam-footer">
                        <!-- Vista LIVE -->
                        <div id="footer-live-view" style="display: flex; width: 100%; align-items: center; justify-content: space-between;">
                            <button type="button" class="btn btn-secondary" onclick="EvidenceCameraModal.close()" style="min-height: 44px; font-weight: 600; padding: 0.45rem 1rem;">
                                Cancelar
                            </button>
                            <button type="button" class="btn-shutter-trigger" onclick="EvidenceCameraModal.freezeFrame()">
                                <i class="fa-solid fa-circle-dot"></i> Capturar Foto
                            </button>
                            <span style="font-size: 0.8rem; color: #94a3b8; font-weight: 600;">
                                <i class="fa-solid fa-expand"></i> Máx. Calidad
                            </span>
                        </div>

                        <!-- Vista FROZEN -->
                        <div id="footer-frozen-view" style="display: none; width: 100%; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 0.5rem;">
                            <button type="button" class="btn btn-secondary" onclick="EvidenceCameraModal.retakePhoto()" style="min-height: 44px; font-weight: 600; padding: 0.45rem 1.15rem; display: inline-flex; align-items: center; gap: 0.4rem;">
                                <i class="fa-solid fa-rotate-left"></i> Tomar otra foto
                            </button>
                            <div style="display: flex; gap: 0.6rem; align-items: center;">
                                <button type="button" class="btn btn-secondary" onclick="EvidenceCameraModal.close()" style="min-height: 44px; font-weight: 600; padding: 0.45rem 1rem;">
                                    Cancelar
                                </button>
                                <button type="button" class="btn btn-primary" onclick="EvidenceCameraModal.saveEvidence()" style="min-height: 44px; font-weight: 700; font-size: 0.95rem; padding: 0.45rem 1.4rem; background-color: var(--primary-color, #0f766e); display: inline-flex; align-items: center; gap: 0.5rem; box-shadow: 0 4px 12px rgba(15, 118, 110, 0.3);">
                                    <i class="fa-solid fa-check"></i> Guardar Evidencia
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(modalDiv);

            this.modalEl = modalDiv;
            this.videoEl = document.getElementById('evidence-modal-video');
            this.canvasEl = document.getElementById('evidence-modal-canvas');
            this.ctx = this.canvasEl.getContext('2d');
            this.cameraSelectEl = document.getElementById('evidence-modal-camera-select');

            this.bindEvents();
        },

        bindEvents() {
            this.canvasEl.addEventListener('pointerdown', (e) => this.onPointerDown(e));
            this.canvasEl.addEventListener('pointermove', (e) => this.onPointerMove(e));
            this.canvasEl.addEventListener('pointerup', (e) => this.onPointerUp(e));
            this.canvasEl.addEventListener('pointercancel', (e) => this.onPointerUp(e));
        },

        getCanvasCoords(e) {
            const rect = this.canvasEl.getBoundingClientRect();
            const scaleX = this.canvasEl.width / rect.width;
            const scaleY = this.canvasEl.height / rect.height;
            return {
                x: (e.clientX - rect.left) * scaleX,
                y: (e.clientY - rect.top) * scaleY
            };
        },

        onPointerDown(e) {
            if (this.currentState !== 'frozen') return;
            e.preventDefault();
            this.isDrawing = true;
            this.canvasEl.setPointerCapture(e.pointerId);

            const coords = this.getCanvasCoords(e);
            this.startX = coords.x;
            this.startY = coords.y;

            this.saveStateToHistory();

            this.ctx.strokeStyle = this.currentColor;
            this.ctx.fillStyle = this.currentColor;
            this.ctx.lineWidth = this.currentLineWidth;
            this.ctx.lineCap = 'round';
            this.ctx.lineJoin = 'round';

            if (this.currentTool === 'brush') {
                this.ctx.beginPath();
                this.ctx.moveTo(this.startX, this.startY);
                this.ctx.lineTo(this.startX, this.startY);
                this.ctx.stroke();
            }
        },

        onPointerMove(e) {
            if (!this.isDrawing || this.currentState !== 'frozen') return;
            e.preventDefault();

            const coords = this.getCanvasCoords(e);
            const currentX = coords.x;
            const currentY = coords.y;

            if (this.currentTool === 'brush') {
                this.ctx.lineTo(currentX, currentY);
                this.ctx.stroke();
            } else {
                this.restoreLatestSnapshot();
                this.ctx.strokeStyle = this.currentColor;
                this.ctx.fillStyle = this.currentColor;
                this.ctx.lineWidth = this.currentLineWidth;
                this.ctx.lineCap = 'round';
                this.ctx.lineJoin = 'round';

                if (this.currentTool === 'arrow') {
                    this.drawArrow(this.startX, this.startY, currentX, currentY);
                } else if (this.currentTool === 'rect') {
                    this.drawRect(this.startX, this.startY, currentX, currentY);
                } else if (this.currentTool === 'circle') {
                    this.drawCircle(this.startX, this.startY, currentX, currentY);
                }
            }
        },

        onPointerUp(e) {
            if (!this.isDrawing) return;
            e.preventDefault();
            this.isDrawing = false;
            try {
                this.canvasEl.releasePointerCapture(e.pointerId);
            } catch (err) {}

            if (this.currentTool === 'brush') {
                this.ctx.closePath();
            }
        },

        drawArrow(fromX, fromY, toX, toY) {
            const headlen = Math.max(22, this.currentLineWidth * 3.4);
            const angle = Math.atan2(toY - fromY, toX - fromX);

            this.ctx.beginPath();
            this.ctx.moveTo(fromX, fromY);
            this.ctx.lineTo(toX, toY);
            this.ctx.stroke();

            this.ctx.beginPath();
            this.ctx.moveTo(toX, toY);
            this.ctx.lineTo(toX - headlen * Math.cos(angle - Math.PI / 6), toY - headlen * Math.sin(angle - Math.PI / 6));
            this.ctx.lineTo(toX - headlen * Math.cos(angle + Math.PI / 6), toY - headlen * Math.sin(angle + Math.PI / 6));
            this.ctx.closePath();
            this.ctx.fill();
        },

        drawRect(fromX, fromY, toX, toY) {
            const width = toX - fromX;
            const height = toY - fromY;
            this.ctx.beginPath();
            this.ctx.strokeRect(fromX, fromY, width, height);
        },

        drawCircle(fromX, fromY, toX, toY) {
            const radiusX = Math.abs(toX - fromX) / 2;
            const radiusY = Math.abs(toY - fromY) / 2;
            const centerX = fromX + (toX - fromX) / 2;
            const centerY = fromY + (toY - fromY) / 2;

            this.ctx.beginPath();
            this.ctx.ellipse(centerX, centerY, radiusX, radiusY, 0, 0, 2 * Math.PI);
            this.ctx.stroke();
        },

        saveStateToHistory() {
            if (this.history.length >= this.maxHistory) {
                this.history.shift();
            }
            this.history.push(this.ctx.getImageData(0, 0, this.canvasEl.width, this.canvasEl.height));
        },

        restoreLatestSnapshot() {
            if (this.history.length > 0) {
                const latest = this.history[this.history.length - 1];
                this.ctx.putImageData(latest, 0, 0);
            }
        },

        undo() {
            if (this.history.length > 1) {
                this.history.pop();
                const prevState = this.history[this.history.length - 1];
                this.ctx.putImageData(prevState, 0, 0);
            } else if (this.history.length === 1) {
                this.clearCanvas();
            }
        },

        clearCanvas() {
            if (!this.bgImage) return;
            this.ctx.clearRect(0, 0, this.canvasEl.width, this.canvasEl.height);
            this.ctx.drawImage(this.bgImage, 0, 0, this.canvasEl.width, this.canvasEl.height);
            this.history = [this.ctx.getImageData(0, 0, this.canvasEl.width, this.canvasEl.height)];
        },

        setTool(toolName, btnElement) {
            this.currentTool = toolName;
            document.querySelectorAll('#evidence-modal-toolbar [data-cam-tool]').forEach(b => b.classList.remove('active'));
            if (btnElement) btnElement.classList.add('active');
        },

        setColor(colorHex, swatchElement) {
            this.currentColor = colorHex;
            document.querySelectorAll('#evidence-modal-toolbar .annotator-color-swatch').forEach(s => s.classList.remove('active'));
            if (swatchElement) swatchElement.classList.add('active');
        },

        setLineWidth(width, btnElement) {
            this.currentLineWidth = width;
            if (btnElement && btnElement.parentElement) {
                btnElement.parentElement.querySelectorAll('.annotator-btn').forEach(b => b.classList.remove('active'));
                btnElement.classList.add('active');
            }
        },

        async open(onSave) {
            this.init();
            this.onSaveCallback = onSave;
            this.currentState = 'live';
            this.history = [];
            this.bgImage = null;

            // Mostrar modal
            this.modalEl.style.display = 'flex';
            document.body.style.overflow = 'hidden';

            // Resetear UI a estado LIVE
            this.videoEl.style.display = 'block';
            this.canvasEl.style.display = 'none';
            document.getElementById('evidence-modal-guide').style.display = 'flex';
            document.getElementById('evidence-modal-toolbar').style.display = 'none';
            document.getElementById('evidence-modal-selector-container').style.display = 'none';
            document.getElementById('footer-live-view').style.display = 'flex';
            document.getElementById('footer-frozen-view').style.display = 'none';
            document.getElementById('evidence-modal-title').innerHTML = '<i class="fa-solid fa-camera"></i> Capturar Evidencia en Alta Calidad';

            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                Swal.fire('Error', 'Tu navegador o dispositivo no soporta acceso directo a la cámara.', 'error');
                this.close();
                return;
            }

            try {
                // 1. Iniciar stream con prioridad trasera (environment)
                await this.startStream(null);

                // 2. Enumerar dispositivos con permisos ya otorgados
                await this.updateCameraDevices();
            } catch (err) {
                console.error("Error al iniciar cámara de evidencia:", err);
                Swal.fire('Error', 'No se pudo acceder a la cámara: ' + (err.message || err), 'error');
                this.close();
            }
        },

        async updateCameraDevices() {
            try {
                this.availableDevices = await CameraHelper.getVideoDevices();
                this.cameraSelectEl.innerHTML = '';

                if (this.availableDevices && this.availableDevices.length > 1) {
                    let activeTrackId = null;
                    if (this.stream) {
                        const track = this.stream.getVideoTracks()[0];
                        if (track && track.getSettings) {
                            activeTrackId = track.getSettings().deviceId;
                        }
                    }

                    this.availableDevices.forEach((device, idx) => {
                        const opt = document.createElement('option');
                        opt.value = device.deviceId;
                        opt.innerText = device.label || `Cámara ${idx + 1}`;
                        if (activeTrackId && device.deviceId === activeTrackId) {
                            opt.selected = true;
                        }
                        this.cameraSelectEl.appendChild(opt);
                    });

                    document.getElementById('evidence-modal-selector-container').style.display = 'flex';
                    this.cameraSelectEl.onchange = () => {
                        this.startStream(this.cameraSelectEl.value);
                    };
                } else {
                    document.getElementById('evidence-modal-selector-container').style.display = 'none';
                }
            } catch (e) {
                console.warn('No se pudieron listar cámaras adicionales:', e);
                document.getElementById('evidence-modal-selector-container').style.display = 'none';
            }
        },

        async startStream(deviceId) {
            if (this.stream) {
                this.stream.getTracks().forEach(t => t.stop());
                this.stream = null;
            }

            const constraints = CameraHelper.getCameraConstraints(deviceId);
            try {
                const stream = await navigator.mediaDevices.getUserMedia(constraints);
                this.stream = stream;
                this.videoEl.srcObject = stream;
                await this.videoEl.play();
            } catch (err) {
                console.error("Error getUserMedia:", err);
                Swal.fire('Error', 'No se pudo activar el video: ' + err.message, 'error');
            }
        },

        freezeFrame() {
            if (!this.videoEl || !this.videoEl.videoWidth) {
                Swal.fire('Atención', 'La cámara aún no tiene señal de video lista.', 'warning');
                return;
            }

            // Congelar a máxima resolución nativa del sensor
            const width = this.videoEl.videoWidth;
            const height = this.videoEl.videoHeight;

            this.canvasEl.width = width;
            this.canvasEl.height = height;

            // Dibujar frame capturado
            this.ctx.drawImage(this.videoEl, 0, 0, width, height);

            // Guardar imagen base para reset/clear
            const snapshotData = this.ctx.getImageData(0, 0, width, height);
            this.history = [snapshotData];

            const baseImg = new Image();
            baseImg.src = this.canvasEl.toDataURL('image/jpeg', 0.95);
            this.bgImage = baseImg;

            // Cambiar a estado FROZEN
            this.currentState = 'frozen';

            // Pausar video en vivo y mostrar canvas
            this.videoEl.style.display = 'none';
            this.canvasEl.style.display = 'block';
            document.getElementById('evidence-modal-guide').style.display = 'none';
            document.getElementById('evidence-modal-toolbar').style.display = 'flex';
            document.getElementById('evidence-modal-selector-container').style.display = 'none';
            document.getElementById('footer-live-view').style.display = 'none';
            document.getElementById('footer-frozen-view').style.display = 'flex';
            document.getElementById('evidence-modal-title').innerHTML = '<i class="fa-solid fa-paintbrush"></i> Foto Capturada — Puedes editarla o guardarla tal cual';
        },

        retakePhoto() {
            this.currentState = 'live';
            this.history = [];
            this.bgImage = null;

            // Regresar a vista LIVE
            this.videoEl.style.display = 'block';
            this.canvasEl.style.display = 'none';
            document.getElementById('evidence-modal-guide').style.display = 'flex';
            document.getElementById('evidence-modal-toolbar').style.display = 'none';
            if (this.availableDevices.length > 1) {
                document.getElementById('evidence-modal-selector-container').style.display = 'flex';
            }
            document.getElementById('footer-live-view').style.display = 'flex';
            document.getElementById('footer-frozen-view').style.display = 'none';
            document.getElementById('evidence-modal-title').innerHTML = '<i class="fa-solid fa-camera"></i> Capturar Evidencia en Alta Calidad';
        },

        saveEvidence() {
            if (!this.canvasEl || !this.onSaveCallback) return;

            // Exportar a máxima calidad JPEG (0.92)
            this.canvasEl.toBlob((blob) => {
                if (!blob) {
                    Swal.fire('Error', 'No se pudo generar el archivo de imagen.', 'error');
                    return;
                }
                const filename = `evidencia_${Date.now()}.jpg`;
                const finalFile = new File([blob], filename, { type: 'image/jpeg' });
                this.onSaveCallback(finalFile);
                this.close();
            }, 'image/jpeg', 0.92);
        },

        close() {
            if (this.stream) {
                this.stream.getTracks().forEach(t => t.stop());
                this.stream = null;
            }
            if (this.videoEl) {
                this.videoEl.srcObject = null;
            }
            if (this.modalEl) {
                this.modalEl.style.display = 'none';
            }
            document.body.style.overflow = '';
            this.currentState = 'live';
            this.history = [];
            this.bgImage = null;
        }
    };

    // Exportar al ámbito global
    window.VoiceDictation = VoiceDictation;
    window.CameraHelper = CameraHelper;
    window.PhotoAnnotator = PhotoAnnotator;
    window.EvidenceCameraModal = EvidenceCameraModal;

})(window);

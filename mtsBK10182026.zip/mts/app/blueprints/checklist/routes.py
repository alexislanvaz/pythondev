import os
import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app, session, jsonify
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from app.blueprints.db import run_query

checklist_bp = Blueprint('checklist', __name__, template_folder='templates')

@checklist_bp.route('/templates')
@login_required
def listar_templates():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('index'))
    
    templates = run_query("""
        SELECT t.ID, t.Nombre, t.Descripcion, t.TipoFrecuencia, t.NivelChecklistID, 
               nl.Nombre AS NivelNombre, nl.Codigo AS NivelCodigo,
               t.activo, t.fecharegistro, u.Nombre AS Creador 
        FROM ChecklistTemplates t
        INNER JOIN CatUsuarios u ON t.UsuarioRegistroID = u.ID
        LEFT JOIN CatNivelesChecklist nl ON t.NivelChecklistID = nl.ID
        ORDER BY t.ID DESC
    """, query_type='SELECT')
    
    return render_template('checklist/admin_templates.html', templates=templates)

@checklist_bp.route('/templates/crear', methods=['GET', 'POST'])
@login_required
def crear_template():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        current_app.logger.info(f"CREAR TEMPLATE POST DATA: {dict(request.form)}")
        nombre = request.form.get('nombre', '').strip()
        descripcion = request.form.get('descripcion', '').strip()
        tipo_frecuencia = request.form.get('tipo_frecuencia', '').strip()
        nivel_checklist_id = request.form.get('nivel_checklist_id', '2').strip()
        
        # Obtener los campos dinamicos
        field_names = request.form.getlist('field_name')
        field_types = request.form.getlist('field_type')
        min_limits = request.form.getlist('min_limit')
        max_limits = request.form.getlist('max_limit')
        units = request.form.getlist('unit')
        requireds = request.form.getlist('required')
        options_list = request.form.getlist('options')
        
        if not nombre or not tipo_frecuencia or not nivel_checklist_id:
            flash('El nombre, la frecuencia y el nivel de aplicacion son obligatorios.', 'danger')
            return redirect(url_for('checklist.crear_template'))
        
        if not field_names:
            flash('Debe agregar al menos un campo a la plantilla.', 'danger')
            return redirect(url_for('checklist.crear_template'))
        
        try:
            # Insertar plantilla
            res_temp = run_query("""
                INSERT INTO ChecklistTemplates (Nombre, Descripcion, TipoFrecuencia, NivelChecklistID, UsuarioRegistroID, activo, fecharegistro)
                OUTPUT INSERTED.ID
                VALUES (?, ?, ?, ?, ?, 1, GETDATE())
            """, (nombre, descripcion, tipo_frecuencia, int(nivel_checklist_id), current_user.id), query_type='INSERT')
            
            template_id = res_temp[0]['ID']
            
            # Insertar campos de plantilla
            for idx, f_name in enumerate(field_names):
                f_type = field_types[idx]
                f_min = float(min_limits[idx]) if min_limits[idx] else None
                f_max = float(max_limits[idx]) if max_limits[idx] else None
                f_unit = units[idx].strip() if units[idx] else None
                f_req = 1 if requireds[idx] == 'true' or requireds[idx] == '1' else 0
                f_opts = options_list[idx].strip() if options_list[idx] else None
                
                run_query("""
                    INSERT INTO ChecklistTemplateItems (TemplateID, Nombre, TipoCampo, ValorMinimo, ValorMaximo, UnidadMedida, OpcionesSeleccion, Requerido, Orden, activo)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
                """, (template_id, f_name.strip(), f_type, f_min, f_max, f_unit, f_opts, f_req, idx), query_type='INSERT')
                
            flash('Plantilla de checklist creada exitosamente.', 'success')
            return redirect(url_for('checklist.listar_templates'))
        except Exception as e:
            current_app.logger.error(f"Error al crear plantilla: {e}")
            flash('Ocurrio un error al guardar la plantilla.', 'danger')
            
    niveles = run_query("SELECT ID, Codigo, Nombre, Descripcion FROM CatNivelesChecklist WHERE activo = 1 ORDER BY ID", query_type='SELECT')
    return render_template('checklist/crear_template.html', niveles=niveles)

@checklist_bp.route('/templates/editar/<int:template_id>', methods=['GET', 'POST'])
@login_required
def editar_template(template_id):
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('index'))
        
    template_info = run_query("SELECT ID, Nombre, Descripcion, TipoFrecuencia, NivelChecklistID, activo FROM ChecklistTemplates WHERE ID = ?", (template_id,), 'SELECT')
    if not template_info:
        flash('Plantilla no encontrada.', 'danger')
        return redirect(url_for('checklist.listar_templates'))
        
    if request.method == 'POST':
        nombre = request.form.get('nombre', '').strip()
        descripcion = request.form.get('descripcion', '').strip()
        tipo_frecuencia = request.form.get('tipo_frecuencia', '').strip()
        nivel_checklist_id = request.form.get('nivel_checklist_id', '2').strip()
        
        # Obtener los campos dinamicos
        field_ids = request.form.getlist('field_id')
        field_names = request.form.getlist('field_name')
        field_types = request.form.getlist('field_type')
        min_limits = request.form.getlist('min_limit')
        max_limits = request.form.getlist('max_limit')
        units = request.form.getlist('unit')
        requireds = request.form.getlist('required')
        options_list = request.form.getlist('options')
        
        if not nombre or not tipo_frecuencia or not nivel_checklist_id:
            flash('El nombre, la frecuencia y el nivel de aplicacion son obligatorios.', 'danger')
            return redirect(url_for('checklist.editar_template', template_id=template_id))
            
        if not field_names:
            flash('Debe agregar al menos un campo a la plantilla.', 'danger')
            return redirect(url_for('checklist.editar_template', template_id=template_id))
            
        try:
            # Actualizar plantilla
            run_query("""
                UPDATE ChecklistTemplates 
                SET Nombre = ?, Descripcion = ?, TipoFrecuencia = ?, NivelChecklistID = ?
                WHERE ID = ?
            """, (nombre, descripcion, tipo_frecuencia, int(nivel_checklist_id), template_id), query_type='UPDATE')
            
            submitted_ids = []
            
            # Actualizar/Insertar campos
            for idx, f_name in enumerate(field_names):
                f_id_raw = field_ids[idx] if idx < len(field_ids) else 'new'
                f_type = field_types[idx]
                f_min = float(min_limits[idx]) if idx < len(min_limits) and min_limits[idx] else None
                f_max = float(max_limits[idx]) if idx < len(max_limits) and max_limits[idx] else None
                f_unit = units[idx].strip() if idx < len(units) and units[idx] else None
                f_req = 1 if idx < len(requireds) and (requireds[idx] == 'true' or requireds[idx] == '1') else 0
                f_opts = options_list[idx].strip() if idx < len(options_list) and options_list[idx] else None
                
                if f_id_raw != 'new' and f_id_raw.isdigit():
                    f_id = int(f_id_raw)
                    # Actualizar campo existente
                    run_query("""
                        UPDATE ChecklistTemplateItems 
                        SET Nombre = ?, TipoCampo = ?, ValorMinimo = ?, ValorMaximo = ?, UnidadMedida = ?, OpcionesSeleccion = ?, Requerido = ?, Orden = ?, activo = 1
                        WHERE ID = ? AND TemplateID = ?
                    """, (f_name.strip(), f_type, f_min, f_max, f_unit, f_opts, f_req, idx, f_id, template_id), query_type='UPDATE')
                    submitted_ids.append(f_id)
                else:
                    # Insertar nuevo campo
                    res_item = run_query("""
                        INSERT INTO ChecklistTemplateItems (TemplateID, Nombre, TipoCampo, ValorMinimo, ValorMaximo, UnidadMedida, OpcionesSeleccion, Requerido, Orden, activo)
                        OUTPUT INSERTED.ID
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
                    """, (template_id, f_name.strip(), f_type, f_min, f_max, f_unit, f_opts, f_req, idx), query_type='INSERT')
                    if res_item:
                        submitted_ids.append(res_item[0]['ID'])
            
            # Desactivar campos que no fueron enviados (eliminados en la UI)
            if submitted_ids:
                placeholders = ",".join(["?"] * len(submitted_ids))
                query_deactivate = f"""
                    UPDATE ChecklistTemplateItems 
                    SET activo = 0 
                    WHERE TemplateID = ? AND ID NOT IN ({placeholders})
                """
                params = [template_id] + submitted_ids
                run_query(query_deactivate, tuple(params), query_type='UPDATE')
            else:
                run_query("UPDATE ChecklistTemplateItems SET activo = 0 WHERE TemplateID = ?", (template_id,), query_type='UPDATE')
                
            flash('Plantilla de checklist actualizada exitosamente.', 'success')
            return redirect(url_for('checklist.listar_templates'))
        except Exception as e:
            current_app.logger.error(f"Error al actualizar plantilla {template_id}: {e}")
            flash('Ocurrio un error al actualizar la plantilla.', 'danger')
            
    items = run_query("""
        SELECT ID, Nombre, TipoCampo, ValorMinimo, ValorMaximo, UnidadMedida, OpcionesSeleccion, Requerido 
        FROM ChecklistTemplateItems 
        WHERE TemplateID = ? AND activo = 1 
        ORDER BY Orden
    """, (template_id,), 'SELECT')
    
    niveles = run_query("SELECT ID, Codigo, Nombre, Descripcion FROM CatNivelesChecklist WHERE activo = 1 ORDER BY ID", query_type='SELECT')
    
    return render_template('checklist/editar_template.html', template=template_info[0], items=items, niveles=niveles)

@checklist_bp.route('/templates/toggle/<int:id>', methods=['POST'])
@login_required
def toggle_template(id):
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        return jsonify({"success": False, "error": "No autorizado"}), 403
    
    try:
        current_status = run_query("SELECT activo FROM ChecklistTemplates WHERE ID = ?", (id,), 'SELECT')
        if not current_status:
            return jsonify({"success": False, "error": "Plantilla no encontrada"}), 404
        
        new_status = 0 if current_status[0]['activo'] else 1
        run_query("UPDATE ChecklistTemplates SET activo = ? WHERE ID = ?", (new_status, id), 'UPDATE')
        return jsonify({"success": True, "new_status": new_status})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@checklist_bp.route('/llenar', methods=['GET', 'POST'])
@login_required
def seleccionar_checklist():
    if request.method == 'POST':
        template_id = request.form.get('template_id')
        linea_id = request.form.get('linea_id')
        estacion_id = request.form.get('estacion_id', '').strip()
        equipo_id = request.form.get('equipo_id', '').strip()
        
        if not template_id or not linea_id:
            flash('Debe seleccionar la linea y la plantilla.', 'danger')
            return redirect(url_for('checklist.seleccionar_checklist'))
            
        return redirect(url_for('checklist.llenar_checklist', 
                                template_id=template_id, 
                                linea_id=linea_id,
                                estacion_id=estacion_id or '', 
                                equipo_id=equipo_id or ''))
        
    templates = run_query("""
        SELECT t.ID, t.Nombre, t.TipoFrecuencia, t.NivelChecklistID, nl.Codigo AS NivelCodigo, nl.Nombre AS NivelNombre
        FROM ChecklistTemplates t
        INNER JOIN CatNivelesChecklist nl ON t.NivelChecklistID = nl.ID
        WHERE t.activo = 1
        ORDER BY t.Nombre
    """, query_type='SELECT')
    lineas = run_query("SELECT ID, Nombre FROM CatLineas WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    estaciones = run_query("SELECT ID, LineaID, Nombre FROM CatEstaciones WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    equipos = run_query("SELECT ID, EstacionID, Nombre FROM CatEquipos WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    
    return render_template('checklist/seleccionar_ejecutar.html', 
                           templates=templates, 
                           lineas=lineas, 
                           estaciones=estaciones, 
                           equipos=equipos)

@checklist_bp.route('/llenar/<int:template_id>', methods=['GET', 'POST'])
@login_required
def llenar_checklist(template_id):
    linea_id = request.args.get('linea_id')
    estacion_id = request.args.get('estacion_id')
    equipo_id = request.args.get('equipo_id')
    
    template_info = run_query("SELECT ID, Nombre, Descripcion, TipoFrecuencia, NivelChecklistID FROM ChecklistTemplates WHERE ID = ? AND activo = 1", (template_id,), 'SELECT')
    if not template_info:
        flash('Plantilla no encontrada o inactiva.', 'danger')
        return redirect(url_for('checklist.seleccionar_checklist'))
        
    items = run_query("SELECT ID, Nombre, TipoCampo, ValorMinimo, ValorMaximo, UnidadMedida, OpcionesSeleccion, Requerido FROM ChecklistTemplateItems WHERE TemplateID = ? AND activo = 1 ORDER BY Orden", (template_id,), 'SELECT')
    
    linea_info = run_query("SELECT Nombre FROM CatLineas WHERE ID = ?", (linea_id,), 'SELECT') if linea_id else None
    estacion_info = run_query("SELECT Nombre FROM CatEstaciones WHERE ID = ?", (estacion_id,), 'SELECT') if estacion_id else None
    equipo_info = run_query("SELECT Nombre FROM CatEquipos WHERE ID = ?", (equipo_id,), 'SELECT') if equipo_id else None
    
    # Si por alguna razon falta linea_id pero viene estacion_id, derivar linea
    if not linea_info and estacion_id:
        est_lin = run_query("SELECT l.Nombre FROM CatEstaciones e INNER JOIN CatLineas l ON e.LineaID = l.ID WHERE e.ID = ?", (estacion_id,), 'SELECT')
        if est_lin:
            linea_info = est_lin
    
    if request.method == 'POST':
        comentario = request.form.get('comentario_general', '').strip()
        evidence_file = request.files.get('evidencia_archivo')
        uploaded_path = request.form.get('path_evidencia_subida', '').strip()
        
        path_evidencia = None
        if uploaded_path:
            path_evidencia = uploaded_path
        elif evidence_file and evidence_file.filename != '':
            storage_dir = current_app.config.get('STORAGE_PATH')
            if not storage_dir:
                flash("STORAGE_PATH no configurado en el sistema.", "danger")
                return redirect(url_for('checklist.seleccionar_checklist'))
            upload_dir = os.path.join(storage_dir, 'checklists')
            try:
                os.makedirs(upload_dir, exist_ok=True)
                filename = secure_filename(f"chk_{template_id}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}_{evidence_file.filename}")
                evidence_file.save(os.path.join(upload_dir, filename))
                path_evidencia = f"checklists/{filename}"
            except PermissionError as pe:
                current_app.logger.error(f"Error de permisos al guardar en Storage '{upload_dir}': {pe}")
                flash(f"Error de permisos al guardar archivo en almacenamiento de red ({upload_dir}).", "warning")
            except Exception as fe:
                current_app.logger.error(f"Error al guardar archivo en '{upload_dir}': {fe}")
                flash(f"No se pudo guardar la evidencia fisica: {str(fe)}", "warning")
            
        try:
            # Crear ejecucion
            res_exec = run_query("""
                INSERT INTO ChecklistEjecuciones (TemplateID, UsuarioID, TurnoID, LineaID, EstacionID, EquipoID, FechaEjecucion, ComentarioGeneral, PathEvidencia, activo)
                OUTPUT INSERTED.ID
                VALUES (?, ?, ?, ?, ?, ?, GETDATE(), ?, ?, 1)
            """, (
                template_id, 
                current_user.id, 
                current_user.turno_id or 1, 
                linea_id or None,
                estacion_id or None, 
                equipo_id or None, 
                comentario or None, 
                path_evidencia
            ), query_type='INSERT')
            
            exec_id = res_exec[0]['ID']
            
            # Guardar valores individuales de cada campo
            for item in items:
                item_id = item['ID']
                val_raw = request.form.get(f"val_{item_id}", '').strip()
                
                v_text = None
                v_num = None
                v_bool = None
                out_of_bounds = 0
                
                if item['TipoCampo'] == 'number':
                    if val_raw:
                        v_num = float(val_raw)
                        v_min = item['ValorMinimo']
                        v_max = item['ValorMaximo']
                        if (v_min is not None and v_num < v_min) or (v_max is not None and v_num > v_max):
                            out_of_bounds = 1
                elif item['TipoCampo'] == 'boolean':
                    v_bool = 1 if val_raw == '1' else 0
                else:
                    v_text = val_raw
                    
                run_query("""
                    INSERT INTO ChecklistEjecucionValores (EjecucionID, ItemID, ValorTexto, ValorNumero, ValorBoolean, EstaFueraRango)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (exec_id, item_id, v_text, v_num, v_bool, out_of_bounds), query_type='INSERT')
                
            flash('Checklist enviado y registrado exitosamente.', 'success')
            return redirect(url_for('checklist.seleccionar_checklist'))
        except Exception as e:
            current_app.logger.error(f"Error al registrar ejecucion de checklist: {e}")
            flash('Ocurrio un error al guardar la ejecucion del checklist.', 'danger')
            
    return render_template('checklist/llenar_checklist.html', 
                           template=template_info[0], 
                           items=items,
                           linea_id=linea_id,
                           estacion_id=estacion_id, 
                           equipo_id=equipo_id,
                           linea_nombre=linea_info[0]['Nombre'] if linea_info else None,
                           estacion_nombre=estacion_info[0]['Nombre'] if estacion_info else None,
                           equipo_nombre=equipo_info[0]['Nombre'] if equipo_info else None)

@checklist_bp.route('/historial')
@login_required
def historial_ejecuciones():
    # Obtener el listado de todas las ejecuciones de checklist con Linea y Estacion
    ejecuciones = run_query("""
        SELECT e.ID, t.Nombre AS TemplateNombre, u.Nombre AS TecnicoNombre, tur.Nombre AS TurnoNombre, 
               lin.Nombre AS LineaNombre, est.Nombre AS EstacionNombre, eq.Nombre AS EquipoNombre, e.FechaEjecucion,
               (SELECT COUNT(*) FROM ChecklistEjecucionValores v WHERE v.EjecucionID = e.ID AND v.EstaFueraRango = 1) AS FueraRangoCount
        FROM ChecklistEjecuciones e
        INNER JOIN ChecklistTemplates t ON e.TemplateID = t.ID
        INNER JOIN CatUsuarios u ON e.UsuarioID = u.ID
        INNER JOIN CatTurnos tur ON e.TurnoID = tur.ID
        LEFT JOIN CatLineas lin ON e.LineaID = lin.ID
        LEFT JOIN CatEstaciones est ON e.EstacionID = est.ID
        LEFT JOIN CatEquipos eq ON e.EquipoID = eq.ID
        WHERE e.activo = 1
        ORDER BY e.FechaEjecucion DESC
    """, query_type='SELECT')
    
    return render_template('checklist/historial_ejecuciones.html', ejecuciones=ejecuciones)

@checklist_bp.route('/historial/detalle/<int:id>')
@login_required
def detalle_ejecucion(id):
    ejecucion_info = run_query("""
        SELECT e.ID, t.Nombre AS TemplateNombre, t.TipoFrecuencia, u.Nombre AS TecnicoNombre, tur.Nombre AS TurnoNombre, 
               lin.Nombre AS LineaNombre, est.Nombre AS EstacionNombre, eq.Nombre AS EquipoNombre, e.FechaEjecucion, e.ComentarioGeneral, e.PathEvidencia
        FROM ChecklistEjecuciones e
        INNER JOIN ChecklistTemplates t ON e.TemplateID = t.ID
        INNER JOIN CatUsuarios u ON e.UsuarioID = u.ID
        INNER JOIN CatTurnos tur ON e.TurnoID = tur.ID
        LEFT JOIN CatLineas lin ON e.LineaID = lin.ID
        LEFT JOIN CatEstaciones est ON e.EstacionID = est.ID
        LEFT JOIN CatEquipos eq ON e.EquipoID = eq.ID
        WHERE e.ID = ? AND e.activo = 1
    """, (id,), 'SELECT')
    
    if not ejecucion_info:
        return jsonify({"success": False, "error": "Ejecucion no encontrada"}), 404
        
    valores = run_query("""
        SELECT i.Nombre AS ItemNombre, i.TipoCampo, i.ValorMinimo, i.ValorMaximo, i.UnidadMedida,
               v.ValorTexto, v.ValorNumero, v.ValorBoolean, v.EstaFueraRango
        FROM ChecklistEjecucionValores v
        INNER JOIN ChecklistTemplateItems i ON v.ItemID = i.ID
        WHERE v.EjecucionID = ?
        ORDER BY i.Orden
    """, (id,), 'SELECT')
    
    valores_limpios = []
    for val in valores:
        val_str = ""
        eval_lbl = "OK"
        if val['TipoCampo'] == 'number':
            val_str = f"{val['ValorNumero']} {val['UnidadMedida'] or ''}"
            if val['EstaFueraRango']:
                eval_lbl = "FUERA_RANGO"
        elif val['TipoCampo'] == 'boolean':
            val_str = "OK" if val['ValorBoolean'] else "NOK"
            eval_lbl = "OK" if val['ValorBoolean'] else "ALERTA"
        else:
            val_str = val['ValorTexto'] or ""
            eval_lbl = "N/A"
            
        valores_limpios.append({
            "item": val['ItemNombre'],
            "valor": val_str,
            "minimo": val['ValorMinimo'],
            "maximo": val['ValorMaximo'],
            "status": eval_lbl
        })
        
    data = {
        "template": ejecucion_info[0]['TemplateNombre'],
        "frecuencia": ejecucion_info[0]['TipoFrecuencia'],
        "tecnico": ejecucion_info[0]['TecnicoNombre'],
        "turno": ejecucion_info[0]['TurnoNombre'],
        "linea": ejecucion_info[0]['LineaNombre'] or 'N/A',
        "estacion": ejecucion_info[0]['EstacionNombre'] or 'General de Linea',
        "equipo": ejecucion_info[0]['EquipoNombre'] or 'N/A',
        "fecha": ejecucion_info[0]['FechaEjecucion'].strftime('%Y-%m-%d %H:%M'),
        "comentario": ejecucion_info[0]['ComentarioGeneral'] or '',
        "evidencia": ejecucion_info[0]['PathEvidencia'] or '',
        "valores": valores_limpios
    }
    
    return jsonify({"success": True, "detalle": data})

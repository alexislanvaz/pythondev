-- ============================================================
-- Project Management Application
-- SQL Server 2016+ Compatible Schema
-- Schema: dbo
-- ============================================================

USE master;
GO

-- Create database if needed (comment out if already exists)
-- CREATE DATABASE pm_app COLLATE Latin1_General_CI_AS;
-- GO

-- USE pm_app;
-- GO

-- ============================================================
-- 1. ROLES
-- ============================================================

IF OBJECT_ID('dbo.roles', 'U') IS NOT NULL DROP TABLE dbo.roles;
GO

CREATE TABLE dbo.roles (
    id               INT            NOT NULL IDENTITY(1,1),
    name             NVARCHAR(50)   NOT NULL,
    description      NVARCHAR(255)  NULL,
    permissions_json NVARCHAR(MAX)  NULL,
    created_at       DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_roles PRIMARY KEY (id),
    CONSTRAINT UQ_roles_name UNIQUE (name)
);
GO

-- ============================================================
-- 2. USERS
-- ============================================================

IF OBJECT_ID('dbo.users', 'U') IS NOT NULL DROP TABLE dbo.users;
GO

CREATE TABLE dbo.users (
    id            INT            NOT NULL IDENTITY(1,1),
    username      NVARCHAR(80)   NOT NULL,
    email         NVARCHAR(150)  NOT NULL,
    password_hash NVARCHAR(255)  NOT NULL,
    full_name     NVARCHAR(150)  NULL,
    avatar_url    NVARCHAR(500)  NULL,
    role_id       INT            NOT NULL,
    is_active     BIT            NOT NULL DEFAULT 1,
    last_login    DATETIME2      NULL,
    created_at    DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),
    updated_at    DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_users PRIMARY KEY (id),
    CONSTRAINT UQ_users_username UNIQUE (username),
    CONSTRAINT UQ_users_email UNIQUE (email),
    CONSTRAINT FK_users_role FOREIGN KEY (role_id) REFERENCES dbo.roles(id)
);
GO

CREATE INDEX IX_users_role_id   ON dbo.users (role_id);
CREATE INDEX IX_users_email     ON dbo.users (email);
CREATE INDEX IX_users_is_active ON dbo.users (is_active);
GO

-- ============================================================
-- 3. WORKSPACES
-- ============================================================

IF OBJECT_ID('dbo.workspaces', 'U') IS NOT NULL DROP TABLE dbo.workspaces;
GO

CREATE TABLE dbo.workspaces (
    id          INT            NOT NULL IDENTITY(1,1),
    name        NVARCHAR(150)  NOT NULL,
    slug        NVARCHAR(150)  NOT NULL,
    description NVARCHAR(500)  NULL,
    owner_id    INT            NOT NULL,
    created_at  DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),
    updated_at  DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_workspaces PRIMARY KEY (id),
    CONSTRAINT UQ_workspaces_slug UNIQUE (slug),
    CONSTRAINT FK_workspaces_owner FOREIGN KEY (owner_id) REFERENCES dbo.users(id)
);
GO

CREATE INDEX IX_workspaces_owner_id ON dbo.workspaces (owner_id);
CREATE INDEX IX_workspaces_slug     ON dbo.workspaces (slug);
GO

-- ============================================================
-- 4. WORKSPACE MEMBERS
-- ============================================================

IF OBJECT_ID('dbo.workspace_members', 'U') IS NOT NULL DROP TABLE dbo.workspace_members;
GO

CREATE TABLE dbo.workspace_members (
    id           INT       NOT NULL IDENTITY(1,1),
    workspace_id INT       NOT NULL,
    user_id      INT       NOT NULL,
    role_id      INT       NOT NULL,
    joined_at    DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_workspace_members PRIMARY KEY (id),
    CONSTRAINT UQ_workspace_members_pair UNIQUE (workspace_id, user_id),
    CONSTRAINT FK_wm_workspace FOREIGN KEY (workspace_id) REFERENCES dbo.workspaces(id) ON DELETE CASCADE,
    CONSTRAINT FK_wm_user     FOREIGN KEY (user_id)      REFERENCES dbo.users(id)      ON DELETE NO ACTION,
    CONSTRAINT FK_wm_role     FOREIGN KEY (role_id)      REFERENCES dbo.roles(id)      ON DELETE NO ACTION
);
GO

CREATE INDEX IX_wm_workspace_id ON dbo.workspace_members (workspace_id);
CREATE INDEX IX_wm_user_id      ON dbo.workspace_members (user_id);
GO

-- ============================================================
-- 5. PROJECTS
-- ============================================================

IF OBJECT_ID('dbo.projects', 'U') IS NOT NULL DROP TABLE dbo.projects;
GO

CREATE TABLE dbo.projects (
    id               INT            NOT NULL IDENTITY(1,1),
    workspace_id     INT            NOT NULL,
    name             NVARCHAR(150)  NOT NULL,
    slug             NVARCHAR(150)  NOT NULL,
    description      NVARCHAR(2000) NULL,
    status           NVARCHAR(20)   NOT NULL DEFAULT N'planning',
    priority         NVARCHAR(10)   NOT NULL DEFAULT N'medium',
    start_date       DATE           NULL,
    end_date         DATE           NULL,
    progress_percent DECIMAL(5,2)   NOT NULL DEFAULT 0.00,
    owner_id         INT            NOT NULL,
    color_hex        NVARCHAR(7)    NOT NULL DEFAULT N'#20808D',
    created_at       DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),
    updated_at       DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_projects PRIMARY KEY (id),
    CONSTRAINT UQ_projects_workspace_slug UNIQUE (workspace_id, slug),
    CONSTRAINT FK_projects_workspace FOREIGN KEY (workspace_id) REFERENCES dbo.workspaces(id) ON DELETE CASCADE,
    CONSTRAINT FK_projects_owner    FOREIGN KEY (owner_id)      REFERENCES dbo.users(id)       ON DELETE NO ACTION,
    CONSTRAINT CK_projects_status   CHECK (status   IN (N'planning', N'active', N'on_hold', N'completed', N'cancelled')),
    CONSTRAINT CK_projects_priority CHECK (priority IN (N'low', N'medium', N'high', N'critical')),
    CONSTRAINT CK_projects_progress CHECK (progress_percent BETWEEN 0.00 AND 100.00)
);
GO

CREATE INDEX IX_projects_workspace_id ON dbo.projects (workspace_id);
CREATE INDEX IX_projects_owner_id     ON dbo.projects (owner_id);
CREATE INDEX IX_projects_status       ON dbo.projects (status);
CREATE INDEX IX_projects_priority     ON dbo.projects (priority);
GO

-- ============================================================
-- 6. PROJECT MEMBERS
-- ============================================================

IF OBJECT_ID('dbo.project_members', 'U') IS NOT NULL DROP TABLE dbo.project_members;
GO

CREATE TABLE dbo.project_members (
    id          INT       NOT NULL IDENTITY(1,1),
    project_id  INT       NOT NULL,
    user_id     INT       NOT NULL,
    role_id     INT       NOT NULL,
    assigned_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_project_members PRIMARY KEY (id),
    CONSTRAINT UQ_project_members_pair UNIQUE (project_id, user_id),
    CONSTRAINT FK_pm_project FOREIGN KEY (project_id) REFERENCES dbo.projects(id) ON DELETE CASCADE,
    CONSTRAINT FK_pm_user    FOREIGN KEY (user_id)    REFERENCES dbo.users(id)    ON DELETE NO ACTION,
    CONSTRAINT FK_pm_role    FOREIGN KEY (role_id)    REFERENCES dbo.roles(id)    ON DELETE NO ACTION
);
GO

CREATE INDEX IX_pm_project_id ON dbo.project_members (project_id);
CREATE INDEX IX_pm_user_id    ON dbo.project_members (user_id);
GO

-- ============================================================
-- 7. EPICS
-- ============================================================

IF OBJECT_ID('dbo.epics', 'U') IS NOT NULL DROP TABLE dbo.epics;
GO

CREATE TABLE dbo.epics (
    id          INT            NOT NULL IDENTITY(1,1),
    project_id  INT            NOT NULL,
    name        NVARCHAR(150)  NOT NULL,
    description NVARCHAR(2000) NULL,
    status      NVARCHAR(20)   NOT NULL DEFAULT N'planning',
    start_date  DATE           NULL,
    end_date    DATE           NULL,
    color_hex   NVARCHAR(7)    NOT NULL DEFAULT N'#7A39BB',
    created_at  DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_epics PRIMARY KEY (id),
    CONSTRAINT FK_epics_project FOREIGN KEY (project_id) REFERENCES dbo.projects(id) ON DELETE CASCADE,
    CONSTRAINT CK_epics_status CHECK (status IN (N'planning', N'active', N'on_hold', N'completed', N'cancelled'))
);
GO

CREATE INDEX IX_epics_project_id ON dbo.epics (project_id);
CREATE INDEX IX_epics_status     ON dbo.epics (status);
GO

-- ============================================================
-- 8. SPRINTS
-- ============================================================

IF OBJECT_ID('dbo.sprints', 'U') IS NOT NULL DROP TABLE dbo.sprints;
GO

CREATE TABLE dbo.sprints (
    id         INT            NOT NULL IDENTITY(1,1),
    project_id INT            NOT NULL,
    name       NVARCHAR(150)  NOT NULL,
    goal       NVARCHAR(1000) NULL,
    status     NVARCHAR(15)   NOT NULL DEFAULT N'planned',
    start_date DATE           NULL,
    end_date   DATE           NULL,
    created_at DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_sprints PRIMARY KEY (id),
    CONSTRAINT FK_sprints_project FOREIGN KEY (project_id) REFERENCES dbo.projects(id) ON DELETE CASCADE,
    CONSTRAINT CK_sprints_status CHECK (status IN (N'planned', N'active', N'completed'))
);
GO

CREATE INDEX IX_sprints_project_id ON dbo.sprints (project_id);
CREATE INDEX IX_sprints_status     ON dbo.sprints (status);
GO

-- ============================================================
-- 9. TASK STATUSES
-- ============================================================

IF OBJECT_ID('dbo.task_statuses', 'U') IS NOT NULL DROP TABLE dbo.task_statuses;
GO

CREATE TABLE dbo.task_statuses (
    id          INT           NOT NULL IDENTITY(1,1),
    project_id  INT           NOT NULL,
    name        NVARCHAR(80)  NOT NULL,
    color_hex   NVARCHAR(7)   NOT NULL DEFAULT N'#BAB9B4',
    order_index INT           NOT NULL DEFAULT 0,
    is_default  BIT           NOT NULL DEFAULT 0,
    category    NVARCHAR(15)  NOT NULL DEFAULT N'todo',

    CONSTRAINT PK_task_statuses PRIMARY KEY (id),
    CONSTRAINT UQ_task_statuses_pair UNIQUE (project_id, name),
    CONSTRAINT FK_task_statuses_project FOREIGN KEY (project_id) REFERENCES dbo.projects(id) ON DELETE CASCADE,
    CONSTRAINT CK_task_statuses_category CHECK (category IN (N'todo', N'in_progress', N'done'))
);
GO

CREATE INDEX IX_task_statuses_project_id ON dbo.task_statuses (project_id);
CREATE INDEX IX_task_statuses_category   ON dbo.task_statuses (category);
GO

-- ============================================================
-- 10. TASKS
-- ============================================================

IF OBJECT_ID('dbo.tasks', 'U') IS NOT NULL DROP TABLE dbo.tasks;
GO

CREATE TABLE dbo.tasks (
    id             INT            NOT NULL IDENTITY(1,1),
    project_id     INT            NOT NULL,
    epic_id        INT            NULL,
    sprint_id      INT            NULL,
    parent_task_id INT            NULL,
    title          NVARCHAR(300)  NOT NULL,
    description    NVARCHAR(MAX)  NULL,
    type           NVARCHAR(10)   NOT NULL DEFAULT N'task',
    status_id      INT            NOT NULL,
    priority       NVARCHAR(10)   NOT NULL DEFAULT N'medium',
    assignee_id    INT            NULL,
    reporter_id    INT            NOT NULL,
    estimated_hours DECIMAL(8,2)  NULL,
    actual_hours    DECIMAL(8,2)  NOT NULL DEFAULT 0.00,
    due_date       DATE           NULL,
    start_date     DATE           NULL,
    order_index    INT            NOT NULL DEFAULT 0,
    created_at     DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),
    updated_at     DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_tasks PRIMARY KEY (id),
    CONSTRAINT FK_tasks_project      FOREIGN KEY (project_id)     REFERENCES dbo.projects(id)      ON DELETE CASCADE,
    CONSTRAINT FK_tasks_epic         FOREIGN KEY (epic_id)        REFERENCES dbo.epics(id)         ON DELETE NO ACTION,
    CONSTRAINT FK_tasks_sprint       FOREIGN KEY (sprint_id)      REFERENCES dbo.sprints(id)       ON DELETE NO ACTION,
    CONSTRAINT FK_tasks_parent       FOREIGN KEY (parent_task_id) REFERENCES dbo.tasks(id)         ON DELETE NO ACTION,
    CONSTRAINT FK_tasks_status       FOREIGN KEY (status_id)      REFERENCES dbo.task_statuses(id) ON DELETE NO ACTION,
    CONSTRAINT FK_tasks_assignee     FOREIGN KEY (assignee_id)    REFERENCES dbo.users(id)         ON DELETE NO ACTION,
    CONSTRAINT FK_tasks_reporter     FOREIGN KEY (reporter_id)    REFERENCES dbo.users(id)         ON DELETE NO ACTION,
    CONSTRAINT CK_tasks_type         CHECK (type     IN (N'task', N'bug', N'feature', N'story')),
    CONSTRAINT CK_tasks_priority     CHECK (priority IN (N'low', N'medium', N'high', N'critical'))
);
GO

CREATE INDEX IX_tasks_project_id     ON dbo.tasks (project_id);
CREATE INDEX IX_tasks_epic_id        ON dbo.tasks (epic_id);
CREATE INDEX IX_tasks_sprint_id      ON dbo.tasks (sprint_id);
CREATE INDEX IX_tasks_status_id      ON dbo.tasks (status_id);
CREATE INDEX IX_tasks_assignee_id    ON dbo.tasks (assignee_id);
CREATE INDEX IX_tasks_reporter_id    ON dbo.tasks (reporter_id);
CREATE INDEX IX_tasks_parent_task_id ON dbo.tasks (parent_task_id);
CREATE INDEX IX_tasks_priority       ON dbo.tasks (priority);
CREATE INDEX IX_tasks_due_date       ON dbo.tasks (due_date);
CREATE INDEX IX_tasks_type           ON dbo.tasks (type);
GO

-- ============================================================
-- 11. TASK LABELS
-- ============================================================

IF OBJECT_ID('dbo.task_labels', 'U') IS NOT NULL DROP TABLE dbo.task_labels;
GO

CREATE TABLE dbo.task_labels (
    id         INT           NOT NULL IDENTITY(1,1),
    name       NVARCHAR(80)  NOT NULL,
    color_hex  NVARCHAR(7)   NOT NULL DEFAULT N'#20808D',
    project_id INT           NOT NULL,

    CONSTRAINT PK_task_labels PRIMARY KEY (id),
    CONSTRAINT UQ_task_labels_pair UNIQUE (project_id, name),
    CONSTRAINT FK_task_labels_project FOREIGN KEY (project_id) REFERENCES dbo.projects(id) ON DELETE CASCADE
);
GO

CREATE INDEX IX_task_labels_project_id ON dbo.task_labels (project_id);
GO

-- ============================================================
-- 12. TASK LABEL MAP
-- ============================================================

IF OBJECT_ID('dbo.task_label_map', 'U') IS NOT NULL DROP TABLE dbo.task_label_map;
GO

CREATE TABLE dbo.task_label_map (
    task_id  INT NOT NULL,
    label_id INT NOT NULL,

    CONSTRAINT PK_task_label_map PRIMARY KEY (task_id, label_id),
    CONSTRAINT FK_tlm_task  FOREIGN KEY (task_id)  REFERENCES dbo.tasks(id)       ON DELETE CASCADE,
    CONSTRAINT FK_tlm_label FOREIGN KEY (label_id) REFERENCES dbo.task_labels(id) ON DELETE NO ACTION
);
GO

CREATE INDEX IX_tlm_label_id ON dbo.task_label_map (label_id);
GO

-- ============================================================
-- 13. TASK DEPENDENCIES
-- ============================================================

IF OBJECT_ID('dbo.task_dependencies', 'U') IS NOT NULL DROP TABLE dbo.task_dependencies;
GO

CREATE TABLE dbo.task_dependencies (
    id                 INT          NOT NULL IDENTITY(1,1),
    task_id            INT          NOT NULL,
    depends_on_task_id INT          NOT NULL,
    dependency_type    NVARCHAR(25) NOT NULL DEFAULT N'finish_to_start',

    CONSTRAINT PK_task_dependencies PRIMARY KEY (id),
    CONSTRAINT UQ_task_dep_pair UNIQUE (task_id, depends_on_task_id),
    CONSTRAINT FK_td_task         FOREIGN KEY (task_id)            REFERENCES dbo.tasks(id) ON DELETE CASCADE,
    CONSTRAINT FK_td_depends_on   FOREIGN KEY (depends_on_task_id) REFERENCES dbo.tasks(id) ON DELETE NO ACTION,
    CONSTRAINT CK_td_type CHECK (dependency_type IN (
        N'finish_to_start', N'start_to_start', N'finish_to_finish', N'start_to_finish'
    )),
    CONSTRAINT CK_td_no_self CHECK (task_id <> depends_on_task_id)
);
GO

CREATE INDEX IX_td_task_id            ON dbo.task_dependencies (task_id);
CREATE INDEX IX_td_depends_on_task_id ON dbo.task_dependencies (depends_on_task_id);
GO

-- ============================================================
-- 14. TASK WATCHERS
-- ============================================================

IF OBJECT_ID('dbo.task_watchers', 'U') IS NOT NULL DROP TABLE dbo.task_watchers;
GO

CREATE TABLE dbo.task_watchers (
    task_id INT NOT NULL,
    user_id INT NOT NULL,

    CONSTRAINT PK_task_watchers PRIMARY KEY (task_id, user_id),
    CONSTRAINT FK_tw_task FOREIGN KEY (task_id) REFERENCES dbo.tasks(id) ON DELETE CASCADE,
    CONSTRAINT FK_tw_user FOREIGN KEY (user_id) REFERENCES dbo.users(id) ON DELETE NO ACTION
);
GO

CREATE INDEX IX_tw_user_id ON dbo.task_watchers (user_id);
GO

-- ============================================================
-- 15. COMMENTS
-- ============================================================

IF OBJECT_ID('dbo.comments', 'U') IS NOT NULL DROP TABLE dbo.comments;
GO

CREATE TABLE dbo.comments (
    id                INT           NOT NULL IDENTITY(1,1),
    task_id           INT           NOT NULL,
    user_id           INT           NOT NULL,
    content           NVARCHAR(MAX) NOT NULL,
    parent_comment_id INT           NULL,
    created_at        DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME(),
    updated_at        DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME(),
    is_deleted        BIT           NOT NULL DEFAULT 0,

    CONSTRAINT PK_comments PRIMARY KEY (id),
    CONSTRAINT FK_comments_task          FOREIGN KEY (task_id)           REFERENCES dbo.tasks(id)    ON DELETE CASCADE,
    CONSTRAINT FK_comments_user          FOREIGN KEY (user_id)           REFERENCES dbo.users(id)    ON DELETE NO ACTION,
    CONSTRAINT FK_comments_parent        FOREIGN KEY (parent_comment_id) REFERENCES dbo.comments(id) ON DELETE NO ACTION
);
GO

CREATE INDEX IX_comments_task_id           ON dbo.comments (task_id);
CREATE INDEX IX_comments_user_id           ON dbo.comments (user_id);
CREATE INDEX IX_comments_parent_comment_id ON dbo.comments (parent_comment_id);
CREATE INDEX IX_comments_is_deleted        ON dbo.comments (is_deleted);
GO

-- ============================================================
-- 16. ACTIVITY LOG
-- ============================================================

IF OBJECT_ID('dbo.activity_log', 'U') IS NOT NULL DROP TABLE dbo.activity_log;
GO

CREATE TABLE dbo.activity_log (
    id          INT            NOT NULL IDENTITY(1,1),
    entity_type NVARCHAR(20)   NOT NULL,
    entity_id   INT            NOT NULL,
    user_id     INT            NOT NULL,
    action      NVARCHAR(100)  NOT NULL,
    old_value   NVARCHAR(MAX)  NULL,
    new_value   NVARCHAR(MAX)  NULL,
    created_at  DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_activity_log PRIMARY KEY (id),
    CONSTRAINT FK_al_user FOREIGN KEY (user_id) REFERENCES dbo.users(id) ON DELETE NO ACTION,
    CONSTRAINT CK_al_entity_type CHECK (entity_type IN (N'task', N'project', N'sprint', N'epic', N'workspace'))
);
GO

CREATE INDEX IX_al_entity      ON dbo.activity_log (entity_type, entity_id);
CREATE INDEX IX_al_user_id     ON dbo.activity_log (user_id);
CREATE INDEX IX_al_created_at  ON dbo.activity_log (created_at DESC);
GO

-- ============================================================
-- 17. ATTACHMENTS
-- ============================================================

IF OBJECT_ID('dbo.attachments', 'U') IS NOT NULL DROP TABLE dbo.attachments;
GO

CREATE TABLE dbo.attachments (
    id         INT            NOT NULL IDENTITY(1,1),
    task_id    INT            NOT NULL,
    user_id    INT            NOT NULL,
    filename   NVARCHAR(255)  NOT NULL,
    file_path  NVARCHAR(1000) NOT NULL,
    file_size  BIGINT         NOT NULL DEFAULT 0,
    mime_type  NVARCHAR(150)  NULL,
    created_at DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_attachments PRIMARY KEY (id),
    CONSTRAINT FK_att_task FOREIGN KEY (task_id) REFERENCES dbo.tasks(id) ON DELETE CASCADE,
    CONSTRAINT FK_att_user FOREIGN KEY (user_id) REFERENCES dbo.users(id) ON DELETE NO ACTION
);
GO

CREATE INDEX IX_att_task_id ON dbo.attachments (task_id);
CREATE INDEX IX_att_user_id ON dbo.attachments (user_id);
GO

-- ============================================================
-- 18. TIME LOGS
-- ============================================================

IF OBJECT_ID('dbo.time_logs', 'U') IS NOT NULL DROP TABLE dbo.time_logs;
GO

CREATE TABLE dbo.time_logs (
    id          INT            NOT NULL IDENTITY(1,1),
    task_id     INT            NOT NULL,
    user_id     INT            NOT NULL,
    description NVARCHAR(500)  NULL,
    hours       DECIMAL(8,2)   NOT NULL,
    logged_date DATE           NOT NULL,
    created_at  DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_time_logs PRIMARY KEY (id),
    CONSTRAINT FK_tl_task FOREIGN KEY (task_id) REFERENCES dbo.tasks(id) ON DELETE CASCADE,
    CONSTRAINT FK_tl_user FOREIGN KEY (user_id) REFERENCES dbo.users(id) ON DELETE NO ACTION,
    CONSTRAINT CK_tl_hours CHECK (hours > 0 AND hours <= 24)
);
GO

CREATE INDEX IX_tl_task_id     ON dbo.time_logs (task_id);
CREATE INDEX IX_tl_user_id     ON dbo.time_logs (user_id);
CREATE INDEX IX_tl_logged_date ON dbo.time_logs (logged_date DESC);
GO

-- ============================================================
-- 19. NOTIFICATIONS
-- ============================================================

IF OBJECT_ID('dbo.notifications', 'U') IS NOT NULL DROP TABLE dbo.notifications;
GO

CREATE TABLE dbo.notifications (
    id          INT            NOT NULL IDENTITY(1,1),
    user_id     INT            NOT NULL,
    type        NVARCHAR(50)   NOT NULL,
    title       NVARCHAR(200)  NOT NULL,
    message     NVARCHAR(1000) NOT NULL,
    entity_type NVARCHAR(20)   NULL,
    entity_id   INT            NULL,
    is_read     BIT            NOT NULL DEFAULT 0,
    created_at  DATETIME2      NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_notifications PRIMARY KEY (id),
    CONSTRAINT FK_notif_user FOREIGN KEY (user_id) REFERENCES dbo.users(id) ON DELETE CASCADE
);
GO

CREATE INDEX IX_notif_user_id   ON dbo.notifications (user_id);
CREATE INDEX IX_notif_is_read   ON dbo.notifications (user_id, is_read);
CREATE INDEX IX_notif_created   ON dbo.notifications (created_at DESC);
GO

-- ============================================================
-- SEED DATA
-- ============================================================

-- Roles
SET IDENTITY_INSERT dbo.roles ON;

INSERT INTO dbo.roles (id, name, description, permissions_json) VALUES
(1, N'admin', N'Full system access', N'{"all": true}'),
(2, N'project_manager', N'Manage projects, assign tasks, manage sprints',
    N'{"projects": ["create","read","update","delete"], "tasks": ["create","read","update","delete"], "sprints": ["create","read","update","delete"], "members": ["add","remove"], "reports": ["read"]}'),
(3, N'developer', N'Work on assigned tasks, log time, comment',
    N'{"projects": ["read"], "tasks": ["create","read","update"], "sprints": ["read"], "time_logs": ["create","read","update","delete"], "comments": ["create","read","update","delete"]}'),
(4, N'viewer', N'Read-only access to assigned projects',
    N'{"projects": ["read"], "tasks": ["read"], "sprints": ["read"], "comments": ["read"]}');

SET IDENTITY_INSERT dbo.roles OFF;
GO

-- Admin user (password: Admin123! - bcrypt hash placeholder)
SET IDENTITY_INSERT dbo.users ON;

INSERT INTO dbo.users (id, username, email, password_hash, full_name, role_id, is_active) VALUES
(1, N'admin', N'admin@pm-app.local',
    N'$2b$12$placeholder_replace_with_real_bcrypt_hash_admin',
    N'System Admin', 1, 1);

SET IDENTITY_INSERT dbo.users OFF;
GO

-- Default workspace
SET IDENTITY_INSERT dbo.workspaces ON;

INSERT INTO dbo.workspaces (id, name, slug, description, owner_id) VALUES
(1, N'Default Workspace', N'default', N'Default workspace created on setup', 1);

SET IDENTITY_INSERT dbo.workspaces OFF;
GO

-- Admin as workspace member
INSERT INTO dbo.workspace_members (workspace_id, user_id, role_id) VALUES
(1, 1, 1);
GO

-- Sample project
SET IDENTITY_INSERT dbo.projects ON;

INSERT INTO dbo.projects (id, workspace_id, name, slug, description, status, priority, owner_id, color_hex) VALUES
(1, 1, N'Sample Project', N'sample-project', N'Initial demo project', N'active', N'medium', 1, N'#20808D');

SET IDENTITY_INSERT dbo.projects OFF;
GO

-- Default task statuses for sample project
INSERT INTO dbo.task_statuses (project_id, name, color_hex, order_index, is_default, category) VALUES
(1, N'Backlog',     N'#BAB9B4', 0, 0, N'todo'),
(1, N'To Do',       N'#006494', 1, 1, N'todo'),
(1, N'In Progress', N'#DA7101', 2, 0, N'in_progress'),
(1, N'In Review',   N'#7A39BB', 3, 0, N'in_progress'),
(1, N'Done',        N'#437A22', 4, 0, N'done');
GO

-- Admin as project member
INSERT INTO dbo.project_members (project_id, user_id, role_id) VALUES
(1, 1, 1);
GO

PRINT 'Schema created and seed data inserted successfully.';
GO

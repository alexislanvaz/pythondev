# Flask Application Architecture

Project Management Application

---

## Folder Structure

```
pm_app/
|
|-- app/
|   |-- __init__.py                  # Application factory (create_app)
|   |-- extensions.py                # db, login_manager, migrate, mail, etc.
|   |-- config.py                    # Config classes (Development, Production, Testing)
|   |
|   |-- auth/                        # Blueprint: authentication
|   |   |-- __init__.py
|   |   |-- routes.py                # login, logout, register, profile
|   |   |-- forms.py                 # LoginForm, RegisterForm, ChangePasswordForm
|   |   |-- decorators.py            # role_required, login_required wrappers
|   |   |-- utils.py                 # password hashing, token generation
|   |   `-- templates/
|   |       |-- auth/
|   |       |   |-- login.html
|   |       |   |-- register.html
|   |       |   `-- profile.html
|   |
|   |-- dashboard/                   # Blueprint: main dashboard
|   |   |-- __init__.py
|   |   |-- routes.py                # / index, /dashboard
|   |   `-- templates/
|   |       `-- dashboard/
|   |           |-- index.html
|   |           `-- widgets/
|   |               |-- stats_bar.html
|   |               |-- recent_tasks.html
|   |               `-- burndown_chart.html
|   |
|   |-- workspaces/                  # Blueprint: workspace management
|   |   |-- __init__.py
|   |   |-- routes.py
|   |   |-- forms.py
|   |   `-- templates/
|   |       `-- workspaces/
|   |           |-- list.html
|   |           |-- detail.html
|   |           `-- settings.html
|   |
|   |-- projects/                    # Blueprint: project views
|   |   |-- __init__.py
|   |   |-- routes.py
|   |   |-- forms.py
|   |   `-- templates/
|   |       `-- projects/
|   |           |-- list.html
|   |           |-- detail.html
|   |           |-- board.html        # Kanban view
|   |           |-- timeline.html     # Gantt / timeline view
|   |           |-- settings.html
|   |           `-- members.html
|   |
|   |-- tasks/                       # Blueprint: task views
|   |   |-- __init__.py
|   |   |-- routes.py
|   |   |-- forms.py
|   |   `-- templates/
|   |       `-- tasks/
|   |           |-- detail.html
|   |           `-- create.html
|   |
|   |-- sprints/                     # Blueprint: sprint management
|   |   |-- __init__.py
|   |   |-- routes.py
|   |   |-- forms.py
|   |   `-- templates/
|   |       `-- sprints/
|   |           |-- list.html
|   |           `-- board.html        # Sprint board (filtered Kanban)
|   |
|   |-- api/                         # Blueprint: REST API (JSON responses)
|   |   |-- __init__.py
|   |   |-- projects.py
|   |   |-- tasks.py
|   |   |-- sprints.py
|   |   |-- epics.py
|   |   |-- users.py
|   |   |-- time_logs.py
|   |   |-- notifications.py
|   |   `-- activity.py
|   |
|   |-- static/
|   |   |-- css/
|   |   |   |-- main.css
|   |   |   `-- board.css
|   |   |-- js/
|   |   |   |-- board.js             # Kanban drag-and-drop logic
|   |   |   |-- charts.js            # ECharts + ApexCharts wrappers
|   |   |   |-- task_modal.js        # Task create/edit modal
|   |   |   |-- notifications.js     # Polling / notification badge
|   |   |   `-- api.js               # fetch() wrapper with CSRF handling
|   |   `-- img/
|   |       `-- logo.svg
|   |
|   `-- templates/
|       |-- base.html                # Master layout (nav, sidebar, flash messages)
|       |-- errors/
|       |   |-- 403.html
|       |   |-- 404.html
|       |   `-- 500.html
|       `-- partials/
|           |-- sidebar.html
|           |-- navbar.html
|           `-- flash_messages.html
|
|-- database/
|   |-- schema.sql                   # T-SQL DDL + seed data
|   `-- models.py                    # SQLAlchemy ORM models
|
|-- docs/
|   |-- schema_diagram.md            # ER diagram (Mermaid)
|   `-- architecture.md              # This file
|
|-- migrations/                      # Flask-Migrate (Alembic) revisions
|   `-- versions/
|
|-- tests/
|   |-- conftest.py
|   |-- test_auth.py
|   |-- test_projects.py
|   |-- test_tasks.py
|   `-- test_api.py
|
|-- .env.example
|-- .flaskenv
|-- config.py
|-- requirements.txt
|-- wsgi.py                          # WSGI entry point
`-- run.py                           # Development runner
```

---

## Application Factory

```python
# app/__init__.py

from flask import Flask
from .extensions import db, login_manager, migrate
from .config import config_by_name

def create_app(config_name: str = "development") -> Flask:
    app = Flask(__name__)
    app.config.from_object(config_by_name[config_name])

    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)

    # Register blueprints
    from .auth      import auth_bp
    from .dashboard import dashboard_bp
    from .workspaces import workspaces_bp
    from .projects  import projects_bp
    from .tasks     import tasks_bp
    from .sprints   import sprints_bp
    from .api       import api_bp

    app.register_blueprint(auth_bp,       url_prefix="/auth")
    app.register_blueprint(dashboard_bp,  url_prefix="/")
    app.register_blueprint(workspaces_bp, url_prefix="/workspaces")
    app.register_blueprint(projects_bp,   url_prefix="/projects")
    app.register_blueprint(tasks_bp,      url_prefix="/tasks")
    app.register_blueprint(sprints_bp,    url_prefix="/sprints")
    app.register_blueprint(api_bp,        url_prefix="/api/v1")

    return app
```

---

## Blueprint Structure

### auth blueprint  (`/auth`)

Handles session-based authentication with Flask-Login.

| Route | Method | Description |
|---|---|---|
| `/auth/login` | GET, POST | Login form |
| `/auth/logout` | GET | Destroy session |
| `/auth/register` | GET, POST | New user registration |
| `/auth/profile` | GET, POST | Edit own profile, change password |

### dashboard blueprint  (`/`)

Landing page after login. Aggregates cross-project stats.

| Route | Method | Description |
|---|---|---|
| `/` | GET | Redirect to dashboard or login |
| `/dashboard` | GET | Stats overview, recent tasks, burndown |

### workspaces blueprint  (`/workspaces`)

| Route | Method | Description |
|---|---|---|
| `/workspaces/` | GET | List workspaces for current user |
| `/workspaces/new` | GET, POST | Create workspace |
| `/workspaces/<slug>` | GET | Workspace overview |
| `/workspaces/<slug>/settings` | GET, POST | Edit workspace |
| `/workspaces/<slug>/members` | GET, POST | Manage members |

### projects blueprint  (`/projects`)

| Route | Method | Description |
|---|---|---|
| `/projects/<slug>` | GET | Project overview |
| `/projects/<slug>/board` | GET | Kanban board |
| `/projects/<slug>/timeline` | GET | Gantt/timeline view |
| `/projects/<slug>/backlog` | GET | Backlog list |
| `/projects/<slug>/settings` | GET, POST | Edit project |
| `/projects/<slug>/members` | GET, POST | Manage members |

### tasks blueprint  (`/tasks`)

| Route | Method | Description |
|---|---|---|
| `/tasks/<int:id>` | GET | Task detail page |
| `/tasks/new` | GET, POST | Create task (from project context) |

### sprints blueprint  (`/sprints`)

| Route | Method | Description |
|---|---|---|
| `/sprints/<int:id>` | GET | Sprint board |
| `/sprints/<int:id>/report` | GET | Sprint completion report |

### api blueprint  (`/api/v1`)

JSON-only REST API. Used by frontend JS for dynamic updates.
All endpoints return `application/json`. Authentication via session cookie +
CSRF token (`X-CSRFToken` header).

---

## REST API Endpoints

### Projects

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/projects` | List projects (filtered by workspace) |
| POST | `/api/v1/projects` | Create project |
| GET | `/api/v1/projects/<id>` | Get project detail |
| PATCH | `/api/v1/projects/<id>` | Update project fields |
| DELETE | `/api/v1/projects/<id>` | Delete project |
| GET | `/api/v1/projects/<id>/stats` | Progress, task counts by status |
| GET | `/api/v1/projects/<id>/members` | List project members |
| POST | `/api/v1/projects/<id>/members` | Add member |
| DELETE | `/api/v1/projects/<id>/members/<user_id>` | Remove member |

### Tasks

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/tasks` | List tasks (query params: project, sprint, epic, assignee, status) |
| POST | `/api/v1/tasks` | Create task |
| GET | `/api/v1/tasks/<id>` | Get task detail with comments, labels, watchers |
| PATCH | `/api/v1/tasks/<id>` | Update task (partial) |
| DELETE | `/api/v1/tasks/<id>` | Delete task |
| PATCH | `/api/v1/tasks/<id>/status` | Change status (triggers activity log) |
| PATCH | `/api/v1/tasks/<id>/assignee` | Reassign task |
| POST | `/api/v1/tasks/<id>/watch` | Watch task |
| DELETE | `/api/v1/tasks/<id>/watch` | Unwatch task |
| POST | `/api/v1/tasks/<id>/labels` | Add label |
| DELETE | `/api/v1/tasks/<id>/labels/<label_id>` | Remove label |
| PATCH | `/api/v1/tasks/reorder` | Bulk update order_index (Kanban drag) |

### Comments

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/tasks/<id>/comments` | List threaded comments |
| POST | `/api/v1/tasks/<id>/comments` | Create comment |
| PATCH | `/api/v1/comments/<id>` | Edit comment |
| DELETE | `/api/v1/comments/<id>` | Soft delete comment |

### Sprints

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/projects/<id>/sprints` | List sprints |
| POST | `/api/v1/projects/<id>/sprints` | Create sprint |
| PATCH | `/api/v1/sprints/<id>` | Update sprint |
| DELETE | `/api/v1/sprints/<id>` | Delete sprint |
| POST | `/api/v1/sprints/<id>/start` | Activate sprint |
| POST | `/api/v1/sprints/<id>/complete` | Complete sprint |
| POST | `/api/v1/sprints/<id>/tasks` | Add task to sprint |
| DELETE | `/api/v1/sprints/<id>/tasks/<task_id>` | Remove task from sprint |

### Epics

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/projects/<id>/epics` | List epics |
| POST | `/api/v1/projects/<id>/epics` | Create epic |
| PATCH | `/api/v1/epics/<id>` | Update epic |
| DELETE | `/api/v1/epics/<id>` | Delete epic |

### Time Logs

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/tasks/<id>/time` | List time logs for task |
| POST | `/api/v1/tasks/<id>/time` | Log time entry |
| PATCH | `/api/v1/time/<id>` | Edit time log |
| DELETE | `/api/v1/time/<id>` | Delete time log |
| GET | `/api/v1/projects/<id>/time` | Project time report |

### Notifications

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/notifications` | List current user notifications |
| POST | `/api/v1/notifications/read` | Mark all as read |
| PATCH | `/api/v1/notifications/<id>/read` | Mark one as read |
| GET | `/api/v1/notifications/unread-count` | Badge count (polled by JS) |

### Activity

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/projects/<id>/activity` | Project activity feed |
| GET | `/api/v1/tasks/<id>/activity` | Task activity feed |

### Users

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/users/me` | Current user profile |
| PATCH | `/api/v1/users/me` | Update profile |
| GET | `/api/v1/users` | Search users (admin only) |
| PATCH | `/api/v1/users/<id>/role` | Change role (admin only) |
| POST | `/api/v1/users/<id>/deactivate` | Deactivate user (admin only) |

---

## Configuration Classes

```python
# app/config.py

import os

class BaseConfig:
    SECRET_KEY                  = os.environ.get("SECRET_KEY", "dev-secret-change-me")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    WTF_CSRF_ENABLED            = True
    MAX_CONTENT_LENGTH          = 16 * 1024 * 1024  # 16 MB upload limit
    UPLOAD_FOLDER               = os.environ.get("UPLOAD_FOLDER", "uploads")

class DevelopmentConfig(BaseConfig):
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = (
        "mssql+pyodbc://sa:YourPassword@localhost/pm_app"
        "?driver=ODBC+Driver+17+for+SQL+Server"
    )

class ProductionConfig(BaseConfig):
    DEBUG = False
    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL")
    SESSION_COOKIE_SECURE   = True
    SESSION_COOKIE_HTTPONLY = True

class TestingConfig(BaseConfig):
    TESTING = True
    WTF_CSRF_ENABLED = False
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"

config_by_name = {
    "development": DevelopmentConfig,
    "production":  ProductionConfig,
    "testing":     TestingConfig,
}
```

---

## Auth Decorator

```python
# app/auth/decorators.py

from functools import wraps
from flask import abort
from flask_login import current_user

def role_required(*roles):
    """Restrict route to users with one of the given role names."""
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if not current_user.is_authenticated:
                abort(401)
            if current_user.role.name not in roles:
                abort(403)
            return f(*args, **kwargs)
        return decorated
    return decorator
```

---

## Python Dependencies (`requirements.txt`)

```
# Core
Flask==3.0.3
Flask-SQLAlchemy==3.1.1
Flask-Login==0.6.3
Flask-Migrate==4.0.7
Flask-WTF==1.2.1
Flask-Mail==0.10.0
Werkzeug==3.0.3

# Database
pyodbc==5.1.0
SQLAlchemy==2.0.30

# Auth / Security
bcrypt==4.1.3
itsdangerous==2.2.0

# Utilities
python-dotenv==1.0.1
python-slugify==8.0.4
Pillow==10.3.0       # image processing for avatars

# Async / background tasks (optional, recommended)
celery==5.4.0
redis==5.0.4

# Testing
pytest==8.2.0
pytest-flask==1.3.0
coverage==7.5.0

# Production server
gunicorn==22.0.0
```

---

## Frontend JS Architecture

All frontend interactivity runs in vanilla JS. No frameworks.

```
static/js/
|-- api.js            - fetch() wrapper, handles CSRF token injection,
|                       JSON serialization, error normalization
|-- board.js          - Kanban drag-and-drop (HTML5 Drag API), calls
|                       PATCH /api/v1/tasks/reorder on drop
|-- task_modal.js     - Floating task creation/edit panel, loaded
|                       via fetch() into a <dialog> element
|-- charts.js         - Shared init for ECharts (burndown, velocity)
|                       and ApexCharts (donut summary, time bar)
`-- notifications.js  - Polls /api/v1/notifications/unread-count every
                        30 seconds, updates nav badge
```

### Chart Usage Pattern

- **ECharts**: Burndown chart, sprint velocity, project timeline (Gantt-style).
- **ApexCharts**: Donut chart (tasks by status), bar chart (time logged per user),
  radial progress gauge on project cards.

---

## Key Conventions

1. All API responses follow a consistent envelope:
   ```json
   {"data": ..., "error": null, "meta": {"page": 1, "total": 42}}
   ```

2. `updated_at` is set server-side via SQLAlchemy `onupdate`; clients never send it.

3. Activity log entries are created inside service functions (not routes) to ensure
   they fire regardless of the caller.

4. Slug generation uses `python-slugify` and guarantees uniqueness by appending a
   short UUID suffix on collision.

5. File uploads are stored in `UPLOAD_FOLDER/<workspace_id>/<project_id>/`; the path
   is stored in `attachments.file_path` relative to `UPLOAD_FOLDER`.

6. CSRF protection is enforced on all non-GET HTML forms via Flask-WTF and on all
   AJAX POST/PATCH/DELETE requests via the `X-CSRFToken` header read from the
   meta tag rendered in `base.html`.

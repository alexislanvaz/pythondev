# Database Schema Diagram

Project Management Application - SQL Server 2016+

---

## ER Diagram (Mermaid)

```mermaid
erDiagram
    roles {
        int id PK
        nvarchar name
        nvarchar description
        nvarchar permissions_json
        datetime2 created_at
    }

    users {
        int id PK
        nvarchar username
        nvarchar email
        nvarchar password_hash
        nvarchar full_name
        nvarchar avatar_url
        int role_id FK
        bit is_active
        datetime2 last_login
        datetime2 created_at
        datetime2 updated_at
    }

    workspaces {
        int id PK
        nvarchar name
        nvarchar slug
        nvarchar description
        int owner_id FK
        datetime2 created_at
        datetime2 updated_at
    }

    workspace_members {
        int id PK
        int workspace_id FK
        int user_id FK
        int role_id FK
        datetime2 joined_at
    }

    projects {
        int id PK
        int workspace_id FK
        nvarchar name
        nvarchar slug
        nvarchar description
        nvarchar status
        nvarchar priority
        date start_date
        date end_date
        decimal progress_percent
        int owner_id FK
        nvarchar color_hex
        datetime2 created_at
        datetime2 updated_at
    }

    project_members {
        int id PK
        int project_id FK
        int user_id FK
        int role_id FK
        datetime2 assigned_at
    }

    epics {
        int id PK
        int project_id FK
        nvarchar name
        nvarchar description
        nvarchar status
        date start_date
        date end_date
        nvarchar color_hex
        datetime2 created_at
    }

    sprints {
        int id PK
        int project_id FK
        nvarchar name
        nvarchar goal
        nvarchar status
        date start_date
        date end_date
        datetime2 created_at
    }

    task_statuses {
        int id PK
        int project_id FK
        nvarchar name
        nvarchar color_hex
        int order_index
        bit is_default
        nvarchar category
    }

    tasks {
        int id PK
        int project_id FK
        int epic_id FK
        int sprint_id FK
        int parent_task_id FK
        nvarchar title
        nvarchar description
        nvarchar type
        int status_id FK
        nvarchar priority
        int assignee_id FK
        int reporter_id FK
        decimal estimated_hours
        decimal actual_hours
        date due_date
        date start_date
        int order_index
        datetime2 created_at
        datetime2 updated_at
    }

    task_labels {
        int id PK
        nvarchar name
        nvarchar color_hex
        int project_id FK
    }

    task_label_map {
        int task_id FK
        int label_id FK
    }

    task_dependencies {
        int id PK
        int task_id FK
        int depends_on_task_id FK
        nvarchar dependency_type
    }

    task_watchers {
        int task_id FK
        int user_id FK
    }

    comments {
        int id PK
        int task_id FK
        int user_id FK
        nvarchar content
        int parent_comment_id FK
        datetime2 created_at
        datetime2 updated_at
        bit is_deleted
    }

    activity_log {
        int id PK
        nvarchar entity_type
        int entity_id
        int user_id FK
        nvarchar action
        nvarchar old_value
        nvarchar new_value
        datetime2 created_at
    }

    attachments {
        int id PK
        int task_id FK
        int user_id FK
        nvarchar filename
        nvarchar file_path
        bigint file_size
        nvarchar mime_type
        datetime2 created_at
    }

    time_logs {
        int id PK
        int task_id FK
        int user_id FK
        nvarchar description
        decimal hours
        date logged_date
        datetime2 created_at
    }

    notifications {
        int id PK
        int user_id FK
        nvarchar type
        nvarchar title
        nvarchar message
        nvarchar entity_type
        int entity_id
        bit is_read
        datetime2 created_at
    }

    roles ||--o{ users : "assigned to"
    roles ||--o{ workspace_members : "assigned in workspace"
    roles ||--o{ project_members : "assigned in project"

    users ||--o{ workspaces : "owns"
    users ||--o{ workspace_members : "belongs to"
    users ||--o{ projects : "owns"
    users ||--o{ project_members : "belongs to"
    users ||--o{ tasks : "assigned to (assignee)"
    users ||--o{ tasks : "created by (reporter)"
    users ||--o{ comments : "writes"
    users ||--o{ activity_log : "generates"
    users ||--o{ attachments : "uploads"
    users ||--o{ time_logs : "logs"
    users ||--o{ notifications : "receives"
    users ||--o{ task_watchers : "watches"

    workspaces ||--o{ workspace_members : "has"
    workspaces ||--o{ projects : "contains"

    projects ||--o{ project_members : "has"
    projects ||--o{ epics : "has"
    projects ||--o{ sprints : "has"
    projects ||--o{ tasks : "contains"
    projects ||--o{ task_statuses : "defines"
    projects ||--o{ task_labels : "defines"

    epics ||--o{ tasks : "groups"
    sprints ||--o{ tasks : "contains"

    task_statuses ||--o{ tasks : "categorizes"

    tasks ||--o{ tasks : "has subtasks (self-ref)"
    tasks ||--o{ task_label_map : "has"
    tasks ||--o{ task_dependencies : "depends on"
    tasks ||--o{ task_watchers : "watched by"
    tasks ||--o{ comments : "has"
    tasks ||--o{ attachments : "has"
    tasks ||--o{ time_logs : "tracks time"

    task_labels ||--o{ task_label_map : "applied via"
```

---

## Table Descriptions

### roles

Stores the four system roles. The `permissions_json` column holds a JSON object
describing which resource/action pairs the role is allowed to perform. Permissions
are enforced at the application layer (Flask decorators).

| Column | Type | Notes |
|---|---|---|
| id | INT IDENTITY | Primary key |
| name | NVARCHAR(50) | Unique role name |
| description | NVARCHAR(255) | Human-readable description |
| permissions_json | NVARCHAR(MAX) | JSON object: {"resource": ["action"]} |
| created_at | DATETIME2 | UTC insert timestamp |

---

### users

Application users. Each user belongs to exactly one global role. Finer-grained
access is controlled through workspace_members and project_members role assignments.
`password_hash` stores a bcrypt hash; the plain password is never persisted.

---

### workspaces

Top-level organizational unit. A workspace groups multiple projects and has its
own member list. The `slug` field is URL-friendly and globally unique.

---

### workspace_members

Junction table linking users to workspaces with a specific role. A user can
belong to many workspaces with different roles in each.

---

### projects

A project lives inside one workspace. The `status` field tracks lifecycle:
`planning -> active -> on_hold | completed | cancelled`. Progress is stored as
a percentage that can be computed or manually set.

---

### project_members

Junction table for project-level membership. Allows a user to have a different
role inside a project than their global or workspace role.

---

### epics

High-level feature groupings within a project. Epics span multiple sprints and
contain many tasks. They carry their own status and date range.

---

### sprints

Time-boxed work cycles within a project. A sprint has a goal, a fixed date range,
and a lifecycle: `planned -> active -> completed`. Only one sprint should be
`active` at a time per project (enforced at application layer).

---

### task_statuses

Per-project configurable workflow columns (e.g., Backlog, To Do, In Progress,
In Review, Done). The `category` field maps each custom status to one of three
canonical phases (`todo`, `in_progress`, `done`) for reporting purposes.

---

### tasks

The core entity. Supports hierarchical subtasks via `parent_task_id` (self-reference).
Can belong to an epic and/or a sprint simultaneously. Task type values:
`task`, `bug`, `feature`, `story`.

---

### task_labels

Color-coded labels scoped to a project. Applied to tasks via `task_label_map`.

---

### task_label_map

Many-to-many bridge between tasks and labels. Composite primary key.

---

### task_dependencies

Tracks dependencies between tasks. Dependency types follow standard project
management semantics:
- `finish_to_start` - task B cannot start until task A finishes (most common)
- `start_to_start`  - task B cannot start until task A starts
- `finish_to_finish` - task B cannot finish until task A finishes
- `start_to_finish` - task B cannot finish until task A starts

---

### task_watchers

Many-to-many bridge: users who watch (subscribe to notifications on) a task.

---

### comments

Threaded comments on tasks. Soft delete via `is_deleted` flag preserves the
thread structure. Nested replies via `parent_comment_id`.

---

### activity_log

Audit trail for changes to tasks, projects, sprints, epics, and workspaces.
Stores `old_value` and `new_value` as serialized strings (JSON or plain text)
for the changed field. The `action` field uses verb-object format:
e.g., `status_changed`, `assignee_updated`, `task_created`.

---

### attachments

Files attached to tasks. The actual binary is stored on disk or object storage;
this table stores the metadata and path reference.

---

### time_logs

Manual time entries against tasks. The `hours` field is constrained between 0
and 24 per entry. Summed into `tasks.actual_hours` via application logic or
a trigger.

---

### notifications

In-app notification feed per user. The `entity_type` + `entity_id` pair enables
deep-linking to the relevant resource. Read state is tracked with `is_read`.

---

## Roles and Permissions

| Role | Level | Key Permissions |
|---|---|---|
| admin | System | Full access to all resources, user management, workspace creation |
| project_manager | Project | Create/edit/delete projects and tasks, manage sprints and epics, add/remove members, view reports |
| developer | Task | Read projects, create and update own tasks, log time, write comments, manage own attachments |
| viewer | Read-only | Read access to assigned projects, tasks, sprints, and comments - no write operations |

Permissions are enforced via Flask route decorators that read `current_user.role.name`
and check against the `permissions_json` stored in the role record. Project-level
overrides are resolved by checking `project_members.role_id` before falling back
to the user's global role.

---

## Key Design Decisions

1. **Per-project task statuses** - Each project defines its own workflow columns,
   enabling flexible Kanban-style boards without a rigid global status enum.

2. **Soft deletes on comments** - Deleting a comment marks `is_deleted = 1` so
   threaded replies remain structurally intact in the UI.

3. **Self-referential tasks** - Subtasks are tasks with a non-null `parent_task_id`.
   Only one level of nesting is recommended at the application layer.

4. **Canonical status categories** - `task_statuses.category` always resolves to
   `todo | in_progress | done`, allowing charts and burndown calculations to work
   regardless of how many custom columns a project has.

5. **NVARCHAR throughout** - All string columns use NVARCHAR for full Unicode
   support, covering international characters in task titles, comments, etc.

6. **DATETIME2 for timestamps** - More precision and range than DATETIME; UTC
   values are stored and converted to the user's timezone at the application layer.

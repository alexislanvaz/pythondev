"""
Tasks blueprint routes.
All routes require the user to be logged in.
"""

from flask import render_template
from flask_login import login_required, current_user

from app.tasks import tasks_bp


@tasks_bp.get("/mine")
@login_required
def my_tasks():
    """Render the My Tasks page. Data is loaded client-side via the API."""
    return render_template(
        "tasks/my_tasks.html",
        user=current_user,
        page_title="My Tasks",
    )

"""
Tasks blueprint package.
Handles UI routes for task-related views (e.g. My Tasks page).
"""

from flask import Blueprint

tasks_bp = Blueprint(
    "tasks",
    __name__,
    template_folder="templates",
    url_prefix="/tasks",
)

from app.tasks import routes  # noqa: E402,F401

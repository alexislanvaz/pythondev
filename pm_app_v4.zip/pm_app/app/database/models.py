"""
SQLAlchemy models for the project management application.
Database: SQL Server (pyodbc / mssql+pyodbc driver)
"""

from datetime import datetime, date
from decimal import Decimal
from typing import Optional

from flask_login import UserMixin

# Import the shared db instance from extensions to avoid creating
# a duplicate SQLAlchemy instance.
from app.extensions import db


# ============================================================
# Role
# ============================================================

class Role(db.Model):
    __tablename__ = "roles"
    __table_args__ = {"schema": "dbo"}

    id               = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name             = db.Column(db.Unicode(50),  nullable=False, unique=True)
    description      = db.Column(db.Unicode(255), nullable=True)
    permissions_json = db.Column(db.UnicodeText,  nullable=True)
    created_at       = db.Column(db.DateTime2,    nullable=False, default=datetime.utcnow)

    # Relationships
    users             = db.relationship("User",             backref="role",      lazy="dynamic")
    workspace_members = db.relationship("WorkspaceMember",  backref="role",      lazy="dynamic")
    project_members   = db.relationship("ProjectMember",    backref="role",      lazy="dynamic")

    def to_dict(self) -> dict:
        return {
            "id":          self.id,
            "name":        self.name,
            "description": self.description,
        }

    def __repr__(self) -> str:
        return f"<Role {self.name}>"


# ============================================================
# User
# ============================================================

class User(UserMixin, db.Model):
    __tablename__ = "users"
    __table_args__ = {"schema": "dbo"}

    id            = db.Column(db.Integer,     primary_key=True, autoincrement=True)
    username      = db.Column(db.Unicode(80),  nullable=False, unique=True)
    email         = db.Column(db.Unicode(150), nullable=False, unique=True)
    password_hash = db.Column(db.Unicode(255), nullable=False)
    full_name     = db.Column(db.Unicode(150), nullable=True)
    avatar_url    = db.Column(db.Unicode(500), nullable=True)
    role_id       = db.Column(db.Integer,      db.ForeignKey("dbo.roles.id"), nullable=False)
    is_active     = db.Column(db.Boolean,      nullable=False, default=True)
    last_login    = db.Column(db.DateTime2,    nullable=True)
    created_at    = db.Column(db.DateTime2,    nullable=False, default=datetime.utcnow)
    updated_at    = db.Column(db.DateTime2,    nullable=False, default=datetime.utcnow,
                              onupdate=datetime.utcnow)

    # Relationships
    owned_workspaces  = db.relationship("Workspace",       foreign_keys="Workspace.owner_id",
                                        backref="owner",   lazy="dynamic")
    workspace_members = db.relationship("WorkspaceMember", backref="user", lazy="dynamic")
    owned_projects    = db.relationship("Project",         foreign_keys="Project.owner_id",
                                        backref="owner",   lazy="dynamic")
    project_members   = db.relationship("ProjectMember",   backref="user", lazy="dynamic")
    assigned_tasks    = db.relationship("Task",            foreign_keys="Task.assignee_id",
                                        backref="assignee", lazy="dynamic")
    reported_tasks    = db.relationship("Task",            foreign_keys="Task.reporter_id",
                                        backref="reporter", lazy="dynamic")
    comments          = db.relationship("Comment",         backref="user", lazy="dynamic")
    activity_logs     = db.relationship("ActivityLog",     backref="user", lazy="dynamic")
    attachments       = db.relationship("Attachment",      backref="user", lazy="dynamic")
    time_logs         = db.relationship("TimeLog",         backref="user", lazy="dynamic")
    notifications     = db.relationship("Notification",    backref="user", lazy="dynamic")
    watched_tasks     = db.relationship("Task",            secondary="dbo.task_watchers",
                                        backref=db.backref("watchers", lazy="dynamic"),
                                        lazy="dynamic")

    def to_dict(self, include_sensitive: bool = False) -> dict:
        data = {
            "id":         self.id,
            "username":   self.username,
            "email":      self.email,
            "full_name":  self.full_name,
            "avatar_url": self.avatar_url,
            "role_id":    self.role_id,
            "role_name":  self.role.name if self.role else None,
            "is_active":  self.is_active,
            "last_login": self.last_login.isoformat() if self.last_login else None,
            "created_at": self.created_at.isoformat(),
        }
        if include_sensitive:
            data["password_hash"] = self.password_hash
        return data

    def __repr__(self) -> str:
        return f"<User {self.username}>"


# ============================================================
# Workspace
# ============================================================

class Workspace(db.Model):
    __tablename__ = "workspaces"
    __table_args__ = {"schema": "dbo"}

    id          = db.Column(db.Integer,     primary_key=True, autoincrement=True)
    name        = db.Column(db.Unicode(150), nullable=False)
    slug        = db.Column(db.Unicode(150), nullable=False, unique=True)
    description = db.Column(db.Unicode(500), nullable=True)
    owner_id    = db.Column(db.Integer,      db.ForeignKey("dbo.users.id"), nullable=False)
    created_at  = db.Column(db.DateTime2,    nullable=False, default=datetime.utcnow)
    updated_at  = db.Column(db.DateTime2,    nullable=False, default=datetime.utcnow,
                            onupdate=datetime.utcnow)

    # Relationships
    members  = db.relationship("WorkspaceMember", backref="workspace", lazy="dynamic",
                               cascade="all, delete-orphan")
    projects = db.relationship("Project",          backref="workspace", lazy="dynamic",
                               cascade="all, delete-orphan")

    def to_dict(self) -> dict:
        return {
            "id":          self.id,
            "name":        self.name,
            "slug":        self.slug,
            "description": self.description,
            "owner_id":    self.owner_id,
            "created_at":  self.created_at.isoformat(),
            "updated_at":  self.updated_at.isoformat(),
        }

    def __repr__(self) -> str:
        return f"<Workspace {self.slug}>"


# ============================================================
# WorkspaceMember
# ============================================================

class WorkspaceMember(db.Model):
    __tablename__ = "workspace_members"
    __table_args__ = (
        db.UniqueConstraint("workspace_id", "user_id", name="UQ_workspace_members_pair"),
        {"schema": "dbo"},
    )

    id           = db.Column(db.Integer,  primary_key=True, autoincrement=True)
    workspace_id = db.Column(db.Integer,  db.ForeignKey("dbo.workspaces.id"), nullable=False)
    user_id      = db.Column(db.Integer,  db.ForeignKey("dbo.users.id"),      nullable=False)
    role_id      = db.Column(db.Integer,  db.ForeignKey("dbo.roles.id"),      nullable=False)
    joined_at    = db.Column(db.DateTime2, nullable=False, default=datetime.utcnow)

    def to_dict(self) -> dict:
        return {
            "id":           self.id,
            "workspace_id": self.workspace_id,
            "user_id":      self.user_id,
            "role_id":      self.role_id,
            "joined_at":    self.joined_at.isoformat(),
        }


# ============================================================
# Project
# ============================================================

class Project(db.Model):
    __tablename__ = "projects"
    __table_args__ = (
        db.UniqueConstraint("workspace_id", "slug", name="UQ_projects_workspace_slug"),
        {"schema": "dbo"},
    )

    id               = db.Column(db.Integer,       primary_key=True, autoincrement=True)
    workspace_id     = db.Column(db.Integer,        db.ForeignKey("dbo.workspaces.id"), nullable=False)
    name             = db.Column(db.Unicode(150),   nullable=False)
    slug             = db.Column(db.Unicode(150),   nullable=False)
    description      = db.Column(db.Unicode(2000),  nullable=True)
    status           = db.Column(db.Unicode(20),    nullable=False, default="planning")
    priority         = db.Column(db.Unicode(10),    nullable=False, default="medium")
    start_date       = db.Column(db.Date,           nullable=True)
    end_date         = db.Column(db.Date,           nullable=True)
    progress_percent = db.Column(db.Numeric(5, 2),  nullable=False, default=Decimal("0.00"))
    owner_id         = db.Column(db.Integer,         db.ForeignKey("dbo.users.id"), nullable=False)
    color_hex        = db.Column(db.Unicode(7),     nullable=False, default="#20808D")
    created_at       = db.Column(db.DateTime2,      nullable=False, default=datetime.utcnow)
    updated_at       = db.Column(db.DateTime2,      nullable=False, default=datetime.utcnow,
                                 onupdate=datetime.utcnow)

    # Relationships
    members       = db.relationship("ProjectMember", backref="project", lazy="dynamic",
                                    cascade="all, delete-orphan")
    epics         = db.relationship("Epic",          backref="project", lazy="dynamic",
                                    cascade="all, delete-orphan")
    sprints       = db.relationship("Sprint",        backref="project", lazy="dynamic",
                                    cascade="all, delete-orphan")
    tasks         = db.relationship("Task",          backref="project", lazy="dynamic",
                                    cascade="all, delete-orphan")
    task_statuses = db.relationship("TaskStatus",    backref="project", lazy="dynamic",
                                    cascade="all, delete-orphan")
    task_labels   = db.relationship("TaskLabel",     backref="project", lazy="dynamic",
                                    cascade="all, delete-orphan")

    def to_dict(self) -> dict:
        return {
            "id":               self.id,
            "workspace_id":     self.workspace_id,
            "name":             self.name,
            "slug":             self.slug,
            "description":      self.description,
            "status":           self.status,
            "priority":         self.priority,
            "start_date":       self.start_date.isoformat() if self.start_date else None,
            "end_date":         self.end_date.isoformat()   if self.end_date   else None,
            "progress_percent": float(self.progress_percent),
            "owner_id":         self.owner_id,
            "color_hex":        self.color_hex,
            "created_at":       self.created_at.isoformat(),
            "updated_at":       self.updated_at.isoformat(),
        }

    def __repr__(self) -> str:
        return f"<Project {self.slug}>"


# ============================================================
# ProjectMember
# ============================================================

class ProjectMember(db.Model):
    __tablename__ = "project_members"
    __table_args__ = (
        db.UniqueConstraint("project_id", "user_id", name="UQ_project_members_pair"),
        {"schema": "dbo"},
    )

    id          = db.Column(db.Integer,  primary_key=True, autoincrement=True)
    project_id  = db.Column(db.Integer,  db.ForeignKey("dbo.projects.id"), nullable=False)
    user_id     = db.Column(db.Integer,  db.ForeignKey("dbo.users.id"),    nullable=False)
    role_id     = db.Column(db.Integer,  db.ForeignKey("dbo.roles.id"),    nullable=False)
    assigned_at = db.Column(db.DateTime2, nullable=False, default=datetime.utcnow)

    def to_dict(self) -> dict:
        return {
            "id":          self.id,
            "project_id":  self.project_id,
            "user_id":     self.user_id,
            "role_id":     self.role_id,
            "assigned_at": self.assigned_at.isoformat(),
        }


# ============================================================
# Epic
# ============================================================

class Epic(db.Model):
    __tablename__ = "epics"
    __table_args__ = {"schema": "dbo"}

    id          = db.Column(db.Integer,      primary_key=True, autoincrement=True)
    project_id  = db.Column(db.Integer,       db.ForeignKey("dbo.projects.id"), nullable=False)
    name        = db.Column(db.Unicode(150),  nullable=False)
    description = db.Column(db.Unicode(2000), nullable=True)
    status      = db.Column(db.Unicode(20),   nullable=False, default="planning")
    start_date  = db.Column(db.Date,          nullable=True)
    end_date    = db.Column(db.Date,          nullable=True)
    color_hex   = db.Column(db.Unicode(7),    nullable=False, default="#7A39BB")
    created_at  = db.Column(db.DateTime2,     nullable=False, default=datetime.utcnow)

    # Relationships
    tasks = db.relationship("Task", backref="epic", lazy="dynamic")

    def to_dict(self) -> dict:
        return {
            "id":          self.id,
            "project_id":  self.project_id,
            "name":        self.name,
            "description": self.description,
            "status":      self.status,
            "start_date":  self.start_date.isoformat() if self.start_date else None,
            "end_date":    self.end_date.isoformat()   if self.end_date   else None,
            "color_hex":   self.color_hex,
            "created_at":  self.created_at.isoformat(),
        }

    def __repr__(self) -> str:
        return f"<Epic {self.name}>"


# ============================================================
# Sprint
# ============================================================

class Sprint(db.Model):
    __tablename__ = "sprints"
    __table_args__ = {"schema": "dbo"}

    id         = db.Column(db.Integer,      primary_key=True, autoincrement=True)
    project_id = db.Column(db.Integer,       db.ForeignKey("dbo.projects.id"), nullable=False)
    name       = db.Column(db.Unicode(150),  nullable=False)
    goal       = db.Column(db.Unicode(1000), nullable=True)
    status     = db.Column(db.Unicode(15),   nullable=False, default="planned")
    start_date = db.Column(db.Date,          nullable=True)
    end_date   = db.Column(db.Date,          nullable=True)
    created_at = db.Column(db.DateTime2,     nullable=False, default=datetime.utcnow)

    # Relationships
    tasks = db.relationship("Task", backref="sprint", lazy="dynamic")

    def to_dict(self) -> dict:
        return {
            "id":         self.id,
            "project_id": self.project_id,
            "name":       self.name,
            "goal":       self.goal,
            "status":     self.status,
            "start_date": self.start_date.isoformat() if self.start_date else None,
            "end_date":   self.end_date.isoformat()   if self.end_date   else None,
            "created_at": self.created_at.isoformat(),
        }

    def __repr__(self) -> str:
        return f"<Sprint {self.name}>"


# ============================================================
# TaskStatus
# ============================================================

class TaskStatus(db.Model):
    __tablename__ = "task_statuses"
    __table_args__ = (
        db.UniqueConstraint("project_id", "name", name="UQ_task_statuses_pair"),
        {"schema": "dbo"},
    )

    id          = db.Column(db.Integer,    primary_key=True, autoincrement=True)
    project_id  = db.Column(db.Integer,    db.ForeignKey("dbo.projects.id"), nullable=False)
    name        = db.Column(db.Unicode(80), nullable=False)
    color_hex   = db.Column(db.Unicode(7),  nullable=False, default="#BAB9B4")
    order_index = db.Column(db.Integer,     nullable=False, default=0)
    is_default  = db.Column(db.Boolean,     nullable=False, default=False)
    category    = db.Column(db.Unicode(15), nullable=False, default="todo")

    # Relationships
    tasks = db.relationship("Task", backref="status", lazy="dynamic")

    def to_dict(self) -> dict:
        return {
            "id":          self.id,
            "project_id":  self.project_id,
            "name":        self.name,
            "color_hex":   self.color_hex,
            "order_index": self.order_index,
            "is_default":  self.is_default,
            "category":    self.category,
        }

    def __repr__(self) -> str:
        return f"<TaskStatus {self.name}>"


# ============================================================
# TaskLabel
# ============================================================

class TaskLabel(db.Model):
    __tablename__ = "task_labels"
    __table_args__ = (
        db.UniqueConstraint("project_id", "name", name="UQ_task_labels_pair"),
        {"schema": "dbo"},
    )

    id         = db.Column(db.Integer,    primary_key=True, autoincrement=True)
    name       = db.Column(db.Unicode(80), nullable=False)
    color_hex  = db.Column(db.Unicode(7),  nullable=False, default="#20808D")
    project_id = db.Column(db.Integer,     db.ForeignKey("dbo.projects.id"), nullable=False)

    def to_dict(self) -> dict:
        return {
            "id":         self.id,
            "name":       self.name,
            "color_hex":  self.color_hex,
            "project_id": self.project_id,
        }

    def __repr__(self) -> str:
        return f"<TaskLabel {self.name}>"


# ============================================================
# Association table: task_watchers
# ============================================================

task_watchers = db.Table(
    "task_watchers",
    db.Column("task_id", db.Integer, db.ForeignKey("dbo.tasks.id"),  primary_key=True),
    db.Column("user_id", db.Integer, db.ForeignKey("dbo.users.id"),  primary_key=True),
    schema="dbo",
)

# ============================================================
# Association table: task_label_map
# ============================================================

task_label_map = db.Table(
    "task_label_map",
    db.Column("task_id",  db.Integer, db.ForeignKey("dbo.tasks.id"),        primary_key=True),
    db.Column("label_id", db.Integer, db.ForeignKey("dbo.task_labels.id"), primary_key=True),
    schema="dbo",
)


# ============================================================
# Task
# ============================================================

class Task(db.Model):
    __tablename__ = "tasks"
    __table_args__ = {"schema": "dbo"}

    id              = db.Column(db.Integer,      primary_key=True, autoincrement=True)
    project_id      = db.Column(db.Integer,       db.ForeignKey("dbo.projects.id"),      nullable=False)
    epic_id         = db.Column(db.Integer,       db.ForeignKey("dbo.epics.id"),          nullable=True)
    sprint_id       = db.Column(db.Integer,       db.ForeignKey("dbo.sprints.id"),        nullable=True)
    parent_task_id  = db.Column(db.Integer,       db.ForeignKey("dbo.tasks.id"),          nullable=True)
    title           = db.Column(db.Unicode(300),  nullable=False)
    description     = db.Column(db.UnicodeText,   nullable=True)
    type            = db.Column(db.Unicode(10),   nullable=False, default="task")
    status_id       = db.Column(db.Integer,       db.ForeignKey("dbo.task_statuses.id"), nullable=False)
    priority        = db.Column(db.Unicode(10),   nullable=False, default="medium")
    assignee_id     = db.Column(db.Integer,       db.ForeignKey("dbo.users.id"),          nullable=True)
    reporter_id     = db.Column(db.Integer,       db.ForeignKey("dbo.users.id"),          nullable=False)
    estimated_hours = db.Column(db.Numeric(8, 2), nullable=True)
    actual_hours    = db.Column(db.Numeric(8, 2), nullable=False, default=Decimal("0.00"))
    due_date        = db.Column(db.Date,          nullable=True)
    start_date      = db.Column(db.Date,          nullable=True)
    order_index     = db.Column(db.Integer,       nullable=False, default=0)
    created_at      = db.Column(db.DateTime2,     nullable=False, default=datetime.utcnow)
    updated_at      = db.Column(db.DateTime2,     nullable=False, default=datetime.utcnow,
                                onupdate=datetime.utcnow)

    # Self-referential relationship for subtasks
    subtasks = db.relationship(
        "Task", backref=db.backref("parent_task", remote_side="Task.id"), lazy="dynamic"
    )

    # Many-to-many relationships
    labels = db.relationship("TaskLabel", secondary=task_label_map, backref="tasks", lazy="subquery")

    # One-to-many relationships
    comments     = db.relationship("Comment",         backref="task", lazy="dynamic",
                                   cascade="all, delete-orphan")
    attachments  = db.relationship("Attachment",      backref="task", lazy="dynamic",
                                   cascade="all, delete-orphan")
    time_logs    = db.relationship("TimeLog",         backref="task", lazy="dynamic",
                                   cascade="all, delete-orphan")
    dependencies = db.relationship("TaskDependency",  foreign_keys="TaskDependency.task_id",
                                   backref="task",    lazy="dynamic",
                                   cascade="all, delete-orphan")
    dependents   = db.relationship("TaskDependency",  foreign_keys="TaskDependency.depends_on_task_id",
                                   backref="depends_on_task", lazy="dynamic")

    def to_dict(self) -> dict:
        return {
            "id":               self.id,
            "project_id":       self.project_id,
            "epic_id":          self.epic_id,
            "sprint_id":        self.sprint_id,
            "parent_task_id":   self.parent_task_id,
            "title":            self.title,
            "description":      self.description,
            "type":             self.type,
            "status_id":        self.status_id,
            "status_name":      self.status.name if self.status else None,
            "priority":         self.priority,
            "assignee_id":      self.assignee_id,
            "reporter_id":      self.reporter_id,
            "estimated_hours":  float(self.estimated_hours) if self.estimated_hours else None,
            "actual_hours":     float(self.actual_hours),
            "due_date":         self.due_date.isoformat()    if self.due_date    else None,
            "start_date":       self.start_date.isoformat()  if self.start_date  else None,
            "order_index":      self.order_index,
            "created_at":       self.created_at.isoformat(),
            "updated_at":       self.updated_at.isoformat(),
            "labels":           [l.to_dict() for l in self.labels],
        }

    @property
    def is_overdue(self) -> bool:
        if self.due_date and self.status and self.status.category != "done":
            return self.due_date < date.today()
        return False

    def __repr__(self) -> str:
        return f"<Task {self.id}: {self.title[:40]}>"


# ============================================================
# TaskDependency
# ============================================================

class TaskDependency(db.Model):
    __tablename__ = "task_dependencies"
    __table_args__ = (
        db.UniqueConstraint("task_id", "depends_on_task_id", name="UQ_task_dep_pair"),
        {"schema": "dbo"},
    )

    id                 = db.Column(db.Integer,    primary_key=True, autoincrement=True)
    task_id            = db.Column(db.Integer,    db.ForeignKey("dbo.tasks.id"), nullable=False)
    depends_on_task_id = db.Column(db.Integer,    db.ForeignKey("dbo.tasks.id"), nullable=False)
    dependency_type    = db.Column(db.Unicode(25), nullable=False, default="finish_to_start")

    def to_dict(self) -> dict:
        return {
            "id":                 self.id,
            "task_id":            self.task_id,
            "depends_on_task_id": self.depends_on_task_id,
            "dependency_type":    self.dependency_type,
        }


# ============================================================
# Comment
# ============================================================

class Comment(db.Model):
    __tablename__ = "comments"
    __table_args__ = {"schema": "dbo"}

    id                = db.Column(db.Integer,   primary_key=True, autoincrement=True)
    task_id           = db.Column(db.Integer,   db.ForeignKey("dbo.tasks.id"),    nullable=False)
    user_id           = db.Column(db.Integer,   db.ForeignKey("dbo.users.id"),    nullable=False)
    content           = db.Column(db.UnicodeText, nullable=False)
    parent_comment_id = db.Column(db.Integer,   db.ForeignKey("dbo.comments.id"), nullable=True)
    created_at        = db.Column(db.DateTime2,  nullable=False, default=datetime.utcnow)
    updated_at        = db.Column(db.DateTime2,  nullable=False, default=datetime.utcnow,
                                  onupdate=datetime.utcnow)
    is_deleted        = db.Column(db.Boolean,    nullable=False, default=False)

    replies = db.relationship(
        "Comment",
        backref=db.backref("parent_comment", remote_side="Comment.id"),
        lazy="dynamic",
    )

    def to_dict(self) -> dict:
        return {
            "id":                self.id,
            "task_id":           self.task_id,
            "user_id":           self.user_id,
            "content":           self.content if not self.is_deleted else "[deleted]",
            "parent_comment_id": self.parent_comment_id,
            "created_at":        self.created_at.isoformat(),
            "updated_at":        self.updated_at.isoformat(),
            "is_deleted":        self.is_deleted,
        }

    def __repr__(self) -> str:
        return f"<Comment {self.id} on task {self.task_id}>"


# ============================================================
# ActivityLog
# ============================================================

class ActivityLog(db.Model):
    __tablename__ = "activity_log"
    __table_args__ = {"schema": "dbo"}

    id          = db.Column(db.Integer,     primary_key=True, autoincrement=True)
    entity_type = db.Column(db.Unicode(20), nullable=False)
    entity_id   = db.Column(db.Integer,     nullable=False)
    user_id     = db.Column(db.Integer,     db.ForeignKey("dbo.users.id"), nullable=False)
    action      = db.Column(db.Unicode(100), nullable=False)
    old_value   = db.Column(db.UnicodeText,  nullable=True)
    new_value   = db.Column(db.UnicodeText,  nullable=True)
    created_at  = db.Column(db.DateTime2,   nullable=False, default=datetime.utcnow)

    def to_dict(self) -> dict:
        return {
            "id":          self.id,
            "entity_type": self.entity_type,
            "entity_id":   self.entity_id,
            "user_id":     self.user_id,
            "action":      self.action,
            "old_value":   self.old_value,
            "new_value":   self.new_value,
            "created_at":  self.created_at.isoformat(),
        }

    def __repr__(self) -> str:
        return f"<ActivityLog {self.action} on {self.entity_type}/{self.entity_id}>"


# ============================================================
# Attachment
# ============================================================

class Attachment(db.Model):
    __tablename__ = "attachments"
    __table_args__ = {"schema": "dbo"}

    id         = db.Column(db.Integer,      primary_key=True, autoincrement=True)
    task_id    = db.Column(db.Integer,       db.ForeignKey("dbo.tasks.id"),  nullable=False)
    user_id    = db.Column(db.Integer,       db.ForeignKey("dbo.users.id"),  nullable=False)
    filename   = db.Column(db.Unicode(255),  nullable=False)
    file_path  = db.Column(db.Unicode(1000), nullable=False)
    file_size  = db.Column(db.BigInteger,    nullable=False, default=0)
    mime_type  = db.Column(db.Unicode(150),  nullable=True)
    created_at = db.Column(db.DateTime2,     nullable=False, default=datetime.utcnow)

    def to_dict(self) -> dict:
        return {
            "id":         self.id,
            "task_id":    self.task_id,
            "user_id":    self.user_id,
            "filename":   self.filename,
            "file_path":  self.file_path,
            "file_size":  self.file_size,
            "mime_type":  self.mime_type,
            "created_at": self.created_at.isoformat(),
        }

    def __repr__(self) -> str:
        return f"<Attachment {self.filename}>"


# ============================================================
# TimeLog
# ============================================================

class TimeLog(db.Model):
    __tablename__ = "time_logs"
    __table_args__ = {"schema": "dbo"}

    id          = db.Column(db.Integer,     primary_key=True, autoincrement=True)
    task_id     = db.Column(db.Integer,      db.ForeignKey("dbo.tasks.id"),  nullable=False)
    user_id     = db.Column(db.Integer,      db.ForeignKey("dbo.users.id"),  nullable=False)
    description = db.Column(db.Unicode(500), nullable=True)
    hours       = db.Column(db.Numeric(8, 2), nullable=False)
    logged_date = db.Column(db.Date,          nullable=False)
    created_at  = db.Column(db.DateTime2,    nullable=False, default=datetime.utcnow)

    def to_dict(self) -> dict:
        return {
            "id":          self.id,
            "task_id":     self.task_id,
            "user_id":     self.user_id,
            "description": self.description,
            "hours":       float(self.hours),
            "logged_date": self.logged_date.isoformat(),
            "created_at":  self.created_at.isoformat(),
        }

    def __repr__(self) -> str:
        return f"<TimeLog {self.hours}h on task {self.task_id}>"


# ============================================================
# Notification
# ============================================================

class Notification(db.Model):
    __tablename__ = "notifications"
    __table_args__ = {"schema": "dbo"}

    id          = db.Column(db.Integer,      primary_key=True, autoincrement=True)
    user_id     = db.Column(db.Integer,       db.ForeignKey("dbo.users.id"), nullable=False,
                            onupdate=None)
    type        = db.Column(db.Unicode(50),  nullable=False)
    title       = db.Column(db.Unicode(200), nullable=False)
    message     = db.Column(db.Unicode(1000), nullable=False)
    entity_type = db.Column(db.Unicode(20),  nullable=True)
    entity_id   = db.Column(db.Integer,      nullable=True)
    is_read     = db.Column(db.Boolean,      nullable=False, default=False)
    created_at  = db.Column(db.DateTime2,    nullable=False, default=datetime.utcnow)

    def to_dict(self) -> dict:
        return {
            "id":          self.id,
            "user_id":     self.user_id,
            "type":        self.type,
            "title":       self.title,
            "message":     self.message,
            "entity_type": self.entity_type,
            "entity_id":   self.entity_id,
            "is_read":     self.is_read,
            "created_at":  self.created_at.isoformat(),
        }

    def __repr__(self) -> str:
        return f"<Notification {self.type} for user {self.user_id}>"

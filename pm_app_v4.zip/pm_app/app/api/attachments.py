"""
Attachments API blueprint.
Prefix: /api/v1/tasks  (registered via api_bp)
All responses use the envelope: {"data": ..., "error": null, "meta": {}}
"""

import mimetypes
import os
import uuid

from flask import Blueprint, current_app, request, send_from_directory
from flask_login import current_user, login_required
from werkzeug.utils import secure_filename

from app.extensions import db
from app.database.models import Attachment, ProjectMember, Task

attachments_bp = Blueprint("attachments", __name__, url_prefix="/v1/tasks")


# ------------------------------------------------------------------ #
# Constants
# ------------------------------------------------------------------ #

MAX_FILE_SIZE = 16 * 1024 * 1024  # 16 MB

ALLOWED_EXTENSIONS = {
    "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx",
    "txt", "md", "csv", "json", "xml",
    "png", "jpg", "jpeg", "gif", "webp", "svg",
    "zip", "tar", "gz", "7z",
    "mp4", "mov", "avi",
    "py", "js", "ts", "html", "css", "sql",
}


# ------------------------------------------------------------------ #
# Helpers
# ------------------------------------------------------------------ #

def _ok(data, meta=None):
    from flask import jsonify
    return jsonify({"data": data, "error": None, "meta": meta or {}})


def _err(message, status=400):
    from flask import jsonify
    return jsonify({"data": None, "error": message, "meta": {}}), status


def _is_member(project_id, user_id=None):
    uid = user_id or current_user.id
    return ProjectMember.query.filter_by(
        project_id=project_id, user_id=uid
    ).first() is not None


def _member_role(project_id, user_id=None):
    uid = user_id or current_user.id
    pm = ProjectMember.query.filter_by(project_id=project_id, user_id=uid).first()
    return pm.role.name.lower() if pm and pm.role else None


def _allowed_file(filename):
    """Return True if the file extension is in ALLOWED_EXTENSIONS."""
    if "." not in filename:
        return False
    ext = filename.rsplit(".", 1)[1].lower()
    return ext in ALLOWED_EXTENSIONS


def _file_icon(mime_type, filename):
    """Return a category string based on mime_type or file extension."""
    mt = (mime_type or "").lower()

    if mt.startswith("image/"):
        return "image"
    if mt.startswith("video/"):
        return "video"
    if mt in (
        "application/pdf",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "text/plain",
        "text/markdown",
    ):
        return "document"
    if mt in (
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "text/csv",
    ):
        return "spreadsheet"
    if mt in (
        "application/vnd.ms-powerpoint",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ):
        return "presentation"
    if mt in (
        "application/zip",
        "application/x-tar",
        "application/gzip",
        "application/x-7z-compressed",
        "application/x-rar-compressed",
    ):
        return "archive"

    # Fallback: check extension
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext in ("png", "jpg", "jpeg", "gif", "webp", "svg"):
        return "image"
    if ext in ("mp4", "mov", "avi"):
        return "video"
    if ext in ("xls", "xlsx", "csv"):
        return "spreadsheet"
    if ext in ("ppt", "pptx"):
        return "presentation"
    if ext in ("zip", "tar", "gz", "7z"):
        return "archive"
    if ext in ("py", "js", "ts", "html", "css", "sql", "json", "xml", "md"):
        return "code"
    if ext in ("pdf", "doc", "docx", "txt"):
        return "document"

    return "other"


def _file_size_human(size_bytes):
    """Return a human-readable file size string."""
    if size_bytes >= 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    return f"{size_bytes / 1024:.1f} KB"


def _attachment_dict(att):
    """Serialise an Attachment instance for API responses."""
    uploader = None
    if att.user:
        uploader = {
            "id": att.user.id,
            "full_name": att.user.full_name,
        }
    return {
        "id": att.id,
        "filename": att.filename,
        "file_path_url": att.file_path,
        "file_size": att.file_size,
        "file_size_human": _file_size_human(att.file_size),
        "mime_type": att.mime_type,
        "file_icon": _file_icon(att.mime_type, att.filename),
        "created_at": att.created_at.isoformat(),
        "uploader": uploader,
    }


# ------------------------------------------------------------------ #
# GET /api/v1/tasks/<task_id>/attachments
# ------------------------------------------------------------------ #

@attachments_bp.get("/<int:task_id>/attachments")
@login_required
def list_attachments(task_id):
    task = Task.query.get_or_404(task_id)
    if not _is_member(task.project_id):
        return _err("Forbidden", 403)

    atts = (
        Attachment.query
        .filter_by(task_id=task_id)
        .order_by(Attachment.created_at.desc())
        .all()
    )
    return _ok([_attachment_dict(a) for a in atts])


# ------------------------------------------------------------------ #
# POST /api/v1/tasks/<task_id>/attachments
# ------------------------------------------------------------------ #

@attachments_bp.post("/<int:task_id>/attachments")
@login_required
def upload_attachments(task_id):
    task = Task.query.get_or_404(task_id)
    if not _is_member(task.project_id):
        return _err("Forbidden", 403)

    # Accept both 'file' (single) and 'files[]' (multiple) field names
    files = request.files.getlist("files[]") or request.files.getlist("file")
    if not files:
        return _err("No files provided")

    upload_folder = current_app.config.get("UPLOAD_FOLDER", "uploads")
    workspace_id = task.project.workspace_id
    save_dir = os.path.join(
        upload_folder,
        str(workspace_id),
        str(task.project_id),
        str(task_id),
    )
    os.makedirs(save_dir, exist_ok=True)

    created = []
    errors = []

    for f in files:
        original_name = f.filename or ""
        if not original_name:
            errors.append({"filename": "", "error": "Empty filename"})
            continue

        if not _allowed_file(original_name):
            errors.append({"filename": original_name, "error": "File type not allowed"})
            continue

        # Read into memory to check size before saving
        f.stream.seek(0, 2)          # seek to end
        file_size = f.stream.tell()
        f.stream.seek(0)             # rewind

        if file_size == 0:
            errors.append({"filename": original_name, "error": "File is empty"})
            continue

        if file_size > MAX_FILE_SIZE:
            errors.append({
                "filename": original_name,
                "error": f"File exceeds maximum size of {MAX_FILE_SIZE // (1024 * 1024)} MB",
            })
            continue

        safe_name = secure_filename(original_name)
        unique_name = f"{uuid.uuid4().hex}_{safe_name}"
        full_path = os.path.join(save_dir, unique_name)

        try:
            f.save(full_path)
        except OSError as exc:
            errors.append({"filename": original_name, "error": str(exc)})
            continue

        mime_type, _ = mimetypes.guess_type(original_name)

        # Relative path stored in DB (used as file_path_url for serving)
        rel_path = os.path.join(
            str(workspace_id),
            str(task.project_id),
            str(task_id),
            unique_name,
        ).replace("\\", "/")

        att = Attachment(
            task_id=task_id,
            user_id=current_user.id,
            filename=original_name,
            file_path=rel_path,
            file_size=file_size,
            mime_type=mime_type,
        )
        db.session.add(att)
        db.session.flush()
        created.append(_attachment_dict(att))

    db.session.commit()

    meta = {}
    if errors:
        meta["errors"] = errors

    return _ok(created, meta=meta), 201


# ------------------------------------------------------------------ #
# DELETE /api/v1/tasks/<task_id>/attachments/<attachment_id>
# ------------------------------------------------------------------ #

@attachments_bp.delete("/<int:task_id>/attachments/<int:attachment_id>")
@login_required
def delete_attachment(task_id, attachment_id):
    task = Task.query.get_or_404(task_id)

    att = Attachment.query.get_or_404(attachment_id)
    if att.task_id != task_id:
        return _err("Attachment does not belong to this task", 400)

    role = _member_role(task.project_id)
    is_uploader = att.user_id == current_user.id
    if role not in ("project_manager", "admin", "owner") and not is_uploader:
        return _err("Not authorized to delete this attachment", 403)

    # Remove physical file, ignoring missing files
    upload_folder = current_app.config.get("UPLOAD_FOLDER", "uploads")
    full_path = os.path.join(upload_folder, att.file_path.replace("/", os.sep))
    try:
        os.remove(full_path)
    except OSError:
        pass

    db.session.delete(att)
    db.session.commit()
    return _ok("ok")


# ------------------------------------------------------------------ #
# GET /api/v1/tasks/<task_id>/attachments/<attachment_id>/download
# ------------------------------------------------------------------ #

@attachments_bp.get("/<int:task_id>/attachments/<int:attachment_id>/download")
@login_required
def download_attachment(task_id, attachment_id):
    task = Task.query.get_or_404(task_id)
    if not _is_member(task.project_id):
        return _err("Forbidden", 403)

    att = Attachment.query.get_or_404(attachment_id)
    if att.task_id != task_id:
        return _err("Attachment does not belong to this task", 400)

    upload_folder = current_app.config.get("UPLOAD_FOLDER", "uploads")
    # file_path is relative: workspace_id/project_id/task_id/unique_name
    file_dir = os.path.join(
        upload_folder,
        os.path.dirname(att.file_path.replace("/", os.sep)),
    )
    unique_name = os.path.basename(att.file_path)

    return send_from_directory(
        file_dir,
        unique_name,
        as_attachment=True,
        download_name=att.filename,
    )

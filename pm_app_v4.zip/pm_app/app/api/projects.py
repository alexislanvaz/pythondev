"""
Projects API blueprint.
Prefix: /api/v1/projects  (registered via api_bp)
"""

from datetime import datetime
from flask import Blueprint, request, jsonify
from flask_login import current_user, login_required
from sqlalchemy import func

try:
    from slugify import slugify
except ImportError:
    import re
    def slugify(text):
        text = text.lower().strip()
        text = re.sub(r"[^\w\s-]", "", text)
        text = re.sub(r"[\s_-]+", "-", text)
        return re.sub(r"^-+|-+$", "", text)

from app.extensions import db
from app.database.models import (
    Project,
    ProjectMember,
    TaskStatus,
    Task,
    Sprint,
    Epic,
    User,
)

projects_api_bp = Blueprint("projects_api", __name__, url_prefix="/v1/projects")


# ------------------------------------------------------------------ #
# Helpers
# ------------------------------------------------------------------ #

def _ok(data, meta=None):
    return jsonify({"data": data, "error": None, "meta": meta or {}})


def _err(message, status=400):
    return jsonify({"data": None, "error": message, "meta": {}}), status


def _is_member(project_id, user_id=None):
    uid = user_id or current_user.id
    return ProjectMember.query.filter_by(project_id=project_id, user_id=uid).first() is not None


def _member_role(project_id, user_id=None):
    uid = user_id or current_user.id
    pm = ProjectMember.query.filter_by(project_id=project_id, user_id=uid).first()
    return pm.role.name.lower() if pm and pm.role else None


def _project_summary(project):
    member_count = project.members.count()
    task_count   = project.tasks.count()
    owner = project.owner
    return {
        "id":               project.id,
        "name":             project.name,
        "slug":             project.slug,
        "status":           project.status,
        "priority":         project.priority,
        "progress_percent": float(project.progress_percent),
        "color_hex":        project.color_hex,
        "start_date":       project.start_date.isoformat() if project.start_date else None,
        "end_date":         project.end_date.isoformat()   if project.end_date   else None,
        "owner": {
            "id":   owner.id,
            "name": owner.full_name or owner.username,
        } if owner else None,
        "member_count": member_count,
        "task_count":   task_count,
    }


def _default_statuses():
    return [
        {"name": "Backlog",      "color_hex": "#7b80a0", "order_index": 0, "is_default": True,  "category": "todo"},
        {"name": "To Do",        "color_hex": "#4f6ef7", "order_index": 1, "is_default": False, "category": "todo"},
        {"name": "In Progress",  "color_hex": "#f0a429", "order_index": 2, "is_default": False, "category": "in_progress"},
        {"name": "In Review",    "color_hex": "#9b59b6", "order_index": 3, "is_default": False, "category": "in_progress"},
        {"name": "Done",         "color_hex": "#3ecf8e", "order_index": 4, "is_default": False, "category": "done"},
    ]


# ------------------------------------------------------------------ #
# GET /api/v1/projects
# ------------------------------------------------------------------ #

@projects_api_bp.get("")
@login_required
def list_projects():
    workspace_id = request.args.get("workspace_id", type=int)

    memberships = ProjectMember.query.filter_by(user_id=current_user.id).all()
    project_ids = [m.project_id for m in memberships]

    q = Project.query.filter(Project.id.in_(project_ids))
    if workspace_id:
        q = q.filter_by(workspace_id=workspace_id)

    projects = q.order_by(Project.name.asc()).all()
    return _ok([_project_summary(p) for p in projects])


# ------------------------------------------------------------------ #
# POST /api/v1/projects
# ------------------------------------------------------------------ #

@projects_api_bp.post("")
@login_required
def create_project():
    body = request.get_json(silent=True) or {}

    workspace_id = body.get("workspace_id")
    name         = (body.get("name") or "").strip()
    if not workspace_id or not name:
        return _err("workspace_id and name are required")

    base_slug = slugify(name)
    slug      = base_slug
    counter   = 1
    while Project.query.filter_by(workspace_id=workspace_id, slug=slug).first():
        slug = f"{base_slug}-{counter}"
        counter += 1

    project = Project(
        workspace_id=workspace_id,
        name=name,
        slug=slug,
        description=body.get("description"),
        status=body.get("status", "planning"),
        priority=body.get("priority", "medium"),
        start_date=_parse_date(body.get("start_date")),
        end_date=_parse_date(body.get("end_date")),
        color_hex=body.get("color_hex", "#4f6ef7"),
        owner_id=current_user.id,
    )
    db.session.add(project)
    db.session.flush()

    # Add creator as project member with their current role
    member = ProjectMember(
        project_id=project.id,
        user_id=current_user.id,
        role_id=current_user.role_id,
    )
    db.session.add(member)

    # Create default task statuses
    for s in _default_statuses():
        ts = TaskStatus(
            project_id=project.id,
            name=s["name"],
            color_hex=s["color_hex"],
            order_index=s["order_index"],
            is_default=s["is_default"],
            category=s["category"],
        )
        db.session.add(ts)

    db.session.commit()
    return _ok(_project_summary(project)), 201


def _parse_date(value):
    if not value:
        return None
    try:
        from datetime import date
        return date.fromisoformat(value)
    except (ValueError, TypeError):
        return None


# ------------------------------------------------------------------ #
# GET /api/v1/projects/<project_id>
# ------------------------------------------------------------------ #

@projects_api_bp.get("/<int:project_id>")
@login_required
def get_project(project_id):
    project = Project.query.get_or_404(project_id)
    if not _is_member(project_id):
        return _err("Forbidden", 403)

    members = [
        {
            "id":       pm.id,
            "user_id":  pm.user_id,
            "role_id":  pm.role_id,
            "role_name": pm.role.name if pm.role else None,
            "full_name": pm.user.full_name if pm.user else None,
            "avatar_url": pm.user.avatar_url if pm.user else None,
            "assigned_at": pm.assigned_at.isoformat(),
        }
        for pm in project.members.all()
    ]

    statuses = [s.to_dict() for s in
                project.task_statuses.order_by(TaskStatus.order_index.asc()).all()]

    active_sprints = [
        sp.to_dict()
        for sp in project.sprints.filter_by(status="active").all()
    ]

    epics = [e.to_dict() for e in project.epics.all()]

    data = project.to_dict()
    data["members"]        = members
    data["statuses"]       = statuses
    data["active_sprints"] = active_sprints
    data["epics"]          = epics

    return _ok(data)


# ------------------------------------------------------------------ #
# PATCH /api/v1/projects/<project_id>
# ------------------------------------------------------------------ #

@projects_api_bp.patch("/<int:project_id>")
@login_required
def update_project(project_id):
    project = Project.query.get_or_404(project_id)
    if not _is_member(project_id):
        return _err("Forbidden", 403)

    body = request.get_json(silent=True) or {}
    editable = {
        "name", "description", "status", "priority",
        "start_date", "end_date", "color_hex", "progress_percent",
    }
    for field in editable:
        if field not in body:
            continue
        if field in ("start_date", "end_date"):
            setattr(project, field, _parse_date(body[field]))
        else:
            setattr(project, field, body[field])

    project.updated_at = datetime.utcnow()
    db.session.commit()
    return _ok(_project_summary(project))


# ------------------------------------------------------------------ #
# GET /api/v1/projects/<project_id>/stats
# ------------------------------------------------------------------ #

@projects_api_bp.get("/<int:project_id>/stats")
@login_required
def project_stats(project_id):
    project = Project.query.get_or_404(project_id)
    if not _is_member(project_id):
        return _err("Forbidden", 403)

    from datetime import date
    today = date.today()

    # Tasks by status
    rows = (
        db.session.query(
            TaskStatus.name,
            TaskStatus.color_hex,
            func.count(Task.id).label("count"),
        )
        .join(Task, Task.status_id == TaskStatus.id)
        .filter(Task.project_id == project_id)
        .group_by(TaskStatus.name, TaskStatus.color_hex)
        .all()
    )
    tasks_by_status = [
        {"status_name": r.name, "color": r.color_hex, "count": r.count}
        for r in rows
    ]

    # Tasks by priority
    rows2 = (
        db.session.query(Task.priority, func.count(Task.id).label("count"))
        .filter_by(project_id=project_id)
        .group_by(Task.priority)
        .all()
    )
    tasks_by_priority = [{"priority": r.priority, "count": r.count} for r in rows2]

    # Tasks by assignee
    rows3 = (
        db.session.query(
            User.id,
            User.full_name,
            func.count(Task.id).label("count"),
        )
        .join(Task, Task.assignee_id == User.id)
        .filter(Task.project_id == project_id)
        .group_by(User.id, User.full_name)
        .all()
    )
    tasks_by_assignee = [
        {"user_id": r.id, "full_name": r.full_name, "count": r.count}
        for r in rows3
    ]

    # Overdue
    overdue_count = (
        Task.query
        .join(TaskStatus, Task.status_id == TaskStatus.id)
        .filter(
            Task.project_id == project_id,
            Task.due_date < today,
            TaskStatus.category != "done",
        )
        .count()
    )

    # Hours
    hours = (
        db.session.query(
            func.sum(Task.estimated_hours).label("estimated"),
            func.sum(Task.actual_hours).label("actual"),
        )
        .filter(Task.project_id == project_id)
        .first()
    )

    return _ok({
        "tasks_by_status":    tasks_by_status,
        "tasks_by_priority":  tasks_by_priority,
        "tasks_by_assignee":  tasks_by_assignee,
        "overdue_count":      overdue_count,
        "total_estimated_hours": float(hours.estimated or 0),
        "total_actual_hours":    float(hours.actual or 0),
    })

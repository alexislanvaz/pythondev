"""
Sprints API blueprint.
Prefix: /api/v1/sprints  (registered inside api_bp which has prefix /api)

Full URL examples:
  GET  /api/v1/projects/<id>/sprints
  POST /api/v1/projects/<id>/sprints
  GET  /api/v1/sprints/<id>
  ...
"""

from datetime import date, timedelta

from flask import Blueprint, request, jsonify
from flask_login import current_user, login_required

from app.extensions import db
from app.database.models import (
    ActivityLog,
    Project,
    ProjectMember,
    Sprint,
    Task,
    TaskStatus,
    TimeLog,
)

sprints_api_bp = Blueprint("sprints_api", __name__, url_prefix="/v1")


# ------------------------------------------------------------------ #
# Response helpers
# ------------------------------------------------------------------ #

def _ok(data, meta=None, status=200):
    return jsonify({"data": data, "error": None, "meta": meta or {}}), status


def _err(message, status=400):
    return jsonify({"data": None, "error": message, "meta": {}}), status


# ------------------------------------------------------------------ #
# Access helpers
# ------------------------------------------------------------------ #

def _get_member(project_id):
    """Return the ProjectMember row or None."""
    return ProjectMember.query.filter_by(
        project_id=project_id, user_id=current_user.id
    ).first()


def _member_role(project_id):
    member = _get_member(project_id)
    return member.role.name.lower() if member and member.role else None


def _is_manager_or_admin(project_id):
    role = _member_role(project_id)
    return role in ("project_manager", "admin", "owner")


# ------------------------------------------------------------------ #
# Serialisation helpers
# ------------------------------------------------------------------ #

def _sprint_summary(sprint):
    """Sprint dict with task counts."""
    total = sprint.tasks.count()
    completed = (
        sprint.tasks
        .join(Task.status)
        .filter(TaskStatus.category == "done")
        .count()
    )
    return {
        "id":                    sprint.id,
        "project_id":            sprint.project_id,
        "name":                  sprint.name,
        "goal":                  sprint.goal,
        "status":                sprint.status,
        "start_date":            sprint.start_date.isoformat() if sprint.start_date else None,
        "end_date":              sprint.end_date.isoformat()   if sprint.end_date   else None,
        "created_at":            sprint.created_at.isoformat(),
        "task_count":            total,
        "completed_task_count":  completed,
    }


def _task_for_sprint(task):
    """Compact task representation used inside sprint detail columns."""
    assignee = None
    if task.assignee:
        assignee = {
            "id":         task.assignee.id,
            "full_name":  task.assignee.full_name,
            "avatar_url": task.assignee.avatar_url,
        }
    status = None
    if task.status:
        status = {
            "id":       task.status.id,
            "name":     task.status.name,
            "color":    task.status.color_hex,
            "category": task.status.category,
        }
    return {
        "id":              task.id,
        "title":           task.title,
        "type":            task.type,
        "priority":        task.priority,
        "status":          status,
        "assignee":        assignee,
        "estimated_hours": float(task.estimated_hours) if task.estimated_hours else None,
        "actual_hours":    float(task.actual_hours),
        "due_date":        task.due_date.isoformat() if task.due_date else None,
        "order_index":     task.order_index,
        "labels":          [{"id": l.id, "name": l.name, "color_hex": l.color_hex} for l in task.labels],
    }


def _log(entity_type, entity_id, action, old_value=None, new_value=None):
    entry = ActivityLog(
        entity_type=entity_type,
        entity_id=entity_id,
        user_id=current_user.id,
        action=action,
        old_value=str(old_value) if old_value is not None else None,
        new_value=str(new_value) if new_value is not None else None,
    )
    db.session.add(entry)


def _parse_date(value):
    if not value:
        return None
    try:
        return date.fromisoformat(value)
    except (ValueError, TypeError):
        return None


# ------------------------------------------------------------------ #
# GET /api/v1/projects/<project_id>/sprints
# ------------------------------------------------------------------ #

@sprints_api_bp.get("/projects/<int:project_id>/sprints")
@login_required
def list_sprints(project_id):
    project = db.session.get(Project, project_id)
    if not project:
        return _err("Project not found", 404)
    if not _get_member(project_id):
        return _err("Forbidden", 403)

    # Order: nulls last for start_date
    sprints = (
        Sprint.query
        .filter_by(project_id=project_id)
        .order_by(
            db.case(
                (Sprint.start_date.is_(None), 1),
                else_=0
            ),
            Sprint.start_date.asc(),
            Sprint.created_at.asc(),
        )
        .all()
    )
    return _ok([_sprint_summary(s) for s in sprints])


# ------------------------------------------------------------------ #
# POST /api/v1/projects/<project_id>/sprints
# ------------------------------------------------------------------ #

@sprints_api_bp.post("/projects/<int:project_id>/sprints")
@login_required
def create_sprint(project_id):
    project = db.session.get(Project, project_id)
    if not project:
        return _err("Project not found", 404)
    if not _get_member(project_id):
        return _err("Forbidden", 403)

    body = request.get_json(silent=True) or {}
    name = (body.get("name") or "").strip()
    if not name:
        return _err("name is required")

    # Validate: do not allow creating a sprint directly as active if one already exists
    requested_status = body.get("status", "planned")
    if requested_status == "active":
        existing_active = Sprint.query.filter_by(
            project_id=project_id, status="active"
        ).first()
        if existing_active:
            return _err("Another sprint is already active in this project")

    sprint = Sprint(
        project_id=project_id,
        name=name,
        goal=body.get("goal"),
        status="planned",
        start_date=_parse_date(body.get("start_date")),
        end_date=_parse_date(body.get("end_date")),
    )
    db.session.add(sprint)
    db.session.flush()
    _log("sprint", sprint.id, "sprint_created", new_value=name)
    db.session.commit()
    return _ok(_sprint_summary(sprint)), 201


# ------------------------------------------------------------------ #
# GET /api/v1/sprints/<sprint_id>
# ------------------------------------------------------------------ #

@sprints_api_bp.get("/sprints/<int:sprint_id>")
@login_required
def get_sprint(sprint_id):
    sprint = db.session.get(Sprint, sprint_id)
    if not sprint:
        return _err("Sprint not found", 404)
    if not _get_member(sprint.project_id):
        return _err("Forbidden", 403)

    # Load all statuses for the project, ordered
    statuses = (
        TaskStatus.query
        .filter_by(project_id=sprint.project_id)
        .order_by(TaskStatus.order_index.asc())
        .all()
    )

    # Load tasks of the sprint
    tasks = (
        sprint.tasks
        .order_by(Task.order_index.asc())
        .all()
    )

    # Build columns grouped by category
    category_order = ["todo", "in_progress", "done"]
    columns_map = {cat: {"category": cat, "statuses": [], "tasks": []} for cat in category_order}

    for st in statuses:
        cat = st.category if st.category in columns_map else "todo"
        columns_map[cat]["statuses"].append(st.to_dict())

    for t in tasks:
        cat = t.status.category if t.status and t.status.category in columns_map else "todo"
        columns_map[cat]["tasks"].append(_task_for_sprint(t))

    columns = [columns_map[c] for c in category_order]

    return _ok({
        "sprint":  _sprint_summary(sprint),
        "columns": columns,
    })


# ------------------------------------------------------------------ #
# PATCH /api/v1/sprints/<sprint_id>
# ------------------------------------------------------------------ #

@sprints_api_bp.patch("/sprints/<int:sprint_id>")
@login_required
def update_sprint(sprint_id):
    sprint = db.session.get(Sprint, sprint_id)
    if not sprint:
        return _err("Sprint not found", 404)
    if not _is_manager_or_admin(sprint.project_id):
        return _err("Only project managers or admins can edit sprints", 403)
    if sprint.status not in ("planned", "active"):
        return _err("Cannot edit a completed sprint")

    body = request.get_json(silent=True) or {}
    editable = ("name", "goal", "start_date", "end_date")

    for field in editable:
        if field not in body:
            continue
        if field in ("start_date", "end_date"):
            setattr(sprint, field, _parse_date(body[field]))
        else:
            setattr(sprint, field, body[field])

    db.session.commit()
    return _ok(_sprint_summary(sprint))


# ------------------------------------------------------------------ #
# DELETE /api/v1/sprints/<sprint_id>
# ------------------------------------------------------------------ #

@sprints_api_bp.delete("/sprints/<int:sprint_id>")
@login_required
def delete_sprint(sprint_id):
    sprint = db.session.get(Sprint, sprint_id)
    if not sprint:
        return _err("Sprint not found", 404)
    if not _is_manager_or_admin(sprint.project_id):
        return _err("Only project managers or admins can delete sprints", 403)
    if sprint.status != "planned":
        return _err("Only planned sprints can be deleted")

    # Detach tasks from the sprint
    Task.query.filter_by(sprint_id=sprint_id).update({"sprint_id": None})
    db.session.delete(sprint)
    db.session.commit()
    return _ok("deleted")


# ------------------------------------------------------------------ #
# POST /api/v1/sprints/<sprint_id>/start
# ------------------------------------------------------------------ #

@sprints_api_bp.post("/sprints/<int:sprint_id>/start")
@login_required
def start_sprint(sprint_id):
    sprint = db.session.get(Sprint, sprint_id)
    if not sprint:
        return _err("Sprint not found", 404)
    if not _get_member(sprint.project_id):
        return _err("Forbidden", 403)
    if sprint.status != "planned":
        return _err("Only planned sprints can be started")

    # Validate no other active sprint in the same project
    existing_active = Sprint.query.filter(
        Sprint.project_id == sprint.project_id,
        Sprint.status == "active",
        Sprint.id != sprint_id,
    ).first()
    if existing_active:
        return _err(f"Sprint '{existing_active.name}' is already active in this project")

    sprint.status = "active"
    if not sprint.start_date:
        sprint.start_date = date.today()

    _log("sprint", sprint.id, "sprint_started", old_value="planned", new_value="active")
    db.session.commit()
    return _ok(_sprint_summary(sprint))


# ------------------------------------------------------------------ #
# POST /api/v1/sprints/<sprint_id>/complete
# ------------------------------------------------------------------ #

@sprints_api_bp.post("/sprints/<int:sprint_id>/complete")
@login_required
def complete_sprint(sprint_id):
    sprint = db.session.get(Sprint, sprint_id)
    if not sprint:
        return _err("Sprint not found", 404)
    if not _get_member(sprint.project_id):
        return _err("Forbidden", 403)
    if sprint.status != "active":
        return _err("Only active sprints can be completed")

    sprint.status = "completed"
    if not sprint.end_date:
        sprint.end_date = date.today()

    # Compute closure stats
    all_tasks = sprint.tasks.all()
    total     = len(all_tasks)
    completed = sum(
        1 for t in all_tasks
        if t.status and t.status.category == "done"
    )
    incomplete = total - completed
    rate       = round((completed / total * 100), 1) if total else 0.0

    _log(
        "sprint", sprint.id, "sprint_completed",
        old_value="active",
        new_value=f"completed; rate={rate}%",
    )
    db.session.commit()

    return _ok({
        "sprint": _sprint_summary(sprint),
        "stats": {
            "total":            total,
            "completed":        completed,
            "incomplete":       incomplete,
            "completion_rate":  rate,
        },
    })


# ------------------------------------------------------------------ #
# POST /api/v1/sprints/<sprint_id>/tasks
# ------------------------------------------------------------------ #

@sprints_api_bp.post("/sprints/<int:sprint_id>/tasks")
@login_required
def add_task_to_sprint(sprint_id):
    sprint = db.session.get(Sprint, sprint_id)
    if not sprint:
        return _err("Sprint not found", 404)
    if not _get_member(sprint.project_id):
        return _err("Forbidden", 403)

    body    = request.get_json(silent=True) or {}
    task_id = body.get("task_id")
    if not task_id:
        return _err("task_id is required")

    task = db.session.get(Task, task_id)
    if not task:
        return _err("Task not found", 404)
    if task.project_id != sprint.project_id:
        return _err("Task does not belong to this project")

    task.sprint_id = sprint_id
    db.session.commit()
    return _ok(_task_for_sprint(task))


# ------------------------------------------------------------------ #
# DELETE /api/v1/sprints/<sprint_id>/tasks/<task_id>
# ------------------------------------------------------------------ #

@sprints_api_bp.delete("/sprints/<int:sprint_id>/tasks/<int:task_id>")
@login_required
def remove_task_from_sprint(sprint_id, task_id):
    sprint = db.session.get(Sprint, sprint_id)
    if not sprint:
        return _err("Sprint not found", 404)
    if not _get_member(sprint.project_id):
        return _err("Forbidden", 403)

    task = db.session.get(Task, task_id)
    if not task or task.sprint_id != sprint_id:
        return _err("Task not found in this sprint", 404)

    task.sprint_id = None
    db.session.commit()
    return _ok("ok")


# ------------------------------------------------------------------ #
# GET /api/v1/sprints/<sprint_id>/burndown
# ------------------------------------------------------------------ #

@sprints_api_bp.get("/sprints/<int:sprint_id>/burndown")
@login_required
def sprint_burndown(sprint_id):
    sprint = db.session.get(Sprint, sprint_id)
    if not sprint:
        return _err("Sprint not found", 404)
    if not _get_member(sprint.project_id):
        return _err("Forbidden", 403)

    if not sprint.start_date or not sprint.end_date:
        return _ok(None)

    sprint_start = sprint.start_date
    sprint_end   = sprint.end_date
    today        = date.today()
    total_days   = max((sprint_end - sprint_start).days, 1)

    tasks = sprint.tasks.all()

    # Determine if we have estimated hours to use as the metric
    total_hours = sum(float(t.estimated_hours) for t in tasks if t.estimated_hours)
    use_hours   = total_hours > 0

    # Build ideal burndown line
    ideal = []
    current = sprint_start
    while current <= sprint_end:
        day_index = (current - sprint_start).days
        if use_hours:
            remaining = total_hours * (1 - day_index / total_days)
        else:
            remaining = len(tasks) * (1 - day_index / total_days)
        ideal.append([current.isoformat(), round(max(remaining, 0), 2)])
        current += timedelta(days=1)

    # Build actual burndown from sprint_start to today
    actual      = []
    end_actual  = min(today, sprint_end)
    current     = sprint_start

    if use_hours:
        while current <= end_actual:
            logged = (
                db.session.query(db.func.sum(TimeLog.hours))
                .join(Task, TimeLog.task_id == Task.id)
                .filter(
                    Task.sprint_id == sprint_id,
                    TimeLog.logged_date <= current,
                )
                .scalar()
            ) or 0
            remaining = max(total_hours - float(logged), 0)
            actual.append([current.isoformat(), round(remaining, 2)])
            current += timedelta(days=1)
    else:
        # Proxy: count tasks whose status is "done"
        # We do not have daily snapshots, so we use a simple heuristic:
        # tasks completed = tasks whose updated_at <= current and status.category == "done"
        total_count = len(tasks)
        while current <= end_actual:
            done_count = sum(
                1 for t in tasks
                if t.status
                and t.status.category == "done"
                and t.updated_at.date() <= current
            )
            remaining = max(total_count - done_count, 0)
            actual.append([current.isoformat(), remaining])
            current += timedelta(days=1)

    return _ok({
        "sprint_name": sprint.name,
        "start":       sprint_start.isoformat(),
        "end":         sprint_end.isoformat(),
        "ideal":       ideal,
        "actual":      actual,
    })

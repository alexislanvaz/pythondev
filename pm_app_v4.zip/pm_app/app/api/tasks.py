"""
Tasks API blueprint.
Prefix: /api/v1/tasks  (registered via api_bp)
All responses use the envelope: {"data": ..., "error": null, "meta": {}}
"""

from datetime import date, datetime
from flask import Blueprint, request, jsonify
from flask_login import current_user, login_required
from sqlalchemy import func

from app.extensions import db
from app.database.models import (
    Task,
    TaskStatus,
    TaskLabel,
    ProjectMember,
    ActivityLog,
    Comment,
    TimeLog,
    User,
)

tasks_bp = Blueprint("tasks", __name__, url_prefix="/v1/tasks")


# ------------------------------------------------------------------ #
# Helpers
# ------------------------------------------------------------------ #

def _ok(data, meta=None):
    return jsonify({"data": data, "error": None, "meta": meta or {}})


def _err(message, status=400):
    return jsonify({"data": None, "error": message, "meta": {}}), status


def _is_member(project_id, user_id=None):
    uid = user_id or current_user.id
    return ProjectMember.query.filter_by(
        project_id=project_id, user_id=uid
    ).first() is not None


def _member_role(project_id, user_id=None):
    uid = user_id or current_user.id
    pm = ProjectMember.query.filter_by(project_id=project_id, user_id=uid).first()
    return pm.role.name.lower() if pm and pm.role else None


def _task_summary(task):
    """Compact representation used in list and kanban responses."""
    assignee = None
    if task.assignee:
        assignee = {
            "id": task.assignee.id,
            "full_name": task.assignee.full_name,
            "avatar_url": task.assignee.avatar_url,
        }
    status = None
    if task.status:
        status = {
            "id": task.status.id,
            "name": task.status.name,
            "color": task.status.color_hex,
            "category": task.status.category,
        }
    return {
        "id": task.id,
        "title": task.title,
        "type": task.type,
        "priority": task.priority,
        "status": status,
        "assignee": assignee,
        "estimated_hours": float(task.estimated_hours) if task.estimated_hours else None,
        "actual_hours": float(task.actual_hours),
        "due_date": task.due_date.isoformat() if task.due_date else None,
        "order_index": task.order_index,
        "labels": [{"id": l.id, "name": l.name, "color_hex": l.color_hex} for l in task.labels],
        "comment_count": task.comments.filter_by(is_deleted=False).count(),
    }


def _task_detail(task):
    """Full representation for the task detail endpoint."""
    base = _task_summary(task)
    base.update({
        "project_id": task.project_id,
        "epic_id": task.epic_id,
        "sprint_id": task.sprint_id,
        "parent_task_id": task.parent_task_id,
        "description": task.description,
        "reporter_id": task.reporter_id,
        "start_date": task.start_date.isoformat() if task.start_date else None,
        "created_at": task.created_at.isoformat(),
        "updated_at": task.updated_at.isoformat(),
        "comments": _build_comments(task),
        "time_logs": [_tl_dict(tl) for tl in task.time_logs.all()],
        "watchers": [
            {"id": w.id, "full_name": w.full_name, "avatar_url": w.avatar_url}
            for w in task.watchers.all()
        ],
        "dependencies": [d.to_dict() for d in task.dependencies.all()],
    })
    return base


def _build_comments(task):
    top_level = (
        Comment.query
        .filter_by(task_id=task.id, parent_comment_id=None, is_deleted=False)
        .order_by(Comment.created_at.asc())
        .all()
    )
    result = []
    for c in top_level:
        cd = _comment_dict(c)
        cd["replies"] = [
            _comment_dict(r)
            for r in c.replies.filter_by(is_deleted=False)
            .order_by(Comment.created_at.asc())
            .all()
        ]
        result.append(cd)
    return result


def _comment_dict(c):
    return {
        "id": c.id,
        "task_id": c.task_id,
        "parent_comment_id": c.parent_comment_id,
        "content": c.content,
        "created_at": c.created_at.isoformat(),
        "updated_at": c.updated_at.isoformat(),
        "user": {
            "id": c.user.id,
            "full_name": c.user.full_name,
            "avatar_url": c.user.avatar_url,
        } if c.user else None,
    }


def _tl_dict(tl):
    return {
        "id": tl.id,
        "hours": float(tl.hours),
        "description": tl.description,
        "logged_date": tl.logged_date.isoformat(),
        "user": {
            "id": tl.user.id,
            "full_name": tl.user.full_name,
        } if tl.user else None,
    }


def _log_activity(entity_type, entity_id, action, old_value=None, new_value=None):
    entry = ActivityLog(
        entity_type=entity_type,
        entity_id=entity_id,
        user_id=current_user.id,
        action=action,
        old_value=str(old_value) if old_value is not None else None,
        new_value=str(new_value) if new_value is not None else None,
    )
    db.session.add(entry)


# ------------------------------------------------------------------ #
# GET /api/v1/tasks
# ------------------------------------------------------------------ #

@tasks_bp.get("")
@login_required
def list_tasks():
    project_id = request.args.get("project_id", type=int)
    if not project_id:
        return _err("project_id is required")

    if not _is_member(project_id):
        return _err("Forbidden", 403)

    q = Task.query.filter_by(project_id=project_id)

    sprint_id   = request.args.get("sprint_id",   type=int)
    epic_id     = request.args.get("epic_id",     type=int)
    assignee_id = request.args.get("assignee_id", type=int)
    status_id   = request.args.get("status_id",   type=int)
    priority    = request.args.get("priority")
    task_type   = request.args.get("type")

    if sprint_id:
        q = q.filter_by(sprint_id=sprint_id)
    if epic_id:
        q = q.filter_by(epic_id=epic_id)
    if assignee_id:
        q = q.filter_by(assignee_id=assignee_id)
    if status_id:
        q = q.filter_by(status_id=status_id)
    if priority:
        q = q.filter_by(priority=priority)
    if task_type:
        q = q.filter_by(type=task_type)

    tasks = q.order_by(Task.order_index.asc()).all()
    return _ok([_task_summary(t) for t in tasks])


# ------------------------------------------------------------------ #
# POST /api/v1/tasks
# ------------------------------------------------------------------ #

@tasks_bp.post("")
@login_required
def create_task():
    body = request.get_json(silent=True) or {}

    project_id = body.get("project_id")
    title      = body.get("title", "").strip()
    if not project_id or not title:
        return _err("project_id and title are required")

    if not _is_member(project_id):
        return _err("Forbidden", 403)

    status_id = body.get("status_id")
    if not status_id:
        default_status = TaskStatus.query.filter_by(
            project_id=project_id, is_default=True
        ).first()
        if not default_status:
            default_status = TaskStatus.query.filter_by(project_id=project_id).first()
        if not default_status:
            return _err("No task status found for this project")
        status_id = default_status.id

    # Determine next order_index for the target status
    max_idx = db.session.query(func.max(Task.order_index)).filter_by(
        project_id=project_id, status_id=status_id
    ).scalar() or 0

    task = Task(
        project_id=project_id,
        title=title,
        type=body.get("type", "task"),
        priority=body.get("priority", "medium"),
        status_id=status_id,
        assignee_id=body.get("assignee_id"),
        reporter_id=current_user.id,
        epic_id=body.get("epic_id"),
        sprint_id=body.get("sprint_id"),
        estimated_hours=body.get("estimated_hours"),
        due_date=_parse_date(body.get("due_date")),
        start_date=_parse_date(body.get("start_date")),
        description=body.get("description"),
        order_index=max_idx + 1,
    )
    db.session.add(task)
    db.session.flush()

    _log_activity("task", task.id, "task_created", new_value=title)
    db.session.commit()

    return _ok(_task_summary(task)), 201


def _parse_date(value):
    if not value:
        return None
    try:
        return date.fromisoformat(value)
    except (ValueError, TypeError):
        return None


# ------------------------------------------------------------------ #
# GET /api/v1/tasks/<task_id>
# ------------------------------------------------------------------ #

@tasks_bp.get("/<int:task_id>")
@login_required
def get_task(task_id):
    task = Task.query.get_or_404(task_id)
    if not _is_member(task.project_id):
        return _err("Forbidden", 403)
    return _ok(_task_detail(task))


# ------------------------------------------------------------------ #
# PATCH /api/v1/tasks/<task_id>
# ------------------------------------------------------------------ #

@tasks_bp.patch("/<int:task_id>")
@login_required
def update_task(task_id):
    task = Task.query.get_or_404(task_id)
    if not _is_member(task.project_id):
        return _err("Forbidden", 403)

    body = request.get_json(silent=True) or {}

    editable = {
        "title", "description", "priority", "assignee_id",
        "epic_id", "sprint_id", "estimated_hours", "due_date", "start_date",
    }

    for field in editable:
        if field not in body:
            continue
        old_val = getattr(task, field)
        if field in ("due_date", "start_date"):
            new_val = _parse_date(body[field])
        else:
            new_val = body[field]
        setattr(task, field, new_val)
        if old_val != new_val:
            _log_activity("task", task.id, f"field_updated:{field}",
                          old_value=old_val, new_value=new_val)

    task.updated_at = datetime.utcnow()
    db.session.commit()
    return _ok(_task_summary(task))


# ------------------------------------------------------------------ #
# DELETE /api/v1/tasks/<task_id>
# ------------------------------------------------------------------ #

@tasks_bp.delete("/<int:task_id>")
@login_required
def delete_task(task_id):
    task = Task.query.get_or_404(task_id)
    role = _member_role(task.project_id)
    if role not in ("project_manager", "admin", "owner"):
        return _err("Only project managers or admins can delete tasks", 403)
    db.session.delete(task)
    db.session.commit()
    return _ok("deleted")


# ------------------------------------------------------------------ #
# PATCH /api/v1/tasks/<task_id>/status
# ------------------------------------------------------------------ #

@tasks_bp.patch("/<int:task_id>/status")
@login_required
def change_status(task_id):
    task = Task.query.get_or_404(task_id)
    if not _is_member(task.project_id):
        return _err("Forbidden", 403)

    body = request.get_json(silent=True) or {}
    new_status_id = body.get("status_id")
    if not new_status_id:
        return _err("status_id is required")

    new_status = TaskStatus.query.filter_by(
        id=new_status_id, project_id=task.project_id
    ).first()
    if not new_status:
        return _err("Invalid status for this project", 400)

    old_status = task.status.name if task.status else None
    old_status_id = task.status_id

    task.status_id = new_status_id
    task.updated_at = datetime.utcnow()

    _log_activity(
        "task", task.id, "status_changed",
        old_value=old_status_id,
        new_value=new_status_id,
    )
    db.session.commit()
    return _ok(_task_summary(task))


# ------------------------------------------------------------------ #
# PATCH /api/v1/tasks/reorder
# ------------------------------------------------------------------ #

@tasks_bp.patch("/reorder")
@login_required
def reorder_tasks():
    body = request.get_json(silent=True) or {}
    updates = body.get("updates", [])

    for item in updates:
        task_id     = item.get("id")
        order_index = item.get("order_index")
        status_id   = item.get("status_id")
        if not task_id:
            continue
        task = Task.query.get(task_id)
        if not task:
            continue
        if not _is_member(task.project_id):
            continue
        if order_index is not None:
            task.order_index = order_index
        if status_id is not None:
            task.status_id = status_id
        task.updated_at = datetime.utcnow()

    db.session.commit()
    return _ok("ok")


# ------------------------------------------------------------------ #
# POST /api/v1/tasks/<task_id>/comments
# ------------------------------------------------------------------ #

@tasks_bp.post("/<int:task_id>/comments")
@login_required
def add_comment(task_id):
    task = Task.query.get_or_404(task_id)
    if not _is_member(task.project_id):
        return _err("Forbidden", 403)

    body = request.get_json(silent=True) or {}
    content = (body.get("content") or "").strip()
    if not content:
        return _err("content is required")

    parent_id = body.get("parent_comment_id")
    comment = Comment(
        task_id=task_id,
        user_id=current_user.id,
        content=content,
        parent_comment_id=parent_id,
    )
    db.session.add(comment)
    db.session.commit()
    return _ok(_comment_dict(comment)), 201


# ------------------------------------------------------------------ #
# GET /api/v1/tasks/<task_id>/comments
# ------------------------------------------------------------------ #

@tasks_bp.get("/<int:task_id>/comments")
@login_required
def list_comments(task_id):
    task = Task.query.get_or_404(task_id)
    if not _is_member(task.project_id):
        return _err("Forbidden", 403)
    return _ok(_build_comments(task))


# ------------------------------------------------------------------ #
# POST /api/v1/tasks/<task_id>/time
# ------------------------------------------------------------------ #

@tasks_bp.post("/<int:task_id>/time")
@login_required
def log_time(task_id):
    task = Task.query.get_or_404(task_id)
    if not _is_member(task.project_id):
        return _err("Forbidden", 403)

    body = request.get_json(silent=True) or {}
    hours       = body.get("hours")
    description = body.get("description", "")
    logged_date = _parse_date(body.get("logged_date"))

    if hours is None:
        return _err("hours is required")
    if not logged_date:
        logged_date = date.today()

    tl = TimeLog(
        task_id=task_id,
        user_id=current_user.id,
        hours=hours,
        description=description,
        logged_date=logged_date,
    )
    db.session.add(tl)

    # Update actual_hours on the task
    task.actual_hours = float(task.actual_hours) + float(hours)
    task.updated_at = datetime.utcnow()

    db.session.commit()
    return _ok(_tl_dict(tl)), 201


# ------------------------------------------------------------------ #
# GET /api/v1/tasks/<task_id>/subtasks
# ------------------------------------------------------------------ #

@tasks_bp.get("/<int:task_id>/subtasks")
@login_required
def list_subtasks(task_id):
    task = Task.query.get_or_404(task_id)
    if not _is_member(task.project_id):
        return _err("Forbidden", 403)

    subtasks = (
        Task.query
        .filter_by(parent_task_id=task_id)
        .order_by(Task.order_index.asc(), Task.id.asc())
        .all()
    )
    return _ok([_task_summary(s) for s in subtasks])


# ------------------------------------------------------------------ #
# POST /api/v1/tasks/<task_id>/subtasks
# ------------------------------------------------------------------ #

@tasks_bp.post("/<int:task_id>/subtasks")
@login_required
def create_subtask(task_id):
    parent = Task.query.get_or_404(task_id)
    if not _is_member(parent.project_id):
        return _err("Forbidden", 403)

    body = request.get_json(silent=True) or {}
    title = (body.get("title") or "").strip()
    if not title:
        return _err("title is required")

    # Resolve default status for the project
    status_id = body.get("status_id")
    if not status_id:
        default_status = (
            TaskStatus.query
            .filter_by(project_id=parent.project_id, is_default=True)
            .first()
        )
        if not default_status:
            default_status = (
                TaskStatus.query
                .filter_by(project_id=parent.project_id)
                .order_by(TaskStatus.order_index.asc())
                .first()
            )
        if not default_status:
            return _err("No task status found for this project")
        status_id = default_status.id

    # order_index = max existing subtask order_index + 1
    max_idx = (
        db.session.query(func.max(Task.order_index))
        .filter_by(parent_task_id=task_id)
        .scalar()
    ) or 0

    subtask = Task(
        project_id=parent.project_id,
        epic_id=parent.epic_id,
        sprint_id=parent.sprint_id,
        parent_task_id=task_id,
        title=title,
        type=body.get("type", "task"),
        priority=body.get("priority", "medium"),
        status_id=status_id,
        assignee_id=body.get("assignee_id"),
        reporter_id=current_user.id,
        estimated_hours=body.get("estimated_hours"),
        due_date=_parse_date(body.get("due_date")),
        order_index=max_idx + 1,
    )
    db.session.add(subtask)
    db.session.flush()

    _log_activity("task", task_id, "subtask_added", new_value=title)
    db.session.commit()

    return _ok(_task_summary(subtask)), 201


# ------------------------------------------------------------------ #
# PATCH /api/v1/tasks/<task_id>/subtasks/<subtask_id>
# ------------------------------------------------------------------ #

@tasks_bp.patch("/<int:task_id>/subtasks/<int:subtask_id>")
@login_required
def update_subtask(task_id, subtask_id):
    parent = Task.query.get_or_404(task_id)
    if not _is_member(parent.project_id):
        return _err("Forbidden", 403)

    subtask = Task.query.get_or_404(subtask_id)
    if subtask.parent_task_id != task_id:
        return _err("Subtask does not belong to the specified parent task", 400)

    body = request.get_json(silent=True) or {}

    editable = {
        "title", "priority", "assignee_id",
        "estimated_hours", "due_date", "status_id",
    }
    for field in editable:
        if field not in body:
            continue
        if field == "due_date":
            setattr(subtask, field, _parse_date(body[field]))
        elif field == "status_id":
            # Verify the status belongs to the project
            st = TaskStatus.query.filter_by(
                id=body[field], project_id=parent.project_id
            ).first()
            if not st:
                return _err("Invalid status for this project", 400)
            subtask.status_id = st.id
        else:
            setattr(subtask, field, body[field])

    subtask.updated_at = datetime.utcnow()
    db.session.commit()
    return _ok(_task_summary(subtask))


# ------------------------------------------------------------------ #
# DELETE /api/v1/tasks/<task_id>/subtasks/<subtask_id>
# ------------------------------------------------------------------ #

@tasks_bp.delete("/<int:task_id>/subtasks/<int:subtask_id>")
@login_required
def delete_subtask(task_id, subtask_id):
    parent = Task.query.get_or_404(task_id)

    subtask = Task.query.get_or_404(subtask_id)
    if subtask.parent_task_id != task_id:
        return _err("Subtask does not belong to the specified parent task", 400)

    role = _member_role(parent.project_id)
    is_reporter = subtask.reporter_id == current_user.id
    if role not in ("project_manager", "admin", "owner") and not is_reporter:
        return _err("Not authorized to delete this subtask", 403)

    db.session.delete(subtask)
    db.session.commit()
    return _ok("ok")


# ------------------------------------------------------------------ #
# GET /api/v1/tasks/mine
# GET /api/v1/tasks/mine/stats
# IMPORTANT: these routes are defined BEFORE /<int:task_id> so Flask
# does not try to cast 'mine' as an integer.
# ------------------------------------------------------------------ #

from datetime import timedelta
from app.database.models import Project


PRIORITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}
PRIORITY_COLOR = {
    "critical": "#e05454",
    "high":     "#f0a429",
    "medium":   "#4f6ef7",
    "low":      "#3ecf8e",
}


def _task_summary_mine(task):
    """Extended _task_summary that includes project info for /mine."""
    base = _task_summary(task)
    project = task.project
    base["project_id"]    = task.project_id
    base["project_name"]  = project.name  if project else None
    base["project_color"] = project.color_hex if project else None
    return base


def _build_mine_summary(tasks_list):
    today    = date.today()
    week_end = today + timedelta(days=7)
    month_start = today.replace(day=1)

    total       = len(tasks_list)
    overdue     = 0
    due_today   = 0
    due_week    = 0
    completed_month = 0

    for t in tasks_list:
        cat = t.status.category if t.status else "todo"
        if cat == "done":
            if t.updated_at and t.updated_at.date() >= month_start:
                completed_month += 1
            continue
        if t.due_date:
            if t.due_date < today:
                overdue += 1
            elif t.due_date == today:
                due_today += 1
            elif today < t.due_date <= week_end:
                due_week += 1

    return {
        "total":               total,
        "overdue":             overdue,
        "due_today":           due_today,
        "due_this_week":       due_week,
        "completed_this_month": completed_month,
    }


@tasks_bp.get("/mine")
@login_required
def my_tasks():
    today    = date.today()
    week_end = today + timedelta(days=7)

    # Base query: tasks assigned to current user
    q = Task.query.filter_by(assignee_id=current_user.id)

    # Optional filters
    status_category = request.args.get("status_category")
    priority_param  = request.args.get("priority")
    project_id_param = request.args.get("project_id", type=int)
    search_param    = request.args.get("search", "").strip()
    group_by        = request.args.get("group_by", "project")
    sort_param      = request.args.get("sort", "due_date_asc")

    if project_id_param:
        q = q.filter(Task.project_id == project_id_param)

    if priority_param:
        q = q.filter(Task.priority == priority_param)

    if status_category == "overdue":
        from sqlalchemy import and_
        q = q.join(TaskStatus, Task.status_id == TaskStatus.id).filter(
            and_(Task.due_date < today, TaskStatus.category != "done")
        )
    elif status_category:
        q = q.join(TaskStatus, Task.status_id == TaskStatus.id).filter(
            TaskStatus.category == status_category
        )

    if search_param:
        q = q.filter(Task.title.ilike(f"%{search_param}%"))

    # Sorting
    if sort_param == "due_date_desc":
        q = q.order_by(Task.due_date.desc().nullslast(), Task.id.desc())
    elif sort_param == "priority_desc":
        from sqlalchemy import case
        priority_case = case(
            {"critical": 0, "high": 1, "medium": 2, "low": 3},
            value=Task.priority,
            else_=4,
        )
        q = q.order_by(priority_case, Task.id.asc())
    elif sort_param == "created_desc":
        q = q.order_by(Task.created_at.desc())
    else:  # due_date_asc default
        q = q.order_by(Task.due_date.asc().nullslast(), Task.id.asc())

    all_tasks = q.all()

    # Build summary from the full set (before grouping)
    summary = _build_mine_summary(all_tasks)

    # Group tasks
    groups_dict = {}
    groups_order = []

    if group_by == "project":
        for t in all_tasks:
            key = str(t.project_id)
            if key not in groups_dict:
                proj = t.project
                label = proj.name if proj else "Unknown Project"
                color = proj.color_hex if proj else "#7b80a0"
                groups_dict[key] = {"key": key, "label": label, "color": color, "tasks": []}
                groups_order.append(key)
            groups_dict[key]["tasks"].append(_task_summary_mine(t))

    elif group_by == "priority":
        for priority in ("critical", "high", "medium", "low"):
            key = priority
            groups_dict[key] = {
                "key":   key,
                "label": priority.capitalize(),
                "color": PRIORITY_COLOR[priority],
                "tasks": [],
            }
            groups_order.append(key)
        for t in all_tasks:
            p = t.priority if t.priority in groups_dict else "low"
            groups_dict[p]["tasks"].append(_task_summary_mine(t))

    elif group_by == "due_date":
        bucket_order = ["overdue", "today", "tomorrow", "this_week", "later", "no_due_date"]
        bucket_labels = {
            "overdue":     "Overdue",
            "today":       "Today",
            "tomorrow":    "Tomorrow",
            "this_week":   "This Week",
            "later":       "Later",
            "no_due_date": "No Due Date",
        }
        bucket_colors = {
            "overdue":     "#e05454",
            "today":       "#f0a429",
            "tomorrow":    "#4f6ef7",
            "this_week":   "#3ecf8e",
            "later":       "#7b80a0",
            "no_due_date": "#2e3248",
        }
        for bk in bucket_order:
            groups_dict[bk] = {
                "key":   bk,
                "label": bucket_labels[bk],
                "color": bucket_colors[bk],
                "tasks": [],
            }
            groups_order.append(bk)
        tomorrow = today + timedelta(days=1)
        for t in all_tasks:
            if t.due_date is None:
                bk = "no_due_date"
            elif t.due_date < today:
                bk = "overdue"
            elif t.due_date == today:
                bk = "today"
            elif t.due_date == tomorrow:
                bk = "tomorrow"
            elif t.due_date <= week_end:
                bk = "this_week"
            else:
                bk = "later"
            groups_dict[bk]["tasks"].append(_task_summary_mine(t))

    elif group_by == "status":
        for t in all_tasks:
            st = t.status
            key   = str(st.id)   if st else "none"
            label = st.name      if st else "No Status"
            color = st.color_hex if st else "#7b80a0"
            if key not in groups_dict:
                groups_dict[key] = {"key": key, "label": label, "color": color, "tasks": []}
                groups_order.append(key)
            groups_dict[key]["tasks"].append(_task_summary_mine(t))
    else:
        # Fallback: group by project
        for t in all_tasks:
            key = str(t.project_id)
            if key not in groups_dict:
                proj = t.project
                label = proj.name if proj else "Unknown Project"
                color = proj.color_hex if proj else "#7b80a0"
                groups_dict[key] = {"key": key, "label": label, "color": color, "tasks": []}
                groups_order.append(key)
            groups_dict[key]["tasks"].append(_task_summary_mine(t))

    groups = [groups_dict[k] for k in groups_order if groups_dict[k]["tasks"]]

    return _ok({"groups": groups, "summary": summary})


@tasks_bp.get("/mine/stats")
@login_required
def my_tasks_stats():
    today    = date.today()
    week_end = today + timedelta(days=7)
    month_start = today.replace(day=1)

    all_tasks = Task.query.filter_by(assignee_id=current_user.id).all()

    total            = len(all_tasks)
    overdue          = 0
    due_today        = 0
    due_week         = 0
    completed_month  = 0
    by_priority      = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    by_project_map   = {}

    for t in all_tasks:
        cat = t.status.category if t.status else "todo"

        # Priority counts (all tasks regardless of status)
        p = t.priority if t.priority in by_priority else "low"
        by_priority[p] += 1

        # Project counts (all tasks)
        pid = t.project_id
        if pid not in by_project_map:
            proj = t.project
            by_project_map[pid] = {
                "project_id":    pid,
                "project_name":  proj.name      if proj else None,
                "project_color": proj.color_hex if proj else None,
                "count":         0,
            }
        by_project_map[pid]["count"] += 1

        if cat == "done":
            if t.updated_at and t.updated_at.date() >= month_start:
                completed_month += 1
            continue

        if t.due_date:
            if t.due_date < today:
                overdue += 1
            elif t.due_date == today:
                due_today += 1
            elif today < t.due_date <= week_end:
                due_week += 1

    return _ok({
        "total":               total,
        "overdue":             overdue,
        "due_today":           due_today,
        "due_this_week":       due_week,
        "completed_this_month": completed_month,
        "by_priority":         by_priority,
        "by_project":          list(by_project_map.values()),
    })


# ------------------------------------------------------------------ #
# GET /api/v1/tasks/<task_id>/subtasks/summary
# ------------------------------------------------------------------ #

@tasks_bp.get("/<int:task_id>/subtasks/summary")
@login_required
def subtasks_summary(task_id):
    task = Task.query.get_or_404(task_id)
    if not _is_member(task.project_id):
        return _err("Forbidden", 403)

    subtasks = Task.query.filter_by(parent_task_id=task_id).all()
    total = len(subtasks)
    completed = sum(
        1 for s in subtasks
        if s.status and s.status.category == "done"
    )
    percent = round((completed / total * 100.0), 2) if total > 0 else 0.0
    return _ok({"total": total, "completed": completed, "percent": percent})

"""
Notifications API blueprint.
Prefix: /api/v1/notifications  (registered via api_bp)
"""

from flask import Blueprint, jsonify
from flask_login import current_user, login_required

from app.extensions import db
from app.database.models import Notification

notif_bp = Blueprint("notifications", __name__, url_prefix="/v1/notifications")


# ------------------------------------------------------------------ #
# Helpers
# ------------------------------------------------------------------ #

def _ok(data, meta=None):
    return jsonify({"data": data, "error": None, "meta": meta or {}})


def _err(message, status=400):
    return jsonify({"data": None, "error": message, "meta": {}}), status


# ------------------------------------------------------------------ #
# GET /api/v1/notifications
# ------------------------------------------------------------------ #

@notif_bp.get("")
@login_required
def list_notifications():
    notifs = (
        Notification.query
        .filter_by(user_id=current_user.id)
        .order_by(Notification.created_at.desc())
        .limit(30)
        .all()
    )
    return _ok([n.to_dict() for n in notifs])


# ------------------------------------------------------------------ #
# GET /api/v1/notifications/unread-count
# ------------------------------------------------------------------ #

@notif_bp.get("/unread-count")
@login_required
def unread_count():
    count = Notification.query.filter_by(
        user_id=current_user.id, is_read=False
    ).count()
    return _ok({"count": count})


# ------------------------------------------------------------------ #
# POST /api/v1/notifications/read-all
# ------------------------------------------------------------------ #

@notif_bp.post("/read-all")
@login_required
def read_all():
    Notification.query.filter_by(
        user_id=current_user.id, is_read=False
    ).update({"is_read": True})
    db.session.commit()
    return _ok("ok")


# ------------------------------------------------------------------ #
# PATCH /api/v1/notifications/<notif_id>/read
# ------------------------------------------------------------------ #

@notif_bp.patch("/<int:notif_id>/read")
@login_required
def read_one(notif_id):
    notif = Notification.query.filter_by(
        id=notif_id, user_id=current_user.id
    ).first_or_404()
    notif.is_read = True
    db.session.commit()
    return _ok(notif.to_dict())

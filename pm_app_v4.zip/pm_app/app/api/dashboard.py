"""
Dashboard API blueprint.
Prefix: /api/v1/dashboard
"""

from datetime import date, timedelta

from flask import Blueprint, jsonify
from flask_login import current_user, login_required

from app.database.models import (
    ActivityLog,
    Project,
    ProjectMember,
    Sprint,
    Task,
    TaskStatus,
    TimeLog,
    User,
)
from app.extensions import db

dashboard_api_bp = Blueprint("dashboard_api", __name__, url_prefix="/v1/dashboard")


@dashboard_api_bp.get("/stats")
@login_required
def stats():
    user_id = current_user.id
    today = date.today()
    month_start = today.replace(day=1)

    # ------------------------------------------------------------------
    # Stat cards
    # ------------------------------------------------------------------
    active_projects = (
        ProjectMember.query
        .filter_by(user_id=user_id)
        .count()
    )

    done_status_ids = [
        s.id for s in TaskStatus.query.filter_by(category="done").all()
    ]

    assigned_q = Task.query.filter_by(assignee_id=user_id)

    pending_tasks = assigned_q.filter(
        Task.status_id.notin_(done_status_ids) if done_status_ids else True
    ).count()

    completed_this_month = assigned_q.filter(
        Task.status_id.in_(done_status_ids) if done_status_ids else False,
        Task.updated_at >= month_start,
    ).count()

    overdue = assigned_q.filter(
        Task.due_date < today,
        Task.status_id.notin_(done_status_ids) if done_status_ids else True,
    ).count()

    # ------------------------------------------------------------------
    # Tasks by status (across projects the user is member of)
    # ------------------------------------------------------------------
    member_project_ids = [
        m.project_id for m in ProjectMember.query.filter_by(user_id=user_id).all()
    ]

    statuses = (
        TaskStatus.query
        .filter(TaskStatus.project_id.in_(member_project_ids))
        .all()
    ) if member_project_ids else []

    # Aggregate by status name + color
    status_counts = {}
    for s in statuses:
        key = (s.name, s.color_hex)
        count = Task.query.filter_by(status_id=s.id).count()
        if key not in status_counts:
            status_counts[key] = 0
        status_counts[key] += count

    tasks_by_status = [
        {"status_name": name, "color": color, "count": cnt}
        for (name, color), cnt in status_counts.items()
        if cnt > 0
    ]

    # ------------------------------------------------------------------
    # Tasks by assignee (projects the user belongs to)
    # ------------------------------------------------------------------
    assignees_raw = {}
    if member_project_ids:
        rows = (
            db.session.query(
                User.full_name,
                db.func.count(Task.id).label("total"),
                db.func.sum(
                    db.case(
                        (Task.status_id.in_(done_status_ids), 1),
                        else_=0
                    )
                ).label("completed")
            )
            .join(Task, Task.assignee_id == User.id)
            .filter(Task.project_id.in_(member_project_ids))
            .group_by(User.full_name)
            .all()
        )
        for row in rows:
            name = row.full_name or "Unassigned"
            total = row.total or 0
            completed = int(row.completed or 0)
            assignees_raw[name] = {
                "full_name": name,
                "pending": total - completed,
                "completed": completed,
            }

    tasks_by_assignee = list(assignees_raw.values())

    # ------------------------------------------------------------------
    # Recent activity (last 10 entries)
    # ------------------------------------------------------------------
    activity_logs = (
        ActivityLog.query
        .order_by(ActivityLog.created_at.desc())
        .limit(10)
        .all()
    )
    recent_activity = []
    for log in activity_logs:
        recent_activity.append({
            "user": log.user.full_name if log.user else "Unknown",
            "action": log.action,
            "entity_type": log.entity_type,
            "entity_id": log.entity_id,
            "created_at": log.created_at.isoformat(),
        })

    # ------------------------------------------------------------------
    # Upcoming tasks (due in next 7 days)
    # ------------------------------------------------------------------
    next_week = today + timedelta(days=7)
    upcoming_rows = (
        Task.query
        .filter(
            Task.assignee_id == user_id,
            Task.due_date >= today,
            Task.due_date <= next_week,
            Task.status_id.notin_(done_status_ids) if done_status_ids else True,
        )
        .order_by(Task.due_date.asc())
        .limit(20)
        .all()
    )
    upcoming_tasks = []
    for t in upcoming_rows:
        upcoming_tasks.append({
            "id": t.id,
            "title": t.title,
            "project_name": t.project.name if t.project else None,
            "due_date": t.due_date.isoformat() if t.due_date else None,
            "priority": t.priority,
            "status_name": t.status.name if t.status else None,
            "status_color": t.status.color_hex if t.status else "#BAB9B4",
        })

    # ------------------------------------------------------------------
    # Active sprint burndown (first active sprint across user's projects)
    # ------------------------------------------------------------------
    active_sprint_burndown = None
    if member_project_ids:
        sprint = (
            Sprint.query
            .filter(
                Sprint.project_id.in_(member_project_ids),
                Sprint.status == "active",
            )
            .first()
        )
        if sprint and sprint.start_date and sprint.end_date:
            sprint_tasks = Task.query.filter_by(sprint_id=sprint.id).all()
            total_hours = sum(
                float(t.estimated_hours) for t in sprint_tasks if t.estimated_hours
            )
            sprint_start = sprint.start_date
            sprint_end = sprint.end_date
            total_days = (sprint_end - sprint_start).days or 1

            ideal = []
            cur = sprint_start
            while cur <= sprint_end:
                day_idx = (cur - sprint_start).days
                rem = total_hours * (1 - day_idx / total_days)
                ideal.append([cur.isoformat(), round(max(rem, 0), 2)])
                cur += timedelta(days=1)

            actual = []
            cur = sprint_start
            end_actual = min(today, sprint_end)
            while cur <= end_actual:
                logged = (
                    db.session.query(db.func.sum(TimeLog.hours))
                    .join(Task, TimeLog.task_id == Task.id)
                    .filter(
                        Task.sprint_id == sprint.id,
                        TimeLog.logged_date <= cur,
                    )
                    .scalar()
                ) or 0
                rem = max(total_hours - float(logged), 0)
                actual.append([cur.isoformat(), round(rem, 2)])
                cur += timedelta(days=1)

            active_sprint_burndown = {
                "sprint_name": sprint.name,
                "ideal": ideal,
                "actual": actual,
            }

    return jsonify({
        "data": {
            "stats": {
                "active_projects": active_projects,
                "pending_tasks": pending_tasks,
                "completed_this_month": completed_this_month,
                "overdue": overdue,
            },
            "tasks_by_status": tasks_by_status,
            "tasks_by_assignee": tasks_by_assignee,
            "recent_activity": recent_activity,
            "upcoming_tasks": upcoming_tasks,
            "active_sprint_burndown": active_sprint_burndown,
        }
    })

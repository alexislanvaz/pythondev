"""
Users API blueprint.
Prefix: /api/v1  (registered via api_bp)
"""

from flask import Blueprint, request, jsonify
from flask_login import current_user, login_required

from app.extensions import db
from app.database.models import User, ProjectMember, Project

users_bp = Blueprint("users", __name__, url_prefix="/v1")


# ------------------------------------------------------------------ #
# Helpers
# ------------------------------------------------------------------ #

def _ok(data, meta=None):
    return jsonify({"data": data, "error": None, "meta": meta or {}})


def _err(message, status=400):
    return jsonify({"data": None, "error": message, "meta": {}}), status


def _is_member(project_id, user_id=None):
    uid = user_id or current_user.id
    return ProjectMember.query.filter_by(project_id=project_id, user_id=uid).first() is not None


def _member_role(project_id, user_id=None):
    uid = user_id or current_user.id
    pm = ProjectMember.query.filter_by(project_id=project_id, user_id=uid).first()
    return pm.role.name.lower() if pm and pm.role else None


# ------------------------------------------------------------------ #
# GET /api/v1/users/me
# ------------------------------------------------------------------ #

@users_bp.get("/users/me")
@login_required
def me():
    return _ok(current_user.to_dict())


# ------------------------------------------------------------------ #
# GET /api/v1/users?search=xxx
# ------------------------------------------------------------------ #

@users_bp.get("/users")
@login_required
def search_users():
    q = request.args.get("search", "").strip()
    if not q:
        return _ok([])

    pattern = f"%{q}%"
    users = (
        User.query
        .filter(
            User.is_active == True,  # noqa: E712
            db.or_(
                User.username.ilike(pattern),
                User.full_name.ilike(pattern),
                User.email.ilike(pattern),
            )
        )
        .limit(20)
        .all()
    )
    return _ok([
        {
            "id":         u.id,
            "username":   u.username,
            "full_name":  u.full_name,
            "avatar_url": u.avatar_url,
        }
        for u in users
    ])


# ------------------------------------------------------------------ #
# GET /api/v1/projects/<project_id>/members
# ------------------------------------------------------------------ #

@users_bp.get("/projects/<int:project_id>/members")
@login_required
def list_members(project_id):
    Project.query.get_or_404(project_id)
    if not _is_member(project_id):
        return _err("Forbidden", 403)

    members = ProjectMember.query.filter_by(project_id=project_id).all()
    return _ok([
        {
            "id":          pm.id,
            "user_id":     pm.user_id,
            "username":    pm.user.username if pm.user else None,
            "full_name":   pm.user.full_name if pm.user else None,
            "avatar_url":  pm.user.avatar_url if pm.user else None,
            "role_id":     pm.role_id,
            "role_name":   pm.role.name if pm.role else None,
            "assigned_at": pm.assigned_at.isoformat(),
        }
        for pm in members
    ])


# ------------------------------------------------------------------ #
# POST /api/v1/projects/<project_id>/members
# ------------------------------------------------------------------ #

@users_bp.post("/projects/<int:project_id>/members")
@login_required
def add_member(project_id):
    Project.query.get_or_404(project_id)
    role = _member_role(project_id)
    if role not in ("project_manager", "admin", "owner"):
        return _err("Only project managers or admins can add members", 403)

    body    = request.get_json(silent=True) or {}
    user_id = body.get("user_id")
    role_id = body.get("role_id")
    if not user_id or not role_id:
        return _err("user_id and role_id are required")

    user = User.query.get(user_id)
    if not user:
        return _err("User not found", 404)

    existing = ProjectMember.query.filter_by(project_id=project_id, user_id=user_id).first()
    if existing:
        return _err("User is already a member of this project", 409)

    pm = ProjectMember(project_id=project_id, user_id=user_id, role_id=role_id)
    db.session.add(pm)
    db.session.commit()
    return _ok({
        "id":         pm.id,
        "project_id": pm.project_id,
        "user_id":    pm.user_id,
        "role_id":    pm.role_id,
    }), 201


# ------------------------------------------------------------------ #
# DELETE /api/v1/projects/<project_id>/members/<user_id>
# ------------------------------------------------------------------ #

@users_bp.delete("/projects/<int:project_id>/members/<int:user_id>")
@login_required
def remove_member(project_id, user_id):
    Project.query.get_or_404(project_id)
    role = _member_role(project_id)
    if role not in ("project_manager", "admin", "owner"):
        return _err("Only project managers or admins can remove members", 403)

    pm = ProjectMember.query.filter_by(project_id=project_id, user_id=user_id).first()
    if not pm:
        return _err("Member not found", 404)

    # Do not allow removing the project owner
    project = Project.query.get(project_id)
    if project and project.owner_id == user_id:
        return _err("Cannot remove the project owner", 400)

    db.session.delete(pm)
    db.session.commit()
    return _ok("removed")

"""
Epics API blueprint.
Prefix: /api/v1  (registered inside api_bp which has prefix /api)

Full URL examples:
  GET    /api/v1/projects/<id>/epics
  POST   /api/v1/projects/<id>/epics
  GET    /api/v1/epics/<id>
  PATCH  /api/v1/epics/<id>
  DELETE /api/v1/epics/<id>
  GET    /api/v1/epics/<id>/tasks
  POST   /api/v1/epics/<id>/tasks/<task_id>
  DELETE /api/v1/epics/<id>/tasks/<task_id>
"""

from datetime import date

from flask import Blueprint, request, jsonify
from flask_login import current_user, login_required

from app.extensions import db
from app.database.models import (
    ActivityLog,
    Epic,
    Project,
    ProjectMember,
    Sprint,
    Task,
    TaskStatus,
)

epics_api_bp = Blueprint("epics_api", __name__, url_prefix="/v1")


# ------------------------------------------------------------------ #
# Response helpers
# ------------------------------------------------------------------ #

def _ok(data, meta=None, status=200):
    return jsonify({"data": data, "error": None, "meta": meta or {}}), status


def _err(message, status=400):
    return jsonify({"data": None, "error": message, "meta": {}}), status


# ------------------------------------------------------------------ #
# Access helpers
# ------------------------------------------------------------------ #

def _get_member(project_id):
    """Return the ProjectMember row for the current user, or None."""
    return ProjectMember.query.filter_by(
        project_id=project_id, user_id=current_user.id
    ).first()


def _member_role(project_id):
    member = _get_member(project_id)
    return member.role.name.lower() if member and member.role else None


def _is_manager_or_admin(project_id):
    role = _member_role(project_id)
    return role in ("project_manager", "admin", "owner")


# ------------------------------------------------------------------ #
# Serialisation helpers
# ------------------------------------------------------------------ #

# Priority ordering for sorting
PRIORITY_ORDER = {"critical": 4, "high": 3, "medium": 2, "low": 1}


def _task_row(task):
    """Compact task representation used across epic endpoints."""
    assignee = None
    if task.assignee:
        assignee = {
            "id":         task.assignee.id,
            "full_name":  task.assignee.full_name,
            "avatar_url": task.assignee.avatar_url,
        }
    status = None
    if task.status:
        status = {
            "id":       task.status.id,
            "name":     task.status.name,
            "color":    task.status.color_hex,
            "category": task.status.category,
        }
    sprint_name = task.sprint.name if task.sprint else None
    return {
        "id":              task.id,
        "title":           task.title,
        "type":            task.type,
        "priority":        task.priority,
        "status":          status,
        "assignee":        assignee,
        "estimated_hours": float(task.estimated_hours) if task.estimated_hours else None,
        "actual_hours":    float(task.actual_hours),
        "due_date":        task.due_date.isoformat() if task.due_date else None,
        "sprint_id":       task.sprint_id,
        "sprint_name":     sprint_name,
        "epic_id":         task.epic_id,
        "labels":          [{"id": l.id, "name": l.name, "color_hex": l.color_hex} for l in task.labels],
    }


def _epic_summary(epic):
    """Epic dict with task counts and progress percent."""
    all_tasks = epic.tasks.all()
    total = len(all_tasks)
    done = sum(
        1 for t in all_tasks
        if t.status and t.status.category == "done"
    )
    progress = round((done / total * 100), 1) if total else 0.0
    return {
        "id":                   epic.id,
        "project_id":           epic.project_id,
        "name":                 epic.name,
        "description":          epic.description,
        "status":               epic.status,
        "start_date":           epic.start_date.isoformat() if epic.start_date else None,
        "end_date":             epic.end_date.isoformat()   if epic.end_date   else None,
        "color_hex":            epic.color_hex,
        "task_count":           total,
        "completed_task_count": done,
        "progress_percent":     progress,
    }


def _epic_stats(epic):
    """Compute detailed stats for an epic."""
    all_tasks = epic.tasks.all()
    total = len(all_tasks)
    today = date.today()

    # by_status aggregation
    status_counts = {}
    for t in all_tasks:
        if t.status:
            sid = t.status.id
            if sid not in status_counts:
                status_counts[sid] = {
                    "status_name": t.status.name,
                    "color":       t.status.color_hex,
                    "count":       0,
                }
            status_counts[sid]["count"] += 1

    # by_priority aggregation
    priority_counts = {}
    for t in all_tasks:
        p = t.priority or "medium"
        priority_counts[p] = priority_counts.get(p, 0) + 1

    total_estimated = sum(
        float(t.estimated_hours) for t in all_tasks if t.estimated_hours
    )
    total_actual = sum(float(t.actual_hours) for t in all_tasks)
    overdue = sum(
        1 for t in all_tasks
        if t.due_date
        and t.status
        and t.status.category != "done"
        and t.due_date < today
    )

    return {
        "total_tasks":            total,
        "by_status":              list(status_counts.values()),
        "by_priority":            [
            {"priority": p, "count": c}
            for p, c in priority_counts.items()
        ],
        "total_estimated_hours":  round(total_estimated, 2),
        "total_actual_hours":     round(total_actual, 2),
        "overdue_count":          overdue,
    }


def _log(entity_type, entity_id, action, old_value=None, new_value=None):
    entry = ActivityLog(
        entity_type=entity_type,
        entity_id=entity_id,
        user_id=current_user.id,
        action=action,
        old_value=str(old_value) if old_value is not None else None,
        new_value=str(new_value) if new_value is not None else None,
    )
    db.session.add(entry)


def _parse_date(value):
    if not value:
        return None
    try:
        return date.fromisoformat(value)
    except (ValueError, TypeError):
        return None


# ------------------------------------------------------------------ #
# GET /api/v1/projects/<project_id>/epics
# ------------------------------------------------------------------ #

@epics_api_bp.get("/projects/<int:project_id>/epics")
@login_required
def list_epics(project_id):
    project = db.session.get(Project, project_id)
    if not project:
        return _err("Project not found", 404)
    if not _get_member(project_id):
        return _err("Forbidden", 403)

    epics = (
        Epic.query
        .filter_by(project_id=project_id)
        .order_by(
            db.case(
                (Epic.start_date.is_(None), 1),
                else_=0
            ),
            Epic.start_date.asc(),
            Epic.id.asc(),
        )
        .all()
    )
    return _ok([_epic_summary(e) for e in epics])


# ------------------------------------------------------------------ #
# POST /api/v1/projects/<project_id>/epics
# ------------------------------------------------------------------ #

@epics_api_bp.post("/projects/<int:project_id>/epics")
@login_required
def create_epic(project_id):
    project = db.session.get(Project, project_id)
    if not project:
        return _err("Project not found", 404)
    if not _get_member(project_id):
        return _err("Forbidden", 403)

    body = request.get_json(silent=True) or {}
    name = (body.get("name") or "").strip()
    if not name:
        return _err("name is required")

    epic = Epic(
        project_id=project_id,
        name=name,
        description=body.get("description"),
        status=body.get("status", "planning"),
        start_date=_parse_date(body.get("start_date")),
        end_date=_parse_date(body.get("end_date")),
        color_hex=body.get("color_hex", "#7A39BB"),
    )
    db.session.add(epic)
    db.session.flush()
    _log("epic", epic.id, "epic_created", new_value=name)
    db.session.commit()
    return _ok(_epic_summary(epic)), 201


# ------------------------------------------------------------------ #
# GET /api/v1/epics/<epic_id>
# ------------------------------------------------------------------ #

@epics_api_bp.get("/epics/<int:epic_id>")
@login_required
def get_epic(epic_id):
    epic = db.session.get(Epic, epic_id)
    if not epic:
        return _err("Epic not found", 404)
    if not _get_member(epic.project_id):
        return _err("Forbidden", 403)

    tasks = (
        epic.tasks
        .order_by(Task.order_index.asc())
        .all()
    )

    return _ok({
        "epic":  _epic_summary(epic),
        "tasks": [_task_row(t) for t in tasks],
        "stats": _epic_stats(epic),
    })


# ------------------------------------------------------------------ #
# PATCH /api/v1/epics/<epic_id>
# ------------------------------------------------------------------ #

@epics_api_bp.patch("/epics/<int:epic_id>")
@login_required
def update_epic(epic_id):
    epic = db.session.get(Epic, epic_id)
    if not epic:
        return _err("Epic not found", 404)
    if not _is_manager_or_admin(epic.project_id):
        return _err("Only project managers or admins can edit epics", 403)

    body = request.get_json(silent=True) or {}
    date_fields = ("start_date", "end_date")
    editable = ("name", "description", "status", "start_date", "end_date", "color_hex")

    for field in editable:
        if field not in body:
            continue
        if field in date_fields:
            setattr(epic, field, _parse_date(body[field]))
        else:
            setattr(epic, field, body[field])

    _log("epic", epic.id, "epic_updated", new_value=str(body))
    db.session.commit()

    result = _epic_summary(epic)
    result["stats"] = _epic_stats(epic)
    return _ok(result)


# ------------------------------------------------------------------ #
# DELETE /api/v1/epics/<epic_id>
# ------------------------------------------------------------------ #

@epics_api_bp.delete("/epics/<int:epic_id>")
@login_required
def delete_epic(epic_id):
    epic = db.session.get(Epic, epic_id)
    if not epic:
        return _err("Epic not found", 404)
    if not _is_manager_or_admin(epic.project_id):
        return _err("Only project managers or admins can delete epics", 403)

    # Detach tasks from epic without deleting them
    Task.query.filter_by(epic_id=epic_id).update({"epic_id": None})
    _log("epic", epic.id, "epic_deleted", old_value=epic.name)
    db.session.delete(epic)
    db.session.commit()
    return _ok("ok")


# ------------------------------------------------------------------ #
# GET /api/v1/epics/<epic_id>/tasks
# ------------------------------------------------------------------ #

@epics_api_bp.get("/epics/<int:epic_id>/tasks")
@login_required
def list_epic_tasks(epic_id):
    epic = db.session.get(Epic, epic_id)
    if not epic:
        return _err("Epic not found", 404)
    if not _get_member(epic.project_id):
        return _err("Forbidden", 403)

    query = Task.query.filter_by(epic_id=epic_id)

    # Optional filters via query params
    status_id   = request.args.get("status_id",   type=int)
    assignee_id = request.args.get("assignee_id", type=int)
    priority    = request.args.get("priority")
    sprint_id   = request.args.get("sprint_id",   type=int)

    if status_id:
        query = query.filter(Task.status_id == status_id)
    if assignee_id:
        query = query.filter(Task.assignee_id == assignee_id)
    if priority:
        query = query.filter(Task.priority == priority)
    if sprint_id is not None:
        if sprint_id == 0:
            query = query.filter(Task.sprint_id.is_(None))
        else:
            query = query.filter(Task.sprint_id == sprint_id)

    tasks = query.all()

    # Sort by priority DESC (critical > high > medium > low), then due_date ASC nulls last
    def _sort_key(t):
        prio = PRIORITY_ORDER.get(t.priority or "medium", 2)
        due  = t.due_date if t.due_date else date.max
        return (-prio, due)

    tasks.sort(key=_sort_key)
    return _ok([_task_row(t) for t in tasks])


# ------------------------------------------------------------------ #
# POST /api/v1/epics/<epic_id>/tasks/<task_id>
# ------------------------------------------------------------------ #

@epics_api_bp.post("/epics/<int:epic_id>/tasks/<int:task_id>")
@login_required
def assign_task_to_epic(epic_id, task_id):
    epic = db.session.get(Epic, epic_id)
    if not epic:
        return _err("Epic not found", 404)
    if not _get_member(epic.project_id):
        return _err("Forbidden", 403)

    task = db.session.get(Task, task_id)
    if not task:
        return _err("Task not found", 404)
    if task.project_id != epic.project_id:
        return _err("Task does not belong to the same project as the epic")

    task.epic_id = epic_id
    _log("task", task.id, "task_assigned_to_epic", old_value=task.epic_id, new_value=epic_id)
    db.session.commit()
    return _ok(_task_row(task))


# ------------------------------------------------------------------ #
# DELETE /api/v1/epics/<epic_id>/tasks/<task_id>
# ------------------------------------------------------------------ #

@epics_api_bp.delete("/epics/<int:epic_id>/tasks/<int:task_id>")
@login_required
def remove_task_from_epic(epic_id, task_id):
    epic = db.session.get(Epic, epic_id)
    if not epic:
        return _err("Epic not found", 404)
    if not _get_member(epic.project_id):
        return _err("Forbidden", 403)

    task = db.session.get(Task, task_id)
    if not task or task.epic_id != epic_id:
        return _err("Task not found in this epic", 404)

    task.epic_id = None
    _log("task", task.id, "task_removed_from_epic", old_value=epic_id, new_value=None)
    db.session.commit()
    return _ok("ok")

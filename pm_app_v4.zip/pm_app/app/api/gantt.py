"""
Gantt API blueprint.
Prefix: /api/v1/gantt
"""

from datetime import date, timedelta

from flask import Blueprint, jsonify
from flask_login import current_user, login_required

from app.database.models import Epic, Project, ProjectMember, Sprint, Task
from app.extensions import db

gantt_bp = Blueprint("gantt", __name__, url_prefix="/v1/gantt")


def _check_project_access(project_id):
    """Return project if current user is a member, else None."""
    project = db.session.get(Project, project_id)
    if not project:
        return None
    member = ProjectMember.query.filter_by(
        project_id=project_id, user_id=current_user.id
    ).first()
    if not member:
        return None
    return project


def _task_progress(task):
    """Calculate progress 0-100 from actual_hours / estimated_hours."""
    if task.estimated_hours and float(task.estimated_hours) > 0:
        pct = float(task.actual_hours) / float(task.estimated_hours) * 100
        return min(round(pct, 1), 100)
    return 0.0


def _resolve_dates(start, end):
    """Ensure both start and end are defined."""
    if start and end:
        return start, end
    if start and not end:
        return start, start + timedelta(days=1)
    if end and not start:
        return end - timedelta(days=1), end
    return None, None


@gantt_bp.get("/project/<int:project_id>")
@login_required
def project_gantt(project_id):
    project = _check_project_access(project_id)
    if not project:
        return jsonify({"error": "Not found or forbidden"}), 404

    tasks = (
        Task.query
        .filter(
            Task.project_id == project_id,
            db.or_(Task.start_date.isnot(None), Task.due_date.isnot(None))
        )
        .order_by(Task.order_index.asc(), Task.created_at.asc())
        .all()
    )

    task_data = []
    for t in tasks:
        start, end = _resolve_dates(t.start_date, t.due_date)
        if not start:
            continue

        deps = [d.depends_on_task_id for d in t.dependencies.all()]

        task_data.append({
            "id": t.id,
            "title": t.title,
            "type": t.type,
            "start": start.isoformat(),
            "end": end.isoformat(),
            "progress": _task_progress(t),
            "assignee": t.assignee.full_name if t.assignee else None,
            "status": t.status.name if t.status else None,
            "status_color": t.status.color_hex if t.status else "#BAB9B4",
            "priority": t.priority,
            "epic_name": t.epic.name if t.epic else None,
            "sprint_name": t.sprint.name if t.sprint else None,
            "dependencies": deps,
        })

    # Epics
    epics = Epic.query.filter_by(project_id=project_id).all()
    epic_data = []
    for e in epics:
        start, end = _resolve_dates(e.start_date, e.end_date)
        if not start:
            continue
        epic_data.append({
            "id": e.id,
            "name": e.name,
            "start": start.isoformat(),
            "end": end.isoformat(),
            "color": e.color_hex,
        })

    # Sprints
    sprints = Sprint.query.filter_by(project_id=project_id).all()
    sprint_data = []
    for s in sprints:
        start, end = _resolve_dates(s.start_date, s.end_date)
        if not start:
            continue
        sprint_data.append({
            "id": s.id,
            "name": s.name,
            "start": start.isoformat(),
            "end": end.isoformat(),
            "status": s.status,
        })

    return jsonify({
        "data": task_data,
        "epics": epic_data,
        "sprints": sprint_data,
    })


@gantt_bp.get("/project/<int:project_id>/burndown")
@login_required
def project_burndown(project_id):
    project = _check_project_access(project_id)
    if not project:
        return jsonify({"error": "Not found or forbidden"}), 404

    sprint = (
        Sprint.query
        .filter_by(project_id=project_id, status="active")
        .first()
    )
    if not sprint or not sprint.start_date or not sprint.end_date:
        return jsonify({"data": None})

    tasks = (
        Task.query
        .filter_by(sprint_id=sprint.id)
        .all()
    )

    total_hours = sum(
        float(t.estimated_hours) for t in tasks if t.estimated_hours
    )

    today = date.today()
    sprint_start = sprint.start_date
    sprint_end = sprint.end_date
    total_days = (sprint_end - sprint_start).days or 1

    # Build ideal line
    ideal = []
    current = sprint_start
    while current <= sprint_end:
        day_index = (current - sprint_start).days
        remaining = total_hours * (1 - day_index / total_days)
        ideal.append([current.isoformat(), round(max(remaining, 0), 2)])
        current += timedelta(days=1)

    # Build actual line from sprint_start to today
    # For each day, estimate remaining = total - sum of actual hours for tasks
    # whose status changed to done on or before that day.
    # Since we do not track daily state, we use a simpler heuristic:
    # remaining = total_estimated - cumulative actual hours logged up to that day.
    from app.database.models import TimeLog

    actual = []
    current = sprint_start
    end_actual = min(today, sprint_end)
    while current <= end_actual:
        logged = (
            db.session.query(db.func.sum(TimeLog.hours))
            .join(Task, TimeLog.task_id == Task.id)
            .filter(
                Task.sprint_id == sprint.id,
                TimeLog.logged_date <= current,
            )
            .scalar()
        ) or 0
        remaining = max(total_hours - float(logged), 0)
        actual.append([current.isoformat(), round(remaining, 2)])
        current += timedelta(days=1)

    return jsonify({
        "data": {
            "sprint_name": sprint.name,
            "start": sprint_start.isoformat(),
            "end": sprint_end.isoformat(),
            "ideal": ideal,
            "actual": actual,
        }
    })

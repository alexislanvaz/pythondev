"""
Projects HTML routes.
"""

from flask import render_template, redirect, url_for, abort
from flask_login import current_user, login_required

from app.database.models import Project, ProjectMember, TaskStatus, Workspace
from app.projects import projects_bp


def _get_project_or_403(project_id):
    """Return project if current_user is a member, else abort."""
    project = Project.query.get_or_404(project_id)
    member = ProjectMember.query.filter_by(
        project_id=project_id, user_id=current_user.id
    ).first()
    if not member:
        abort(403)
    return project


# ------------------------------------------------------------------ #
# GET /projects/
# ------------------------------------------------------------------ #

@projects_bp.get("/")
@login_required
def list_projects():
    memberships = ProjectMember.query.filter_by(user_id=current_user.id).all()
    project_ids = [m.project_id for m in memberships]
    projects = Project.query.filter(Project.id.in_(project_ids)).order_by(Project.name.asc()).all()

    # Try to get active workspace from first project
    workspace = None
    if projects:
        workspace = projects[0].workspace

    return render_template(
        "projects/list.html",
        projects=projects,
        workspace=workspace,
    )


# ------------------------------------------------------------------ #
# GET /projects/new
# ------------------------------------------------------------------ #

@projects_bp.get("/new")
@login_required
def new_project():
    workspaces = (
        Workspace.query
        .join(Workspace.members)
        .filter_by(user_id=current_user.id)
        .all()
    )
    return render_template("projects/new.html", workspaces=workspaces)


# ------------------------------------------------------------------ #
# GET /projects/<project_id>/board
# ------------------------------------------------------------------ #

@projects_bp.get("/<int:project_id>/board")
@login_required
def board(project_id):
    project  = _get_project_or_403(project_id)
    statuses = (
        TaskStatus.query
        .filter_by(project_id=project_id)
        .order_by(TaskStatus.order_index.asc())
        .all()
    )
    members = (
        ProjectMember.query
        .filter_by(project_id=project_id)
        .all()
    )
    return render_template(
        "projects/board.html",
        project=project,
        statuses=statuses,
        members=members,
    )


# ------------------------------------------------------------------ #
# GET /projects/<project_id>/backlog
# ------------------------------------------------------------------ #

@projects_bp.get("/<int:project_id>/backlog")
@login_required
def backlog(project_id):
    project  = _get_project_or_403(project_id)
    statuses = (
        TaskStatus.query
        .filter_by(project_id=project_id)
        .order_by(TaskStatus.order_index.asc())
        .all()
    )
    return render_template(
        "projects/backlog.html",
        project=project,
        statuses=statuses,
    )


# ------------------------------------------------------------------ #
# GET /projects/<project_id>/timeline
# ------------------------------------------------------------------ #

@projects_bp.get("/<int:project_id>/timeline")
@login_required
def timeline(project_id):
    project = _get_project_or_403(project_id)
    return render_template(
        "projects/timeline.html",
        project=project,
    )

"""
Sprints HTML blueprint package.
"""

from flask import Blueprint

sprints_bp = Blueprint(
    "sprints",
    __name__,
    template_folder="templates",
)

from app.sprints import routes  # noqa: E402,F401

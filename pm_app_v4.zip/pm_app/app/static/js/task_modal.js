/**
 * task_modal.js
 * Floating dialog for viewing and editing a task.
 * Depends on api.js being loaded first.
 * Exposes global: openTaskModal(taskId)
 */

(function (global) {
  "use strict";

  // ---------------------------------------------------------------- //
  // Build modal DOM once (lazy)
  // ---------------------------------------------------------------- //

  let dialog = null;
  let currentTaskId = null;

  function ensureDialog() {
    if (dialog) return;

    dialog = document.createElement("dialog");
    dialog.id = "task-modal";
    dialog.className = "task-modal";
    dialog.innerHTML = `
      <div class="tm-inner">

        <!-- Modal header -->
        <div class="tm-header">
          <div class="tm-header__left">
            <span id="tm-type-badge" class="badge-type"></span>
            <input
              id="tm-title"
              class="tm-title-input"
              type="text"
              placeholder="Task title"
              maxlength="300"
            >
          </div>
          <div class="tm-header__right">
            <select id="tm-status" class="tm-select"></select>
            <button class="tm-close-btn" id="tm-close" aria-label="Close">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
              </svg>
            </button>
          </div>
        </div>

        <!-- Modal body -->
        <div class="tm-body">

          <!-- Left column: tabs + content -->
          <div class="tm-main">

            <!-- Tab navigation -->
            <div class="modal-tabs">
              <button class="modal-tab active" data-tab="details">Details</button>
              <button class="modal-tab" data-tab="subtasks">
                Subtasks <span class="tab-badge" id="subtask-count">0</span>
              </button>
              <button class="modal-tab" data-tab="attachments">
                Attachments <span class="tab-badge" id="attachment-count">0</span>
              </button>
            </div>

            <!-- Tab: Details (existing content) -->
            <div class="modal-tab-content" id="tab-details">

              <section class="tm-section">
                <h4 class="tm-section-label">Description</h4>
                <textarea id="tm-description" class="tm-textarea" rows="4" placeholder="Add a description..."></textarea>
                <button class="btn btn-ghost btn-sm" id="tm-save-desc" style="margin-top:8px;">Save description</button>
              </section>

              <section class="tm-section">
                <h4 class="tm-section-label">Comments</h4>
                <div id="tm-comments"></div>
                <form id="tm-comment-form" class="tm-comment-form">
                  <textarea
                    id="tm-comment-input"
                    class="tm-textarea"
                    rows="2"
                    placeholder="Write a comment..."
                  ></textarea>
                  <button type="submit" class="btn btn-primary btn-sm">Comment</button>
                </form>
              </section>

              <section class="tm-section">
                <h4 class="tm-section-label">Time Logs</h4>
                <div id="tm-timelogs"></div>
                <form id="tm-timelog-form" class="tm-timelog-form">
                  <div class="tm-timelog-fields">
                    <input id="tm-log-hours" type="number" step="0.25" min="0.25" class="tm-input" placeholder="Hours" style="width:90px;">
                    <input id="tm-log-date"  type="date"   class="tm-input" style="width:160px;">
                    <input id="tm-log-desc"  type="text"   class="tm-input" placeholder="Description (optional)" style="flex:1;">
                  </div>
                  <button type="submit" class="btn btn-ghost btn-sm">Log Time</button>
                </form>
              </section>

            </div>

            <!-- Tab: Subtasks -->
            <div class="modal-tab-content hidden" id="tab-subtasks">
              <div class="subtasks-section">

                <div class="subtask-progress-bar-container">
                  <div class="subtask-progress-bar" id="subtask-progress-bar" style="width:0%"></div>
                </div>
                <span class="subtask-progress-label" id="subtask-progress-label">0 / 0 completadas</span>

                <ul class="subtask-list" id="subtask-list"></ul>

                <div class="subtask-add-row">
                  <input type="text" id="subtask-new-title" placeholder="Add subtask..." class="subtask-input" maxlength="300">
                  <button class="btn btn-ghost btn-sm" id="subtask-add-btn">Add</button>
                </div>

              </div>
            </div>

            <!-- Tab: Attachments -->
            <div class="modal-tab-content hidden" id="tab-attachments">
              <div class="attachments-section">

                <div class="upload-zone" id="upload-zone">
                  <input type="file" id="file-input" multiple accept="*/*" class="file-input-hidden">
                  <div class="upload-zone-content">
                    <div class="upload-icon">&#8593;</div>
                    <p class="upload-hint">Drop files here or <label for="file-input" class="upload-link">browse</label></p>
                    <p class="upload-hint-sub">Max 16 MB per file</p>
                  </div>
                  <div class="upload-progress hidden" id="upload-progress">
                    <div class="upload-progress-bar" id="upload-progress-bar"></div>
                    <span id="upload-progress-label">Uploading...</span>
                  </div>
                </div>

                <ul class="attachment-list" id="attachment-list"></ul>

              </div>
            </div>

          </div>

          <!-- Right sidebar -->
          <aside class="tm-sidebar">

            <div class="tm-field">
              <label class="tm-label">Assignee</label>
              <div id="tm-assignee-display" class="tm-field-value text-muted">Unassigned</div>
              <select id="tm-assignee" class="tm-select" style="width:100%;margin-top:4px;display:none;"></select>
              <button class="btn btn-ghost btn-sm" id="tm-edit-assignee" style="margin-top:4px;">Change</button>
            </div>

            <div class="tm-field">
              <label class="tm-label">Priority</label>
              <select id="tm-priority" class="tm-select" style="width:100%;">
                <option value="critical">Critical</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </div>

            <div class="tm-field">
              <label class="tm-label">Due Date</label>
              <input id="tm-due-date" type="date" class="tm-input" style="width:100%;">
            </div>

            <div class="tm-field">
              <label class="tm-label">Estimated Hours</label>
              <input id="tm-estimated" type="number" step="0.5" min="0" class="tm-input" style="width:100%;">
            </div>

            <div class="tm-field">
              <label class="tm-label">Actual Hours</label>
              <div id="tm-actual-hours" class="tm-field-value">0</div>
            </div>

            <div class="tm-field">
              <label class="tm-label">Labels</label>
              <div id="tm-labels-display"></div>
            </div>

            <button class="btn btn-primary" id="tm-save-fields" style="width:100%;margin-top:16px;">Save Changes</button>

          </aside>
        </div>

      </div>
    `;

    document.body.appendChild(dialog);

    // Close on backdrop click
    dialog.addEventListener("click", function (e) {
      if (e.target === dialog) closeModal();
    });

    document.getElementById("tm-close").addEventListener("click", closeModal);

    // Save description
    document.getElementById("tm-save-desc").addEventListener("click", saveDescription);

    // Comment submission
    document.getElementById("tm-comment-form").addEventListener("submit", submitComment);

    // Time log submission
    document.getElementById("tm-timelog-form").addEventListener("submit", submitTimeLog);

    // Status change
    document.getElementById("tm-status").addEventListener("change", changeStatus);

    // Toggle assignee selector
    document.getElementById("tm-edit-assignee").addEventListener("click", function () {
      var sel = document.getElementById("tm-assignee");
      sel.style.display = sel.style.display === "none" ? "block" : "none";
    });

    // Save sidebar fields
    document.getElementById("tm-save-fields").addEventListener("click", saveFields);

    // Close on Escape
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && dialog.open) closeModal();
    });

    // Tab switching
    dialog.querySelectorAll(".modal-tab").forEach(function (btn) {
      btn.addEventListener("click", function () {
        switchTab(btn.getAttribute("data-tab"));
      });
    });

    // Subtask add button
    document.getElementById("subtask-add-btn").addEventListener("click", function () {
      if (currentTaskId) addSubtask(currentTaskId);
    });

    // Subtask add on Enter key
    document.getElementById("subtask-new-title").addEventListener("keydown", function (e) {
      if (e.key === "Enter" && currentTaskId) addSubtask(currentTaskId);
    });

    // Attachment drag & drop
    var uploadZone = document.getElementById("upload-zone");

    uploadZone.addEventListener("dragover", function (e) {
      e.preventDefault();
      uploadZone.classList.add("drag-over");
    });

    uploadZone.addEventListener("dragleave", function (e) {
      uploadZone.classList.remove("drag-over");
    });

    uploadZone.addEventListener("drop", function (e) {
      e.preventDefault();
      uploadZone.classList.remove("drag-over");
      if (currentTaskId && e.dataTransfer.files.length > 0) {
        uploadFiles(currentTaskId, e.dataTransfer.files);
      }
    });

    // File input change
    document.getElementById("file-input").addEventListener("change", function (e) {
      if (currentTaskId && e.target.files.length > 0) {
        uploadFiles(currentTaskId, e.target.files);
        // Reset input so the same file can be re-uploaded if needed
        e.target.value = "";
      }
    });
  }

  // ---------------------------------------------------------------- //
  // Tab switching
  // ---------------------------------------------------------------- //

  function switchTab(tabName) {
    dialog.querySelectorAll(".modal-tab").forEach(function (btn) {
      btn.classList.toggle("active", btn.getAttribute("data-tab") === tabName);
    });
    dialog.querySelectorAll(".modal-tab-content").forEach(function (pane) {
      pane.classList.add("hidden");
    });
    var target = document.getElementById("tab-" + tabName);
    if (target) target.classList.remove("hidden");
  }

  // ---------------------------------------------------------------- //
  // Open modal
  // ---------------------------------------------------------------- //

  global.openTaskModal = async function (taskId) {
    ensureDialog();
    currentTaskId = taskId;

    // Reset to Details tab
    switchTab("details");

    // Clear previous content
    document.getElementById("tm-title").value            = "";
    document.getElementById("tm-description").value      = "";
    document.getElementById("tm-type-badge").textContent = "";
    document.getElementById("tm-comments").innerHTML     = "";
    document.getElementById("tm-timelogs").innerHTML     = "";
    document.getElementById("tm-labels-display").innerHTML = "";
    document.getElementById("subtask-list").innerHTML    = "";
    document.getElementById("subtask-count").textContent = "0";
    document.getElementById("attachment-list").innerHTML = "";
    document.getElementById("attachment-count").textContent = "0";
    updateSubtaskProgress([]);

    dialog.showModal();

    try {
      var resp = await apiGet("/api/v1/tasks/" + taskId);
      populateModal(resp.data);
    } catch (e) {
      alert("Failed to load task: " + e.message);
      closeModal();
      return;
    }

    // Load subtasks and attachments in parallel
    loadSubtasks(taskId);
    loadAttachments(taskId);
  };

  function closeModal() {
    if (dialog && dialog.open) dialog.close();
    currentTaskId = null;
  }

  // ---------------------------------------------------------------- //
  // Populate modal with task data
  // ---------------------------------------------------------------- //

  function populateModal(task) {
    document.getElementById("tm-title").value       = task.title || "";
    document.getElementById("tm-description").value = task.description || "";
    document.getElementById("tm-priority").value    = task.priority || "medium";
    document.getElementById("tm-due-date").value    = task.due_date || "";
    document.getElementById("tm-estimated").value   = task.estimated_hours || "";
    document.getElementById("tm-actual-hours").textContent = task.actual_hours || "0";

    // Type badge
    var typeBadge = document.getElementById("tm-type-badge");
    typeBadge.textContent = task.type || "task";
    typeBadge.style.cssText = buildTypeStyle(task.type);

    // Status selector - load from statuses if available (populated via board), else minimal
    var statusSel = document.getElementById("tm-status");
    statusSel.innerHTML = "";
    if (task.status) {
      var opt = document.createElement("option");
      opt.value = task.status.id;
      opt.textContent = task.status.name;
      opt.selected = true;
      statusSel.appendChild(opt);
    }
    // Load all project statuses asynchronously to populate selector and cache them
    loadStatusOptions(task.project_id, task.status_id);

    // Assignee
    var assigneeDisplay = document.getElementById("tm-assignee-display");
    if (task.assignee) {
      assigneeDisplay.textContent = task.assignee.full_name || "Unassigned";
    } else {
      assigneeDisplay.textContent = "Unassigned";
    }
    loadAssigneeOptions(task.project_id, task.assignee_id);

    // Labels
    var labelsDiv = document.getElementById("tm-labels-display");
    (task.labels || []).forEach(function (l) {
      var tag = document.createElement("span");
      tag.className = "task-label";
      tag.textContent = l.name;
      tag.style.cssText = "background:" + l.color_hex + "20;color:" + l.color_hex + ";border:1px solid " + l.color_hex + "50;";
      labelsDiv.appendChild(tag);
    });

    // Comments
    renderComments(task.comments || []);

    // Time logs
    renderTimeLogs(task.time_logs || []);
  }

  async function loadStatusOptions(projectId, currentStatusId) {
    try {
      var resp = await apiGet("/api/v1/projects/" + projectId);
      var statuses = resp.data.statuses || [];
      // Cache statuses globally for subtask toggle use
      window._taskStatuses = statuses;
      var sel = document.getElementById("tm-status");
      sel.innerHTML = "";
      statuses.forEach(function (s) {
        var opt = document.createElement("option");
        opt.value = s.id;
        opt.textContent = s.name;
        if (s.id === currentStatusId) opt.selected = true;
        sel.appendChild(opt);
      });
    } catch (_) {}
  }

  async function loadAssigneeOptions(projectId, currentAssigneeId) {
    try {
      var resp = await apiGet("/api/v1/projects/" + projectId + "/members");
      var members = resp.data || [];
      var sel = document.getElementById("tm-assignee");
      sel.innerHTML = "<option value=\"\">Unassigned</option>";
      members.forEach(function (m) {
        var opt = document.createElement("option");
        opt.value = m.user_id;
        opt.textContent = m.full_name || m.username || "User " + m.user_id;
        if (m.user_id === currentAssigneeId) opt.selected = true;
        sel.appendChild(opt);
      });
    } catch (_) {}
  }

  // ---------------------------------------------------------------- //
  // Render comments
  // ---------------------------------------------------------------- //

  function renderComments(comments) {
    var container = document.getElementById("tm-comments");
    container.innerHTML = "";
    comments.forEach(function (c) {
      container.appendChild(buildCommentEl(c));
      (c.replies || []).forEach(function (r) {
        var el = buildCommentEl(r);
        el.style.marginLeft = "24px";
        container.appendChild(el);
      });
    });
  }

  function buildCommentEl(c) {
    var el = document.createElement("div");
    el.className = "tm-comment";
    var user = c.user ? (c.user.full_name || "User") : "User";
    var date = new Date(c.created_at).toLocaleString();
    el.innerHTML =
      "<div class=\"tm-comment-meta\">" +
        "<strong>" + escHtml(user) + "</strong>" +
        "<span class=\"text-muted\" style=\"font-size:11px;\">" + date + "</span>" +
      "</div>" +
      "<div class=\"tm-comment-body\">" + escHtml(c.content) + "</div>";
    return el;
  }

  // ---------------------------------------------------------------- //
  // Render time logs
  // ---------------------------------------------------------------- //

  function renderTimeLogs(logs) {
    var container = document.getElementById("tm-timelogs");
    container.innerHTML = "";
    if (!logs.length) {
      container.innerHTML = "<span class='text-muted' style='font-size:12px;'>No time logged yet.</span>";
      return;
    }
    logs.forEach(function (tl) {
      var el = document.createElement("div");
      el.className = "tm-timelog-entry";
      var user = tl.user ? (tl.user.full_name || "User") : "User";
      el.innerHTML =
        "<span class=\"text-muted\" style=\"font-size:12px;\">" + tl.logged_date + "</span>" +
        "<strong style=\"margin:0 6px;\">" + tl.hours + "h</strong>" +
        "<span>" + escHtml(user) + "</span>" +
        (tl.description
          ? "<span class=\"text-muted\" style=\"font-size:11px;margin-left:6px;\">" + escHtml(tl.description) + "</span>"
          : "");
      container.appendChild(el);
    });
  }

  // ---------------------------------------------------------------- //
  // Subtasks
  // ---------------------------------------------------------------- //

  async function loadSubtasks(taskId) {
    try {
      var resp = await apiGet("/api/v1/tasks/" + taskId + "/subtasks");
      var subtasks = resp.data || [];
      renderSubtaskList(subtasks);
      updateSubtaskProgress(subtasks);
      document.getElementById("subtask-count").textContent = subtasks.length;
    } catch (_) {}
  }

  function renderSubtaskList(subtasks) {
    var list = document.getElementById("subtask-list");
    list.innerHTML = "";
    subtasks.forEach(function (st) {
      list.appendChild(buildSubtaskItem(st));
    });
  }

  function buildSubtaskItem(st) {
    var isDone = st.status && st.status.category === "done";
    var li = document.createElement("li");
    li.className = "subtask-item";
    li.setAttribute("data-id", st.id);

    var priorityVal = (st.priority || "medium").toLowerCase();

    // Assignee initials
    var initials = "";
    if (st.assignee && st.assignee.full_name) {
      var parts = st.assignee.full_name.trim().split(" ");
      initials = parts.length >= 2
        ? parts[0][0].toUpperCase() + parts[parts.length - 1][0].toUpperCase()
        : parts[0][0].toUpperCase();
    }

    li.innerHTML =
      "<input type=\"checkbox\" class=\"subtask-check\"" + (isDone ? " checked" : "") + ">" +
      "<span class=\"subtask-title" + (isDone ? " done" : "") + "\">" + escHtml(st.title) + "</span>" +
      "<span class=\"subtask-priority priority-dot priority-dot--" + escHtml(priorityVal) + "\"></span>" +
      (st.assignee
        ? "<span class=\"subtask-assignee\" title=\"" + escHtml(st.assignee.full_name || "") + "\">" + escHtml(initials) + "</span>"
        : "<span class=\"subtask-assignee\"></span>") +
      "<button class=\"subtask-delete btn-icon\" data-id=\"" + st.id + "\" title=\"Delete subtask\">x</button>";

    // Checkbox toggle
    li.querySelector(".subtask-check").addEventListener("change", function (e) {
      toggleSubtask(currentTaskId, st.id, e.target.checked, li);
    });

    // Delete button
    li.querySelector(".subtask-delete").addEventListener("click", function () {
      deleteSubtask(currentTaskId, st.id);
    });

    return li;
  }

  function updateSubtaskProgress(subtasks) {
    var total = subtasks.length;
    var completed = subtasks.filter(function (s) {
      return s.status && s.status.category === "done";
    }).length;
    var pct = total > 0 ? Math.round((completed / total) * 100) : 0;

    document.getElementById("subtask-progress-bar").style.width = pct + "%";
    document.getElementById("subtask-progress-label").textContent =
      completed + " / " + total + " completadas";
  }

  async function addSubtask(taskId) {
    var input = document.getElementById("subtask-new-title");
    var title = input.value.trim();
    if (!title) return;
    try {
      await apiPost("/api/v1/tasks/" + taskId + "/subtasks", { title: title });
      input.value = "";
      loadSubtasks(taskId);
    } catch (e) {
      alert("Failed to add subtask: " + e.message);
    }
  }

  async function toggleSubtask(taskId, subtaskId, isDone, liEl) {
    var statuses = window._taskStatuses || [];
    var targetStatus = null;

    if (isDone) {
      // Find first status with category === "done"
      targetStatus = statuses.find(function (s) { return s.category === "done"; });
    } else {
      // Find default status (is_default=true) or first with category "todo"
      targetStatus = statuses.find(function (s) { return s.is_default === true; });
      if (!targetStatus) {
        targetStatus = statuses.find(function (s) { return s.category === "todo"; });
      }
    }

    if (!targetStatus) return;

    try {
      await apiPatch(
        "/api/v1/tasks/" + taskId + "/subtasks/" + subtaskId,
        { status_id: targetStatus.id }
      );

      // Update UI without reloading full list
      if (liEl) {
        var checkbox = liEl.querySelector(".subtask-check");
        var titleSpan = liEl.querySelector(".subtask-title");
        if (checkbox) checkbox.checked = isDone;
        if (titleSpan) {
          if (isDone) {
            titleSpan.classList.add("done");
          } else {
            titleSpan.classList.remove("done");
          }
        }
      }

      // Recalculate progress from DOM
      var allItems = document.querySelectorAll("#subtask-list .subtask-item");
      var total = allItems.length;
      var completed = 0;
      allItems.forEach(function (item) {
        if (item.querySelector(".subtask-check") && item.querySelector(".subtask-check").checked) {
          completed++;
        }
      });
      document.getElementById("subtask-progress-bar").style.width =
        (total > 0 ? Math.round((completed / total) * 100) : 0) + "%";
      document.getElementById("subtask-progress-label").textContent =
        completed + " / " + total + " completadas";

    } catch (e) {
      // Revert checkbox on error
      if (liEl) {
        var cb = liEl.querySelector(".subtask-check");
        if (cb) cb.checked = !isDone;
      }
      alert("Failed to update subtask: " + e.message);
    }
  }

  async function deleteSubtask(taskId, subtaskId) {
    if (!confirm("Delete this subtask?")) return;
    try {
      await apiDelete("/api/v1/tasks/" + taskId + "/subtasks/" + subtaskId);
      loadSubtasks(taskId);
    } catch (e) {
      alert("Failed to delete subtask: " + e.message);
    }
  }

  // ---------------------------------------------------------------- //
  // Attachments
  // ---------------------------------------------------------------- //

  async function loadAttachments(taskId) {
    try {
      var resp = await apiGet("/api/v1/tasks/" + taskId + "/attachments");
      var attachments = resp.data || [];
      renderAttachmentList(attachments, taskId);
      document.getElementById("attachment-count").textContent = attachments.length;
    } catch (_) {}
  }

  function renderAttachmentList(attachments, taskId) {
    var list = document.getElementById("attachment-list");
    list.innerHTML = "";
    attachments.forEach(function (att) {
      list.appendChild(buildAttachmentItem(att, taskId));
    });
  }

  function buildAttachmentItem(att, taskId) {
    var li = document.createElement("li");
    li.className = "attachment-item";
    li.setAttribute("data-id", att.id);

    // Extension label from filename
    var ext = att.filename && att.filename.includes(".")
      ? att.filename.split(".").pop().toLowerCase().slice(0, 4)
      : "file";

    var uploader = att.uploader ? (att.uploader.full_name || "User") : "User";
    var createdDate = att.created_at
      ? new Date(att.created_at).toLocaleDateString()
      : "";

    li.innerHTML =
      "<div class=\"att-icon att-icon-" + escHtml(att.file_icon || "other") + "\">" + escHtml(ext) + "</div>" +
      "<div class=\"att-info\">" +
        "<span class=\"att-filename\">" + escHtml(att.filename) + "</span>" +
        "<span class=\"att-meta\">" +
          escHtml(att.file_size_human || "") + " \u00b7 " +
          escHtml(uploader) + " \u00b7 " +
          createdDate +
        "</span>" +
      "</div>" +
      "<div class=\"att-actions\">" +
        "<a href=\"/api/v1/tasks/" + taskId + "/attachments/" + att.id + "/download\"" +
           " class=\"btn-icon att-download\" target=\"_blank\" title=\"Download\">&#8595;</a>" +
        "<button class=\"btn-icon att-delete\" data-id=\"" + att.id + "\" title=\"Delete\">&#215;</button>" +
      "</div>";

    li.querySelector(".att-delete").addEventListener("click", function () {
      deleteAttachment(taskId, att.id);
    });

    return li;
  }

  function uploadFiles(taskId, files) {
    var csrfMeta = document.querySelector("meta[name=\"csrf-token\"]");
    var csrfToken = csrfMeta ? csrfMeta.getAttribute("content") : "";

    var formData = new FormData();
    for (var i = 0; i < files.length; i++) {
      formData.append("files[]", files[i]);
    }

    var progressWrap = document.getElementById("upload-progress");
    var progressBar  = document.getElementById("upload-progress-bar");
    var progressLabel = document.getElementById("upload-progress-label");

    progressWrap.classList.remove("hidden", "error");
    progressBar.style.width = "0%";
    progressLabel.textContent = "Uploading...";

    var xhr = new XMLHttpRequest();

    xhr.upload.onprogress = function (e) {
      if (e.lengthComputable) {
        var pct = Math.round((e.loaded / e.total) * 100);
        progressBar.style.width = pct + "%";
        progressLabel.textContent = "Uploading... " + pct + "%";
      }
    };

    xhr.onload = function () {
      progressWrap.classList.add("hidden");
      progressBar.style.width = "0%";

      var json = null;
      try { json = JSON.parse(xhr.responseText); } catch (_) {}

      if (xhr.status >= 200 && xhr.status < 300) {
        // Show partial errors if any
        if (json && json.meta && json.meta.errors && json.meta.errors.length > 0) {
          var msgs = json.meta.errors.map(function (err) {
            return (err.filename || "file") + ": " + err.error;
          });
          showUploadErrors(msgs);
        }
        loadAttachments(taskId);
      } else {
        progressWrap.classList.remove("hidden");
        progressWrap.classList.add("error");
        progressBar.style.width = "100%";
        var errMsg = (json && json.error) ? json.error : "Upload failed (HTTP " + xhr.status + ")";
        progressLabel.textContent = errMsg;
        setTimeout(function () {
          progressWrap.classList.add("hidden");
          progressWrap.classList.remove("error");
        }, 4000);
      }
    };

    xhr.onerror = function () {
      progressWrap.classList.remove("hidden");
      progressWrap.classList.add("error");
      progressBar.style.width = "100%";
      progressLabel.textContent = "Network error during upload.";
      setTimeout(function () {
        progressWrap.classList.add("hidden");
        progressWrap.classList.remove("error");
      }, 4000);
    };

    xhr.open("POST", "/api/v1/tasks/" + taskId + "/attachments");
    xhr.setRequestHeader("X-CSRFToken", csrfToken);
    xhr.send(formData);
  }

  function showUploadErrors(messages) {
    var zone = document.getElementById("upload-zone");
    var existing = zone.parentNode.querySelector(".upload-error-list");
    if (existing) existing.remove();

    var div = document.createElement("div");
    div.className = "upload-error-list";
    div.style.cssText =
      "background:rgba(224,84,84,0.1);border:1px solid var(--danger);border-radius:4px;" +
      "padding:8px 12px;margin-bottom:8px;font-size:12px;color:var(--danger);";
    div.innerHTML =
      "<strong>Some files were not uploaded:</strong><ul style=\"margin:4px 0 0 16px;padding:0;\">" +
      messages.map(function (m) { return "<li>" + escHtml(m) + "</li>"; }).join("") +
      "</ul>";

    zone.parentNode.insertBefore(div, zone);

    setTimeout(function () { div.remove(); }, 6000);
  }

  async function deleteAttachment(taskId, attachmentId) {
    if (!confirm("Delete this attachment?")) return;
    try {
      await apiDelete("/api/v1/tasks/" + taskId + "/attachments/" + attachmentId);
      loadAttachments(taskId);
    } catch (e) {
      alert("Failed to delete attachment: " + e.message);
    }
  }

  // ---------------------------------------------------------------- //
  // Actions
  // ---------------------------------------------------------------- //

  async function saveDescription() {
    if (!currentTaskId) return;
    var description = document.getElementById("tm-description").value;
    try {
      var resp = await apiPatch("/api/v1/tasks/" + currentTaskId, { description: description });
      if (global.refreshTaskCard) global.refreshTaskCard(resp.data);
    } catch (e) {
      alert("Failed to save description: " + e.message);
    }
  }

  async function submitComment(e) {
    e.preventDefault();
    if (!currentTaskId) return;
    var input   = document.getElementById("tm-comment-input");
    var content = input.value.trim();
    if (!content) return;
    try {
      await apiPost("/api/v1/tasks/" + currentTaskId + "/comments", { content: content });
      input.value = "";
      // Re-fetch comments
      var taskResp = await apiGet("/api/v1/tasks/" + currentTaskId);
      renderComments(taskResp.data.comments || []);
    } catch (e) {
      alert("Failed to post comment: " + e.message);
    }
  }

  async function submitTimeLog(e) {
    e.preventDefault();
    if (!currentTaskId) return;
    var hours       = parseFloat(document.getElementById("tm-log-hours").value);
    var logged_date = document.getElementById("tm-log-date").value;
    var description = document.getElementById("tm-log-desc").value.trim();
    if (!hours || hours <= 0) { alert("Enter valid hours."); return; }
    try {
      await apiPost("/api/v1/tasks/" + currentTaskId + "/time", { hours: hours, logged_date: logged_date, description: description });
      document.getElementById("tm-log-hours").value = "";
      document.getElementById("tm-log-desc").value  = "";
      var taskResp = await apiGet("/api/v1/tasks/" + currentTaskId);
      renderTimeLogs(taskResp.data.time_logs || []);
      document.getElementById("tm-actual-hours").textContent = taskResp.data.actual_hours || "0";
      if (global.refreshTaskCard) global.refreshTaskCard(taskResp.data);
    } catch (e) {
      alert("Failed to log time: " + e.message);
    }
  }

  async function changeStatus() {
    if (!currentTaskId) return;
    var statusId = parseInt(document.getElementById("tm-status").value, 10);
    try {
      var resp = await apiPatch("/api/v1/tasks/" + currentTaskId + "/status", { status_id: statusId });
      if (global.refreshTaskCard) global.refreshTaskCard(resp.data);
    } catch (e) {
      alert("Failed to change status: " + e.message);
    }
  }

  async function saveFields() {
    if (!currentTaskId) return;
    var priority     = document.getElementById("tm-priority").value;
    var due_date     = document.getElementById("tm-due-date").value || null;
    var estimated    = document.getElementById("tm-estimated").value;
    var title        = document.getElementById("tm-title").value.trim();
    var assignee_sel = document.getElementById("tm-assignee");
    var assignee_id  = assignee_sel.style.display !== "none" && assignee_sel.value
      ? parseInt(assignee_sel.value, 10)
      : undefined;

    var body = { title: title, priority: priority, due_date: due_date };
    if (estimated !== "") body.estimated_hours = parseFloat(estimated);
    if (assignee_id !== undefined) body.assignee_id = assignee_id || null;

    try {
      var resp = await apiPatch("/api/v1/tasks/" + currentTaskId, body);
      if (global.refreshTaskCard) global.refreshTaskCard(resp.data);
      // Update assignee display
      if (assignee_id !== undefined) {
        var sel = document.getElementById("tm-assignee");
        var selectedOpt = sel.options[sel.selectedIndex];
        document.getElementById("tm-assignee-display").textContent =
          assignee_id ? selectedOpt.textContent : "Unassigned";
      }
    } catch (e) {
      alert("Failed to save changes: " + e.message);
    }
  }

  // ---------------------------------------------------------------- //
  // Utilities
  // ---------------------------------------------------------------- //

  function buildTypeStyle(type) {
    var map = {
      task:    "background:#4f6ef720;color:#4f6ef7;",
      bug:     "background:#e0545420;color:#e05454;",
      feature: "background:#3ecf8e20;color:#3ecf8e;",
      story:   "background:#f0a42920;color:#f0a429;",
    };
    return (map[type] || map.task) + "padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;";
  }

  function escHtml(str) {
    if (!str) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

}(window));

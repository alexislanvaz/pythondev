/**
 * charts.js
 * Dashboard chart initialization module.
 * Depends on ECharts 5 and ApexCharts loaded globally.
 */

(function (global) {
  "use strict";

  // ------------------------------------------------------------------ //
  // Palette constants
  // ------------------------------------------------------------------ //

  var ACCENT  = "#4f6ef7";
  var SUCCESS = "#3ecf8e";
  var MUTED   = "#7b80a0";
  var BG      = "#1a1d27";
  var SURFACE = "#22263a";
  var BORDER  = "#2e3248";
  var TEXT    = "#e2e4ef";

  // ------------------------------------------------------------------ //
  // ApexCharts dark theme base
  // ------------------------------------------------------------------ //

  var APEX_THEME = {
    mode: "dark",
    palette: "palette1",
    monochrome: { enabled: false },
  };

  var APEX_CHART_BASE = {
    background: BG,
    toolbar: { show: false },
    fontFamily: "Inter, system-ui, sans-serif",
    foreColor: MUTED,
  };

  var APEX_GRID = {
    borderColor: BORDER,
    strokeDashArray: 3,
  };

  // ------------------------------------------------------------------ //
  // 1. Burndown chart (ECharts line)
  // ------------------------------------------------------------------ //

  /**
   * @param {string} containerId
   * @param {object} data  { sprint_name, ideal: [[date, h], ...], actual: [[date, h], ...] }
   * @returns {object} ECharts instance
   */
  function initBurndownChart(containerId, data) {
    var el = document.getElementById(containerId);
    if (!el || !data) return null;

    el.classList.remove("skeleton");

    var chart = echarts.init(el, null, { renderer: "canvas" });

    var idealData  = (data.ideal  || []).map(function (p) { return [p[0], p[1]]; });
    var actualData = (data.actual || []).map(function (p) { return [p[0], p[1]]; });

    var option = {
      backgroundColor: BG,
      textStyle: { fontFamily: "Inter, system-ui, sans-serif", color: TEXT },
      legend: {
        top: 6,
        right: 12,
        itemWidth: 14,
        itemHeight: 10,
        textStyle: { color: MUTED, fontSize: 11 },
        data: ["Ideal", "Actual"],
      },
      tooltip: {
        trigger: "axis",
        backgroundColor: SURFACE,
        borderColor: BORDER,
        borderWidth: 1,
        textStyle: { color: TEXT, fontSize: 12 },
        formatter: function (params) {
          var date = params[0] ? params[0].axisValue : "";
          var lines = params.map(function (p) {
            return '<span style="color:' + p.color + '">' + p.seriesName + "</span>: " + p.value[1] + "h";
          });
          return "<div style='margin-bottom:4px;color:" + MUTED + ";font-size:11px'>" + date + "</div>" + lines.join("<br>");
        },
      },
      grid: {
        top: 44,
        bottom: 28,
        left: 44,
        right: 16,
        containLabel: false,
      },
      xAxis: {
        type: "time",
        axisLine:  { lineStyle: { color: BORDER } },
        axisTick:  { lineStyle: { color: BORDER } },
        axisLabel: { color: MUTED, fontSize: 11 },
        splitLine: { lineStyle: { color: BORDER, type: "dashed" } },
      },
      yAxis: {
        type: "value",
        name: "Hours",
        nameTextStyle: { color: MUTED, fontSize: 11 },
        axisLine:  { show: false },
        axisTick:  { show: false },
        axisLabel: { color: MUTED, fontSize: 11 },
        splitLine: { lineStyle: { color: BORDER, type: "dashed" } },
      },
      series: [
        {
          name: "Ideal",
          type: "line",
          smooth: false,
          data: idealData,
          symbol: "none",
          lineStyle: { color: MUTED, type: "dashed", width: 1.5 },
          itemStyle: { color: MUTED },
        },
        {
          name: "Actual",
          type: "line",
          smooth: true,
          data: actualData,
          symbol: "circle",
          symbolSize: 5,
          lineStyle: { color: ACCENT, width: 2 },
          itemStyle: { color: ACCENT },
          areaStyle: {
            color: {
              type: "linear",
              x: 0, y: 0, x2: 0, y2: 1,
              colorStops: [
                { offset: 0, color: ACCENT + "40" },
                { offset: 1, color: ACCENT + "00" },
              ],
            }
          },
        },
      ],
    };

    chart.setOption(option);
    window.addEventListener("resize", function () { chart.resize(); });
    return chart;
  }

  // ------------------------------------------------------------------ //
  // 2. Tasks donut chart (ApexCharts)
  // ------------------------------------------------------------------ //

  /**
   * @param {string} containerId
   * @param {Array}  data  [{ status_name, color, count }, ...]
   * @returns {object} ApexCharts instance
   */
  function initTasksDonut(containerId, data) {
    var el = document.getElementById(containerId);
    if (!el || !data || data.length === 0) return null;

    el.classList.remove("skeleton");
    el.innerHTML = "";

    var labels = data.map(function (d) { return d.status_name; });
    var series = data.map(function (d) { return d.count; });
    var colors = data.map(function (d) { return d.color || ACCENT; });
    var total  = series.reduce(function (a, b) { return a + b; }, 0);

    var options = {
      chart: Object.assign({}, APEX_CHART_BASE, {
        type: "donut",
        height: 220,
      }),
      theme: APEX_THEME,
      series: series,
      labels: labels,
      colors: colors,
      legend: {
        position: "bottom",
        fontSize: "11px",
        labels: { colors: Array(labels.length).fill(MUTED) },
        markers: { width: 9, height: 9, radius: 2 },
      },
      plotOptions: {
        pie: {
          donut: {
            size: "70%",
            labels: {
              show: true,
              total: {
                show: true,
                label: "Total",
                fontSize: "11px",
                color: MUTED,
                formatter: function () { return total; },
              },
              value: {
                fontSize: "22px",
                fontWeight: 700,
                color: TEXT,
              },
            },
          },
        },
      },
      dataLabels: { enabled: false },
      stroke: { width: 2, colors: [BG] },
      tooltip: {
        theme: "dark",
        fillSeriesColor: false,
        y: {
          formatter: function (val) { return val + " tasks"; },
        },
      },
    };

    var chart = new ApexCharts(el, options);
    chart.render();
    return chart;
  }

  // ------------------------------------------------------------------ //
  // 3. Assignees bar chart (ApexCharts horizontal stacked bar)
  // ------------------------------------------------------------------ //

  /**
   * @param {string} containerId
   * @param {Array}  data  [{ full_name, pending, completed }, ...]
   * @returns {object} ApexCharts instance
   */
  function initAssigneesBar(containerId, data) {
    var el = document.getElementById(containerId);
    if (!el || !data || data.length === 0) return null;

    el.classList.remove("skeleton");
    el.innerHTML = "";

    var names     = data.map(function (d) { return d.full_name; });
    var pending   = data.map(function (d) { return d.pending; });
    var completed = data.map(function (d) { return d.completed; });

    var barH = Math.max(names.length * 32 + 60, 180);

    var options = {
      chart: Object.assign({}, APEX_CHART_BASE, {
        type: "bar",
        height: barH,
        stacked: true,
      }),
      theme: APEX_THEME,
      series: [
        { name: "Pending",   data: pending },
        { name: "Completed", data: completed },
      ],
      colors: [ACCENT, SUCCESS],
      plotOptions: {
        bar: {
          horizontal: true,
          borderRadius: 3,
          barHeight: "55%",
        },
      },
      xaxis: {
        categories: names,
        labels: {
          style: { colors: MUTED, fontSize: "11px" },
        },
        axisBorder: { color: BORDER },
        axisTicks:  { color: BORDER },
      },
      yaxis: {
        labels: {
          style: { colors: MUTED, fontSize: "11px" },
          maxWidth: 120,
        },
      },
      grid: APEX_GRID,
      legend: {
        position: "top",
        horizontalAlign: "right",
        fontSize: "11px",
        labels: { colors: [MUTED, MUTED] },
        markers: { width: 9, height: 9, radius: 2 },
      },
      tooltip: {
        theme: "dark",
        y: {
          formatter: function (val) { return val + " tasks"; },
        },
      },
      dataLabels: { enabled: false },
    };

    var chart = new ApexCharts(el, options);
    chart.render();
    return chart;
  }

  // ------------------------------------------------------------------ //
  // 4. initAllDashboardCharts
  // ------------------------------------------------------------------ //

  /**
   * @param {object} statsData  Full response from /api/v1/dashboard/stats
   */
  function initAllDashboardCharts(statsData) {
    if (!statsData) return;

    // Burndown
    if (statsData.active_sprint_burndown) {
      initBurndownChart("chart-burndown", statsData.active_sprint_burndown);
    }

    // Donut
    if (statsData.tasks_by_status && statsData.tasks_by_status.length) {
      initTasksDonut("chart-tasks-status", statsData.tasks_by_status);
    }

    // Assignees bar
    if (statsData.tasks_by_assignee && statsData.tasks_by_assignee.length) {
      initAssigneesBar("chart-assignees", statsData.tasks_by_assignee);
    }
  }

  // ------------------------------------------------------------------ //
  // Expose
  // ------------------------------------------------------------------ //

  global.PMCharts = {
    initBurndownChart:      initBurndownChart,
    initTasksDonut:         initTasksDonut,
    initAssigneesBar:       initAssigneesBar,
    initAllDashboardCharts: initAllDashboardCharts,
  };

})(window);

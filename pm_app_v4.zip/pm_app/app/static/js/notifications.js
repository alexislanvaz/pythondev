/**
 * notifications.js
 * Handles the notification bell, unread badge, dropdown list, and polling.
 * Depends on api.js being loaded first.
 */

(function () {
  "use strict";

  const POLL_INTERVAL_MS = 30000;

  let dropdownEl  = null;
  let badgeEl     = null;
  let bellBtn     = null;
  let dropVisible = false;

  // ---------------------------------------------------------------- //
  // Bootstrap on DOMContentLoaded
  // ---------------------------------------------------------------- //

  document.addEventListener("DOMContentLoaded", function () {
    bellBtn = document.querySelector(".notif-btn");
    badgeEl = document.getElementById("notif-count");

    if (!bellBtn) return;

    buildDropdown();
    fetchUnreadCount();
    setInterval(fetchUnreadCount, POLL_INTERVAL_MS);

    bellBtn.addEventListener("click", function (e) {
      e.stopPropagation();
      toggleDropdown();
    });

    document.addEventListener("click", function () {
      if (dropVisible) hideDropdown();
    });
  });

  // ---------------------------------------------------------------- //
  // Unread count
  // ---------------------------------------------------------------- //

  async function fetchUnreadCount() {
    try {
      const resp = await apiGet("/api/v1/notifications/unread-count");
      const count = (resp.data && resp.data.count) || 0;
      if (badgeEl) {
        badgeEl.textContent = count > 0 ? (count > 99 ? "99+" : String(count)) : "";
      }
    } catch (_) {}
  }

  // ---------------------------------------------------------------- //
  // Dropdown
  // ---------------------------------------------------------------- //

  function buildDropdown() {
    dropdownEl = document.createElement("div");
    dropdownEl.id = "notif-dropdown";
    dropdownEl.className = "notif-dropdown";
    dropdownEl.innerHTML = `
      <div class="notif-dropdown__header">
        <span>Notifications</span>
        <button class="btn-link" id="notif-read-all">Mark all read</button>
      </div>
      <div class="notif-dropdown__body" id="notif-list">
        <span class="text-muted" style="font-size:12px;padding:12px;display:block;">Loading...</span>
      </div>
    `;
    dropdownEl.style.display = "none";
    dropdownEl.addEventListener("click", function (e) { e.stopPropagation(); });

    document.getElementById("notif-read-all") ||
      dropdownEl.querySelector("#notif-read-all").addEventListener("click", markAllRead);

    // Attach after bellBtn's parent
    bellBtn.parentNode.style.position = "relative";
    bellBtn.parentNode.appendChild(dropdownEl);

    dropdownEl.querySelector("#notif-read-all").addEventListener("click", markAllRead);
  }

  function toggleDropdown() {
    if (dropVisible) {
      hideDropdown();
    } else {
      showDropdown();
    }
  }

  async function showDropdown() {
    dropdownEl.style.display = "block";
    dropVisible = true;
    await loadNotifications();
  }

  function hideDropdown() {
    dropdownEl.style.display = "none";
    dropVisible = false;
  }

  // ---------------------------------------------------------------- //
  // Load notifications list
  // ---------------------------------------------------------------- //

  async function loadNotifications() {
    const list = document.getElementById("notif-list");
    list.innerHTML = "<span class='text-muted' style='font-size:12px;padding:12px;display:block;'>Loading...</span>";
    try {
      const resp  = await apiGet("/api/v1/notifications");
      const notifs = resp.data || [];
      renderList(notifs);
    } catch (_) {
      list.innerHTML = "<span class='text-muted' style='font-size:12px;padding:12px;display:block;'>Failed to load.</span>";
    }
  }

  function renderList(notifs) {
    const list = document.getElementById("notif-list");
    if (!notifs.length) {
      list.innerHTML = "<span class='text-muted' style='font-size:12px;padding:12px;display:block;'>No notifications.</span>";
      return;
    }
    list.innerHTML = "";
    notifs.forEach(function (n) {
      const el = buildNotifItem(n);
      list.appendChild(el);
    });
  }

  function buildNotifItem(n) {
    const el = document.createElement("div");
    el.className = "notif-item" + (n.is_read ? "" : " notif-item--unread");
    el.dataset.notifId = n.id;

    const date = new Date(n.created_at).toLocaleString("en-US", {
      month: "short", day: "numeric", hour: "2-digit", minute: "2-digit",
    });

    el.innerHTML = `
      <div class="notif-item__title">${escHtml(n.title)}</div>
      <div class="notif-item__msg">${escHtml(n.message)}</div>
      <div class="notif-item__date text-muted">${date}</div>
    `;

    el.addEventListener("click", function () {
      handleNotifClick(n);
    });

    return el;
  }

  async function handleNotifClick(n) {
    if (!n.is_read) {
      try {
        await apiPatch(`/api/v1/notifications/${n.id}/read`, {});
        fetchUnreadCount();
        const el = document.querySelector(`.notif-item[data-notif-id="${n.id}"]`);
        if (el) el.classList.remove("notif-item--unread");
      } catch (_) {}
    }

    // Navigate to entity if applicable
    if (n.entity_type === "task" && n.entity_id) {
      hideDropdown();
      if (typeof openTaskModal === "function") {
        openTaskModal(n.entity_id);
      }
    } else if (n.entity_type === "project" && n.entity_id) {
      window.location.href = `/projects/${n.entity_id}/board`;
    }
  }

  async function markAllRead() {
    try {
      await apiPost("/api/v1/notifications/read-all", {});
      fetchUnreadCount();
      await loadNotifications();
    } catch (_) {}
  }

  // ---------------------------------------------------------------- //
  // Utility
  // ---------------------------------------------------------------- //

  function escHtml(str) {
    if (!str) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

}());

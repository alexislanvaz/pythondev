/**
 * api.js
 * Lightweight fetch wrapper.
 * Injects X-CSRFToken from <meta name="csrf-token"> on mutating requests.
 * All functions return the parsed JSON response body.
 * Throws an Error with the server-supplied .error string on non-2xx responses.
 */

(function (global) {
  "use strict";

  function getCsrfToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    return meta ? meta.getAttribute("content") : "";
  }

  async function request(method, url, body) {
    const headers = { "Content-Type": "application/json" };
    const mutating = ["POST", "PATCH", "PUT", "DELETE"].includes(method.toUpperCase());

    if (mutating) {
      headers["X-CSRFToken"] = getCsrfToken();
    }

    const opts = { method: method.toUpperCase(), headers };
    if (body !== undefined && body !== null) {
      opts.body = JSON.stringify(body);
    }

    const response = await fetch(url, opts);
    let json;
    try {
      json = await response.json();
    } catch (_) {
      json = null;
    }

    if (!response.ok) {
      const msg = (json && json.error) ? json.error : `HTTP ${response.status}`;
      throw new Error(msg);
    }

    return json;
  }

  global.apiGet    = function (url)        { return request("GET",    url); };
  global.apiPost   = function (url, body)  { return request("POST",   url, body); };
  global.apiPatch  = function (url, body)  { return request("PATCH",  url, body); };
  global.apiDelete = function (url)        { return request("DELETE", url); };

}(window));

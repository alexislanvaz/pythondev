"""
Epics HTML blueprint package.
"""

from flask import Blueprint

epics_bp = Blueprint(
    "epics",
    __name__,
    template_folder="templates",
)

from app.epics import routes  # noqa: E402,F401

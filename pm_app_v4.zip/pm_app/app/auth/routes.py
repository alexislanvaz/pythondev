"""
Authentication routes: login, logout, register, profile.
"""

from datetime import datetime

from flask import flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required, login_user, logout_user

from app.auth import auth_bp
from app.auth.forms import ChangePasswordForm, EditProfileForm, LoginForm, RegisterForm
from app.auth.utils import check_password, hash_password
from app.database.models import User
from app.extensions import db


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.index"))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data.lower().strip()).first()

        if user and user.is_active and check_password(form.password.data, user.password_hash):
            login_user(user, remember=form.remember_me.data)
            user.last_login = datetime.utcnow()
            db.session.commit()

            next_page = request.args.get("next")
            return redirect(next_page or url_for("dashboard.index"))
        else:
            flash("Invalid email or password.", "danger")

    return render_template("auth/login.html", form=form)


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been signed out.", "info")
    return redirect(url_for("auth.login"))


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.index"))

    form = RegisterForm()
    if form.validate_on_submit():
        # Check for existing username or email
        existing_user = User.query.filter(
            (User.username == form.username.data.strip()) |
            (User.email == form.email.data.lower().strip())
        ).first()

        if existing_user:
            if existing_user.username == form.username.data.strip():
                flash("Username already taken.", "danger")
            else:
                flash("Email address already registered.", "danger")
        else:
            new_user = User(
                username=form.username.data.strip(),
                email=form.email.data.lower().strip(),
                full_name=form.full_name.data.strip() if form.full_name.data else None,
                password_hash=hash_password(form.password.data),
                role_id=3,  # developer by default
                is_active=True,
            )
            db.session.add(new_user)
            db.session.commit()

            flash("Account created. Please sign in.", "success")
            return redirect(url_for("auth.login"))

    return render_template("auth/register.html", form=form)


@auth_bp.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    edit_form = EditProfileForm(prefix="edit")
    pw_form = ChangePasswordForm(prefix="pw")

    if edit_form.submit.data and edit_form.validate_on_submit():
        current_user.full_name = edit_form.full_name.data.strip() if edit_form.full_name.data else None
        current_user.avatar_url = edit_form.avatar_url.data.strip() if edit_form.avatar_url.data else None
        current_user.updated_at = datetime.utcnow()
        db.session.commit()
        flash("Profile updated.", "success")
        return redirect(url_for("auth.profile"))

    if pw_form.submit.data and pw_form.validate_on_submit():
        if not check_password(pw_form.current_password.data, current_user.password_hash):
            flash("Current password is incorrect.", "danger")
        else:
            current_user.password_hash = hash_password(pw_form.new_password.data)
            current_user.updated_at = datetime.utcnow()
            db.session.commit()
            flash("Password changed successfully.", "success")
            return redirect(url_for("auth.profile"))

    # Pre-fill edit form on GET
    if request.method == "GET":
        edit_form.full_name.data = current_user.full_name
        edit_form.avatar_url.data = current_user.avatar_url

    return render_template("auth/profile.html", edit_form=edit_form, pw_form=pw_form)

"""
Custom decorators for the auth blueprint.
"""

from functools import wraps

from flask import abort
from flask_login import current_user


def role_required(*roles):
    """
    Restrict a view to users whose role name is in the given list.
    Aborts with 403 if the current user does not have an allowed role.

    Usage:
        @role_required('admin', 'project_manager')
        def my_view():
            ...
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                abort(403)
            role_name = current_user.role.name if current_user.role else None
            if role_name not in roles:
                abort(403)
            return f(*args, **kwargs)
        return decorated_function
    return decorator

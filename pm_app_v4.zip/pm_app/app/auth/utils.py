"""
Utility functions for authentication.
"""

import bcrypt


def hash_password(plain: str) -> str:
    """
    Hash a plaintext password using bcrypt.
    Returns the hashed password as a UTF-8 string.
    """
    hashed = bcrypt.hashpw(plain.encode("utf-8"), bcrypt.gensalt())
    return hashed.decode("utf-8")


def check_password(plain: str, hashed: str) -> bool:
    """
    Verify a plaintext password against a stored bcrypt hash.
    Returns True if they match, False otherwise.
    """
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False


def generate_avatar_initials_url(full_name: str):
    """
    Placeholder for generating an avatar URL based on user initials.
    Returns None until the avatar service is implemented.
    """
    return None

"""
Dashboard routes.
"""

from datetime import date

from flask import redirect, render_template, url_for
from flask_login import current_user, login_required

from app.dashboard import dashboard_bp
from app.database.models import Project, ProjectMember, Task, TaskStatus


@dashboard_bp.route("/")
def root():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.index"))
    return redirect(url_for("auth.login"))


@dashboard_bp.route("/dashboard")
@login_required
def index():
    user_id = current_user.id

    # Count projects where the user is a member or owner
    project_count = (
        ProjectMember.query
        .filter_by(user_id=user_id)
        .count()
    )

    # Count tasks assigned to the user (not in a done category)
    done_status_ids = [
        s.id for s in TaskStatus.query.filter_by(category="done").all()
    ]

    assigned_tasks_query = Task.query.filter_by(assignee_id=user_id)

    pending_count = assigned_tasks_query.filter(
        Task.status_id.notin_(done_status_ids) if done_status_ids else True
    ).count()

    # Count overdue tasks: due_date < today, not done
    today = date.today()
    overdue_count = assigned_tasks_query.filter(
        Task.due_date < today,
        Task.status_id.notin_(done_status_ids) if done_status_ids else True,
    ).count()

    # Recent tasks assigned to the user (last 10)
    recent_tasks = (
        assigned_tasks_query
        .order_by(Task.updated_at.desc())
        .limit(10)
        .all()
    )

    return render_template(
        "dashboard/index.html",
        project_count=project_count,
        pending_count=pending_count,
        overdue_count=overdue_count,
        recent_tasks=recent_tasks,
        today=today,
    )

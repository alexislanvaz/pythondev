<img src="Screenshot.png" width="400px">

# Picture-Puzzle-Game
Picture-Puzzle-Game in HTML, JS, CSS

# Features:
* Picture puzzle with different images and 4 difficulty levels
* Messed up and actual image
* Steps counter
* Seconds counter
* Rules button
* New Game button

# Good Luck!

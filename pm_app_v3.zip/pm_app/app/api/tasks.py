"""
Tasks API blueprint.
Prefix: /api/v1/tasks  (registered via api_bp)
All responses use the envelope: {"data": ..., "error": null, "meta": {}}
"""

from datetime import date, datetime
from flask import Blueprint, request, jsonify
from flask_login import current_user, login_required
from sqlalchemy import func

from app.extensions import db
from app.database.models import (
    Task,
    TaskStatus,
    TaskLabel,
    ProjectMember,
    ActivityLog,
    Comment,
    TimeLog,
    User,
)

tasks_bp = Blueprint("tasks", __name__, url_prefix="/v1/tasks")


# ------------------------------------------------------------------ #
# Helpers
# ------------------------------------------------------------------ #

def _ok(data, meta=None):
    return jsonify({"data": data, "error": None, "meta": meta or {}})


def _err(message, status=400):
    return jsonify({"data": None, "error": message, "meta": {}}), status


def _is_member(project_id, user_id=None):
    uid = user_id or current_user.id
    return ProjectMember.query.filter_by(
        project_id=project_id, user_id=uid
    ).first() is not None


def _member_role(project_id, user_id=None):
    uid = user_id or current_user.id
    pm = ProjectMember.query.filter_by(project_id=project_id, user_id=uid).first()
    return pm.role.name.lower() if pm and pm.role else None


def _task_summary(task):
    """Compact representation used in list and kanban responses."""
    assignee = None
    if task.assignee:
        assignee = {
            "id": task.assignee.id,
            "full_name": task.assignee.full_name,
            "avatar_url": task.assignee.avatar_url,
        }
    status = None
    if task.status:
        status = {
            "id": task.status.id,
            "name": task.status.name,
            "color": task.status.color_hex,
            "category": task.status.category,
        }
    return {
        "id": task.id,
        "title": task.title,
        "type": task.type,
        "priority": task.priority,
        "status": status,
        "assignee": assignee,
        "estimated_hours": float(task.estimated_hours) if task.estimated_hours else None,
        "actual_hours": float(task.actual_hours),
        "due_date": task.due_date.isoformat() if task.due_date else None,
        "order_index": task.order_index,
        "labels": [{"id": l.id, "name": l.name, "color_hex": l.color_hex} for l in task.labels],
        "comment_count": task.comments.filter_by(is_deleted=False).count(),
    }


def _task_detail(task):
    """Full representation for the task detail endpoint."""
    base = _task_summary(task)
    base.update({
        "project_id": task.project_id,
        "epic_id": task.epic_id,
        "sprint_id": task.sprint_id,
        "parent_task_id": task.parent_task_id,
        "description": task.description,
        "reporter_id": task.reporter_id,
        "start_date": task.start_date.isoformat() if task.start_date else None,
        "created_at": task.created_at.isoformat(),
        "updated_at": task.updated_at.isoformat(),
        "comments": _build_comments(task),
        "time_logs": [_tl_dict(tl) for tl in task.time_logs.all()],
        "watchers": [
            {"id": w.id, "full_name": w.full_name, "avatar_url": w.avatar_url}
            for w in task.watchers.all()
        ],
        "dependencies": [d.to_dict() for d in task.dependencies.all()],
    })
    return base


def _build_comments(task):
    top_level = (
        Comment.query
        .filter_by(task_id=task.id, parent_comment_id=None, is_deleted=False)
        .order_by(Comment.created_at.asc())
        .all()
    )
    result = []
    for c in top_level:
        cd = _comment_dict(c)
        cd["replies"] = [
            _comment_dict(r)
            for r in c.replies.filter_by(is_deleted=False)
            .order_by(Comment.created_at.asc())
            .all()
        ]
        result.append(cd)
    return result


def _comment_dict(c):
    return {
        "id": c.id,
        "task_id": c.task_id,
        "parent_comment_id": c.parent_comment_id,
        "content": c.content,
        "created_at": c.created_at.isoformat(),
        "updated_at": c.updated_at.isoformat(),
        "user": {
            "id": c.user.id,
            "full_name": c.user.full_name,
            "avatar_url": c.user.avatar_url,
        } if c.user else None,
    }


def _tl_dict(tl):
    return {
        "id": tl.id,
        "hours": float(tl.hours),
        "description": tl.description,
        "logged_date": tl.logged_date.isoformat(),
        "user": {
            "id": tl.user.id,
            "full_name": tl.user.full_name,
        } if tl.user else None,
    }


def _log_activity(entity_type, entity_id, action, old_value=None, new_value=None):
    entry = ActivityLog(
        entity_type=entity_type,
        entity_id=entity_id,
        user_id=current_user.id,
        action=action,
        old_value=str(old_value) if old_value is not None else None,
        new_value=str(new_value) if new_value is not None else None,
    )
    db.session.add(entry)


# ------------------------------------------------------------------ #
# GET /api/v1/tasks
# ------------------------------------------------------------------ #

@tasks_bp.get("")
@login_required
def list_tasks():
    project_id = request.args.get("project_id", type=int)
    if not project_id:
        return _err("project_id is required")

    if not _is_member(project_id):
        return _err("Forbidden", 403)

    q = Task.query.filter_by(project_id=project_id)

    sprint_id   = request.args.get("sprint_id",   type=int)
    epic_id     = request.args.get("epic_id",     type=int)
    assignee_id = request.args.get("assignee_id", type=int)
    status_id   = request.args.get("status_id",   type=int)
    priority    = request.args.get("priority")
    task_type   = request.args.get("type")

    if sprint_id:
        q = q.filter_by(sprint_id=sprint_id)
    if epic_id:
        q = q.filter_by(epic_id=epic_id)
    if assignee_id:
        q = q.filter_by(assignee_id=assignee_id)
    if status_id:
        q = q.filter_by(status_id=status_id)
    if priority:
        q = q.filter_by(priority=priority)
    if task_type:
        q = q.filter_by(type=task_type)

    tasks = q.order_by(Task.order_index.asc()).all()
    return _ok([_task_summary(t) for t in tasks])


# ------------------------------------------------------------------ #
# POST /api/v1/tasks
# ------------------------------------------------------------------ #

@tasks_bp.post("")
@login_required
def create_task():
    body = request.get_json(silent=True) or {}

    project_id = body.get("project_id")
    title      = body.get("title", "").strip()
    if not project_id or not title:
        return _err("project_id and title are required")

    if not _is_member(project_id):
        return _err("Forbidden", 403)

    status_id = body.get("status_id")
    if not status_id:
        default_status = TaskStatus.query.filter_by(
            project_id=project_id, is_default=True
        ).first()
        if not default_status:
            default_status = TaskStatus.query.filter_by(project_id=project_id).first()
        if not default_status:
            return _err("No task status found for this project")
        status_id = default_status.id

    # Determine next order_index for the target status
    max_idx = db.session.query(func.max(Task.order_index)).filter_by(
        project_id=project_id, status_id=status_id
    ).scalar() or 0

    task = Task(
        project_id=project_id,
        title=title,
        type=body.get("type", "task"),
        priority=body.get("priority", "medium"),
        status_id=status_id,
        assignee_id=body.get("assignee_id"),
        reporter_id=current_user.id,
        epic_id=body.get("epic_id"),
        sprint_id=body.get("sprint_id"),
        estimated_hours=body.get("estimated_hours"),
        due_date=_parse_date(body.get("due_date")),
        start_date=_parse_date(body.get("start_date")),
        description=body.get("description"),
        order_index=max_idx + 1,
    )
    db.session.add(task)
    db.session.flush()

    _log_activity("task", task.id, "task_created", new_value=title)
    db.session.commit()

    return _ok(_task_summary(task)), 201


def _parse_date(value):
    if not value:
        return None
    try:
        return date.fromisoformat(value)
    except (ValueError, TypeError):
        return None


# ------------------------------------------------------------------ #
# GET /api/v1/tasks/<task_id>
# ------------------------------------------------------------------ #

@tasks_bp.get("/<int:task_id>")
@login_required
def get_task(task_id):
    task = Task.query.get_or_404(task_id)
    if not _is_member(task.project_id):
        return _err("Forbidden", 403)
    return _ok(_task_detail(task))


# ------------------------------------------------------------------ #
# PATCH /api/v1/tasks/<task_id>
# ------------------------------------------------------------------ #

@tasks_bp.patch("/<int:task_id>")
@login_required
def update_task(task_id):
    task = Task.query.get_or_404(task_id)
    if not _is_member(task.project_id):
        return _err("Forbidden", 403)

    body = request.get_json(silent=True) or {}

    editable = {
        "title", "description", "priority", "assignee_id",
        "epic_id", "sprint_id", "estimated_hours", "due_date", "start_date",
    }

    for field in editable:
        if field not in body:
            continue
        old_val = getattr(task, field)
        if field in ("due_date", "start_date"):
            new_val = _parse_date(body[field])
        else:
            new_val = body[field]
        setattr(task, field, new_val)
        if old_val != new_val:
            _log_activity("task", task.id, f"field_updated:{field}",
                          old_value=old_val, new_value=new_val)

    task.updated_at = datetime.utcnow()
    db.session.commit()
    return _ok(_task_summary(task))


# ------------------------------------------------------------------ #
# DELETE /api/v1/tasks/<task_id>
# ------------------------------------------------------------------ #

@tasks_bp.delete("/<int:task_id>")
@login_required
def delete_task(task_id):
    task = Task.query.get_or_404(task_id)
    role = _member_role(task.project_id)
    if role not in ("project_manager", "admin", "owner"):
        return _err("Only project managers or admins can delete tasks", 403)
    db.session.delete(task)
    db.session.commit()
    return _ok("deleted")


# ------------------------------------------------------------------ #
# PATCH /api/v1/tasks/<task_id>/status
# ------------------------------------------------------------------ #

@tasks_bp.patch("/<int:task_id>/status")
@login_required
def change_status(task_id):
    task = Task.query.get_or_404(task_id)
    if not _is_member(task.project_id):
        return _err("Forbidden", 403)

    body = request.get_json(silent=True) or {}
    new_status_id = body.get("status_id")
    if not new_status_id:
        return _err("status_id is required")

    new_status = TaskStatus.query.filter_by(
        id=new_status_id, project_id=task.project_id
    ).first()
    if not new_status:
        return _err("Invalid status for this project", 400)

    old_status = task.status.name if task.status else None
    old_status_id = task.status_id

    task.status_id = new_status_id
    task.updated_at = datetime.utcnow()

    _log_activity(
        "task", task.id, "status_changed",
        old_value=old_status_id,
        new_value=new_status_id,
    )
    db.session.commit()
    return _ok(_task_summary(task))


# ------------------------------------------------------------------ #
# PATCH /api/v1/tasks/reorder
# ------------------------------------------------------------------ #

@tasks_bp.patch("/reorder")
@login_required
def reorder_tasks():
    body = request.get_json(silent=True) or {}
    updates = body.get("updates", [])

    for item in updates:
        task_id     = item.get("id")
        order_index = item.get("order_index")
        status_id   = item.get("status_id")
        if not task_id:
            continue
        task = Task.query.get(task_id)
        if not task:
            continue
        if not _is_member(task.project_id):
            continue
        if order_index is not None:
            task.order_index = order_index
        if status_id is not None:
            task.status_id = status_id
        task.updated_at = datetime.utcnow()

    db.session.commit()
    return _ok("ok")


# ------------------------------------------------------------------ #
# POST /api/v1/tasks/<task_id>/comments
# ------------------------------------------------------------------ #

@tasks_bp.post("/<int:task_id>/comments")
@login_required
def add_comment(task_id):
    task = Task.query.get_or_404(task_id)
    if not _is_member(task.project_id):
        return _err("Forbidden", 403)

    body = request.get_json(silent=True) or {}
    content = (body.get("content") or "").strip()
    if not content:
        return _err("content is required")

    parent_id = body.get("parent_comment_id")
    comment = Comment(
        task_id=task_id,
        user_id=current_user.id,
        content=content,
        parent_comment_id=parent_id,
    )
    db.session.add(comment)
    db.session.commit()
    return _ok(_comment_dict(comment)), 201


# ------------------------------------------------------------------ #
# GET /api/v1/tasks/<task_id>/comments
# ------------------------------------------------------------------ #

@tasks_bp.get("/<int:task_id>/comments")
@login_required
def list_comments(task_id):
    task = Task.query.get_or_404(task_id)
    if not _is_member(task.project_id):
        return _err("Forbidden", 403)
    return _ok(_build_comments(task))


# ------------------------------------------------------------------ #
# POST /api/v1/tasks/<task_id>/time
# ------------------------------------------------------------------ #

@tasks_bp.post("/<int:task_id>/time")
@login_required
def log_time(task_id):
    task = Task.query.get_or_404(task_id)
    if not _is_member(task.project_id):
        return _err("Forbidden", 403)

    body = request.get_json(silent=True) or {}
    hours       = body.get("hours")
    description = body.get("description", "")
    logged_date = _parse_date(body.get("logged_date"))

    if hours is None:
        return _err("hours is required")
    if not logged_date:
        logged_date = date.today()

    tl = TimeLog(
        task_id=task_id,
        user_id=current_user.id,
        hours=hours,
        description=description,
        logged_date=logged_date,
    )
    db.session.add(tl)

    # Update actual_hours on the task
    task.actual_hours = float(task.actual_hours) + float(hours)
    task.updated_at = datetime.utcnow()

    db.session.commit()
    return _ok(_tl_dict(tl)), 201


# ------------------------------------------------------------------ #
# GET /api/v1/tasks/<task_id>/subtasks
# ------------------------------------------------------------------ #

@tasks_bp.get("/<int:task_id>/subtasks")
@login_required
def list_subtasks(task_id):
    task = Task.query.get_or_404(task_id)
    if not _is_member(task.project_id):
        return _err("Forbidden", 403)

    subtasks = (
        Task.query
        .filter_by(parent_task_id=task_id)
        .order_by(Task.order_index.asc(), Task.id.asc())
        .all()
    )
    return _ok([_task_summary(s) for s in subtasks])


# ------------------------------------------------------------------ #
# POST /api/v1/tasks/<task_id>/subtasks
# ------------------------------------------------------------------ #

@tasks_bp.post("/<int:task_id>/subtasks")
@login_required
def create_subtask(task_id):
    parent = Task.query.get_or_404(task_id)
    if not _is_member(parent.project_id):
        return _err("Forbidden", 403)

    body = request.get_json(silent=True) or {}
    title = (body.get("title") or "").strip()
    if not title:
        return _err("title is required")

    # Resolve default status for the project
    status_id = body.get("status_id")
    if not status_id:
        default_status = (
            TaskStatus.query
            .filter_by(project_id=parent.project_id, is_default=True)
            .first()
        )
        if not default_status:
            default_status = (
                TaskStatus.query
                .filter_by(project_id=parent.project_id)
                .order_by(TaskStatus.order_index.asc())
                .first()
            )
        if not default_status:
            return _err("No task status found for this project")
        status_id = default_status.id

    # order_index = max existing subtask order_index + 1
    max_idx = (
        db.session.query(func.max(Task.order_index))
        .filter_by(parent_task_id=task_id)
        .scalar()
    ) or 0

    subtask = Task(
        project_id=parent.project_id,
        epic_id=parent.epic_id,
        sprint_id=parent.sprint_id,
        parent_task_id=task_id,
        title=title,
        type=body.get("type", "task"),
        priority=body.get("priority", "medium"),
        status_id=status_id,
        assignee_id=body.get("assignee_id"),
        reporter_id=current_user.id,
        estimated_hours=body.get("estimated_hours"),
        due_date=_parse_date(body.get("due_date")),
        order_index=max_idx + 1,
    )
    db.session.add(subtask)
    db.session.flush()

    _log_activity("task", task_id, "subtask_added", new_value=title)
    db.session.commit()

    return _ok(_task_summary(subtask)), 201


# ------------------------------------------------------------------ #
# PATCH /api/v1/tasks/<task_id>/subtasks/<subtask_id>
# ------------------------------------------------------------------ #

@tasks_bp.patch("/<int:task_id>/subtasks/<int:subtask_id>")
@login_required
def update_subtask(task_id, subtask_id):
    parent = Task.query.get_or_404(task_id)
    if not _is_member(parent.project_id):
        return _err("Forbidden", 403)

    subtask = Task.query.get_or_404(subtask_id)
    if subtask.parent_task_id != task_id:
        return _err("Subtask does not belong to the specified parent task", 400)

    body = request.get_json(silent=True) or {}

    editable = {
        "title", "priority", "assignee_id",
        "estimated_hours", "due_date", "status_id",
    }
    for field in editable:
        if field not in body:
            continue
        if field == "due_date":
            setattr(subtask, field, _parse_date(body[field]))
        elif field == "status_id":
            # Verify the status belongs to the project
            st = TaskStatus.query.filter_by(
                id=body[field], project_id=parent.project_id
            ).first()
            if not st:
                return _err("Invalid status for this project", 400)
            subtask.status_id = st.id
        else:
            setattr(subtask, field, body[field])

    subtask.updated_at = datetime.utcnow()
    db.session.commit()
    return _ok(_task_summary(subtask))


# ------------------------------------------------------------------ #
# DELETE /api/v1/tasks/<task_id>/subtasks/<subtask_id>
# ------------------------------------------------------------------ #

@tasks_bp.delete("/<int:task_id>/subtasks/<int:subtask_id>")
@login_required
def delete_subtask(task_id, subtask_id):
    parent = Task.query.get_or_404(task_id)

    subtask = Task.query.get_or_404(subtask_id)
    if subtask.parent_task_id != task_id:
        return _err("Subtask does not belong to the specified parent task", 400)

    role = _member_role(parent.project_id)
    is_reporter = subtask.reporter_id == current_user.id
    if role not in ("project_manager", "admin", "owner") and not is_reporter:
        return _err("Not authorized to delete this subtask", 403)

    db.session.delete(subtask)
    db.session.commit()
    return _ok("ok")


# ------------------------------------------------------------------ #
# GET /api/v1/tasks/<task_id>/subtasks/summary
# ------------------------------------------------------------------ #

@tasks_bp.get("/<int:task_id>/subtasks/summary")
@login_required
def subtasks_summary(task_id):
    task = Task.query.get_or_404(task_id)
    if not _is_member(task.project_id):
        return _err("Forbidden", 403)

    subtasks = Task.query.filter_by(parent_task_id=task_id).all()
    total = len(subtasks)
    completed = sum(
        1 for s in subtasks
        if s.status and s.status.category == "done"
    )
    percent = round((completed / total * 100.0), 2) if total > 0 else 0.0
    return _ok({"total": total, "completed": completed, "percent": percent})

/**
 * MTS Enterprise - Evidence Tools & Multi-modal Utilities
 * 1. Voice-to-Text Dictation (Web Speech API in Spanish - es-MX/es-ES)
 * 2. Photo Annotation & Drawing Canvas (Touch, Stylus, Mouse with PointerEvents)
 * 3. Standardized Rear Camera Prioritization & Stream Helper
 */

(function (window) {
    'use strict';

    // =========================================================================
    // 1. DICTADO POR VOZ (SPEECH RECOGNITION EN ESPAÑOL)
    // =========================================================================
    const VoiceDictation = {
        recognition: null,
        isListening: false,
        activeTarget: null,
        activeButton: null,

        init() {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            if (!SpeechRecognition) {
                return false;
            }

            this.recognition = new SpeechRecognition();
            this.recognition.lang = 'es-MX';
            this.recognition.continuous = true;
            this.recognition.interimResults = true;

            this.recognition.onstart = () => {
                this.isListening = true;
                this.updateButtonUI(true);
            };

            this.recognition.onresult = (event) => {
                if (!this.activeTarget) return;

                let interimTranscript = '';
                let finalTranscript = '';

                for (let i = event.resultIndex; i < event.results.length; ++i) {
                    const transcript = event.results[i][0].transcript;
                    if (event.results[i].isFinal) {
                        finalTranscript += transcript;
                    } else {
                        interimTranscript += transcript;
                    }
                }

                if (finalTranscript) {
                    const currentVal = this.activeTarget.value;
                    const needsSpace = currentVal.length > 0 && !currentVal.endsWith(' ') && !currentVal.endsWith('\n');
                    this.activeTarget.value = currentVal + (needsSpace ? ' ' : '') + finalTranscript.trim() + ' ';
                    this.activeTarget.dispatchEvent(new Event('input', { bubbles: true }));
                }
            };

            this.recognition.onerror = (event) => {
                console.warn('VoiceDictation error:', event.error);
                if (event.error === 'not-allowed') {
                    if (window.Swal) {
                        Swal.fire({
                            icon: 'warning',
                            title: 'Permiso de Micrófono Denegado',
                            text: 'Por favor habilita los permisos de micrófono en tu navegador para usar el dictado por voz.',
                            confirmButtonColor: 'var(--primary-color)'
                        });
                    }
                }
                this.stop();
            };

            this.recognition.onend = () => {
                this.isListening = false;
                this.updateButtonUI(false);
            };

            return true;
        },

        toggle(targetElement, buttonElement) {
            if (!this.recognition && !this.init()) {
                if (window.Swal) {
                    Swal.fire({
                        icon: 'info',
                        title: 'Dictado no soportado',
                        text: 'Tu navegador actual no soporta la API de reconocimiento de voz. Te recomendamos usar Google Chrome o Edge.',
                        confirmButtonColor: 'var(--primary-color)'
                    });
                }
                return;
            }

            if (this.isListening) {
                if (this.activeTarget === targetElement) {
                    this.stop();
                    return;
                }
                this.stop();
            }

            this.activeTarget = typeof targetElement === 'string' ? document.getElementById(targetElement) : targetElement;
            this.activeButton = typeof buttonElement === 'string' ? document.getElementById(buttonElement) : buttonElement;

            try {
                this.recognition.start();
            } catch (e) {
                console.error('Error starting speech recognition:', e);
                this.stop();
            }
        },

        stop() {
            if (this.recognition && this.isListening) {
                try {
                    this.recognition.stop();
                } catch (e) {}
            }
            this.isListening = false;
            this.updateButtonUI(false);
        },

        updateButtonUI(listening) {
            if (!this.activeButton) return;
            if (listening) {
                this.activeButton.classList.add('voice-btn-active');
                this.activeButton.setAttribute('data-listening', 'true');
                const label = this.activeButton.querySelector('.voice-btn-label');
                if (label) label.textContent = 'Escuchando...';
                const icon = this.activeButton.querySelector('i');
                if (icon) icon.className = 'fa-solid fa-microphone-lines fa-fade text-danger';
            } else {
                this.activeButton.classList.remove('voice-btn-active');
                this.activeButton.removeAttribute('data-listening');
                const label = this.activeButton.querySelector('.voice-btn-label');
                if (label) label.textContent = 'Dictar por voz';
                const icon = this.activeButton.querySelector('i');
                if (icon) icon.className = 'fa-solid fa-microphone';
            }
        }
    };


    // =========================================================================
    // 2. GESTOR DE CÁMARA TRASERA ESTANDARIZADA
    // =========================================================================
    const CameraHelper = {
        async getVideoDevices() {
            if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
                return [];
            }
            const devices = await navigator.mediaDevices.enumerateDevices();
            const videoDevices = devices.filter(d => d.kind === 'videoinput');

            // Priorizar cámaras traseras (Back, Rear, Environment, Trasera, Posterior, 0)
            videoDevices.sort((a, b) => {
                const labelA = (a.label || '').toLowerCase();
                const labelB = (b.label || '').toLowerCase();
                const isBackA = labelA.includes('back') || labelA.includes('rear') || labelA.includes('environment') || labelA.includes('trasera') || labelA.includes('posterior') || labelA.includes('0');
                const isBackB = labelB.includes('back') || labelB.includes('rear') || labelB.includes('environment') || labelB.includes('trasera') || labelB.includes('posterior') || labelB.includes('0');
                if (isBackA && !isBackB) return -1;
                if (!isBackA && isBackB) return 1;
                return 0;
            });

            return videoDevices;
        },

        getCameraConstraints(deviceId) {
            if (deviceId) {
                return {
                    video: {
                        deviceId: { exact: deviceId },
                        width: { ideal: 1920 },
                        height: { ideal: 1080 }
                    }
                };
            }
            return {
                video: {
                    facingMode: { ideal: 'environment' },
                    width: { ideal: 1920 },
                    height: { ideal: 1080 }
                }
            };
        }
    };


    // =========================================================================
    // 3. ANOTACIONES Y DIBUJO RÁPIDO SOBRE FOTOS (CANVAS HTML5 NATIVO)
    // =========================================================================
    const PhotoAnnotator = {
        modalEl: null,
        canvasEl: null,
        ctx: null,
        bgImage: null,
        isDrawing: false,
        currentTool: 'brush', // 'brush', 'arrow', 'circle', 'rect'
        currentColor: '#ef4444', // Red default
        currentLineWidth: 6,
        startX: 0,
        startY: 0,
        history: [],
        maxHistory: 15,
        onSaveCallback: null,
        originalFile: null,

        init() {
            if (this.modalEl) return;

            // Inyectar Estilos CSS del Editor
            const style = document.createElement('style');
            style.innerHTML = `
                .annotator-modal-backdrop {
                    display: none;
                    position: fixed;
                    inset: 0;
                    background: rgba(15, 23, 42, 0.88);
                    backdrop-filter: blur(6px);
                    -webkit-backdrop-filter: blur(6px);
                    z-index: 99999;
                    align-items: center;
                    justify-content: center;
                    padding: 0.75rem;
                }
                .annotator-modal-container {
                    background: var(--bg-card, #ffffff);
                    border: 1px solid var(--border-color, #e2e8f0);
                    border-radius: 16px;
                    width: 100%;
                    max-width: 900px;
                    max-height: 94vh;
                    display: flex;
                    flex-direction: column;
                    overflow: hidden;
                    box-shadow: 0 20px 40px rgba(0,0,0,0.35);
                    animation: annotatorPop 0.2s cubic-bezier(0.16, 1, 0.3, 1);
                }
                @keyframes annotatorPop {
                    from { transform: scale(0.95); opacity: 0; }
                    to { transform: scale(1); opacity: 1; }
                }
                .annotator-header {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    padding: 0.75rem 1.25rem;
                    border-bottom: 1px solid var(--border-color, #e2e8f0);
                    background: var(--bg-main, #f8fafc);
                }
                .annotator-title {
                    margin: 0;
                    font-size: 1rem;
                    font-weight: 700;
                    color: var(--primary-color, #0f766e);
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                }
                .annotator-toolbar {
                    display: flex;
                    flex-wrap: wrap;
                    align-items: center;
                    justify-content: space-between;
                    gap: 0.6rem;
                    padding: 0.6rem 1rem;
                    background: var(--bg-card, #ffffff);
                    border-bottom: 1px solid var(--border-color, #e2e8f0);
                }
                .annotator-tool-group {
                    display: inline-flex;
                    align-items: center;
                    gap: 0.35rem;
                    background: var(--bg-main, #f1f5f9);
                    padding: 0.25rem;
                    border-radius: 10px;
                    border: 1px solid var(--border-color, #e2e8f0);
                }
                .annotator-btn {
                    background: transparent;
                    border: none;
                    border-radius: 8px;
                    padding: 0.4rem 0.65rem;
                    font-size: 0.85rem;
                    font-weight: 600;
                    color: var(--text-secondary, #475569);
                    cursor: pointer;
                    display: inline-flex;
                    align-items: center;
                    gap: 0.35rem;
                    transition: all 0.15s ease;
                    touch-action: manipulation;
                    min-height: 36px;
                }
                .annotator-btn:hover {
                    background: rgba(0,0,0,0.05);
                    color: var(--text-primary, #0f172a);
                }
                .annotator-btn.active {
                    background: var(--primary-color, #0f766e);
                    color: #ffffff !important;
                    box-shadow: 0 2px 6px rgba(15, 118, 110, 0.25);
                }
                .annotator-color-swatch {
                    width: 24px;
                    height: 24px;
                    border-radius: 50%;
                    cursor: pointer;
                    border: 2px solid transparent;
                    transition: transform 0.15s, border-color 0.15s;
                    touch-action: manipulation;
                }
                .annotator-color-swatch:hover {
                    transform: scale(1.15);
                }
                .annotator-color-swatch.active {
                    transform: scale(1.2);
                    border-color: #ffffff;
                    box-shadow: 0 0 0 2px var(--primary-color, #0f766e);
                }
                .annotator-canvas-wrapper {
                    flex: 1;
                    min-height: 280px;
                    max-height: 60vh;
                    background: #0f172a;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    overflow: hidden;
                    position: relative;
                    padding: 0.5rem;
                }
                #annotator-canvas {
                    display: block;
                    max-width: 100%;
                    max-height: 100%;
                    border-radius: 8px;
                    box-shadow: 0 4px 14px rgba(0,0,0,0.5);
                    touch-action: none; /* Esencial para PointerEvents fluidos en touch/lápiz */
                    cursor: crosshair;
                }
                .annotator-footer {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    flex-wrap: wrap;
                    gap: 0.75rem;
                    padding: 0.75rem 1.25rem;
                    border-top: 1px solid var(--border-color, #e2e8f0);
                    background: var(--bg-main, #f8fafc);
                }
                .voice-btn-active {
                    background-color: #ef4444 !important;
                    color: #ffffff !important;
                    border-color: #ef4444 !important;
                    animation: pulseMicrophone 1.5s infinite;
                }
                @keyframes pulseMicrophone {
                    0% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.6); }
                    70% { box-shadow: 0 0 0 10px rgba(239, 68, 68, 0); }
                    100% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
                }
            `;
            document.head.appendChild(style);

            // Inyectar Estructura HTML del Modal
            const modalDiv = document.createElement('div');
            modalDiv.id = 'annotator-modal';
            modalDiv.className = 'annotator-modal-backdrop';
            modalDiv.innerHTML = `
                <div class="annotator-modal-container">
                    <div class="annotator-header">
                        <h3 class="annotator-title">
                            <i class="fa-solid fa-paintbrush"></i> Anotaciones y Marcado de Evidencia
                        </h3>
                        <button type="button" class="btn-close-annotator" onclick="PhotoAnnotator.close()" style="background: transparent; border: none; font-size: 1.25rem; color: var(--text-secondary); cursor: pointer;">
                            <i class="fa-solid fa-xmark"></i>
                        </button>
                    </div>

                    <!-- Toolbar de Herramientas, Colores y Acciones -->
                    <div class="annotator-toolbar">
                        <!-- Herramientas de Dibujo -->
                        <div class="annotator-tool-group">
                            <button type="button" class="annotator-btn active" data-tool="brush" onclick="PhotoAnnotator.setTool('brush', this)" title="Pincel a mano alzada">
                                <i class="fa-solid fa-pen"></i> <span class="d-none d-sm-inline">Pincel</span>
                            </button>
                            <button type="button" class="annotator-btn" data-tool="arrow" onclick="PhotoAnnotator.setTool('arrow', this)" title="Flecha indicadora">
                                <i class="fa-solid fa-arrow-right"></i> <span class="d-none d-sm-inline">Flecha</span>
                            </button>
                            <button type="button" class="annotator-btn" data-tool="circle" onclick="PhotoAnnotator.setTool('circle', this)" title="Círculo de resaltado">
                                <i class="fa-regular fa-circle"></i> <span class="d-none d-sm-inline">Círculo</span>
                            </button>
                            <button type="button" class="annotator-btn" data-tool="rect" onclick="PhotoAnnotator.setTool('rect', this)" title="Rectángulo">
                                <i class="fa-regular fa-square"></i> <span class="d-none d-sm-inline">Cuadro</span>
                            </button>
                        </div>

                        <!-- Paleta de Colores Rápidos -->
                        <div class="annotator-tool-group" style="padding: 0.35rem 0.6rem; gap: 0.5rem;">
                            <div class="annotator-color-swatch active" style="background-color: #ef4444;" onclick="PhotoAnnotator.setColor('#ef4444', this)" title="Rojo (Anomalía)"></div>
                            <div class="annotator-color-swatch" style="background-color: #eab308;" onclick="PhotoAnnotator.setColor('#eab308', this)" title="Amarillo (Precaución)"></div>
                            <div class="annotator-color-swatch" style="background-color: #10b981;" onclick="PhotoAnnotator.setColor('#10b981', this)" title="Verde (Correcto)"></div>
                            <div class="annotator-color-swatch" style="background-color: #3b82f6;" onclick="PhotoAnnotator.setColor('#3b82f6', this)" title="Azul"></div>
                            <div class="annotator-color-swatch" style="background-color: #ffffff;" onclick="PhotoAnnotator.setColor('#ffffff', this)" title="Blanco"></div>
                        </div>

                        <!-- Grosor de Trazo -->
                        <div class="annotator-tool-group">
                            <button type="button" class="annotator-btn" onclick="PhotoAnnotator.setLineWidth(3, this)" title="Fino">Fino</button>
                            <button type="button" class="annotator-btn active" onclick="PhotoAnnotator.setLineWidth(6, this)" title="Medio">Medio</button>
                            <button type="button" class="annotator-btn" onclick="PhotoAnnotator.setLineWidth(12, this)" title="Grueso">Grueso</button>
                        </div>

                        <!-- Deshacer y Limpiar -->
                        <div class="annotator-tool-group">
                            <button type="button" class="annotator-btn" onclick="PhotoAnnotator.undo()" title="Deshacer último trazo">
                                <i class="fa-solid fa-rotate-left"></i> Deshacer
                            </button>
                            <button type="button" class="annotator-btn" onclick="PhotoAnnotator.clearCanvas()" title="Borrar todas las anotaciones">
                                <i class="fa-solid fa-trash-can"></i> Limpiar
                            </button>
                        </div>
                    </div>

                    <!-- Lienzo Interactivo -->
                    <div class="annotator-canvas-wrapper">
                        <canvas id="annotator-canvas"></canvas>
                    </div>

                    <!-- Footer con Acciones de Guardado -->
                    <div class="annotator-footer">
                        <button type="button" class="btn btn-secondary" onclick="PhotoAnnotator.close()" style="min-height: 42px; font-weight: 600; padding: 0.4rem 1rem;">
                            Cancelar
                        </button>
                        <div style="display: flex; gap: 0.6rem; align-items: center;">
                            <button type="button" class="btn btn-secondary" onclick="PhotoAnnotator.saveOriginal()" style="min-height: 42px; font-weight: 600; font-size: 0.84rem; padding: 0.4rem 0.9rem;">
                                Guardar sin marcar
                            </button>
                            <button type="button" class="btn btn-primary" onclick="PhotoAnnotator.saveAnnotated()" style="min-height: 42px; font-weight: 700; font-size: 0.88rem; padding: 0.4rem 1.2rem; background-color: var(--primary-color); display: inline-flex; align-items: center; gap: 0.4rem;">
                                <i class="fa-solid fa-check"></i> Adjuntar Evidencia
                            </button>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(modalDiv);

            this.modalEl = modalDiv;
            this.canvasEl = document.getElementById('annotator-canvas');
            this.ctx = this.canvasEl.getContext('2d');

            this.bindEvents();
        },

        bindEvents() {
            // Unificado con PointerEvents (Mouse, Lápiz Óptico/Stylus y Touch sin lag)
            this.canvasEl.addEventListener('pointerdown', (e) => this.onPointerDown(e));
            this.canvasEl.addEventListener('pointermove', (e) => this.onPointerMove(e));
            this.canvasEl.addEventListener('pointerup', (e) => this.onPointerUp(e));
            this.canvasEl.addEventListener('pointercancel', (e) => this.onPointerUp(e));
        },

        getCanvasCoords(e) {
            const rect = this.canvasEl.getBoundingClientRect();
            const scaleX = this.canvasEl.width / rect.width;
            const scaleY = this.canvasEl.height / rect.height;
            return {
                x: (e.clientX - rect.left) * scaleX,
                y: (e.clientY - rect.top) * scaleY
            };
        },

        onPointerDown(e) {
            e.preventDefault();
            this.isDrawing = true;
            this.canvasEl.setPointerCapture(e.pointerId);

            const coords = this.getCanvasCoords(e);
            this.startX = coords.x;
            this.startY = coords.y;

            // Guardar estado previo para Undo o preview de formas
            this.saveStateToHistory();

            this.ctx.strokeStyle = this.currentColor;
            this.ctx.fillStyle = this.currentColor;
            this.ctx.lineWidth = this.currentLineWidth;
            this.ctx.lineCap = 'round';
            this.ctx.lineJoin = 'round';

            if (this.currentTool === 'brush') {
                this.ctx.beginPath();
                this.ctx.moveTo(this.startX, this.startY);
                this.ctx.lineTo(this.startX, this.startY);
                this.ctx.stroke();
            }
        },

        onPointerMove(e) {
            if (!this.isDrawing) return;
            e.preventDefault();

            const coords = this.getCanvasCoords(e);
            const currentX = coords.x;
            const currentY = coords.y;

            if (this.currentTool === 'brush') {
                this.ctx.lineTo(currentX, currentY);
                this.ctx.stroke();
            } else {
                // Para formas geométricas (Flecha, Círculo, Rectángulo), restauramos el último snapshot y previsualizamos
                this.restoreLatestSnapshot();
                this.ctx.strokeStyle = this.currentColor;
                this.ctx.fillStyle = this.currentColor;
                this.ctx.lineWidth = this.currentLineWidth;
                this.ctx.lineCap = 'round';
                this.ctx.lineJoin = 'round';

                if (this.currentTool === 'arrow') {
                    this.drawArrow(this.startX, this.startY, currentX, currentY);
                } else if (this.currentTool === 'rect') {
                    this.drawRect(this.startX, this.startY, currentX, currentY);
                } else if (this.currentTool === 'circle') {
                    this.drawCircle(this.startX, this.startY, currentX, currentY);
                }
            }
        },

        onPointerUp(e) {
            if (!this.isDrawing) return;
            e.preventDefault();
            this.isDrawing = false;
            try {
                this.canvasEl.releasePointerCapture(e.pointerId);
            } catch (err) {}

            if (this.currentTool === 'brush') {
                this.ctx.closePath();
            }
        },

        drawArrow(fromX, fromY, toX, toY) {
            const headlen = Math.max(14, this.currentLineWidth * 3.2);
            const angle = Math.atan2(toY - fromY, toX - fromX);

            // Línea del cuerpo
            this.ctx.beginPath();
            this.ctx.moveTo(fromX, fromY);
            this.ctx.lineTo(toX, toY);
            this.ctx.stroke();

            // Punta de la flecha
            this.ctx.beginPath();
            this.ctx.moveTo(toX, toY);
            this.ctx.lineTo(toX - headlen * Math.cos(angle - Math.PI / 6), toY - headlen * Math.sin(angle - Math.PI / 6));
            this.ctx.lineTo(toX - headlen * Math.cos(angle + Math.PI / 6), toY - headlen * Math.sin(angle + Math.PI / 6));
            this.ctx.closePath();
            this.ctx.fill();
        },

        drawRect(fromX, fromY, toX, toY) {
            const width = toX - fromX;
            const height = toY - fromY;
            this.ctx.beginPath();
            this.ctx.strokeRect(fromX, fromY, width, height);
        },

        drawCircle(fromX, fromY, toX, toY) {
            const radiusX = Math.abs(toX - fromX) / 2;
            const radiusY = Math.abs(toY - fromY) / 2;
            const centerX = fromX + (toX - fromX) / 2;
            const centerY = fromY + (toY - fromY) / 2;

            this.ctx.beginPath();
            this.ctx.ellipse(centerX, centerY, radiusX, radiusY, 0, 0, 2 * Math.PI);
            this.ctx.stroke();
        },

        saveStateToHistory() {
            if (this.history.length >= this.maxHistory) {
                this.history.shift();
            }
            this.history.push(this.ctx.getImageData(0, 0, this.canvasEl.width, this.canvasEl.height));
        },

        restoreLatestSnapshot() {
            if (this.history.length > 0) {
                const latest = this.history[this.history.length - 1];
                this.ctx.putImageData(latest, 0, 0);
            }
        },

        undo() {
            if (this.history.length > 1) {
                this.history.pop(); // Eliminar estado actual
                const prevState = this.history[this.history.length - 1];
                this.ctx.putImageData(prevState, 0, 0);
            } else if (this.history.length === 1) {
                this.clearCanvas();
            }
        },

        clearCanvas() {
            if (!this.bgImage) return;
            this.ctx.clearRect(0, 0, this.canvasEl.width, this.canvasEl.height);
            this.ctx.drawImage(this.bgImage, 0, 0, this.canvasEl.width, this.canvasEl.height);
            this.history = [this.ctx.getImageData(0, 0, this.canvasEl.width, this.canvasEl.height)];
        },

        setTool(toolName, btnElement) {
            this.currentTool = toolName;
            document.querySelectorAll('.annotator-toolbar [data-tool]').forEach(b => b.classList.remove('active'));
            if (btnElement) btnElement.classList.add('active');
        },

        setColor(colorHex, swatchElement) {
            this.currentColor = colorHex;
            document.querySelectorAll('.annotator-color-swatch').forEach(s => s.classList.remove('active'));
            if (swatchElement) swatchElement.classList.add('active');
        },

        setLineWidth(width, btnElement) {
            this.currentLineWidth = width;
            if (btnElement && btnElement.parentElement) {
                btnElement.parentElement.querySelectorAll('.annotator-btn').forEach(b => b.classList.remove('active'));
                btnElement.classList.add('active');
            }
        },

        /**
         * Abre el editor con la imagen provista (File, Blob, HTMLVideoElement, HTMLImageElement o URL)
         */
        open(imageSource, originalFile, onSave) {
            this.init();
            this.onSaveCallback = onSave;
            this.originalFile = originalFile || null;
            this.history = [];

            const processLoadedImage = (img) => {
                this.bgImage = img;

                // Redimensionar respetando aspect ratio con límite de resolución (máx 1600x1200 para fluidez en tablet)
                let width = img.videoWidth || img.naturalWidth || img.width || 1280;
                let height = img.videoHeight || img.naturalHeight || img.height || 720;
                const maxDim = 1600;

                if (width > maxDim || height > maxDim) {
                    if (width > height) {
                        height = Math.round((height * maxDim) / width);
                        width = maxDim;
                    } else {
                        width = Math.round((width * maxDim) / height);
                        height = maxDim;
                    }
                }

                this.canvasEl.width = width;
                this.canvasEl.height = height;

                this.ctx.drawImage(img, 0, 0, width, height);
                this.history = [this.ctx.getImageData(0, 0, width, height)];

                this.modalEl.style.display = 'flex';
            };

            if (imageSource instanceof HTMLVideoElement) {
                processLoadedImage(imageSource);
            } else if (imageSource instanceof HTMLImageElement && imageSource.complete) {
                processLoadedImage(imageSource);
            } else if (imageSource instanceof Blob || imageSource instanceof File) {
                const img = new Image();
                const url = URL.createObjectURL(imageSource);
                img.onload = () => {
                    processLoadedImage(img);
                    URL.revokeObjectURL(url);
                };
                img.src = url;
            } else if (typeof imageSource === 'string') {
                const img = new Image();
                img.crossOrigin = "anonymous";
                img.onload = () => {
                    processLoadedImage(img);
                };
                img.src = imageSource;
            }
        },

        close() {
            if (this.modalEl) {
                this.modalEl.style.display = 'none';
            }
            this.history = [];
            this.bgImage = null;
        },

        saveOriginal() {
            if (this.originalFile && this.onSaveCallback) {
                this.onSaveCallback(this.originalFile);
                this.close();
            } else {
                this.saveAnnotated();
            }
        },

        saveAnnotated() {
            if (!this.canvasEl || !this.onSaveCallback) return;

            this.canvasEl.toBlob((blob) => {
                const finalFile = new File([blob], "evidencia_anotada.jpg", { type: "image/jpeg" });
                this.onSaveCallback(finalFile);
                this.close();
            }, 'image/jpeg', 0.85);
        }
    };

    // Exportar al ámbito global
    window.VoiceDictation = VoiceDictation;
    window.CameraHelper = CameraHelper;
    window.PhotoAnnotator = PhotoAnnotator;

})(window);

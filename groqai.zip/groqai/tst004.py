import requests
import json

# GPT4ALL
'''
http://localhost:4891/v1/models

{"data":[{"created":0,"id":"DeepSeek-R1-Distill-Qwen-7B","object":"model","owned_by":"humanity",
"parent":null,"permissions":[{"allow_create_engine":false,"allow_fine_tuning":false,"allow_logprobs":false,"allow_sampling":false,"allow_search_indices":false,
"allow_view":true,"created":0,"group":null,"id":"placeholder","is_blocking":false,"object":"model_permission","organization":"*"}],"root":"DeepSeek-R1-Distill-Qwen-7B"},

{"created":0,"id":"Llama 3.2 3B Instruct","object":"model","owned_by":"humanity","parent":null,"permissions":
[{"allow_create_engine":false,"allow_fine_tuning":false,"allow_logprobs":false,"allow_sampling":false,"allow_search_indices":false,
"allow_view":true,"created":0,"group":null,"id":"placeholder","is_blocking":false,"object":"model_permission","organization":"*"}],"root":"Llama 3.2 3B Instruct"}],"object":"list"}
'''
# URL del endpoint
url = "http://localhost:4891/v1/chat/completions"

# Encabezados
headers = {
    "Content-Type": "application/json"
}

# Datos de la solicitud
data = {
    "model": "Llama 3.2 3B Instruct",
    "messages": [
        {"role": "system", "content": "eres integrante de recursos humanos que esta para apoyar a los empleados de una empresa en los problemas laborales, siempre dar un consejo de animo"},
        {"role": "user", "content": "que debo hacer en caso de tener una discusion con un companero de trabajo"}
    ],
    "temperature": 0.7,
    "max_tokens": 500,
    "stream": False
}

# Enviar la solicitud POST
response = requests.post(url, headers=headers, data=json.dumps(data))

# Imprimir la respuesta
print(response.json())

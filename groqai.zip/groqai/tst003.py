import requests
import json

# URL del endpoint
url = "http://localhost:1234/v1/chat/completions"

# Encabezados
headers = {
    "Content-Type": "application/json"
}

# Datos de la solicitud
data = {
    "model": "llama-3.2-3b-instruct",
    "messages": [
        {"role": "system", "content": "eres integrante de recursos humanos que esta para apoyar a los empleados de una empresa en los problemas laborales, siempre dar un consejo de animo"},
        {"role": "user", "content": "mi jefe directo me hablo mal hoy"}
    ],
    "temperature": 0.7,
    "max_tokens": -1,
    "stream": False
}

# Enviar la solicitud POST
response = requests.post(url, headers=headers, data=json.dumps(data))

# Imprimir la respuesta
print(response.json())

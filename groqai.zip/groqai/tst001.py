import os

from groq import Groq

client = Groq(
    api_key= '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'#os.environ.get("GROQ_API_KEY"),
)

chat_completion = client.chat.completions.create(
    messages=[
        {
            "role": "user",
            "content": "explica en menos de 200 palabras si el uso de groq ai es libre",
        }
    ],
    model="llama-3.3-70b-versatile",
)

print(chat_completion.choices[0].message.content)
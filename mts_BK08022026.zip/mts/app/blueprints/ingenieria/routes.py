from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app.blueprints.db import run_query

ingenieria_bp = Blueprint('ingenieria', __name__, template_folder='templates')

@ingenieria_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        if current_user.rol == 'Lider de Linea':
            return redirect(url_for('lider.crear_orden_trabajo'))
        elif current_user.rol == 'Tecnico':
            return redirect(url_for('tecnico.panel_tareas'))
        return redirect(url_for('auth.login'))

    # 1. Resumen de estados usando run_query
    resumen_estados = run_query("""
        SELECT eo.Nombre, COUNT(ot.ID) AS Cantidad
        FROM OrdenesTrabajo ot
        INNER JOIN CatEstadosOT eo ON ot.EstadoID = eo.ID
        WHERE ot.activo = 1
        GROUP BY eo.Nombre
    """, query_type='SELECT')
    
    estados_dict = {row['Nombre']: row['Cantidad'] for row in resumen_estados}

    # 2. MTTR Neto
    mttr_neto_rows = run_query("""
        WITH TiemposPausa AS (
            SELECT OrdenTrabajoID,
                   SUM(DATEDIFF(MINUTE, FechaInicioPausa, COALESCE(FechaFinPausa, GETDATE()))) AS MinutosPausados
            FROM RegistroPausasOT WHERE activo = 1 GROUP BY OrdenTrabajoID
        )
        SELECT AVG(DATEDIFF(MINUTE, dt.FechaArriboQR, dt.FechaFinActividad) - COALESCE(tp.MinutosPausados, 0)) AS MTTR_Neto
        FROM OrdenesTrabajo ot
        INNER JOIN DetalleTecnicosOT dt ON dt.OrdenTrabajoID = ot.ID 
            AND dt.FechaArriboQR IS NOT NULL AND dt.FechaFinActividad IS NOT NULL
        LEFT JOIN TiemposPausa tp ON tp.OrdenTrabajoID = ot.ID
        WHERE ot.EstadoID = (SELECT ID FROM CatEstadosOT WHERE Nombre = 'Completada')
          AND ot.activo = 1
    """, query_type='SELECT')
    
    mttr_neto = round(mttr_neto_rows[0]['MTTR_Neto'], 1) if mttr_neto_rows and mttr_neto_rows[0]['MTTR_Neto'] is not None else 0.0

    # 3. Down Time Total
    downtime_total_rows = run_query("""
        SELECT SUM(DATEDIFF(MINUTE, ot.FechaReporte, dt.FechaFinActividad)) / 60.0 AS DownTimeTotal
        FROM OrdenesTrabajo ot
        INNER JOIN DetalleTecnicosOT dt ON dt.OrdenTrabajoID = ot.ID AND dt.FechaFinActividad IS NOT NULL
        WHERE ot.EstadoID = (SELECT ID FROM CatEstadosOT WHERE Nombre = 'Completada')
          AND ot.activo = 1
    """, query_type='SELECT')
    
    downtime_total = round(downtime_total_rows[0]['DownTimeTotal'], 1) if downtime_total_rows and downtime_total_rows[0]['DownTimeTotal'] is not None else 0.0

    # Catálogos para filtros gerenciales
    areas = run_query("SELECT ID, Nombre FROM CatAreas WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    lineas = run_query("SELECT ID, Nombre, AreaID FROM CatLineas WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')

    return render_template(
        'ingenieria/dashboard.html',
        estados=estados_dict,
        mttr_neto=mttr_neto,
        downtime_total=downtime_total,
        areas=areas,
        lineas=lineas
    )

@ingenieria_bp.route('/calendario')
@login_required
def vista_calendario_pm():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('auth.login'))
        
    lineas = run_query("SELECT ID, Nombre FROM CatLineas WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    tecnicos = run_query("""
        SELECT u.ID, u.Nombre 
        FROM CatUsuarios u
        INNER JOIN CatRoles r ON u.RolID = r.ID
        WHERE r.Nombre IN ('Tecnico', 'Técnico', 'Mantenimiento') AND u.activo = 1
        ORDER BY u.Nombre
    """, query_type='SELECT')
    if not tecnicos:
        tecnicos = run_query("SELECT ID, Nombre FROM CatUsuarios WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
        
    rutinas = run_query("SELECT ID, Nombre, FrecuenciaDias FROM CatRutinasPreventivas WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')

    return render_template(
        'ingenieria/calendario.html',
        lineas=lineas,
        tecnicos=tecnicos,
        rutinas=rutinas
    )

@ingenieria_bp.route('/historial-ot')
@login_required
def historial_ot():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('auth.login'))
        
    try:
        # Consulta de todas las OTs
        ots = run_query("""
            SELECT 
                ot.ID, 
                ot.TipoMantenimiento,
                lin.Nombre AS Linea, 
                est.Nombre AS Estacion, 
                eq.Nombre AS EquipoNombre, 
                eq.Modelo AS EquipoModelo,
                sfl.Nombre AS SintomaReportado, 
                fr.Nombre AS FallaReal,
                eo.Nombre AS Estado,
                ot.FechaReporte,
                ot.FechaInicioSoporte,
                (
                    SELECT TOP 1 dt.FechaFinActividad 
                    FROM DetalleTecnicosOT dt 
                    WHERE dt.OrdenTrabajoID = ot.ID AND dt.activo = 1 
                    ORDER BY dt.ID DESC
                ) AS FechaFin,
                (
                    SELECT TOP 1 b.Comentario 
                    FROM BitacoraEstadosOT b 
                    WHERE b.OrdenTrabajoID = ot.ID 
                      AND b.EstadoNuevoID = (SELECT ID FROM CatEstadosOT WHERE Nombre = 'CLOSED') 
                    ORDER BY b.ID DESC
                ) AS ComentariosSolucion,
                (
                    SELECT TOP 1 u.Nombre 
                    FROM DetalleTecnicosOT dt 
                    INNER JOIN CatUsuarios u ON dt.TecnicoID = u.ID
                    WHERE dt.OrdenTrabajoID = ot.ID AND dt.activo = 1 
                    ORDER BY dt.ID DESC
                ) AS TecnicoNombre
            FROM OrdenesTrabajo ot
            INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
            INNER JOIN CatLineas lin ON est.LineaID = lin.ID
            INNER JOIN CatEstadosOT eo ON ot.EstadoID = eo.ID
            LEFT JOIN CatEquipos eq ON ot.EquipoID = eq.ID
            LEFT JOIN CatFallasComunes sfl ON ot.SintomaFallaLiderID = sfl.ID
            LEFT JOIN CatFallasComunes fr ON ot.FallaRealID = fr.ID
            WHERE ot.activo = 1
            ORDER BY ot.ID DESC
        """, query_type='SELECT')

        # Cargar mapa de evidencias por OT
        evidencias_rows = run_query("""
            SELECT ID, OrdenTrabajoID, PathArchivo, TipoEvidencia 
            FROM EvidenciasOT 
            WHERE activo = 1
        """, query_type='SELECT')

        evidencias_map = {}
        for ev in evidencias_rows:
            ot_id = ev['OrdenTrabajoID']
            if ot_id not in evidencias_map:
                evidencias_map[ot_id] = []
            evidencias_map[ot_id].append({
                'id': ev['ID'],
                'path': ev['PathArchivo'],
                'tipo': ev['TipoEvidencia'] or 'FALLA'
            })

        for ot in ots:
            ot['Evidencias'] = evidencias_map.get(ot['ID'], [])

        return render_template('ingenieria/historial_ot.html', ots=ots)
    except Exception as e:
        flash(f"Error al cargar historial: {str(e)}", 'danger')
        return redirect(url_for('ingenieria.dashboard'))

@ingenieria_bp.route('/historial-ot/<int:ot_id>')
@login_required
def detalle_ot(ot_id):
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('auth.login'))
        
    try:
        # 1. Cargar detalles principales de la OT
        ot_rows = run_query("""
            SELECT 
                ot.ID, 
                ot.TipoMantenimiento,
                lin.Nombre AS Linea, 
                est.Nombre AS Estacion, 
                eq.Nombre AS EquipoNombre, 
                eq.Modelo AS EquipoModelo,
                eq.NumeroSerie AS EquipoSerie,
                eq.CodigoQR AS EquipoQR,
                eo.Nombre AS Estado,
                ot.FechaReporte,
                ot.FechaInicioSoporte,
                (
                    SELECT TOP 1 dt.FechaFinActividad 
                    FROM DetalleTecnicosOT dt 
                    WHERE dt.OrdenTrabajoID = ot.ID AND dt.activo = 1 
                    ORDER BY dt.ID DESC
                ) AS FechaFin,
                (
                    SELECT TOP 1 dt.FechaArriboQR 
                    FROM DetalleTecnicosOT dt 
                    WHERE dt.OrdenTrabajoID = ot.ID AND dt.activo = 1 
                    ORDER BY dt.ID DESC
                ) AS FechaArriboQR,
                
                -- Reporta Líder
                lid.Nombre AS LiderNombre,
                sfl.Nombre AS SintomaReportado, 
                cfl.Nombre AS ClasificacionReportada,
                c4m.Nombre AS Causa4MReportada,
                ot.AreaAfectadaImpacto,
                ot.EmpleadosAfectados,
                ot.ComentarioLider,
                
                -- Técnico Atiende
                fr.Nombre AS FallaReal,
                (
                    SELECT TOP 1 b.Comentario 
                    FROM BitacoraEstadosOT b 
                    WHERE b.OrdenTrabajoID = ot.ID 
                      AND b.EstadoNuevoID = (SELECT ID FROM CatEstadosOT WHERE Nombre = 'CLOSED') 
                    ORDER BY b.ID DESC
                ) AS ComentariosSolucion,
                (
                    SELECT TOP 1 u.Nombre 
                    FROM DetalleTecnicosOT dt 
                    INNER JOIN CatUsuarios u ON dt.TecnicoID = u.ID
                    WHERE dt.OrdenTrabajoID = ot.ID AND dt.activo = 1 
                    ORDER BY dt.ID DESC
                ) AS TecnicoNombre
            FROM OrdenesTrabajo ot
            INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
            INNER JOIN CatLineas lin ON est.LineaID = lin.ID
            INNER JOIN CatEstadosOT eo ON ot.EstadoID = eo.ID
            LEFT JOIN CatEquipos eq ON ot.EquipoID = eq.ID
            LEFT JOIN CatUsuarios lid ON ot.LiderReportaID = lid.ID
            LEFT JOIN CatFallasComunes sfl ON ot.SintomaFallaLiderID = sfl.ID
            LEFT JOIN CatClasificacionesFallaLider cfl ON ot.ClasificacionFallaLiderID = cfl.ID
            LEFT JOIN CatCausas4M c4m ON ot.Causa4MID = c4m.ID
            LEFT JOIN CatFallasComunes fr ON ot.FallaRealID = fr.ID
            WHERE ot.ID = ? AND ot.activo = 1
        """, (ot_id,), 'SELECT')
        
        if not ot_rows:
            flash("Orden de trabajo no encontrada.", "warning")
            return redirect(url_for('ingenieria.historial_ot'))
            
        ot_info = ot_rows[0]
        
        # 2. Cargar evidencias de la OT
        evidencias = run_query("""
            SELECT PathArchivo, TipoEvidencia 
            FROM EvidenciasOT 
            WHERE OrdenTrabajoID = ? AND activo = 1
        """, (ot_id,), 'SELECT')
        
        # 3. Cargar Bitácora de la OT (Línea de Tiempo)
        timeline = run_query("""
            SELECT b.FechaCambio, u.Nombre AS Usuario, ea.Nombre AS EstadoAnterior, en.Nombre AS EstadoNuevo, b.Comentario
            FROM BitacoraEstadosOT b
            LEFT JOIN CatUsuarios u ON b.UsuarioID = u.ID
            LEFT JOIN CatEstadosOT ea ON b.EstadoAnteriorID = ea.ID
            INNER JOIN CatEstadosOT en ON b.EstadoNuevoID = en.ID
            WHERE b.OrdenTrabajoID = ? AND b.activo = 1
            ORDER BY b.ID ASC
        """, (ot_id,), 'SELECT')
        
        # 4. Calcular Downtime (en minutos y formateado)
        downtime_mins = None
        if ot_info['FechaReporte'] and ot_info['FechaFin']:
            delta = ot_info['FechaFin'] - ot_info['FechaReporte']
            downtime_mins = int(delta.total_seconds() / 60)
            
        # Calcular tiempo de soporte técnico activo (FechaInicioSoporte o FechaArriboQR a FechaFin)
        fecha_inicio_sop = ot_info['FechaInicioSoporte'] or ot_info['FechaArriboQR']
        soporte_mins = None
        if fecha_inicio_sop and ot_info['FechaFin']:
            delta_sop = ot_info['FechaFin'] - fecha_inicio_sop
            soporte_mins = int(delta_sop.total_seconds() / 60)
            if soporte_mins < 0:
                soporte_mins = 0
            
        # Calcular tiempo total en pausa
        pausas = run_query("""
            SELECT SUM(DATEDIFF(MINUTE, FechaInicioPausa, COALESCE(FechaFinPausa, GETDATE()))) AS MinutosPausados
            FROM RegistroPausasOT 
            WHERE OrdenTrabajoID = ? AND activo = 1
        """, (ot_id,), 'SELECT')
        pausado_mins = pausas[0]['MinutosPausados'] if pausas and pausas[0]['MinutosPausados'] else 0
        
        # MTTR Neto = Tiempo Soporte Activo - Tiempo Pausado
        mttr_neto = None
        if soporte_mins is not None:
            mttr_neto = soporte_mins - pausado_mins
            if mttr_neto < 0:
                mttr_neto = 0

        return render_template(
            'ingenieria/detalle_ot.html', 
            ot=ot_info, 
            ot_info=ot_info,
            evidencias=evidencias, 
            timeline=timeline,
            downtime_mins=downtime_mins,
            soporte_mins=soporte_mins,
            pausado_mins=pausado_mins,
            mttr_neto=mttr_neto
        )
    except Exception as e:
        flash(f"Error al cargar detalle de OT: {str(e)}", 'danger')
        return redirect(url_for('ingenieria.historial_ot'))

@ingenieria_bp.route('/desempeno-tecnicos')
@login_required
def desempeno_tecnicos():
    if current_user.rol not in ['Administrador', 'Ingeniero']:
        if current_user.rol == 'Lider de Linea':
            return redirect(url_for('lider.crear_orden_trabajo'))
        elif current_user.rol == 'Tecnico':
            return redirect(url_for('tecnico.panel_tareas'))
        return redirect(url_for('auth.login'))

    periodo = request.args.get('periodo', 'todos')
    tecnico_id = request.args.get('tecnico_id', '')
    linea_id = request.args.get('linea_id', '')

    where_clauses = ["(r.Nombre LIKE '%Tecnico%' OR r.Nombre LIKE '%Técnico%')", "u.activo = 1"]
    params = []

    if periodo == 'hoy':
        where_clauses.append("CAST(ot.FechaReporte AS DATE) = CAST(GETDATE() AS DATE)")
    elif periodo == 'semana':
        where_clauses.append("ot.FechaReporte >= DATEADD(DAY, -7, GETDATE())")
    elif periodo == 'mes':
        where_clauses.append("ot.FechaReporte >= DATEADD(MONTH, -1, GETDATE())")

    if tecnico_id:
        where_clauses.append("u.ID = ?")
        params.append(tecnico_id)

    if linea_id:
        where_clauses.append("est.LineaID = ?")
        params.append(linea_id)

    where_str = " AND ".join(where_clauses)

    query_tecnicos = f"""
        SELECT 
            u.ID as TecnicoID,
            u.Nombre as TecnicoNombre,
            u.NoEmpleado,
            t.Nombre as TurnoNombre,
            COUNT(DISTINCT ot.ID) as TotalOTs,
            SUM(CASE WHEN ot.TipoMantenimiento = 'CORRECTIVO' THEN 1 ELSE 0 END) as Correctivas,
            SUM(CASE WHEN ot.TipoMantenimiento = 'PREVENTIVO' THEN 1 ELSE 0 END) as Preventivas,
            SUM(CASE WHEN eo.Nombre = 'Creada' THEN 1 ELSE 0 END) as Pendientes,
            SUM(CASE WHEN eo.Nombre = 'En Proceso' THEN 1 ELSE 0 END) as EnProceso,
            SUM(CASE WHEN eo.Nombre = 'Pausada' THEN 1 ELSE 0 END) as Pausadas,
            SUM(CASE WHEN eo.Nombre = 'Completada' THEN 1 ELSE 0 END) as Cerradas,
            AVG(DATEDIFF(MINUTE, COALESCE(dt.FechaArriboQR, dt.FechaAsignacion, ot.FechaReporte), dt.FechaFinActividad)) as MTTRPromedio
        FROM CatUsuarios u
        INNER JOIN CatRoles r ON u.RolID = r.ID
        LEFT JOIN CatTurnos t ON u.TurnoID = t.ID
        LEFT JOIN DetalleTecnicosOT dt ON dt.TecnicoID = u.ID AND dt.activo = 1
        LEFT JOIN OrdenesTrabajo ot ON dt.OrdenTrabajoID = ot.ID AND ot.activo = 1
        LEFT JOIN CatEstadosOT eo ON ot.EstadoID = eo.ID
        LEFT JOIN CatEstaciones est ON ot.EstacionID = est.ID
        WHERE {where_str}
        GROUP BY u.ID, u.Nombre, u.NoEmpleado, t.Nombre
        ORDER BY TotalOTs DESC
    """
    
    tecnicos_metrics = run_query(query_tecnicos, tuple(params), 'SELECT')

    # Obtener líneas atendidas por técnico
    lineas_por_tecnico = {}
    query_lineas = """
        SELECT dt.TecnicoID, lin.Nombre AS LineaNombre, COUNT(ot.ID) AS Cantidad
        FROM DetalleTecnicosOT dt
        INNER JOIN OrdenesTrabajo ot ON dt.OrdenTrabajoID = ot.ID AND ot.activo = 1
        INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
        INNER JOIN CatLineas lin ON est.LineaID = lin.ID
        WHERE dt.activo = 1
        GROUP BY dt.TecnicoID, lin.Nombre
    """
    rows_lineas = run_query(query_lineas, (), 'SELECT')
    for r in rows_lineas:
        tid = r['TecnicoID']
        if tid not in lineas_por_tecnico:
            lineas_por_tecnico[tid] = []
        if r['LineaNombre'] not in lineas_por_tecnico[tid]:
            lineas_por_tecnico[tid].append(r['LineaNombre'])

    for t in tecnicos_metrics:
        tid = t['TecnicoID']
        t['LineasAtendidas'] = lineas_por_tecnico.get(tid, [])
        t['MTTRPromedio'] = round(t['MTTRPromedio'], 1) if t['MTTRPromedio'] is not None else 0.0

    total_ots = sum(t['TotalOTs'] for t in tecnicos_metrics)
    total_correctivas = sum(t['Correctivas'] for t in tecnicos_metrics)
    total_preventivas = sum(t['Preventivas'] for t in tecnicos_metrics)
    mttrs = [t['MTTRPromedio'] for t in tecnicos_metrics if t['MTTRPromedio'] > 0]
    avg_mttr_global = round(sum(mttrs) / len(mttrs), 1) if mttrs else 0.0
    top_tech = tecnicos_metrics[0]['TecnicoNombre'] if tecnicos_metrics and tecnicos_metrics[0]['TotalOTs'] > 0 else 'N/A'

    cat_tecnicos = run_query("""
        SELECT u.ID, u.Nombre 
        FROM CatUsuarios u 
        INNER JOIN CatRoles r ON u.RolID = r.ID 
        WHERE (r.Nombre LIKE '%Tecnico%' OR r.Nombre LIKE '%Técnico%') AND u.activo = 1 
        ORDER BY u.Nombre
    """, (), 'SELECT')
    
    cat_lineas = run_query("SELECT ID, Nombre FROM CatLineas WHERE activo = 1 ORDER BY Nombre", (), 'SELECT')

    return render_template(
        'ingenieria/desempeno_tecnicos.html',
        tecnicos_metrics=tecnicos_metrics,
        total_ots=total_ots,
        total_correctivas=total_correctivas,
        total_preventivas=total_preventivas,
        avg_mttr_global=avg_mttr_global,
        top_tech=top_tech,
        periodo=periodo,
        tecnico_id=tecnico_id,
        linea_id=linea_id,
        cat_tecnicos=cat_tecnicos,
        cat_lineas=cat_lineas
    )


@ingenieria_bp.route('/trazabilidad-turno')
@login_required
def trazabilidad_turno():
    import datetime
    import csv
    import io
    from flask import Response, make_response

    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('auth.login'))

    # 1. Cargar catálogo de Turnos y formatear horas
    cat_turnos_raw = run_query("SELECT ID, Nombre, HoraInicio, HoraFin FROM CatTurnos WHERE activo = 1 ORDER BY ID", query_type='SELECT')
    cat_turnos = []
    for t in cat_turnos_raw:
        t_dict = dict(t)
        h_ini = t_dict['HoraInicio']
        h_fin = t_dict['HoraFin']
        t_dict['HoraInicioStr'] = h_ini.strftime('%H:%M') if hasattr(h_ini, 'strftime') else str(h_ini)[:5]
        t_dict['HoraFinStr'] = h_fin.strftime('%H:%M') if hasattr(h_fin, 'strftime') else str(h_fin)[:5]
        cat_turnos.append(t_dict)
    
    # 2. Obtener parámetros de filtro
    fecha_param = request.args.get('fecha')
    turno_id_param = request.args.get('turno_id')
    categoria_param = request.args.get('categoria', 'todos')
    export_param = request.args.get('export')

    now = datetime.datetime.now()
    if not fecha_param:
        fecha_param = now.strftime('%Y-%m-%d')

    # Detectar turno predeterminado si no se especifica
    selected_turno_id = None
    if turno_id_param and turno_id_param != 'all':
        try:
            selected_turno_id = int(turno_id_param)
        except ValueError:
            selected_turno_id = None
    elif turno_id_param == 'all':
        selected_turno_id = 'all'
    else:
        # Autodetectar turno según la hora actual
        current_time_str = now.strftime('%H:%M:%S')
        for t in cat_turnos:
            h_inicio = t['HoraInicioStr'] + ':00' if len(t['HoraInicioStr']) == 5 else t['HoraInicioStr']
            h_fin = t['HoraFinStr'] + ':00' if len(t['HoraFinStr']) == 5 else t['HoraFinStr']
            
            # Caso turno en el mismo día (ej. 06:00 a 14:00)
            if h_inicio <= h_fin:
                if h_inicio <= current_time_str <= h_fin:
                    selected_turno_id = t['ID']
                    break
            else:
                # Caso turno nocturno que cruza medianoche (ej. 22:00 a 06:00)
                if current_time_str >= h_inicio or current_time_str <= h_fin:
                    selected_turno_id = t['ID']
                    break
        if not selected_turno_id and cat_turnos:
            selected_turno_id = cat_turnos[0]['ID']

    # 3. Determinar Rango de Fechas/Horas según turno y fecha seleccionada
    start_dt_str = f"{fecha_param} 00:00:00"
    end_dt_str = f"{fecha_param} 23:59:59"
    turno_obj = None

    if selected_turno_id and selected_turno_id != 'all':
        for t in cat_turnos:
            if t['ID'] == selected_turno_id:
                turno_obj = t
                h_inicio = t['HoraInicioStr']
                h_fin = t['HoraFinStr']
                start_dt_str = f"{fecha_param} {h_inicio}:00"
                
                # Si hora fin < hora inicio, termina al día siguiente
                if h_fin < h_inicio:
                    next_day = datetime.datetime.strptime(fecha_param, '%Y-%m-%d') + datetime.timedelta(days=1)
                    end_dt_str = f"{next_day.strftime('%Y-%m-%d')} {h_fin}:59"
                else:
                    end_dt_str = f"{fecha_param} {h_fin}:59"
                break

    # 4. Consultar Eventos del Sistema en el Rango

    # 4a. Eventos: Creación de OTs por Líder
    sql_creaciones = """
        SELECT 
            ot.ID AS OT_ID,
            ot.FechaReporte AS Timestamp,
            'REPORTE_LIDER' AS TipoEvento,
            'Reporte de Líder (OT Creada)' AS Categoria,
            lin.Nombre AS Linea,
            est.Nombre AS Estacion,
            COALESCE(eq.Nombre, 'S/E') AS Equipo,
            u.Nombre AS Usuario,
            r.Nombre AS RolUsuario,
            ot.TipoMantenimiento,
            COALESCE(sfl.Nombre, 'Falla reportada') AS Descripcion,
            ot.ComentarioLider AS Detalle
        FROM OrdenesTrabajo ot
        INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
        INNER JOIN CatLineas lin ON est.LineaID = lin.ID
        INNER JOIN CatUsuarios u ON ot.LiderReportaID = u.ID
        LEFT JOIN CatRoles r ON u.RolID = r.ID
        LEFT JOIN CatEquipos eq ON ot.EquipoID = eq.ID
        LEFT JOIN CatFallasComunes sfl ON ot.SintomaFallaLiderID = sfl.ID
        WHERE ot.activo = 1
          AND ot.FechaReporte >= ? AND ot.FechaReporte <= ?
    """

    # 4b. Eventos: Arribos Técnicos
    sql_arribos = """
        SELECT 
            ot.ID AS OT_ID,
            dt.FechaArriboQR AS Timestamp,
            'ARRIBO_TECNICO' AS TipoEvento,
            'Atención Técnica (Arribo QR)' AS Categoria,
            lin.Nombre AS Linea,
            est.Nombre AS Estacion,
            COALESCE(eq.Nombre, 'S/E') AS Equipo,
            u.Nombre AS Usuario,
            'Técnico' AS RolUsuario,
            ot.TipoMantenimiento,
            'Técnico escaneó QR e inició atención' AS Descripcion,
            'Arribo registrado en estación' AS Detalle
        FROM DetalleTecnicosOT dt
        INNER JOIN OrdenesTrabajo ot ON dt.OrdenTrabajoID = ot.ID AND ot.activo = 1
        INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
        INNER JOIN CatLineas lin ON est.LineaID = lin.ID
        INNER JOIN CatUsuarios u ON dt.TecnicoID = u.ID
        LEFT JOIN CatEquipos eq ON ot.EquipoID = eq.ID
        WHERE dt.activo = 1
          AND dt.FechaArriboQR IS NOT NULL
          AND dt.FechaArriboQR >= ? AND dt.FechaArriboQR <= ?
    """

    # 4c. Eventos: Pausas de Trabajo
    sql_pausas = """
        SELECT 
            ot.ID AS OT_ID,
            p.FechaInicioPausa AS Timestamp,
            'PAUSA_INICIO' AS TipoEvento,
            'Pausa de Trabajo' AS Categoria,
            lin.Nombre AS Linea,
            est.Nombre AS Estacion,
            COALESCE(eq.Nombre, 'S/E') AS Equipo,
            COALESCE(u.Nombre, 'Técnico') AS Usuario,
            'Técnico' AS RolUsuario,
            ot.TipoMantenimiento,
            COALESCE(mp.Nombre, 'Pausa de trabajo') AS Descripcion,
            COALESCE(p.Comentario, 'OT pausada') AS Detalle
        FROM RegistroPausasOT p
        INNER JOIN OrdenesTrabajo ot ON p.OrdenTrabajoID = ot.ID AND ot.activo = 1
        INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
        INNER JOIN CatLineas lin ON est.LineaID = lin.ID
        LEFT JOIN CatUsuarios u ON p.UsuarioPausaID = u.ID
        LEFT JOIN CatMotivosPausa mp ON p.MotivoPausaID = mp.ID
        LEFT JOIN CatEquipos eq ON ot.EquipoID = eq.ID
        WHERE p.activo = 1
          AND p.FechaInicioPausa >= ? AND p.FechaInicioPausa <= ?
    """

    # 4d. Eventos: Cierre / Solución de OT
    sql_cierres = """
        SELECT 
            ot.ID AS OT_ID,
            dt.FechaFinActividad AS Timestamp,
            CASE WHEN ot.TipoMantenimiento = 'PREVENTIVO' THEN 'PREVENTIVO_COMPLETADO' ELSE 'OT_CERRADA' END AS TipoEvento,
            CASE WHEN ot.TipoMantenimiento = 'PREVENTIVO' THEN 'Preventivo PM Ejecutado' ELSE 'Cierre de OT (Resuelto)' END AS Categoria,
            lin.Nombre AS Linea,
            est.Nombre AS Estacion,
            COALESCE(eq.Nombre, 'S/E') AS Equipo,
            u.Nombre AS Usuario,
            'Técnico' AS RolUsuario,
            ot.TipoMantenimiento,
            COALESCE(fr.Nombre, 'OT resuelta y cerrada') AS Descripcion,
            (
                SELECT TOP 1 b.Comentario 
                FROM BitacoraEstadosOT b 
                WHERE b.OrdenTrabajoID = ot.ID 
                  AND b.EstadoNuevoID = (SELECT ID FROM CatEstadosOT WHERE Nombre IN ('CLOSED', 'Completada'))
                ORDER BY b.ID DESC
            ) AS Detalle
        FROM DetalleTecnicosOT dt
        INNER JOIN OrdenesTrabajo ot ON dt.OrdenTrabajoID = ot.ID AND ot.activo = 1
        INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
        INNER JOIN CatLineas lin ON est.LineaID = lin.ID
        INNER JOIN CatUsuarios u ON dt.TecnicoID = u.ID
        LEFT JOIN CatEquipos eq ON ot.EquipoID = eq.ID
        LEFT JOIN CatFallasComunes fr ON ot.FallaRealID = fr.ID
        WHERE dt.activo = 1
          AND dt.FechaFinActividad IS NOT NULL
          AND dt.FechaFinActividad >= ? AND dt.FechaFinActividad <= ?
    """

    params = (start_dt_str, end_dt_str)

    rows_creaciones = run_query(sql_creaciones, params, 'SELECT')
    rows_arribos = run_query(sql_arribos, params, 'SELECT')
    rows_pausas = run_query(sql_pausas, params, 'SELECT')
    rows_cierres = run_query(sql_cierres, params, 'SELECT')

    # Combinar todos los eventos en un stream unificado
    todos_eventos = []
    for r in rows_creaciones:
        r_dict = dict(r)
        r_dict['BadgeClass'] = 'badge-primary'
        r_dict['IconClass'] = 'fa-solid fa-circle-exclamation'
        todos_eventos.append(r_dict)

    for r in rows_arribos:
        r_dict = dict(r)
        r_dict['BadgeClass'] = 'badge-info'
        r_dict['IconClass'] = 'fa-solid fa-qrcode'
        todos_eventos.append(r_dict)

    for r in rows_pausas:
        r_dict = dict(r)
        r_dict['BadgeClass'] = 'badge-warning'
        r_dict['IconClass'] = 'fa-solid fa-pause'
        todos_eventos.append(r_dict)

    for r in rows_cierres:
        r_dict = dict(r)
        if r_dict['TipoMantenimiento'] == 'PREVENTIVO':
            r_dict['BadgeClass'] = 'badge-purple'
            r_dict['IconClass'] = 'fa-regular fa-calendar-check'
        else:
            r_dict['BadgeClass'] = 'badge-success'
            r_dict['IconClass'] = 'fa-solid fa-circle-check'
        todos_eventos.append(r_dict)

    # Formatear TimestampStr y ordenar cronológicamente descendente
    for ev in todos_eventos:
        ts = ev.get('Timestamp')
        if isinstance(ts, datetime.datetime):
            ev['TimestampStr'] = ts.strftime('%H:%M:%S')
        elif isinstance(ts, datetime.time):
            ev['TimestampStr'] = ts.strftime('%H:%M:%S')
        elif ts:
            ev['TimestampStr'] = str(ts)[:19]
        else:
            ev['TimestampStr'] = '--:--:--'

    def parse_time(ev):
        ts = ev.get('Timestamp')
        if isinstance(ts, datetime.datetime):
            return ts
        elif isinstance(ts, str):
            try:
                return datetime.datetime.strptime(ts[:19], '%Y-%m-%d %H:%M:%S')
            except Exception:
                return datetime.datetime.min
        return datetime.datetime.min

    todos_eventos.sort(key=parse_time, reverse=True)

    # Aplicar filtro por categoría si no es 'todos'
    eventos_filtrados = todos_eventos
    if categoria_param and categoria_param != 'todos':
        if categoria_param == 'lider':
            eventos_filtrados = [e for e in todos_eventos if e['TipoEvento'] == 'REPORTE_LIDER']
        elif categoria_param == 'arribo':
            eventos_filtrados = [e for e in todos_eventos if e['TipoEvento'] == 'ARRIBO_TECNICO']
        elif categoria_param == 'pausa':
            eventos_filtrados = [e for e in todos_eventos if e['TipoEvento'] == 'PAUSA_INICIO']
        elif categoria_param == 'cierre':
            eventos_filtrados = [e for e in todos_eventos if e['TipoEvento'] in ['OT_CERRADA', 'PREVENTIVO_COMPLETADO']]
        elif categoria_param == 'preventivo':
            eventos_filtrados = [e for e in todos_eventos if e['TipoMantenimiento'] == 'PREVENTIVO']

    # 5. Calcular KPIs del Turno
    total_movimientos = len(todos_eventos)
    kpi_creadas = len(rows_creaciones)
    kpi_arribos = len(rows_arribos)
    kpi_cierres = len(rows_cierres)

    # Tiempo total de pausas en el turno
    sql_min_pausas = """
        SELECT SUM(DATEDIFF(MINUTE, FechaInicioPausa, COALESCE(FechaFinPausa, GETDATE()))) AS MinPausados
        FROM RegistroPausasOT
        WHERE activo = 1 AND FechaInicioPausa >= ? AND FechaInicioPausa <= ?
    """
    row_pausa_min = run_query(sql_min_pausas, params, 'SELECT')
    kpi_tiempo_pausado = row_pausa_min[0]['MinPausados'] if row_pausa_min and row_pausa_min[0]['MinPausados'] else 0

    # 6. Manejo de exportación a CSV
    if export_param == 'csv':
        output = io.StringIO()
        writer = csv.writer(output, quoting=csv.QUOTE_MINIMAL)
        writer.writerow(['Fecha_Hora', 'Categoria', 'OT_ID', 'Linea', 'Estacion', 'Equipo', 'Usuario', 'TipoMto', 'Descripcion', 'Detalle'])
        
        for ev in eventos_filtrados:
            ts = ev['Timestamp'].strftime('%Y-%m-%d %H:%M:%S') if isinstance(ev['Timestamp'], datetime.datetime) else str(ev['Timestamp'])
            writer.writerow([
                ts,
                ev['Categoria'],
                f"#{ev['OT_ID']}",
                ev['Linea'],
                ev['Estacion'],
                ev['Equipo'],
                ev['Usuario'],
                ev['TipoMantenimiento'],
                ev['Descripcion'],
                ev.get('Detalle') or ''
            ])
            
        output.seek(0)
        return Response(
            output.getvalue(),
            mimetype='text/csv',
            headers={'Content-Disposition': f'attachment; filename=Trazabilidad_Turno_{fecha_param}.csv'}
        )

    return render_template(
        'ingenieria/trazabilidad_turno.html',
        cat_turnos=cat_turnos,
        fecha_seleccionada=fecha_param,
        turno_seleccionado=selected_turno_id,
        categoria_seleccionada=categoria_param,
        turno_obj=turno_obj,
        eventos=eventos_filtrados,
        total_movimientos=total_movimientos,
        kpi_creadas=kpi_creadas,
        kpi_arribos=kpi_arribos,
        kpi_cierres=kpi_cierres,
        kpi_tiempo_pausado=kpi_tiempo_pausado
    )


@ingenieria_bp.route('/exportar-historial-excel', methods=['POST'])
@login_required
def exportar_historial_excel():
    import datetime
    import io
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from flask import Response, session
    from app.blueprints.ingenieria.translations import TRANSLATIONS as INGENIERIA_TRANSLATIONS

    if current_user.rol not in ['Administrador', 'Ingeniero']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('auth.login'))

    # Obtener el idioma activo de la sesión del usuario (por defecto 'es')
    current_lang = session.get('lang', 'es')
    trans = INGENIERIA_TRANSLATIONS.get(current_lang, INGENIERIA_TRANSLATIONS['es'])

    # Mapeo completo de columnas disponibles en DB con expresiones SQL
    COLUMN_DEFINITIONS = {
        'ot_id': {'key': 'col_ot_id', 'header': 'OT #', 'expr': 'ot.ID'},
        'tipo_mantenimiento': {'key': 'col_tipo_mantenimiento', 'header': 'Tipo Mantenimiento', 'expr': 'ot.TipoMantenimiento'},
        'estado': {'key': 'col_estado', 'header': 'Estado', 'expr': 'eo.Nombre'},
        'fecha_reporte': {'key': 'col_fecha_reporte', 'header': 'Fecha Reporte', 'expr': 'ot.FechaReporte'},
        'fecha_inicio_soporte': {'key': 'col_fecha_inicio_soporte', 'header': 'Fecha Inicio Soporte', 'expr': 'ot.FechaInicioSoporte'},
        'fecha_fin': {'key': 'col_fecha_fin', 'header': 'Fecha Fin / Cierre', 'expr': '(SELECT TOP 1 dt.FechaFinActividad FROM DetalleTecnicosOT dt WHERE dt.OrdenTrabajoID = ot.ID AND dt.activo = 1 ORDER BY dt.ID DESC)'},
        'linea': {'key': 'col_linea', 'header': 'Línea', 'expr': 'lin.Nombre'},
        'estacion': {'key': 'col_estacion', 'header': 'Estación', 'expr': 'est.Nombre'},
        'codigo_qr_estacion': {'key': 'col_codigo_qr_estacion', 'header': 'QR Estación', 'expr': 'est.CodigoQR'},
        'equipo_nombre': {'key': 'col_equipo_nombre', 'header': 'Equipo', 'expr': "COALESCE(eq.Nombre, 'S/E')"},
        'equipo_modelo': {'key': 'col_equipo_modelo', 'header': 'Modelo Equipo', 'expr': "COALESCE(eq.Modelo, 'N/A')"},
        'equipo_serie': {'key': 'col_equipo_serie', 'header': 'Número Serie', 'expr': "COALESCE(eq.NumeroSerie, 'N/A')"},
        'sintoma_reportado': {'key': 'col_sintoma_reportado', 'header': 'Síntoma Reportado', 'expr': "COALESCE(sfl.Nombre, 'N/A')"},
        'clasificacion_falla': {'key': 'col_clasificacion_falla', 'header': 'Clasificación Falla', 'expr': "COALESCE(clf.Nombre, 'N/A')"},
        'causa_4m': {'key': 'col_causa_4m', 'header': 'Causa 4M', 'expr': "COALESCE(c4m.Nombre, 'N/A')"},
        'falla_real': {'key': 'col_falla_real', 'header': 'Falla Real Diagnosticada', 'expr': "COALESCE(fr.Nombre, 'N/A')"},
        'comentarios_solucion': {'key': 'col_comentarios_solucion', 'header': 'Solución Aplicada / Cierre', 'expr': "(SELECT TOP 1 b.Comentario FROM BitacoraEstadosOT b WHERE b.OrdenTrabajoID = ot.ID AND b.EstadoNuevoID = (SELECT ID FROM CatEstadosOT WHERE Nombre IN ('CLOSED', 'Completada')) ORDER BY b.ID DESC)"},
        'comentario_lider': {'key': 'col_comentario_lider', 'header': 'Comentario del Líder', 'expr': "COALESCE(ot.ComentarioLider, 'N/A')"},
        'impacto': {'key': 'col_impacto', 'header': 'Impacto / Área Afectada', 'expr': "COALESCE(ot.AreaAfectadaImpacto, 'N/A')"},
        'empleados_afectados': {'key': 'col_empleados_afectados', 'header': 'Empleados Afectados', 'expr': 'COALESCE(ot.EmpleadosAfectados, 0)'},
        'lider_reporto': {'key': 'col_lider_reporto', 'header': 'Líder que Reportó', 'expr': "COALESCE(ulid.Nombre, 'N/A')"},
        'tecnico_atendio': {'key': 'col_tecnico_atendio', 'header': 'Técnico que Atendió', 'expr': "(SELECT TOP 1 u.Nombre FROM DetalleTecnicosOT dt INNER JOIN CatUsuarios u ON dt.TecnicoID = u.ID WHERE dt.OrdenTrabajoID = ot.ID AND dt.activo = 1 ORDER BY dt.ID DESC)"},
        'downtime_total_min': {'key': 'col_downtime_total_min', 'header': 'Downtime Total (Min)', 'expr': "DATEDIFF(MINUTE, ot.FechaReporte, (SELECT TOP 1 dt.FechaFinActividad FROM DetalleTecnicosOT dt WHERE dt.OrdenTrabajoID = ot.ID AND dt.activo = 1 ORDER BY dt.ID DESC))"},
        'tiempo_soporte_min': {'key': 'col_tiempo_soporte_min', 'header': 'Tiempo Soporte (Min)', 'expr': "(SELECT TOP 1 DATEDIFF(MINUTE, dt.FechaArriboQR, dt.FechaFinActividad) FROM DetalleTecnicosOT dt WHERE dt.OrdenTrabajoID = ot.ID AND dt.activo = 1 ORDER BY dt.ID DESC)"},
        'tiempo_pausado_min': {'key': 'col_tiempo_pausado_min', 'header': 'Tiempo Pausado (Min)', 'expr': "(SELECT SUM(DATEDIFF(MINUTE, p.FechaInicioPausa, COALESCE(p.FechaFinPausa, GETDATE()))) FROM RegistroPausasOT p WHERE p.OrdenTrabajoID = ot.ID AND p.activo = 1)"},
        'mttr_neto_min': {'key': 'col_mttr_neto_min', 'header': 'MTTR Neto (Min)', 'expr': "((SELECT TOP 1 DATEDIFF(MINUTE, dt.FechaArriboQR, dt.FechaFinActividad) FROM DetalleTecnicosOT dt WHERE dt.OrdenTrabajoID = ot.ID AND dt.activo = 1 ORDER BY dt.ID DESC) - COALESCE((SELECT SUM(DATEDIFF(MINUTE, p.FechaInicioPausa, COALESCE(p.FechaFinPausa, GETDATE()))) FROM RegistroPausasOT p WHERE p.OrdenTrabajoID = ot.ID AND p.activo = 1), 0))"}
    }

    # Obtener parámetros enviados por el formulario
    fecha_inicio = request.form.get('fecha_inicio', '').strip()
    fecha_fin = request.form.get('fecha_fin', '').strip()
    modo_alcance = request.form.get('modo_alcance', 'rango_fechas')
    columnas_seleccionadas = request.form.getlist('columnas')

    # Si no se seleccionó ninguna columna, usar predeterminadas
    if not columnas_seleccionadas:
        columnas_seleccionadas = [
            'ot_id', 'tipo_mantenimiento', 'estado', 'fecha_reporte',
            'linea', 'estacion', 'equipo_nombre', 'sintoma_reportado',
            'falla_real', 'comentarios_solucion', 'lider_reporto', 'tecnico_atendio'
        ]

    # Filtrar solo columnas válidas
    cols_validas = [c for c in columnas_seleccionadas if c in COLUMN_DEFINITIONS]
    if not cols_validas:
        cols_validas = ['ot_id', 'tipo_mantenimiento', 'estado', 'fecha_reporte', 'linea', 'estacion', 'sintoma_reportado']

    # Construir expresiones SQL SELECT dinámicas
    select_expressions = [f"{COLUMN_DEFINITIONS[c]['expr']} AS [{c}]" for c in cols_validas]
    select_sql = ", ".join(select_expressions)

    where_clauses = ["ot.activo = 1"]
    sql_params = []

    if modo_alcance == 'rango_fechas' and fecha_inicio and fecha_fin:
        where_clauses.append("ot.FechaReporte >= ? AND ot.FechaReporte <= ?")
        sql_params.extend([f"{fecha_inicio} 00:00:00", f"{fecha_fin} 23:59:59"])

    where_sql = " AND ".join(where_clauses)

    query = f"""
        SELECT {select_sql}
        FROM OrdenesTrabajo ot
        INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
        INNER JOIN CatLineas lin ON est.LineaID = lin.ID
        INNER JOIN CatEstadosOT eo ON ot.EstadoID = eo.ID
        LEFT JOIN CatEquipos eq ON ot.EquipoID = eq.ID
        LEFT JOIN CatFallasComunes sfl ON ot.SintomaFallaLiderID = sfl.ID
        LEFT JOIN CatClasificacionesFallaLider clf ON ot.ClasificacionFallaLiderID = clf.ID
        LEFT JOIN CatCausas4M c4m ON ot.Causa4MID = c4m.ID
        LEFT JOIN CatFallasComunes fr ON ot.FallaRealID = fr.ID
        LEFT JOIN CatUsuarios ulid ON ot.LiderReportaID = ulid.ID
        WHERE {where_sql}
        ORDER BY ot.ID DESC
    """

    rows = run_query(query, tuple(sql_params), 'SELECT')

    # Generar libro de trabajo Excel (.xlsx) con openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = trans.get('history_title', 'Historial OTs')[:31]
    ws.views.sheetView[0].showGridLines = True

    # Estilos corporativos MTS
    fill_header = PatternFill(start_color="0284C7", end_color="0284C7", fill_type="solid")
    fill_title = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
    fill_zebra = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid")

    font_title = Font(name="Calibri", size=14, bold=True, color="FFFFFF")
    font_subtitle = Font(name="Calibri", size=9, italic=True, color="475569")
    font_header = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
    font_body = Font(name="Calibri", size=10, color="0F172A")

    thin_border = Border(
        left=Side(style='thin', color='E2E8F0'),
        right=Side(style='thin', color='E2E8F0'),
        top=Side(style='thin', color='E2E8F0'),
        bottom=Side(style='thin', color='E2E8F0')
    )

    num_cols = len(cols_validas)

    # 1. Fila 1: Banner de Título traducido
    title_banner_text = trans.get('excel_title_banner', 'MTS CMMS - REPORTE DE HISTORIAL DE ÓRDENES DE TRABAJO')
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=num_cols)
    cell_title = ws.cell(row=1, column=1, value=title_banner_text)
    cell_title.font = font_title
    cell_title.fill = fill_title
    cell_title.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 32

    # 2. Fila 2: Subtítulo con información de generación traducida
    now_str = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
    lbl_gen_by = trans.get('excel_subtitle_generated_by', 'Generado por')
    lbl_date = trans.get('excel_subtitle_date', 'Fecha')
    lbl_range = trans.get('excel_subtitle_range', 'Rango')
    lbl_all = trans.get('excel_subtitle_all', 'Histórico Completo')

    rango_str = f"{lbl_range}: {fecha_inicio} - {fecha_fin}" if (modo_alcance == 'rango_fechas' and fecha_inicio) else f"{lbl_range}: {lbl_all}"
    sub_text = f"{lbl_gen_by}: {current_user.nombre} ({current_user.rol}) | {lbl_date}: {now_str} | {rango_str}"
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=num_cols)
    cell_sub = ws.cell(row=2, column=1, value=sub_text)
    cell_sub.font = font_subtitle
    cell_sub.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[2].height = 18

    # 3. Fila 4: Encabezados de Columna traducidos al idioma activo
    ws.row_dimensions[4].height = 24
    for col_idx, col_key in enumerate(cols_validas, start=1):
        i18n_key = COLUMN_DEFINITIONS[col_key]['key']
        header_translated = trans.get(i18n_key, COLUMN_DEFINITIONS[col_key]['header'])
        
        cell_h = ws.cell(row=4, column=col_idx, value=header_translated)
        cell_h.font = font_header
        cell_h.fill = fill_header
        cell_h.alignment = Alignment(horizontal="center", vertical="center")
        cell_h.border = thin_border

    # 4. Filas 5+: Datos del reporte
    current_row = 5
    for row_data in rows:
        ws.row_dimensions[current_row].height = 20
        use_zebra = (current_row % 2 == 0)

        for col_idx, col_key in enumerate(cols_validas, start=1):
            val = row_data.get(col_key)

            # Formatear valores según su tipo
            if isinstance(val, datetime.datetime):
                val_str = val.strftime('%Y-%m-%d %H:%M')
            elif isinstance(val, datetime.date):
                val_str = val.strftime('%Y-%m-%d')
            elif val is None:
                val_str = "N/A"
            else:
                val_str = str(val)

            cell = ws.cell(row=current_row, column=col_idx, value=val_str)
            cell.font = font_body
            cell.border = thin_border
            
            if use_zebra:
                cell.fill = fill_zebra

            if col_key in ['ot_id', 'estado', 'tipo_mantenimiento', 'empleados_afectados', 'downtime_total_min', 'tiempo_soporte_min', 'tiempo_pausado_min', 'mttr_neto_min']:
                cell.alignment = Alignment(horizontal="center", vertical="center")
            else:
                cell.alignment = Alignment(horizontal="left", vertical="center")

        current_row += 1

    # Congelar paneles para que los títulos queden fijos al hacer scroll
    ws.freeze_panes = 'A5'

    # Auto-ajuste dinámico de ancho de columnas
    for col_idx in range(1, num_cols + 1):
        max_len = 0
        col_letter = openpyxl.utils.get_column_letter(col_idx)
        for row_idx in range(4, current_row):
            val_cell = ws.cell(row=row_idx, column=col_idx).value
            if val_cell:
                max_len = max(max_len, len(str(val_cell)))
        ws.column_dimensions[col_letter].width = max(max_len + 4, 14)

    # Devolver el archivo Excel en respuesta HTTP
    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)

    filename_date = datetime.datetime.now().strftime('%Y%m%d_%H%M')
    return Response(
        buffer.getvalue(),
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        headers={'Content-Disposition': f'attachment; filename=Reporte_OTs_MTS_{filename_date}.xlsx'}
    )


    # 4. Filas 5+: Datos del reporte
    current_row = 5
    for row_data in rows:
        ws.row_dimensions[current_row].height = 20
        use_zebra = (current_row % 2 == 0)

        for col_idx, col_key in enumerate(cols_validas, start=1):
            val = row_data.get(col_key)

            # Formatear valores según su tipo
            if isinstance(val, datetime.datetime):
                val_str = val.strftime('%Y-%m-%d %H:%M')
            elif isinstance(val, datetime.date):
                val_str = val.strftime('%Y-%m-%d')
            elif val is None:
                val_str = "N/A"
            else:
                val_str = str(val)

            cell = ws.cell(row=current_row, column=col_idx, value=val_str)
            cell.font = font_body
            cell.border = thin_border
            
            if use_zebra:
                cell.fill = fill_zebra

            if col_key in ['ot_id', 'estado', 'tipo_mantenimiento', 'empleados_afectados', 'downtime_total_min', 'tiempo_soporte_min', 'tiempo_pausado_min', 'mttr_neto_min']:
                cell.alignment = Alignment(horizontal="center", vertical="center")
            else:
                cell.alignment = Alignment(horizontal="left", vertical="center")

        current_row += 1

    # Congelar paneles para que los títulos queden fijos al hacer scroll
    ws.freeze_panes = 'A5'

    # Auto-ajuste dinámico de ancho de columnas
    for col_idx in range(1, num_cols + 1):
        max_len = 0
        col_letter = openpyxl.utils.get_column_letter(col_idx)
        for row_idx in range(4, current_row):
            val_cell = ws.cell(row=row_idx, column=col_idx).value
            if val_cell:
                max_len = max(max_len, len(str(val_cell)))
        ws.column_dimensions[col_letter].width = max(max_len + 4, 14)

    # Devolver el archivo Excel en respuesta HTTP
    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)

    filename_date = datetime.datetime.now().strftime('%Y%m%d_%H%M')
    return Response(
        buffer.getvalue(),
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        headers={'Content-Disposition': f'attachment; filename=Reporte_OTs_MTS_{filename_date}.xlsx'}
    )



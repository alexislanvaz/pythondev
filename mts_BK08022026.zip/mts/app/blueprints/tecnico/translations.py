TRANSLATIONS = {
    'es': {
        'menu_tech_panel': 'Panel de Técnico',
        # Panel Técnico
        'tech_panel_title': 'Panel de Tareas y Órdenes de Trabajo Activas',
        'btn_start_on_demand': 'Iniciar Soporte Sin OT (En Sitio)',
        'btn_attend': 'Atender',
        
        # Atención de OT
        'attend_ot_title': 'Atención e Intervención de Orden de Trabajo',
        'step_1_scan_qr': '1. Escanear Código QR para Confirmar Arribo en Sitio',
        'qr_placeholder': 'Escanear o ingresar código QR...',
        'btn_register_arrival': 'Confirmar Arribo QR',
        'step_2_select_equipment': '2. Seleccionar Equipo a Intervenir',
        'btn_start_support': 'Iniciar Soporte en Equipo',
        'step_3_diagnose_close': '3. Diagnóstico y Cierre de Orden',
        'select_real_fault': 'Seleccionar Modo de Falla Real',
        'closing_comments': 'Comentarios de Solución Aplicada',
        'btn_complete_close': 'Completar y Cerrar OT Exitosamente',
        'btn_pause_ot': 'Pausar Trabajo',
        'btn_handover_ot': 'Transferir a Otro Técnico',

        # Modal Pausa
        'modal_pause_title': 'Pausar Orden de Trabajo',
        'select_pause_reason': 'Seleccione Motivo de Pausa Estandarizado',
        'pause_comment': 'ComentarioExplicativo',
        'btn_confirm_pause': 'Confirmar Pausa',

        # Modal Transferencia (Handover)
        'modal_handover_title': 'Transferencia de Turno (Handover)',
        'select_incoming_tech': 'Seleccione Técnico Entrante',
        'handover_notes': 'Notas de Entrega de Turno',
        'btn_confirm_handover': 'Confirmar Transferencia',

        # Soporte On-Demand
        'on_demand_title': 'Atención de Soporte In-Situ (On-Demand)',
        'on_demand_subtitle': 'Genere una orden de trabajo e inicie la atención directamente en el equipo sin reporte previo del líder.',
        'btn_start_on_demand_submit': 'Crear e Iniciar Soporte In-Situ'
    },
    'en': {
        'menu_tech_panel': 'Tech Panel',
        # Tech Panel
        'tech_panel_title': 'Active Tasks & Work Orders Panel',
        'btn_start_on_demand': 'Start On-Demand Support (On-Site)',
        'btn_attend': 'Attend',
        
        # Attend WO
        'attend_ot_title': 'Work Order Attention & Intervention',
        'step_1_scan_qr': '1. Scan QR Code to Confirm On-Site Arrival',
        'qr_placeholder': 'Scan or enter QR code...',
        'btn_register_arrival': 'Confirm QR Arrival',
        'step_2_select_equipment': '2. Select Equipment to Intervene',
        'btn_start_support': 'Start Equipment Support',
        'step_3_diagnose_close': '3. Diagnosis & Order Closure',
        'select_real_fault': 'Select Real Failure Mode',
        'closing_comments': 'Applied Solution Comments',
        'btn_complete_close': 'Complete and Close WO Successfully',
        'btn_pause_ot': 'Pause Work',
        'btn_handover_ot': 'Transfer to Another Tech',

        # Pause Modal
        'modal_pause_title': 'Pause Work Order',
        'select_pause_reason': 'Select Standardized Pause Reason',
        'pause_comment': 'Explanatory Comment',
        'btn_confirm_pause': 'Confirm Pause',

        # Handover Modal
        'modal_handover_title': 'Shift Transfer (Handover)',
        'select_incoming_tech': 'Select Incoming Technician',
        'handover_notes': 'Shift Handover Notes',
        'btn_confirm_handover': 'Confirm Transfer',

        # On-Demand Support
        'on_demand_title': 'On-Site Support Attention (On-Demand)',
        'on_demand_subtitle': 'Generate a work order and start attention directly on the equipment without a prior leader report.',
        'btn_start_on_demand_submit': 'Create & Start On-Site Support'
    }
}

import datetime
import os
import pyodbc
from app.config import Config

def generate_scripts():
    print("Conectando a SQL Server para extraer esquema y datos...")
    conn = pyodbc.connect(Config.CONN_STRING)
    cursor = conn.cursor()

    querys_dir = os.path.join(os.path.dirname(__file__), 'querys')
    if not os.path.exists(querys_dir):
        os.makedirs(querys_dir)

    schema_file_path = os.path.join(querys_dir, 'sp_Schema_Completo_MTS.sql')
    seed_file_path = os.path.join(querys_dir, 'sp_Seed_Data_Pruebas_MTS.sql')

    # =========================================================================
    # 1. SCRIPT DE ESQUEMA COMPLETO (sp_Schema_Completo_MTS.sql)
    # =========================================================================
    schema_sql = []
    schema_sql.append("-- ===========================================================================")
    schema_sql.append("-- MTS CMMS - SCRIPT DE ESTRUCTURA Y BASE DE DATOS COMPLETA")
    schema_sql.append("-- Incluye: Creación de BD, Tablas, Claves Primarias/Foráneas y Procedimientos Almacenados")
    schema_sql.append("-- ===========================================================================\n")
    schema_sql.append("IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = N'MTS_CMMS')")
    schema_sql.append("BEGIN")
    schema_sql.append("    EXEC('CREATE DATABASE [MTS_CMMS]');")
    schema_sql.append("END")
    schema_sql.append("GO\n")
    schema_sql.append("USE [MTS_CMMS];")
    schema_sql.append("GO\n")

    # Lista ordenada de creación de tablas para evitar conflictos de Foreign Key
    tables_ordered = [
        "CatAreas",
        "CatRoles",
        "CatTurnos",
        "CatEstadosOT",
        "CatMotivosPausa",
        "CatCausas4M",
        "CatClasificacionesFallaLider",
        "CatSintomasFallaLider",
        "CatTiposEquipo",
        "CatFallasComunes",
        "CatSolucionesComunes",
        "CatModosFallaReal",
        "CatRutinasPreventivas",
        "CatUsuarios",
        "CatLineas",
        "CatEstaciones",
        "CatEquipos",
        "RecursosSoporte",
        "CatMateriales",
        "ConfiguracionEscalaciones",
        "OrdenesTrabajo",
        "DetalleTecnicosOT",
        "RegistroPausasOT",
        "BitacoraEstadosOT",
        "BitacoraTransferenciasOT",
        "MaterialesOT",
        "EvidenciasOT",
        "ColaNotificaciones",
        "ProgramacionPreventivos"
    ]

    for t in tables_ordered:
        schema_sql.append(f"-- ---------------------------------------------------------------------------")
        schema_sql.append(f"-- Tabla: {t}")
        schema_sql.append(f"-- ---------------------------------------------------------------------------")
        schema_sql.append(f"IF OBJECT_ID(N'dbo.{t}', N'U') IS NULL")
        schema_sql.append("BEGIN")
        schema_sql.append(f"    CREATE TABLE dbo.[{t}] (")

        # Obtener columnas de la tabla desde SQL Server sys/INFORMATION_SCHEMA
        cursor.execute("""
            SELECT 
                c.name AS ColumnName,
                t.name AS DataType,
                c.max_length AS MaxLength,
                c.precision AS Precision,
                c.scale AS Scale,
                c.is_nullable AS IsNullable,
                c.is_identity AS IsIdentity
            FROM sys.columns c
            INNER JOIN sys.types t ON c.user_type_id = t.user_type_id
            WHERE c.object_id = OBJECT_ID(?)
            ORDER BY c.column_id
        """, (t,))
        cols = cursor.fetchall()

        col_defs = []
        for col_name, data_type, max_len, prec, scale, is_null, is_id in cols:
            col_str = f"        [{col_name}] {data_type.upper()}"
            if data_type in ['varchar', 'nvarchar', 'char', 'nchar']:
                if max_len == -1:
                    col_str += "(MAX)"
                else:
                    length = max_len // 2 if data_type.startswith('n') else max_len
                    col_str += f"({length})"
            elif data_type in ['decimal', 'numeric']:
                col_str += f"({prec},{scale})"

            if is_id:
                col_str += " IDENTITY(1,1)"

            if col_name == 'ID':
                col_str += " PRIMARY KEY"

            if not is_null:
                col_str += " NOT NULL"
            else:
                col_str += " NULL"

            if col_name == 'activo':
                col_str += " DEFAULT 1"
            elif col_name == 'fecharegistro':
                col_str += " DEFAULT GETDATE()"

            col_defs.append(col_str)

        schema_sql.append(",\n".join(col_defs))
        schema_sql.append("    );")
        schema_sql.append("END")
        schema_sql.append("GO\n")

    # Agregar Procedimientos Almacenados
    procs = [
        'sp_OT_Crear_Correctiva',
        'sp_OT_Completar_V2',
        'sp_OT_CrearYAtenderOnDemand',
        'sp_OT_IniciarSoporte',
        'sp_OT_Pausar',
        'sp_OT_Reanudar',
        'sp_OT_RegistrarArriboQR',
        'sp_OT_TransferirTurno',
        'sp_ProcesarEscalacionAlertas'
    ]

    schema_sql.append("-- ===========================================================================")
    schema_sql.append("-- PROCEDIMIENTOS ALMACENADOS")
    schema_sql.append("-- ===========================================================================\n")

    for p in procs:
        cursor.execute("SELECT OBJECT_DEFINITION(OBJECT_ID(?))", (p,))
        row = cursor.fetchone()
        if row and row[0]:
            p_def = row[0].strip()
            if p_def.endswith(';'):
                p_def = p_def[:-1].rstrip()
            schema_sql.append(f"-- ---------------------------------------------------------------------------")
            schema_sql.append(f"-- Procedimiento: {p}")
            schema_sql.append(f"-- ---------------------------------------------------------------------------")
            schema_sql.append(f"IF OBJECT_ID(N'dbo.{p}', N'P') IS NOT NULL")
            schema_sql.append(f"    DROP PROCEDURE dbo.[{p}];")
            schema_sql.append("GO\n")
            schema_sql.append(p_def)
            schema_sql.append("\nGO\n")

    with open(schema_file_path, 'w', encoding='utf-8') as f:
        f.write("\n".join(schema_sql))
    print(f"Script de Esquema Completo generado con éxito en: {schema_file_path}")

    # =========================================================================
    # 2. SCRIPT DE DATOS DE PRUEBA (sp_Seed_Data_Pruebas_MTS.sql)
    # =========================================================================
    seed_sql = []
    seed_sql.append("-- ===========================================================================")
    seed_sql.append("-- MTS CMMS - SCRIPT DE DATOS DE PRUEBA COMPLETO (SEED DATA)")
    seed_sql.append("-- Incluye datos para catálogos, usuarios, líneas, estaciones, equipos y OTs")
    seed_sql.append("-- ===========================================================================\n")
    seed_sql.append("USE [MTS_CMMS];")
    seed_sql.append("GO\n")
    seed_sql.append("SET NOCOUNT ON;\n")

    for t in tables_ordered:
        cursor.execute(f"SELECT COUNT(*) FROM [{t}]")
        cnt = cursor.fetchone()[0]
        if cnt == 0:
            continue

        cursor.execute(f"SELECT * FROM [{t}] ORDER BY ID")
        rows = cursor.fetchall()
        cols = [column[0] for column in cursor.description]

        # Verificar si la tabla tiene columna IDENTITY
        cursor.execute("SELECT c.name FROM sys.columns c WHERE c.object_id = OBJECT_ID(?) AND c.is_identity = 1", (t,))
        has_identity = bool(cursor.fetchone())

        seed_sql.append(f"-- ---------------------------------------------------------------------------")
        seed_sql.append(f"-- Datos de Prueba para la Tabla: {t} ({cnt} registros)")
        seed_sql.append(f"-- ---------------------------------------------------------------------------")
        
        if has_identity:
            seed_sql.append(f"SET IDENTITY_INSERT dbo.[{t}] ON;\n")

        for row in rows:
            val_strs = []
            for val in row:
                if val is None:
                    val_strs.append("NULL")
                elif isinstance(val, bool):
                    val_strs.append("1" if val else "0")
                elif isinstance(val, (int, float)):
                    val_strs.append(str(val))
                elif isinstance(val, datetime.datetime):
                    val_strs.append(f"N'{val.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]}'")
                elif isinstance(val, datetime.date):
                    val_strs.append(f"N'{val.strftime('%Y-%m-%d')}'")
                elif isinstance(val, datetime.time):
                    val_strs.append(f"N'{val.strftime('%H:%M:%S')}'")
                elif isinstance(val, (bytes, bytearray)):
                    val_strs.append("NULL")
                else:
                    # Escapar comillas simples
                    clean_str = str(val).replace("'", "''")
                    val_strs.append(f"N'{clean_str}'")

            col_names_join = ", ".join([f"[{c}]" for c in cols])
            vals_join = ", ".join(val_strs)

            seed_sql.append(f"IF NOT EXISTS (SELECT 1 FROM dbo.[{t}] WHERE [ID] = {row[0]})")
            seed_sql.append(f"    INSERT INTO dbo.[{t}] ({col_names_join}) VALUES ({vals_join});")

        if has_identity:
            seed_sql.append(f"\nSET IDENTITY_INSERT dbo.[{t}] OFF;")
        
        seed_sql.append("GO\n")

    with open(seed_file_path, 'w', encoding='utf-8') as f:
        f.write("\n".join(seed_sql))
    print(f"Script de Datos de Prueba generado con éxito en: {seed_file_path}")

    cursor.close()
    conn.close()

if __name__ == "__main__":
    generate_scripts()

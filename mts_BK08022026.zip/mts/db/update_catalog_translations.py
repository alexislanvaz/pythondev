import os
import re

cat_dir = os.path.join('app', 'blueprints', 'catalogo', 'templates', 'catalogo')

file_mappings = {
    'areas.html': {
        'Catálogo Maestro de Áreas': "{{ _('cat_areas_title') }}",
        'Gestión de divisiones y áreas físicas de la planta de producción.': "{{ _('cat_areas_subtitle') }}",
        'Registrar Área': "{{ _('register_area') }}",
        'Nombre de la Área': "{{ _('area_name') }}",
        'Nombre del Área': "{{ _('area_name') }}",
        'Descripción': "{{ _('description') }}",
        'Cancelar Edición': "{{ _('btn_cancel_edit') }}",
        'Acciones': "{{ _('actions') }}"
    },
    'equipos.html': {
        'Catálogo Maestro de Equipos': "{{ _('cat_equipos_title') }}",
        'Gestión de activos, modelos, números de serie y etiquetas QR.': "{{ _('cat_equipos_subtitle') }}",
        'Registrar Equipo': "{{ _('register_equipment') }}",
        'Nombre del Equipo': "{{ _('equipment_name') }}",
        'Tipo de Equipo': "{{ _('equipment_type') }}",
        'Número de Serie': "{{ _('serial_number') }}",
        'Código QR': "{{ _('qr_code') }}",
        'Cancelar Edición': "{{ _('btn_cancel_edit') }}",
        'Acciones': "{{ _('actions') }}"
    },
    'estaciones.html': {
        'Catálogo Maestro de Estaciones': "{{ _('cat_estaciones_title') }}",
        'Gestión de estaciones de trabajo y generación de códigos QR.': "{{ _('cat_estaciones_subtitle') }}",
        'Registrar Estación': "{{ _('register_station') }}",
        'Nombre de la Estación': "{{ _('station_name') }}",
        'Cancelar Edición': "{{ _('btn_cancel_edit') }}",
        'Acciones': "{{ _('actions') }}"
    },
    'fallas.html': {
        'Modos de Falla Técnica': "{{ _('cat_fallas_title') }}",
        'Registro de fallas técnicas estandarizadas por tipo de equipo.': "{{ _('cat_fallas_subtitle') }}",
        'Registrar Modo de Falla': "{{ _('register_failure') }}",
        'Código de Falla': "{{ _('failure_code') }}",
        'Nombre de la Falla': "{{ _('failure_name') }}",
        'Cancelar Edición': "{{ _('btn_cancel_edit') }}",
        'Acciones': "{{ _('actions') }}"
    },
    'fallas_comunes.html': {
        'Fallas Comunes de Planta': "{{ _('cat_fallas_comunes_title') }}",
        'Catálogo maestro de modos de falla asignados a activos.': "{{ _('cat_fallas_comunes_subtitle') }}",
        'Registrar Falla Común': "{{ _('register_failure') }}",
        'Cancelar Edición': "{{ _('btn_cancel_edit') }}",
        'Acciones': "{{ _('actions') }}"
    },
    'lineas.html': {
        'Catálogo Maestro de Líneas': "{{ _('cat_lineas_title') }}",
        'Gestión de líneas de producción asignadas a cada área.': "{{ _('cat_lineas_subtitle') }}",
        'Registrar Línea': "{{ _('register_line') }}",
        'Nombre de la Línea': "{{ _('line_name') }}",
        'Cancelar Edición': "{{ _('btn_cancel_edit') }}",
        'Acciones': "{{ _('actions') }}"
    },
    'recursos_soporte.html': {
        'Recursos de Soporte Técnico': "{{ _('cat_recursos_soporte_title') }}",
        'Manuales en PDF y guías audiovisuales de mantenimiento.': "{{ _('cat_recursos_soporte_subtitle') }}",
        'Subir Recurso de Soporte': "{{ _('register_resource') }}",
        'Nombre del Recurso': "{{ _('resource_name') }}",
        'Tipo de Recurso': "{{ _('resource_type') }}",
        'Archivo (PDF / Video)': "{{ _('resource_file') }}",
        'Cancelar Edición': "{{ _('btn_cancel_edit') }}",
        'Acciones': "{{ _('actions') }}"
    },
    'roles.html': {
        'Catálogo de Roles de Usuario': "{{ _('cat_roles_title') }}",
        'Definición de permisos y niveles de acceso al sistema.': "{{ _('cat_roles_subtitle') }}",
        'Registrar Rol': "{{ _('register_role') }}",
        'Rol de Usuario': "{{ _('role') }}",
        'Cancelar Edición': "{{ _('btn_cancel_edit') }}",
        'Acciones': "{{ _('actions') }}"
    },
    'soluciones_comunes.html': {
        'Soluciones Comunes Estandarizadas': "{{ _('cat_soluciones_comunes_title') }}",
        'Guías de solución recomendadas por modo de falla.': "{{ _('cat_soluciones_comunes_subtitle') }}",
        'Registrar Solución': "{{ _('register_solution') }}",
        'Nombre de la Solución': "{{ _('solution_name') }}",
        'Cancelar Edición': "{{ _('btn_cancel_edit') }}",
        'Acciones': "{{ _('actions') }}"
    },
    'tipos_equipos.html': {
        'Catálogo de Tipos de Equipo': "{{ _('cat_tipos_equipos_title') }}",
        'Clasificación de maquinarias y herramientas industriales.': "{{ _('cat_tipos_equipos_subtitle') }}",
        'Registrar Tipo de Equipo': "{{ _('register_equipment_type') }}",
        'Tipo de Equipo': "{{ _('equipment_type') }}",
        'Cancelar Edición': "{{ _('btn_cancel_edit') }}",
        'Acciones': "{{ _('actions') }}"
    },
    'turnos.html': {
        'Catálogo de Turnos Operativos': "{{ _('cat_turnos_title') }}",
        'Configuración de horarios de trabajo por turno.': "{{ _('cat_turnos_subtitle') }}",
        'Registrar Turno': "{{ _('register_shift') }}",
        'Hora de Inicio': "{{ _('start_time') }}",
        'Hora de Fin': "{{ _('end_time') }}",
        'Cancelar Edición': "{{ _('btn_cancel_edit') }}",
        'Acciones': "{{ _('actions') }}"
    },
    'usuarios.html': {
        'Control de Usuarios de Planta': "{{ _('cat_usuarios_title') }}",
        'Gestión de credenciales, roles, áreas y turnos operativos.': "{{ _('cat_usuarios_subtitle') }}",
        'Registrar Usuario': "{{ _('register_user') }}",
        'Nombre del Empleado': "{{ _('employee_name') }}",
        'Número de Empleado': "{{ _('employee_no') }}",
        'Correo Electrónico': "{{ _('email') }}",
        'Rol de Usuario': "{{ _('role') }}",
        'Turno Operativo': "{{ _('shift') }}",
        'Cancelar Edición': "{{ _('btn_cancel_edit') }}",
        'Acciones': "{{ _('actions') }}"
    }
}

for fname, mapping in file_mappings.items():
    fpath = os.path.join(cat_dir, fname)
    if os.path.exists(fpath):
        with open(fpath, 'r', encoding='utf-8') as f:
            content = f.read()
        for src, target in mapping.items():
            content = content.replace(src, target)
        with open(fpath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"OK: {fname} traducido con exito.")

import os
import re

cat_dir = os.path.join('app', 'blueprints', 'catalogo', 'templates', 'catalogo')

def process_file(fname):
    fpath = os.path.join(cat_dir, fname)
    with open(fpath, 'r', encoding='utf-8') as f:
        content = f.read()

    tbl_match = re.search(r'id=["\'](tabla-[^"\']+)["\']', content)
    if not tbl_match:
        print(f"Skipping {fname}: no table id found")
        return
    tbl_id = tbl_match.group(1)

    # 1. Contar columnas en <thead>
    thead_match = re.search(r'<thead>(.*?)</thead>', content, re.DOTALL)
    if not thead_match:
        print(f"Skipping {fname}: no thead found")
        return
    thead_inner = thead_match.group(1)
    
    # Si no tiene <tr class="filters-row">, agregarla
    if 'filters-row' not in thead_inner:
        ths = re.findall(r'<th[^>]*>(.*?)</th>', thead_inner, re.DOTALL)
        num_cols = len(ths)

        filters_row = '\n                <tr class="filters-row">\n' + ''.join(['                    <th></th>\n'] * num_cols) + '                </tr>'

        new_thead_inner = re.sub(
            r'<th([^>]*)>(\s*Acciones\s*)</th>',
            r'<th\1 class="no-filter">\2</th>',
            thead_inner
        )

        new_thead_inner = new_thead_inner.rstrip() + filters_row + '\n            '
        content = content.replace(thead_inner, new_thead_inner)

    # 2. Actualizar inicialización de DataTables si no tiene initComplete
    if 'initComplete' not in content:
        target_str = f"$('#{tbl_id}').DataTable({{"
        if target_str in content:
            replacement_str = f"""$('#{tbl_id}').DataTable({{
                "orderCellsTop": true,
                initComplete: function () {{
                    var api = this.api();
                    api.columns().every(function (colIdx) {{
                        var column = this;
                        var header = $(column.header());
                        var headerText = header.text().trim();
                        var filterCell = $('#{tbl_id} thead tr.filters-row th').eq(colIdx);

                        if (header.hasClass('no-filter') || headerText.toLowerCase().includes('acciones') || headerText.toLowerCase().includes('acción') || headerText.toLowerCase().includes('accion')) {{
                            filterCell.html('<span style="font-size:0.7rem; color:var(--text-secondary); opacity:0.4;">-</span>');
                            return;
                        }}

                        var input = $('<input type="text" placeholder="Filtrar..." class="col-filter-input" />')
                            .appendTo(filterCell.empty())
                            .on('keyup change clear', function () {{
                                if (column.search() !== this.value) {{
                                    column.search(this.value).draw();
                                }}
                            }});
                    }});
                }},"""
            content = content.replace(target_str, replacement_str)

    with open(fpath, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"OK: {fname} procesado con exito (Tabla: #{tbl_id})")

if __name__ == "__main__":
    for fname in sorted(os.listdir(cat_dir)):
        if fname.endswith('.html'):
            process_file(fname)

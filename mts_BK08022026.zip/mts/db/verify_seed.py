from app.config import Config
import pyodbc

conn = pyodbc.connect(Config.CONN_STRING)
cursor = conn.cursor()

def fetch(query):
    cursor.execute(query)
    cols = [col[0] for col in cursor.description]
    return [dict(zip(cols, row)) for row in cursor.fetchall()]

print('=== RESUMEN DE REGISTROS EN BASE DE DATOS ===')
tables = [
    'CatAreas', 'CatLineas', 'CatEstaciones', 'CatTiposEquipo', 'CatEquipos',
    'CatRoles', 'CatUsuarios', 'CatSintomasFallaLider', 'CatFallasComunes',
    'CatSolucionesComunes', 'OrdenesTrabajo', 'BitacoraEstadosOT',
    'DetalleTecnicosOT', 'RegistroPausasOT'
]

for t in tables:
    cursor.execute(f'SELECT COUNT(*) FROM {t}')
    print(f'{t:25s}: {cursor.fetchone()[0]} registros')

print('\n=== DISTRIBUCIÓN DE OTs POR ESTADO ===')
ots_by_state = fetch('''
    SELECT e.Nombre as Estado, COUNT(ot.ID) as Total
    FROM OrdenesTrabajo ot
    JOIN CatEstadosOT e ON ot.EstadoID = e.ID
    GROUP BY e.Nombre
''')
for row in ots_by_state:
    print(f'  Estado {row["Estado"]:10s}: {row["Total"]} OTs')

print('\n=== DISTRIBUCIÓN DE OTs POR LÍNEA ===')
ots_by_line = fetch('''
    SELECT l.Nombre as Linea, COUNT(ot.ID) as Total
    FROM OrdenesTrabajo ot
    JOIN CatEstaciones est ON ot.EstacionID = est.ID
    JOIN CatLineas l ON est.LineaID = l.ID
    GROUP BY l.Nombre
    ORDER BY Total DESC
''')
for row in ots_by_line:
    print(f'  Línea {row["Linea"]:12s}: {row["Total"]} OTs')

conn.close()

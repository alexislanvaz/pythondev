from app.config import Config
import pyodbc

def apply_fixes():
    print("Conectando a SQL Server para aplicar correcciones...")
    conn = pyodbc.connect(Config.CONN_STRING)
    cursor = conn.cursor()

    try:
        # 1. Backfill de FechaInicioSoporte en OrdenesTrabajo donde sea NULL y exista FechaArriboQR
        cursor.execute("""
            UPDATE ot
            SET ot.FechaInicioSoporte = dt.FechaArriboQR
            FROM OrdenesTrabajo ot
            INNER JOIN (
                SELECT OrdenTrabajoID, MIN(FechaArriboQR) AS FechaArriboQR
                FROM DetalleTecnicosOT
                WHERE FechaArriboQR IS NOT NULL AND activo = 1
                GROUP BY OrdenTrabajoID
            ) dt ON ot.ID = dt.OrdenTrabajoID
            WHERE ot.FechaInicioSoporte IS NULL;
        """)
        updated_rows = cursor.rowcount
        print(f"Backfill completado. Registros actualizados en OrdenesTrabajo: {updated_rows}")

        # 2. Actualizar sp_OT_RegistrarArriboQR para asegurar que FechaInicioSoporte siempre se registre al arribar
        sp_arribo_sql = """
        ALTER PROCEDURE sp_OT_RegistrarArriboQR
            @OrdenTrabajoID INT,
            @TecnicoID INT,
            @CodigoQR VARCHAR(150)
        AS
        BEGIN
            SET NOCOUNT ON;
            BEGIN TRY
                BEGIN TRANSACTION;

                -- Verificar que el QR corresponda a la estación de la OT o a un equipo de dicha estación
                DECLARE @CleanQR VARCHAR(150) = LTRIM(RTRIM(@CodigoQR));
                IF NOT EXISTS (
                    SELECT 1 
                    FROM OrdenesTrabajo ot
                    INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
                    WHERE ot.ID = @OrdenTrabajoID AND est.CodigoQR = @CleanQR AND ot.activo = 1
                ) AND NOT EXISTS (
                    SELECT 1
                    FROM OrdenesTrabajo ot
                    INNER JOIN CatEquipos eq ON ot.EstacionID = eq.EstacionID
                    WHERE ot.ID = @OrdenTrabajoID AND eq.CodigoQR = @CleanQR AND ot.activo = 1
                )
                BEGIN
                    THROW 50001, 'El código QR escaneado no corresponde a la estación ni a los equipos de esta orden de trabajo.', 1;
                END

                DECLARE @EstadoOngoingID INT;
                DECLARE @EstadoActualID INT;
                SELECT TOP 1 @EstadoOngoingID = ID FROM CatEstadosOT WHERE Nombre = 'ONGOING' AND activo = 1;
                SELECT @EstadoActualID = EstadoID FROM OrdenesTrabajo WHERE ID = @OrdenTrabajoID;

                -- 1. Actualizar OrdenesTrabajo: cambiar a ONGOING y asegurar FechaInicioSoporte
                UPDATE OrdenesTrabajo
                SET EstadoID = @EstadoOngoingID,
                    FechaInicioSoporte = COALESCE(FechaInicioSoporte, GETDATE())
                WHERE ID = @OrdenTrabajoID;

                -- 2. Registrar en Bitacora si cambió de estado
                IF EXISTS (SELECT 1 FROM CatEstadosOT WHERE ID = @EstadoActualID AND Nombre = 'CREATED')
                BEGIN
                    INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, Comentario)
                    VALUES (@OrdenTrabajoID, @EstadoActualID, @EstadoOngoingID, @TecnicoID, 'Arribo de técnico registrado por escaneo de QR. Estado cambiado a ONGOING.');
                END

                -- 3. Insertar o actualizar en DetalleTecnicosOT
                IF EXISTS (SELECT 1 FROM DetalleTecnicosOT WHERE OrdenTrabajoID = @OrdenTrabajoID AND TecnicoID = @TecnicoID AND activo = 1)
                BEGIN
                    UPDATE DetalleTecnicosOT
                    SET FechaArriboQR = COALESCE(FechaArriboQR, GETDATE())
                    WHERE OrdenTrabajoID = @OrdenTrabajoID AND TecnicoID = @TecnicoID AND activo = 1;
                END
                ELSE
                BEGIN
                    INSERT INTO DetalleTecnicosOT (OrdenTrabajoID, TecnicoID, FechaAsignacion, FechaArriboQR, activo, fecharegistro)
                    VALUES (@OrdenTrabajoID, @TecnicoID, GETDATE(), GETDATE(), 1, GETDATE());
                END

                COMMIT TRANSACTION;
            END TRY
            BEGIN CATCH
                IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
                THROW;
            END CATCH;
        END;
        """
        cursor.execute(sp_arribo_sql)
        print("sp_OT_RegistrarArriboQR actualizado correctamente.")

        # 3. Actualizar sp_OT_Completar_V2 para resguardar FechaInicioSoporte si aún era NULL
        sp_completar_v2_sql = """
        ALTER PROCEDURE sp_OT_Completar_V2
            @OrdenTrabajoID INT,
            @EquipoID INT, 
            @FallaRealID INT,
            @TecnicoID INT,
            @ComentariosSolucion VARCHAR(500)
        AS
        BEGIN
            SET NOCOUNT ON;
            BEGIN TRY
                BEGIN TRANSACTION;

                DECLARE @EstadoClosedID INT;
                DECLARE @EstadoActualID INT;
                
                SELECT TOP 1 @EstadoClosedID = ID FROM CatEstadosOT WHERE Nombre = 'CLOSED' AND activo = 1;
                SELECT @EstadoActualID = EstadoID FROM OrdenesTrabajo WHERE ID = @OrdenTrabajoID;

                -- 1. Actualizar orden principal asegurando FechaInicioSoporte
                UPDATE OrdenesTrabajo
                SET EstadoID = @EstadoClosedID,
                    EquipoID = @EquipoID,
                    FallaRealID = @FallaRealID,
                    FechaInicioSoporte = COALESCE(
                        FechaInicioSoporte, 
                        (SELECT TOP 1 FechaArriboQR FROM DetalleTecnicosOT WHERE OrdenTrabajoID = @OrdenTrabajoID AND activo = 1 ORDER BY ID ASC),
                        GETDATE()
                    )
                WHERE ID = @OrdenTrabajoID;

                -- 2. Registrar fin del técnico firmante
                UPDATE DetalleTecnicosOT
                SET FechaFinActividad = GETDATE()
                WHERE OrdenTrabajoID = @OrdenTrabajoID AND TecnicoID = @TecnicoID AND FechaFinActividad IS NULL AND activo = 1;

                -- 3. Bitácora
                INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, Comentario)
                VALUES (@OrdenTrabajoID, @EstadoActualID, @EstadoClosedID, @TecnicoID, @ComentariosSolucion);

                COMMIT TRANSACTION;
            END TRY
            BEGIN CATCH
                IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
                THROW;
            END CATCH;
        END;
        """
        cursor.execute(sp_completar_v2_sql)
        print("sp_OT_Completar_V2 actualizado correctamente.")

        conn.commit()
        print("Todas las correcciones en base de datos se aplicaron con éxito.")

    except Exception as e:
        conn.rollback()
        print(f"Error al aplicar correcciones en BD: {e}")
        raise e
    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__":
    apply_fixes()

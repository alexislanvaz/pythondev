import datetime
import random
import pyodbc
from werkzeug.security import generate_password_hash
from app.config import Config

def seed_database():
    print("Iniciando proceso de seeding en SQL Server...")
    conn = pyodbc.connect(Config.CONN_STRING)
    cursor = conn.cursor()

    try:
        # 1. CatTiposEquipo
        tipos_equipo_data = [
            ("PLC", "Controlador Lógico Programable"),
            ("PC", "Computadora de control de estación"),
            ("ROBOT DE ATORNILLADO", "Robot cartesiano / multieje de atornillado automático"),
            ("SMT PICK & PLACE", "Máquina de colocación de componentes SMT"),
            ("HORNO DE REFLUJO", "Horno de soldado por reflujo multifase"),
            ("LECTOR CODIGO DE BARRAS / VISION", "Sistema de inspección por visión y código QR/1D/2D"),
            ("ATORNILLADOR ELECTRICO", "Herramienta de torque controlado eléctrico"),
            ("BANDA TRANSPORTADORA", "Conveyor de transporte de tablillas/tarjetas"),
            ("PRENSA NEUMATICA", "Prensa neumática de ensamble de conectores")
        ]

        tipos_equipo_map = {}
        for nombre, desc in tipos_equipo_data:
            cursor.execute("SELECT ID FROM CatTiposEquipo WHERE Nombre = ?", (nombre,))
            row = cursor.fetchone()
            if row:
                tipos_equipo_map[nombre] = row[0]
            else:
                cursor.execute("""
                    INSERT INTO CatTiposEquipo (Nombre, Descripcion, activo, fecharegistro, UsuarioRegistroID)
                    OUTPUT INSERTED.ID
                    VALUES (?, ?, 1, GETDATE(), 1)
                """, (nombre, desc))
                tipos_equipo_map[nombre] = cursor.fetchone()[0]
        print(f"CatTiposEquipo listo. Total tipos: {len(tipos_equipo_map)}")

        # 2. CatSintomasFallaLider
        sintomas_data = [
            ("PC No Responde", "Pantalla congelada o software fuera de línea"),
            ("Robot no cicla", "Robot detenido a mitad de secuencia o fuera de home"),
            ("Fuga de aire neumático", "Pérdida de presión neumática en manguera o conector"),
            ("Error de lectura de código QR / Barcode", "El escáner no lee el código de la tarjeta"),
            ("Banda transportadora detenida / ruidosa", "Conveyor atascado o con ruido metálico excesivo"),
            ("Error de torque en atornillador", "Torque fuera de especificación alta/baja"),
            ("Alarmas de temperatura en horno", "Desviación de temperatura en zona de calentamiento"),
            ("Atasco de PCB en estación", "Tablilla atascada en rieles o tope neumático"),
            ("Fallo de comunicación Ethernet/IP", "Pérdida de ping/comunicación entre PLC y PC"),
            ("Celda fotoeléctrica descalibrada", "Sensor no detecta presencia de producto")
        ]

        sintomas_ids = []
        for nombre, desc in sintomas_data:
            cursor.execute("SELECT ID FROM CatSintomasFallaLider WHERE Nombre = ?", (nombre,))
            row = cursor.fetchone()
            if row:
                sintomas_ids.append(row[0])
            else:
                cursor.execute("""
                    INSERT INTO CatSintomasFallaLider (Nombre, Descripcion, activo, fecharegistro, UsuarioRegistroID)
                    OUTPUT INSERTED.ID
                    VALUES (?, ?, 1, GETDATE(), 1)
                """, (nombre, desc))
                sintomas_ids.append(cursor.fetchone()[0])
        print(f"CatSintomasFallaLider listo. Total síntomas: {len(sintomas_ids)}")

        # 3. CatFallasComunes y CatSolucionesComunes
        fallas_soluciones_data = [
            ("PC", "PC-FM-A001", "PC Ciclada", "La PC no responde", ["Reinicio de PC", "Reemplazo de fuente de poder"]),
            ("PLC", "PLC-FM-A001", "PLC CICLADO", "PLC congelado en ciclo de scan", ["RESTART PLC", "Recarga de programa vía RSLogix"]),
            ("ROBOT DE ATORNILLADO", "ROB-FM-001", "Descalibración de Cero / Home", "Eje Z desfasado provocando paro de emergencia", ["Calibración de cero y home de ejes", "Ajuste de sensor home"]),
            ("ROBOT DE ATORNILLADO", "ROB-FM-002", "Error de comunicación con Robot", "Falta de señal READY de controlador", ["Reinicio de controlador de robot", "Reemplazo de cable de comunicación I/O"]),
            ("SMT PICK & PLACE", "SMT-FM-001", "Vacío insuficiente en boquilla", "Pérdida de componentes durante el picado", ["Limpieza y reemplazo de boquilla de vacío", "Ajuste de bomba de vacío"]),
            ("HORNO DE REFLUJO", "HRN-FM-001", "Desviación Térmica en Zona 3", "Temperatura cayó por debajo de tolerancia de soldadura", ["Reemplazo de sensor termopar", "Calibración de controlador PID de zona"]),
            ("LECTOR CODIGO DE BARRAS / VISION", "VIS-FM-001", "Foco desalineado en cámara", "Lectura borrosa de datamatrix", ["Ajuste manual de foco y ganancia LED", "Limpieza de lente con alcohol isopropílico"]),
            ("ATORNILLADOR ELECTRICO", "ATN-FM-001", "Embrague de torque desgastado", "Torque se dispara antes de llegar al valor nominal", ["Reemplazo de resorte y embrague mecánico", "Ajuste con torquímetro digital"]),
            ("BANDA TRANSPORTADORA", "BND-FM-001", "Banda destensada", "Riel desalineado provoca patina de la banda", ["Ajuste de tensión de tensores laterales", "Reemplazo de banda de goma"]),
            ("PRENSA NEUMATICA", "PRS-FM-001", "Fuga en Solenoide 5/2", "Cilindro no baja con suficiente fuerza", ["Reemplazo de solenoide neumático", "Cambio de empaques de cilindro"])
        ]

        fallas_ids = []
        for tipo_eq, cod, nom, desc, soluciones in fallas_soluciones_data:
            t_id = tipos_equipo_map[tipo_eq]
            cursor.execute("SELECT ID FROM CatFallasComunes WHERE CodigoFalla = ?", (cod,))
            row = cursor.fetchone()
            if row:
                f_id = row[0]
            else:
                cursor.execute("""
                    INSERT INTO CatFallasComunes (TipoEquipoID, CodigoFalla, Nombre, Descripcion, activo, fecharegistro, UsuarioRegistroID)
                    OUTPUT INSERTED.ID
                    VALUES (?, ?, ?, ?, 1, GETDATE(), 1)
                """, (t_id, cod, nom, desc))
                f_id = cursor.fetchone()[0]
            fallas_ids.append(f_id)

            for sol_nom in soluciones:
                cursor.execute("SELECT ID FROM CatSolucionesComunes WHERE FallaComunID = ? AND Nombre = ?", (f_id, sol_nom))
                if not cursor.fetchone():
                    cursor.execute("""
                        INSERT INTO CatSolucionesComunes (FallaComunID, Nombre, Descripcion, activo, fecharegistro, UsuarioRegistroID)
                        VALUES (?, ?, ?, 1, GETDATE(), 1)
                    """, (f_id, sol_nom, f"Solución estandarizada: {sol_nom}"))
        print(f"CatFallasComunes y Soluciones listos. Total fallas: {len(fallas_ids)}")

        # 4. CatUsuarios con roles
        default_pwd_hash = generate_password_hash("1234")
        
        # Roles IDs:
        # 1: Administrador, 2: Supervisor, 3: Ingeniero, 4: Tecnico, 5: Lider de linea
        usuarios_data = [
            ("9001", "Carlos Mendoza", "carlos.mendoza@cmms.com", 1, 2, 2), # Admin
            ("5001", "Roberto Gómez", "roberto.gomez@cmms.com", 2, 2, 2), # Sup SMT
            ("5002", "Laura Sánchez", "laura.sanchez@cmms.com", 2, 3, 3), # Sup FA-HMI
            ("5003", "Fernando Castillo", "fernando.castillo@cmms.com", 2, 4, 4), # Sup FA-E&E
            ("4001", "Ing. David Morales", "david.morales@cmms.com", 3, 3, 2), # Ing
            ("4002", "Ing. Ana Patricia Vega", "ana.vega@cmms.com", 3, 2, 3), # Ing
            ("3001", "Tech. Juan Pérez", "juan.perez@cmms.com", 4, 3, 2), # Tecnico Turno 1ro
            ("3002", "Tech. Miguel Ángel Torres", "miguel.torres@cmms.com", 4, 3, 3), # Tecnico Turno A8
            ("3003", "Tech. Ricardo Ruiz", "ricardo.ruiz@cmms.com", 4, 4, 4), # Tecnico Turno B8
            ("3004", "Tech. Alejandro Silva", "alejandro.silva@cmms.com", 4, 2, 5), # Tecnico Turno C8
            ("3005", "Tech. Daniel Cruz", "daniel.cruz@cmms.com", 4, 4, 2), # Tecnico Turno 1ro
            ("2001", "Líder María Hernández", "maria.hernandez@cmms.com", 5, 3, 2), # Lider
            ("2002", "Líder José Luis Ramírez", "jose.ramirez@cmms.com", 5, 3, 3), # Lider
            ("2003", "Líder Sofía Espinoza", "sofia.espinoza@cmms.com", 5, 4, 4), # Lider
            ("2004", "Líder Gabriel Vargas", "gabriel.vargas@cmms.com", 5, 2, 5), # Lider
            ("2005", "Líder Javier Reyes", "javier.reyes@cmms.com", 5, 4, 2)  # Lider
        ]

        usuarios_by_role = {1: [], 2: [], 3: [], 4: [], 5: []}
        
        # Recuperar usuarios existentes
        cursor.execute("SELECT ID, RolID FROM CatUsuarios WHERE activo = 1")
        for u_id, r_id in cursor.fetchall():
            if r_id in usuarios_by_role:
                usuarios_by_role[r_id].append(u_id)

        for no_emp, nom, correo, rol_id, area_id, turno_id in usuarios_data:
            cursor.execute("SELECT ID FROM CatUsuarios WHERE NoEmpleado = ?", (no_emp,))
            row = cursor.fetchone()
            if row:
                u_id = row[0]
            else:
                cursor.execute("""
                    INSERT INTO CatUsuarios (NoEmpleado, Nombre, Correo, RolID, AreaID, TurnoID, activo, fecharegistro, PasswordHash, UsuarioRegistroID)
                    OUTPUT INSERTED.ID
                    VALUES (?, ?, ?, ?, ?, ?, 1, GETDATE(), ?, 1)
                """, (no_emp, nom, correo, rol_id, area_id, turno_id, default_pwd_hash))
                u_id = cursor.fetchone()[0]
            if u_id not in usuarios_by_role[rol_id]:
                usuarios_by_role[rol_id].append(u_id)

        print("CatUsuarios actualizado. Conteo por rol:")
        for r_id, u_list in usuarios_by_role.items():
            print(f"  Rol {r_id}: {len(u_list)} usuarios")

        # 5. CatEstaciones y CatEquipos por líneas
        cursor.execute("SELECT ID, AreaID, Nombre FROM CatLineas WHERE activo = 1")
        lineas = cursor.fetchall()

        estaciones_list = []
        equipos_list = []

        for line_id, area_id, line_nom in lineas:
            # Crear o verificar al menos 2 estaciones por línea
            est_nombres = ["EST-01 ATORNILLADO", "EST-02 TESTER / INSPECCIÓN", "EST-03 ENSAMBLE FINAL"]
            for idx, est_nom in enumerate(est_nombres, 1):
                clean_line = line_nom.replace(" ", "-")
                qr_code = f"QR-{clean_line}-ST{idx}"
                full_est_nom = f"{line_nom} {est_nom}"

                cursor.execute("SELECT ID FROM CatEstaciones WHERE CodigoQR = ?", (qr_code,))
                row = cursor.fetchone()
                if row:
                    e_id = row[0]
                else:
                    cursor.execute("""
                        INSERT INTO CatEstaciones (LineaID, Nombre, CodigoQR, activo, fecharegistro, UsuarioRegistroID)
                        OUTPUT INSERTED.ID
                        VALUES (?, ?, ?, 1, GETDATE(), 1)
                    """, (line_id, full_est_nom, qr_code))
                    e_id = cursor.fetchone()[0]
                estaciones_list.append(e_id)

                # Crear o verificar equipo en esta estación
                eq_nom = f"EQUIPO-{clean_line}-ST{idx}"
                eq_qr = f"EQ-QR-{clean_line}-ST{idx}"
                t_eq_id = random.choice(list(tipos_equipo_map.values()))

                cursor.execute("SELECT ID FROM CatEquipos WHERE EstacionID = ? AND Nombre = ?", (e_id, eq_nom))
                row_eq = cursor.fetchone()
                if row_eq:
                    eq_id = row_eq[0]
                else:
                    cursor.execute("""
                        INSERT INTO CatEquipos (EstacionID, TipoEquipoID, Nombre, Modelo, NumeroSerie, activo, fecharegistro, UsuarioRegistroID, CodigoQR)
                        OUTPUT INSERTED.ID
                        VALUES (?, ?, ?, ?, ?, 1, GETDATE(), 1, ?)
                    """, (e_id, t_eq_id, eq_nom, "MOD-2026-IND", f"SN-2026-{e_id:04d}", eq_qr))
                    eq_id = cursor.fetchone()[0]
                equipos_list.append((eq_id, t_eq_id))

        print(f"Estaciones y Equipos preparados. Total estaciones: {len(estaciones_list)}, Total equipos: {len(equipos_list)}")

        # 6. Generación de 55+ Órdenes de Trabajo (OTs)
        # Estados: 1=CREATED, 2=ONGOING, 3=STOPPED, 4=CANCELED, 5=CLOSED
        # Motivos de pausa: 1=falta Material, 2=Descanso, 3=En espera Herramienta, 4=Escalamiento
        
        cursor.execute("SELECT ID FROM CatClasificacionesFallaLider WHERE activo = 1")
        clasif_ids = [r[0] for r in cursor.fetchall()]

        cursor.execute("SELECT ID FROM CatCausas4M WHERE activo = 1")
        causas4m_ids = [r[0] for r in cursor.fetchall()]

        cursor.execute("SELECT ID FROM CatTurnos WHERE activo = 1")
        turnos_ids = [r[0] for r in cursor.fetchall()]

        impactos = ["LINEA_COMPLETA", "ESTACION_CUELLO_BOTELLA", "ESTACION_REGULAR"]

        # Definir distribución de OTs a generar (total 55 nuevas OTs)
        ot_plan = [
            (1, 'CORRECTIVO', 8),   # CREATED
            (1, 'PREVENTIVO', 4),   # CREATED
            (2, 'CORRECTIVO', 10),  # ONGOING
            (2, 'PREVENTIVO', 5),   # ONGOING
            (3, 'CORRECTIVO', 6),   # STOPPED
            (3, 'PREVENTIVO', 2),   # STOPPED
            (4, 'CORRECTIVO', 3),   # CANCELED
            (4, 'PREVENTIVO', 2),   # CANCELED
            (5, 'CORRECTIVO', 12),  # CLOSED
            (5, 'PREVENTIVO', 8)    # CLOSED
        ]

        lideres = usuarios_by_role[5]
        tecnicos = usuarios_by_role[4]
        inges = usuarios_by_role[3]
        admins = usuarios_by_role[1]

        total_ots_created = 0
        now = datetime.datetime.now()

        for estado_id, tipo_mto, cnt in ot_plan:
            for _ in range(cnt):
                # Generar fecha de reporte aleatoria entre hace 14 días y hoy
                days_ago = random.randint(0, 14)
                hours_ago = random.randint(0, 23)
                mins_ago = random.randint(0, 59)
                fecha_reporte = now - datetime.timedelta(days=days_ago, hours=hours_ago, minutes=mins_ago)

                est_id = random.choice(estaciones_list)
                lider_id = random.choice(lideres)
                turno_id = random.choice(turnos_ids)
                sintoma_id = random.choice(sintomas_ids)
                clasif_id = random.choice(clasif_ids)
                causa4m_id = random.choice(causas4m_ids)
                impacto = random.choice(impactos)
                emp_afectados = random.randint(0, 8)
                comentario = f"Reporte automático de prueba en {tipo_mto} para estación {est_id}."

                # Falla real y equipo diagnosticado para OTs avanzadas/cerradas
                falla_real_id = random.choice(fallas_ids) if estado_id in (2, 3, 5) else None
                equipo_target_id = random.choice(equipos_list)[0] if estado_id in (2, 3, 5) else None

                cursor.execute("""
                    INSERT INTO OrdenesTrabajo (
                        EstacionID, EquipoID, FallaRealID, EstadoID, LiderReportaID, TurnoID,
                        SintomaFallaLiderID, ClasificacionFallaLiderID, Causa4MID, AreaAfectadaImpacto,
                        EmpleadosAfectados, ComentarioLider, FechaReporte, TipoMantenimiento,
                        activo, fecharegistro, UsuarioRegistroID
                    )
                    OUTPUT INSERTED.ID
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
                """, (
                    est_id, equipo_target_id, falla_real_id, estado_id, lider_id, turno_id,
                    sintoma_id, clasif_id, causa4m_id, impacto,
                    emp_afectados, comentario, fecha_reporte, tipo_mto,
                    fecha_reporte, lider_id
                ))
                ot_id = cursor.fetchone()[0]
                total_ots_created += 1

                # 1. Bitácora inicial CREATED
                cursor.execute("""
                    INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, FechaCambio, Comentario, activo)
                    VALUES (?, NULL, 1, ?, ?, 'OT Creada.', 1)
                """, (ot_id, lider_id, fecha_reporte))

                # Si es CREATED, continuar
                if estado_id == 1:
                    continue

                # 2. Transición a ONGOING / Asignación de técnico
                tecnico_id = random.choice(tecnicos)
                fecha_asig = fecha_reporte + datetime.timedelta(minutes=random.randint(2, 15))
                fecha_arribo = fecha_asig + datetime.timedelta(minutes=random.randint(3, 20))

                cursor.execute("""
                    UPDATE OrdenesTrabajo SET FechaInicioSoporte = ? WHERE ID = ?
                """, (fecha_arribo, ot_id))

                cursor.execute("""
                    INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, FechaCambio, Comentario, activo)
                    VALUES (?, 1, 2, ?, ?, 'Técnico escaneó QR y comenzó atención.', 1)
                """, (ot_id, tecnico_id, fecha_arribo))

                if estado_id == 2: # ONGOING
                    cursor.execute("""
                        INSERT INTO DetalleTecnicosOT (OrdenTrabajoID, TecnicoID, FechaAsignacion, FechaArriboQR, FechaFinActividad, activo)
                        VALUES (?, ?, ?, ?, NULL, 1)
                    """, (ot_id, tecnico_id, fecha_asig, fecha_arribo))
                    continue

                if estado_id == 3: # STOPPED
                    fecha_pausa_inicio = fecha_arribo + datetime.timedelta(minutes=random.randint(10, 45))
                    motivo_pausa = random.randint(1, 4)
                    
                    cursor.execute("""
                        INSERT INTO DetalleTecnicosOT (OrdenTrabajoID, TecnicoID, FechaAsignacion, FechaArriboQR, FechaFinActividad, activo)
                        VALUES (?, ?, ?, ?, NULL, 1)
                    """, (ot_id, tecnico_id, fecha_asig, fecha_arribo))

                    cursor.execute("""
                        INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, FechaCambio, Comentario, activo)
                        VALUES (?, 2, 3, ?, ?, 'OT Pausada por técnico.', 1)
                    """, (ot_id, tecnico_id, fecha_pausa_inicio))

                    cursor.execute("""
                        INSERT INTO RegistroPausasOT (OrdenTrabajoID, MotivoPausaID, UsuarioPausaID, FechaInicioPausa, FechaFinPausa, Comentario, activo)
                        VALUES (?, ?, ?, ?, NULL, 'En espera de refacciones/soporte.', 1)
                    """, (ot_id, motivo_pausa, tecnico_id, fecha_pausa_inicio))
                    continue

                if estado_id == 4: # CANCELED
                    fecha_canc = fecha_reporte + datetime.timedelta(minutes=random.randint(5, 30))
                    user_canc = random.choice(inges + admins)
                    cursor.execute("""
                        INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, FechaCambio, Comentario, activo)
                        VALUES (?, 1, 4, ?, ?, 'OT Cancelada por duplicidad o falsa alarma.', 1)
                    """, (ot_id, user_canc, fecha_canc))
                    continue

                if estado_id == 5: # CLOSED
                    duracion_min = random.randint(20, 180)
                    fecha_fin = fecha_arribo + datetime.timedelta(minutes=duracion_min)

                    cursor.execute("""
                        INSERT INTO DetalleTecnicosOT (OrdenTrabajoID, TecnicoID, FechaAsignacion, FechaArriboQR, FechaFinActividad, activo)
                        VALUES (?, ?, ?, ?, ?, 1)
                    """, (ot_id, tecnico_id, fecha_asig, fecha_arribo, fecha_fin))

                    cursor.execute("""
                        INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, FechaCambio, Comentario, activo)
                        VALUES (?, 2, 5, ?, ?, 'OT Finalizada y Cerrada exitosamente.', 1)
                    """, (ot_id, tecnico_id, fecha_fin))

        conn.commit()
        print(f"Seeding finalizado con éxito. Total de OTs generadas: {total_ots_created}")

    except Exception as e:
        conn.rollback()
        print(f"Error durante el seeding: {e}")
        raise e
    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__":
    seed_database()

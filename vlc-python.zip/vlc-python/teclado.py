# from pymouse import PyMouse
from pykeyboard import PyKeyboard

# m = PyMouse()
k = PyKeyboard()

# pressing a key
import time
time.sleep(1)
while True:
    time.sleep(0.5)
    k.press_key('H')

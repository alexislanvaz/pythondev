import subprocess

# subprocess.run(["vlc", "--help"])


ruta = r"F:\prueba.mkv"
play = "Page Up"
pause = "Page Down"

comando = ["vlc", ruta,"--repeat","--fullscreen","--global-key-play="+play,"--global-key-pause="+pause]
print(type(comando))
subprocess.run(comando)

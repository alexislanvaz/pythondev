import os
import logging
from logging.handlers import RotatingFileHandler
from flask import Flask, session, request, redirect, url_for, render_template
from flask_login import LoginManager, login_required
from app.config import Config
from app.models import User
from app.blueprints.auth.translations import TRANSLATIONS as AUTH_TRANSLATIONS
from app.blueprints.catalogo.translations import TRANSLATIONS as CATALOGO_TRANSLATIONS
from app.blueprints.ingenieria.translations import TRANSLATIONS as INGENIERIA_TRANSLATIONS
from app.blueprints.lider.translations import TRANSLATIONS as LIDER_TRANSLATIONS
from app.blueprints.tecnico.translations import TRANSLATIONS as TECNICO_TRANSLATIONS
from app.blueprints.checklist.translations import TRANSLATIONS as CHECKLIST_TRANSLATIONS

def load_translations():
    """Consolida dinámicamente las traducciones de todos los blueprints."""
    merged = {'es': {}, 'en': {}}
    blueprint_translations = [
        AUTH_TRANSLATIONS,
        CATALOGO_TRANSLATIONS,
        INGENIERIA_TRANSLATIONS,
        LIDER_TRANSLATIONS,
        TECNICO_TRANSLATIONS,
        CHECKLIST_TRANSLATIONS
    ]
    for b_trans in blueprint_translations:
        for lang in ['es', 'en']:
            if lang in b_trans:
                merged[lang].update(b_trans[lang])
    return merged

TRANSLATIONS = load_translations()

# Instanciar LoginManager
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message_category = 'warning'

@login_manager.user_loader
def load_user(user_id):
    """Carga un usuario de la sesión mediante pyodbc y run_query de forma segura."""
    if not user_id:
        return None
    try:
        return User.get(int(user_id))
    except (ValueError, TypeError, Exception):
        return None

def create_app():
    """Factoría de aplicación Flask."""
    app = Flask(__name__)
    app.config.from_object(Config)

    # 1. Configuración de Logging Rotativo en Carpeta Física
    log_dir = os.path.join(app.root_path, 'logs')
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
        
    file_handler = RotatingFileHandler(
        os.path.join(log_dir, 'app.log'), 
        maxBytes=10*1024*1024, # 10MB
        backupCount=5,
        encoding='utf-8'
    )
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
    ))
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
    app.logger.setLevel(logging.INFO)
    app.logger.info('Servidor CMMS iniciado exitosamente.')

    # 2. Inicializar Login Manager
    login_manager.init_app(app)

    # 3. Context Processor Global de Traducciones para Jinja2
    @app.context_processor
    def inject_translations():
        lang = session.get('lang', 'es')
        def translate(key):
            return TRANSLATIONS.get(lang, TRANSLATIONS['es']).get(key, key)
        return dict(_=translate, current_lang=lang)

    # 4. Ruta Global para cambiar el idioma
    @app.route('/change-lang/<lang_code>')
    def change_language(lang_code):
        if lang_code in ['es', 'en']:
            session['lang'] = lang_code
        # Redirigir de regreso a la página anterior o al index por defecto
        return redirect(request.referrer or url_for('index'))

    # Servir archivos subidos como evidencias
    from flask import send_from_directory
    @app.route('/static/uploads/<path:filename>')
    def serve_uploads(filename):
        upload_dir = os.path.join(app.root_path, 'static', 'uploads')
        storage_dir = app.config.get('STORAGE_PATH', upload_dir)
        if os.path.exists(os.path.join(storage_dir, filename)):
            return send_from_directory(storage_dir, filename)
        elif os.path.exists(os.path.join(upload_dir, filename)):
            return send_from_directory(upload_dir, filename)
        return "Archivo no encontrado", 404

    # 5. Registro de Blueprints
    from app.blueprints.db import db_bp
    from app.blueprints.db.routes import close_db_connection
    from app.blueprints.auth.routes import auth_bp
    from app.blueprints.lider.routes import lider_bp
    from app.blueprints.tecnico.routes import tecnico_bp
    from app.blueprints.ingenieria.routes import ingenieria_bp
    from app.blueprints.catalogo.routes import catalogo_bp
    from app.blueprints.api.routes import api_bp
    from app.blueprints.checklist.routes import checklist_bp

    app.register_blueprint(db_bp, url_prefix='/db')
    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(lider_bp, url_prefix='/lider')
    app.register_blueprint(tecnico_bp, url_prefix='/tecnico')
    app.register_blueprint(ingenieria_bp, url_prefix='/ingenieria')
    app.register_blueprint(catalogo_bp, url_prefix='/catalogo')
    app.register_blueprint(api_bp, url_prefix='/api')
    app.register_blueprint(checklist_bp, url_prefix='/checklist')

    # Liberación limpia de conexiones de base de datos al finalizar cada petición
    app.teardown_appcontext(close_db_connection)

    # 6. Optimizaciones de Red LAN, Caché HTTP y Compresión Gzip para Tablets Sunmi C11
    import gzip
    @app.after_request
    def optimize_network_and_cache(response):
        # A) Control de Caché HTTP Inteligente
        path = request.path
        if path.startswith('/static/'):
            # Recursos estáticos (librerías vendor JS, CSS, fuentes WOFF2, iconos)
            # se almacenan de forma permanente en la tablet para evitar descargas repetidas
            if not path.startswith('/static/uploads/'):
                response.headers['Cache-Control'] = 'public, max-age=31536000, immutable'
            else:
                # Evidencias/fotos de trabajo se cachean por 1 hora
                response.headers['Cache-Control'] = 'public, max-age=3600'
        else:
            # Las páginas dinámicas HTML no se cachean para mantener métricas en tiempo real
            if response.mimetype == 'text/html':
                response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
                response.headers['Pragma'] = 'no-cache'

        # B) Compresión Gzip al vuelo (Reduce hasta 70% el tráfico en la red LAN industrial)
        accept_encoding = request.headers.get('Accept-Encoding', '')
        if 'gzip' in accept_encoding.lower() and 200 <= response.status_code < 300 and 'Content-Encoding' not in response.headers:
            content_type = response.content_type or ''
            compressible = any(t in content_type for t in [
                'text/', 'javascript', 'json', 'xml', 'svg+xml', 'font/', 'application/x-font-ttf'
            ])
            if compressible:
                if response.direct_passthrough:
                    response.direct_passthrough = False
                data = response.get_data()
                if len(data) > 400:
                    compressed = gzip.compress(data, compresslevel=6)
                    if len(compressed) < len(data):
                        response.set_data(compressed)
                        response.headers['Content-Encoding'] = 'gzip'
                        response.headers['Content-Length'] = len(compressed)
                        response.headers['Vary'] = 'Accept-Encoding'

        return response



    # Ruta raíz principal (Menú Central / Hub con Métricas en Vivo)
    @app.route('/')
    @login_required
    def index():
        from app.blueprints.db import run_query
        from flask_login import current_user
        
        metrics = {
            'ots_activas': 0,
            'ots_en_proceso': 0,
            'ots_espera': 0,
            'ots_detenidas': 0,
            'pms_pendientes': 0,
            'pms_completados': 0,
            'pms_total': 0,
            'pms_pct': 0,
            'checklists_hoy': 0,
            'checklists_total': 0,
            'equipos_total': 0,
            'mis_ots_activas': 0,
            'mis_checklists_hoy': 0
        }
        
        try:
            ot_stats = run_query("""
                SELECT 
                    COUNT(*) AS Total,
                    SUM(CASE WHEN EstadoID IN (1, 2, 3) THEN 1 ELSE 0 END) AS Activas,
                    SUM(CASE WHEN EstadoID = 1 THEN 1 ELSE 0 END) AS CreadasEspera,
                    SUM(CASE WHEN EstadoID = 2 THEN 1 ELSE 0 END) AS EnProceso,
                    SUM(CASE WHEN EstadoID = 3 THEN 1 ELSE 0 END) AS Detenidas
                FROM OrdenesTrabajo 
                WHERE activo = 1
            """, query_type='SELECT')
            if ot_stats and ot_stats[0]['Total'] is not None:
                metrics['ots_activas'] = ot_stats[0]['Activas'] or 0
                metrics['ots_espera'] = ot_stats[0]['CreadasEspera'] or 0
                metrics['ots_en_proceso'] = ot_stats[0]['EnProceso'] or 0
                metrics['ots_detenidas'] = ot_stats[0]['Detenidas'] or 0

            pm_stats = run_query("""
                SELECT 
                    SUM(CASE WHEN Estado = 'PROGRAMADA' THEN 1 ELSE 0 END) AS Programadas,
                    SUM(CASE WHEN Estado = 'COMPLETADA' THEN 1 ELSE 0 END) AS Completadas,
                    COUNT(*) AS Total
                FROM ProgramacionPreventivos 
                WHERE activo = 1
            """, query_type='SELECT')
            if pm_stats and pm_stats[0]['Total']:
                metrics['pms_pendientes'] = pm_stats[0]['Programadas'] or 0
                metrics['pms_completados'] = pm_stats[0]['Completadas'] or 0
                metrics['pms_total'] = pm_stats[0]['Total'] or 0
                if metrics['pms_total'] > 0:
                    metrics['pms_pct'] = round((metrics['pms_completados'] / metrics['pms_total']) * 100, 1)

            chk_stats = run_query("""
                SELECT 
                    COUNT(*) AS Total,
                    SUM(CASE WHEN CAST(FechaEjecucion AS DATE) = CAST(GETDATE() AS DATE) THEN 1 ELSE 0 END) AS Hoy
                FROM ChecklistEjecuciones 
                WHERE activo = 1
            """, query_type='SELECT')
            if chk_stats and chk_stats[0]['Total'] is not None:
                metrics['checklists_total'] = chk_stats[0]['Total'] or 0
                metrics['checklists_hoy'] = chk_stats[0]['Hoy'] or 0

            eq_stats = run_query("SELECT COUNT(*) AS Total FROM CatEquipos WHERE activo = 1", query_type='SELECT')
            if eq_stats and eq_stats[0]['Total'] is not None:
                metrics['equipos_total'] = eq_stats[0]['Total'] or 0

            if current_user.is_authenticated:
                tech_ots = run_query("""
                    SELECT COUNT(DISTINCT ot.ID) AS Total
                    FROM OrdenesTrabajo ot
                    INNER JOIN DetalleTecnicosOT dt ON dt.OrdenTrabajoID = ot.ID
                    WHERE dt.TecnicoID = ? AND dt.FechaFinActividad IS NULL AND ot.EstadoID = 2 AND ot.activo = 1
                """, (current_user.id,), query_type='SELECT')
                metrics['mis_ots_activas'] = tech_ots[0]['Total'] if tech_ots else 0

                tech_chks = run_query("""
                    SELECT COUNT(*) AS Total
                    FROM ChecklistEjecuciones
                    WHERE UsuarioID = ? AND CAST(FechaEjecucion AS DATE) = CAST(GETDATE() AS DATE) AND activo = 1
                """, (current_user.id,), query_type='SELECT')
                metrics['mis_checklists_hoy'] = tech_chks[0]['Total'] if tech_chks else 0

        except Exception as e:
            app.logger.error(f"Error cargando métricas del portal central: {e}")

        return render_template('home.html', metrics=metrics)

    return app

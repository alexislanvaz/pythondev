# handwritten-digit-detector
In This Project , It is a detect a real handwritten digits using python , OpenCV and tensorflow-keras.<br/>
this is also working for real time and image based script.<br/>
<br/>
Accuracy : 97.3%</b>
<br/>
You can clone this project and run it.<br/>
<br/>
this project is also contain some image and video which you can run and check it.<br/>
<br/>
All vidoes file is available in Video folder and Images are available in Image folder.<br/>
<br/>
Result of Image and Video are also available in resultimage and resultvideo folder respectivily.<br/>
<br/>
you can run realtimedetection.py file and check it using video and testscript.py for image.<br/>
<br/>
type command in terminal<br/>
<br/>
<code>python3 realTimedetection.py</code></br>
<br/>
<code>python3 testscript.py</code></br>
<br/>

<b>Result Image</b>
![Result Image](result_image.jpg)
![Result Image1](resultimage/image2.jpg)
![Result Image2](resultimage/image3.jpg)
![Result Image3](resultimage/image4.jpg)
![Result Image4](resultimage/image7.jpg)

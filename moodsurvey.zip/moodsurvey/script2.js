// Acceso a la cámara web
navigator.mediaDevices.getUserMedia({ video: true })
    .then(function(stream) {
        var video = document.getElementById('video');
        video.srcObject = stream;
        video.onloadedmetadata = function(e) {
            video.play();
        };
    })
    .catch(function(err) {
        console.log(err.name + ": " + err.message);
    });

// Captura de imagen
var canvas = document.getElementById('canvas');
var context = canvas.getContext('2d');
var video = document.getElementById('video');
document.getElementById("snap").addEventListener("click", function() {
    context.drawImage(video, 0, 0, 640, 480);
    var imgData = canvas.toDataURL();
    Tesseract.recognize(
        imgData,
        'eng',
        { logger: info => console.log(info) }
    ).then(({ data: { text } }) => {
        console.log(text);
    })
});

document.getElementById("save").addEventListener("click", function() {
    // guarda las respuestas del formulario
    // ...
    // muestra la cámara web
    document.getElementById("video").style.display = "block";
    document.getElementById("snap").style.display = "block";
});

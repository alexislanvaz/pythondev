const form = document.getElementById('surveyForm');
const questions = document.querySelectorAll('.question');
let currentQuestion = 0;

questions[currentQuestion].classList.add('active');

form.addEventListener('change', function (e) {
    if (e.target.tagName === 'INPUT' && e.target.type === 'radio') {
        questions[currentQuestion].classList.remove('active');
        currentQuestion++;
        if (currentQuestion < questions.length) {
            questions[currentQuestion].classList.add('active');
        }
    }
});

form.addEventListener('submit', function (e) {
    e.preventDefault();
    // Aquí puedes agregar el código para guardar las respuestas
    alert('Respuestas guardadas');
});

document.addEventListener('DOMContentLoaded', (event) => {
    const stars = document.querySelectorAll('.star-rating input');

    stars.forEach(star => {
        star.addEventListener('change', (e) => {
            let checked = e.target.checked;
            let currentStar = e.target;

            while (currentStar.previousElementSibling) {
                currentStar.previousElementSibling.checked = checked;
                currentStar = currentStar.previousElementSibling;
            }
        });
    });
});

# Misplaced Pin

This is a simple spot-the-difference game written in JavaScript. There are two panels onto which pins are placed. But the left-hand side panel has one extra pin that the right-hand side panel does not have. The objective of the game is to find that misplaced pin. More pins will be added anew to the panels as you progress up the game levels, making it more difficult to find out where the misplaced is.

![Misplaced Pin screenshot](screenshot.png "Misplaced Pin")

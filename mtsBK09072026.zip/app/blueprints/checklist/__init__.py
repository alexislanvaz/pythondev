from flask import Blueprint

checklist_bp = Blueprint('checklist', __name__, template_folder='templates')

from app.blueprints.checklist import routes

from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app.blueprints.db import run_query

tecnico_bp = Blueprint('tecnico', __name__, template_folder='templates')

@tecnico_bp.route('/panel')
@login_required
def panel_tareas():
    if current_user.rol not in ['Tecnico', 'Administrador']:
        flash('Acceso denegado: Se requiere rol de Técnico.', 'danger')
        return redirect(url_for('auth.login'))

    # Listar OTs activas usando run_query (retorna lista de diccionarios)
    tareas_activas = run_query("""
        SELECT ot.ID, lin.Nombre AS Linea, est.Nombre AS Estacion, eo.Nombre AS Estado, 
               ot.FechaReporte, ot.TipoMantenimiento, sfl.Nombre AS Sintoma,
               lid.Nombre AS LiderNombre
        FROM OrdenesTrabajo ot
        INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
        INNER JOIN CatLineas lin ON est.LineaID = lin.ID
        INNER JOIN CatEstadosOT eo ON ot.EstadoID = eo.ID
        LEFT JOIN CatFallasComunes sfl ON ot.SintomaFallaLiderID = sfl.ID
        LEFT JOIN CatUsuarios lid ON ot.LiderReportaID = lid.ID
        WHERE eo.Nombre IN ('CREATED', 'ONGOING', 'STOPPED')
          AND ot.activo = 1
        ORDER BY ot.FechaReporte DESC
    """, query_type='SELECT')

    return render_template('tecnico/panel.html', tareas=tareas_activas)

@tecnico_bp.route('/on-demand')
@login_required
def soporte_on_demand():
    if current_user.rol not in ['Tecnico', 'Administrador']:
        flash('Acceso denegado: Se requiere rol de Técnico.', 'danger')
        return redirect(url_for('auth.login'))

    # Cargar las líneas para la selección manual
    lineas = run_query("SELECT ID, Nombre FROM CatLineas WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    return render_template('tecnico/soporte_on_demand.html', lineas=lineas)

@tecnico_bp.route('/atencion/<int:ot_id>')
@login_required
def atender_ot(ot_id):
    if current_user.rol not in ['Tecnico', 'Administrador']:
        flash('Acceso denegado: Se requiere rol de Técnico.', 'danger')
        return redirect(url_for('auth.login'))

    # Obtener detalles de la Orden de Trabajo
    ot_rows = run_query("""
        SELECT ot.ID, est.Nombre AS Estacion, est.CodigoQR, eo.Nombre AS Estado, 
               ot.FechaReporte, ot.TipoMantenimiento, ot.EmpleadosAfectados,
               sfl.Nombre AS Sintoma, ot.ComentarioLider, ot.EstacionID,
               ot.FechaInicioSoporte, ot.EquipoID, eq.Nombre AS EquipoNombre
        FROM OrdenesTrabajo ot
        INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
        INNER JOIN CatEstadosOT eo ON ot.EstadoID = eo.ID
        LEFT JOIN CatFallasComunes sfl ON ot.SintomaFallaLiderID = sfl.ID
        LEFT JOIN CatEquipos eq ON ot.EquipoID = eq.ID
        WHERE ot.ID = ? AND ot.activo = 1
    """, (ot_id,), 'SELECT')

    if not ot_rows:
        flash('Orden de trabajo no encontrada.', 'danger')
        return redirect(url_for('tecnico.panel_tareas'))

    ot = ot_rows[0]
    estacion_id = ot['EstacionID']

    # Obtener equipos presentes en la estación
    equipos = run_query("""
        SELECT e.ID, e.Nombre, te.Nombre AS Tipo
        FROM CatEquipos e
        INNER JOIN CatTiposEquipo te ON e.TipoEquipoID = te.ID
        WHERE e.EstacionID = ? AND e.activo = 1
    """, (estacion_id,), 'SELECT')

    # Obtener líneas para la selección de backup
    lineas = run_query("SELECT ID, Nombre FROM CatLineas WHERE activo = 1 ORDER BY Nombre")

    # Obtener motivos de pausa para el modal
    motivos_pausa = run_query("SELECT ID, Nombre FROM CatMotivosPausa WHERE activo = 1 ORDER BY Nombre")

    # Obtener personal técnico activo para transferencias (handover)
    tecnicos_disponibles = run_query("""
        SELECT u.ID, u.Nombre 
        FROM CatUsuarios u
        INNER JOIN CatRoles r ON u.RolID = r.ID
        WHERE r.Nombre = 'Tecnico' AND u.ID <> ? AND u.activo = 1
    """, (current_user.id,), 'SELECT')

    # Obtener evidencia existente si la hubiera
    evidencia_existente = run_query("""
        SELECT TOP 1 PathArchivo 
        FROM EvidenciasOT 
        WHERE OrdenTrabajoID = ?
        ORDER BY ID DESC
    """, (ot_id,), 'SELECT')
    evidencia_path = evidencia_existente[0]['PathArchivo'] if evidencia_existente else None

    return render_template(
        'tecnico/atencion.html',
        ot=ot,
        equipos=equipos,
        lineas=lineas,
        motivos_pausa=motivos_pausa,
        tecnicos=tecnicos_disponibles,
        evidencia_path=evidencia_path
    )


@tecnico_bp.route('/base-conocimiento')
@login_required
def base_conocimiento():
    if current_user.rol not in ['Tecnico', 'Ingeniero', 'Administrador', 'Lider de Linea']:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('auth.login'))

    # Parámetros de filtro desde la URL
    search_query = request.args.get('q', '').strip()
    tipo_equipo_id = request.args.get('tipo_equipo_id', '')
    linea_id = request.args.get('linea_id', '')
    estacion_id = request.args.get('estacion_id', '')
    equipo_id = request.args.get('equipo_id', '')
    active_tab = request.args.get('tab', 'solutions')
    tipo_recurso = request.args.get('tipo_recurso', 'ALL')

    # Catálogos para los menús desplegables
    cat_tipos_equipo = run_query("SELECT ID, Nombre FROM CatTiposEquipo WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    cat_lineas = run_query("SELECT ID, Nombre FROM CatLineas WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')
    cat_estaciones = run_query("SELECT ID, Nombre, LineaID FROM CatEstaciones WHERE activo = 1 ORDER BY Nombre", query_type='SELECT')

    # 1. Soluciones Estándar del Catálogo
    sql_soluciones_estandar = """
        SELECT 
            s.ID, 
            s.Nombre AS SolucionNombre, 
            s.Descripcion AS SolucionPasos, 
            f.ID AS FallaID,
            f.CodigoFalla, 
            f.Nombre AS FallaNombre, 
            f.Descripcion AS FallaDescripcion,
            te.ID AS TipoEquipoID,
            te.Nombre AS TipoEquipoNombre,
            'ESTANDAR' AS Origen
        FROM CatSolucionesComunes s
        INNER JOIN CatFallasComunes f ON s.FallaComunID = f.ID AND f.activo = 1
        INNER JOIN CatTiposEquipo te ON f.TipoEquipoID = te.ID AND te.activo = 1
        WHERE s.activo = 1
    """
    soluciones_estandar = run_query(sql_soluciones_estandar, (), query_type='SELECT')

    # 2. Histórico de OTs Cerradas con Solución Aplicada
    sql_historico_ots = """
        SELECT 
            ot.ID AS OT_ID,
            ot.FechaReporte,
            (
                SELECT TOP 1 dt.FechaFinActividad 
                FROM DetalleTecnicosOT dt 
                WHERE dt.OrdenTrabajoID = ot.ID AND dt.activo = 1 
                ORDER BY dt.ID DESC
            ) AS FechaCierre,
            lin.Nombre AS LineaNombre,
            est.Nombre AS EstacionNombre,
            COALESCE(eq.Nombre, 'S/E') AS EquipoNombre,
            eq.Modelo AS EquipoModelo,
            eq.TipoEquipoID,
            te.Nombre AS TipoEquipoNombre,
            COALESCE(sfl.Nombre, 'Síntoma reportado') AS SintomaReportado,
            COALESCE(fr.Nombre, 'Falla diagnosticada') AS FallaRealNombre,
            fr.CodigoFalla AS FallaRealCodigo,
            (
                SELECT TOP 1 b.Comentario 
                FROM BitacoraEstadosOT b 
                WHERE b.OrdenTrabajoID = ot.ID 
                  AND b.EstadoNuevoID = (SELECT ID FROM CatEstadosOT WHERE Nombre IN ('CLOSED', 'Completada'))
                ORDER BY b.ID DESC
            ) AS ComentarioSolucion,
            (
                SELECT TOP 1 u.Nombre 
                FROM DetalleTecnicosOT dt 
                INNER JOIN CatUsuarios u ON dt.TecnicoID = u.ID
                WHERE dt.OrdenTrabajoID = ot.ID AND dt.activo = 1 
                ORDER BY dt.ID DESC
            ) AS TecnicoResolvio,
            'HISTORICO_OT' AS Origen
        FROM OrdenesTrabajo ot
        INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
        INNER JOIN CatLineas lin ON est.LineaID = lin.ID
        INNER JOIN CatEstadosOT eo ON ot.EstadoID = eo.ID AND eo.Nombre IN ('CLOSED', 'Completada')
        LEFT JOIN CatEquipos eq ON ot.EquipoID = eq.ID
        LEFT JOIN CatTiposEquipo te ON eq.TipoEquipoID = te.ID
        LEFT JOIN CatFallasComunes sfl ON ot.SintomaFallaLiderID = sfl.ID
        LEFT JOIN CatFallasComunes fr ON ot.FallaRealID = fr.ID
        WHERE ot.activo = 1
        ORDER BY ot.ID DESC
    """
    historico_ots = run_query(sql_historico_ots, (), query_type='SELECT')

    # 3. Biblioteca de Recursos de Soporte
    sql_recursos = """
        SELECT 
            r.ID, 
            r.Nombre AS Titulo, 
            r.TipoRecurso, 
            r.PathArchivo, 
            te.ID AS TipoEquipoID,
            te.Nombre AS TipoEquipoNombre,
            f.ID AS FallaComunID,
            CONCAT(f.CodigoFalla, ' - ', f.Nombre) AS FallaComunNombre
        FROM RecursosSoporte r
        INNER JOIN CatTiposEquipo te ON r.TipoEquipoID = te.ID AND te.activo = 1
        LEFT JOIN CatFallasComunes f ON r.FallaComunID = f.ID AND f.activo = 1
        WHERE r.activo = 1
        ORDER BY te.Nombre, r.Nombre
    """
    recursos_soporte = run_query(sql_recursos, (), query_type='SELECT')

    return render_template(
        'tecnico/base_conocimiento.html',
        cat_tipos_equipo=cat_tipos_equipo,
        cat_lineas=cat_lineas,
        cat_estaciones=cat_estaciones,
        soluciones_estandar=soluciones_estandar,
        historico_ots=historico_ots,
        recursos_soporte=recursos_soporte,
        search_query=search_query,
        tipo_equipo_id=tipo_equipo_id,
        linea_id=linea_id,
        estacion_id=estacion_id,
        equipo_id=equipo_id,
        active_tab=active_tab,
        tipo_recurso=tipo_recurso
    )


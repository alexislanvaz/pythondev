-- ===========================================================================
-- MTS CMMS - SCRIPT DE DATOS DE PRUEBA COMPLETO (SEED DATA)
-- Incluye datos para catálogos, usuarios, líneas, estaciones, equipos y OTs
-- ===========================================================================

USE [MTS_CMMS];
GO

SET NOCOUNT ON;

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: CatAreas (4 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[CatAreas] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[CatAreas] WHERE [ID] = 1)
    INSERT INTO dbo.[CatAreas] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (1, N'Administracion', N'Area administrativa central de la planta', 0, N'2026-07-06 22:21:24.203', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatAreas] WHERE [ID] = 2)
    INSERT INTO dbo.[CatAreas] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (2, N'SMT', N'Area de SMT', 1, N'2026-07-13 11:25:46.317', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatAreas] WHERE [ID] = 3)
    INSERT INTO dbo.[CatAreas] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (3, N'FA - HMI', N'Seccion HMI de FA', 1, N'2026-07-13 11:26:30.127', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatAreas] WHERE [ID] = 4)
    INSERT INTO dbo.[CatAreas] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (4, N'FA - E&E', N'Seccion de E&E FA', 1, N'2026-07-13 11:26:47.920', NULL);

SET IDENTITY_INSERT dbo.[CatAreas] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: CatRoles (5 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[CatRoles] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[CatRoles] WHERE [ID] = 1)
    INSERT INTO dbo.[CatRoles] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (1, N'Administrador', N'Rol de administracion y configuracion del sistema', 1, N'2026-07-06 22:21:24.207', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatRoles] WHERE [ID] = 2)
    INSERT INTO dbo.[CatRoles] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (2, N'Supervisor', N'Supervisor de area', 1, N'2026-07-13 11:24:23.087', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatRoles] WHERE [ID] = 3)
    INSERT INTO dbo.[CatRoles] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (3, N'Ingeniero', N'supervisa a los tecnicos', 1, N'2026-07-13 21:32:55.103', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatRoles] WHERE [ID] = 4)
    INSERT INTO dbo.[CatRoles] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (4, N'Tecnico', N'atienden directamente en linea', 1, N'2026-07-13 21:33:16.110', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatRoles] WHERE [ID] = 5)
    INSERT INTO dbo.[CatRoles] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (5, N'Lider de linea', N'reporta problemas', 1, N'2026-07-13 21:33:28.473', NULL);

SET IDENTITY_INSERT dbo.[CatRoles] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: CatTurnos (5 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[CatTurnos] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[CatTurnos] WHERE [ID] = 1)
    INSERT INTO dbo.[CatTurnos] ([ID], [Nombre], [HoraInicio], [HoraFin], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (1, N'Administrativo', N'08:00:00', N'17:00:00', 0, N'2026-07-06 22:21:24.203', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatTurnos] WHERE [ID] = 2)
    INSERT INTO dbo.[CatTurnos] ([ID], [Nombre], [HoraInicio], [HoraFin], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (2, N'1ro', N'07:54:00', N'17:30:00', 1, N'2026-07-13 11:25:08.653', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatTurnos] WHERE [ID] = 3)
    INSERT INTO dbo.[CatTurnos] ([ID], [Nombre], [HoraInicio], [HoraFin], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (3, N'A8', N'06:30:00', N'14:30:00', 1, N'2026-07-13 21:34:20.460', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatTurnos] WHERE [ID] = 4)
    INSERT INTO dbo.[CatTurnos] ([ID], [Nombre], [HoraInicio], [HoraFin], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (4, N'B8', N'14:30:00', N'22:30:00', 1, N'2026-07-13 21:34:35.347', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatTurnos] WHERE [ID] = 5)
    INSERT INTO dbo.[CatTurnos] ([ID], [Nombre], [HoraInicio], [HoraFin], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (5, N'C8', N'22:30:00', N'06:30:00', 1, N'2026-07-13 21:34:55.900', 1);

SET IDENTITY_INSERT dbo.[CatTurnos] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: CatEstadosOT (5 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[CatEstadosOT] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstadosOT] WHERE [ID] = 1)
    INSERT INTO dbo.[CatEstadosOT] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (1, N'CREATED', N'OT Creada', 1, N'2026-07-17 17:03:54.197', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstadosOT] WHERE [ID] = 2)
    INSERT INTO dbo.[CatEstadosOT] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (2, N'ONGOING', N'OT En Proceso', 1, N'2026-07-17 17:03:54.197', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstadosOT] WHERE [ID] = 3)
    INSERT INTO dbo.[CatEstadosOT] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (3, N'STOPPED', N'OT Detenida', 1, N'2026-07-17 17:03:54.197', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstadosOT] WHERE [ID] = 4)
    INSERT INTO dbo.[CatEstadosOT] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (4, N'CANCELED', N'OT Cancelada', 1, N'2026-07-17 17:03:54.197', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstadosOT] WHERE [ID] = 5)
    INSERT INTO dbo.[CatEstadosOT] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (5, N'CLOSED', N'OT Cerrada', 1, N'2026-07-17 17:03:54.197', 1);

SET IDENTITY_INSERT dbo.[CatEstadosOT] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: CatMotivosPausa (4 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[CatMotivosPausa] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[CatMotivosPausa] WHERE [ID] = 1)
    INSERT INTO dbo.[CatMotivosPausa] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (1, N'falta Material', N'Falta de material', 1, N'2026-07-19 17:05:11.363', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatMotivosPausa] WHERE [ID] = 2)
    INSERT INTO dbo.[CatMotivosPausa] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (2, N'Descanso', N'Descanso', 1, N'2026-07-19 17:05:11.363', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatMotivosPausa] WHERE [ID] = 3)
    INSERT INTO dbo.[CatMotivosPausa] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (3, N'En espera Herramienta', N'En espera de herramienta', 1, N'2026-07-19 17:06:13.243', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatMotivosPausa] WHERE [ID] = 4)
    INSERT INTO dbo.[CatMotivosPausa] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (4, N'Escalamiento', N'Personal Clave', 1, N'2026-07-19 17:06:13.243', 1);

SET IDENTITY_INSERT dbo.[CatMotivosPausa] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: CatCausas4M (8 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[CatCausas4M] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[CatCausas4M] WHERE [ID] = 1)
    INSERT INTO dbo.[CatCausas4M] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (1, N'Hombre', N'Causas relacionadas al factor humano', 1, N'2026-07-17 16:27:06.043', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatCausas4M] WHERE [ID] = 2)
    INSERT INTO dbo.[CatCausas4M] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (2, N'Maquina', N'Causas relacionadas a las maquinas', 1, N'2026-07-17 16:27:06.043', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatCausas4M] WHERE [ID] = 3)
    INSERT INTO dbo.[CatCausas4M] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (3, N'Metodo', N'Causas relaciadas al metodo de trabajo', 1, N'2026-07-17 16:27:06.043', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatCausas4M] WHERE [ID] = 4)
    INSERT INTO dbo.[CatCausas4M] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (4, N'Material', N'Causas relaciadas a la materia prima', 1, N'2026-07-17 16:27:06.043', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatCausas4M] WHERE [ID] = 5)
    INSERT INTO dbo.[CatCausas4M] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (5, N'Hombre', N'Causas relacionadas al factor humano', 0, N'2026-07-17 16:54:56.450', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatCausas4M] WHERE [ID] = 6)
    INSERT INTO dbo.[CatCausas4M] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (6, N'Maquina', N'Causas relacionadas a las maquinas', 0, N'2026-07-17 16:54:56.450', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatCausas4M] WHERE [ID] = 7)
    INSERT INTO dbo.[CatCausas4M] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (7, N'Metodo', N'Causas relaciadas al metodo de trabajo', 0, N'2026-07-17 16:54:56.450', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatCausas4M] WHERE [ID] = 8)
    INSERT INTO dbo.[CatCausas4M] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (8, N'Material', N'Causas relaciadas a la materia prima', 0, N'2026-07-17 16:54:56.450', 1);

SET IDENTITY_INSERT dbo.[CatCausas4M] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: CatClasificacionesFallaLider (8 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[CatClasificacionesFallaLider] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[CatClasificacionesFallaLider] WHERE [ID] = 1)
    INSERT INTO dbo.[CatClasificacionesFallaLider] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID], [Causa4MsID]) VALUES (1, N'Personal en Entto.', N'PE', 1, N'2026-07-17 23:22:21.320', 1, 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatClasificacionesFallaLider] WHERE [ID] = 2)
    INSERT INTO dbo.[CatClasificacionesFallaLider] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID], [Causa4MsID]) VALUES (2, N'Falta Personal', N'Falta de personal', 1, N'2026-07-18 17:48:39.130', 1, 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatClasificacionesFallaLider] WHERE [ID] = 3)
    INSERT INTO dbo.[CatClasificacionesFallaLider] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID], [Causa4MsID]) VALUES (3, N'Software', N'Falla del sistema', 1, N'2026-07-18 17:48:39.130', 1, 2);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatClasificacionesFallaLider] WHERE [ID] = 4)
    INSERT INTO dbo.[CatClasificacionesFallaLider] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID], [Causa4MsID]) VALUES (4, N'MIS', N'Sistemas', 1, N'2026-07-18 17:48:39.130', 1, 2);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatClasificacionesFallaLider] WHERE [ID] = 5)
    INSERT INTO dbo.[CatClasificacionesFallaLider] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID], [Causa4MsID]) VALUES (5, N'Mantenimiento', N'PE', 1, N'2026-07-18 17:48:39.130', 1, 2);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatClasificacionesFallaLider] WHERE [ID] = 6)
    INSERT INTO dbo.[CatClasificacionesFallaLider] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID], [Causa4MsID]) VALUES (6, N'Error Humano', N'error', 1, N'2026-07-18 17:48:39.130', 1, 3);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatClasificacionesFallaLider] WHERE [ID] = 7)
    INSERT INTO dbo.[CatClasificacionesFallaLider] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID], [Causa4MsID]) VALUES (7, N'Falta Inventario', N'pcb', 1, N'2026-07-18 17:48:39.130', 1, 4);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatClasificacionesFallaLider] WHERE [ID] = 8)
    INSERT INTO dbo.[CatClasificacionesFallaLider] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID], [Causa4MsID]) VALUES (8, N'problemas de partes', N'almacen', 1, N'2026-07-18 17:48:39.130', 1, 4);

SET IDENTITY_INSERT dbo.[CatClasificacionesFallaLider] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: CatSintomasFallaLider (10 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[CatSintomasFallaLider] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[CatSintomasFallaLider] WHERE [ID] = 1)
    INSERT INTO dbo.[CatSintomasFallaLider] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (1, N'PC No Responde', N'La PC no responde', 1, N'2026-07-17 23:21:23.867', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSintomasFallaLider] WHERE [ID] = 2)
    INSERT INTO dbo.[CatSintomasFallaLider] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (2, N'Robot no cicla', N'Robot detenido a mitad de secuencia o fuera de home', 1, N'2026-07-26 17:51:41.657', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSintomasFallaLider] WHERE [ID] = 3)
    INSERT INTO dbo.[CatSintomasFallaLider] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (3, N'Fuga de aire neumático', N'Pérdida de presión neumática en manguera o conector', 1, N'2026-07-26 17:51:41.660', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSintomasFallaLider] WHERE [ID] = 4)
    INSERT INTO dbo.[CatSintomasFallaLider] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (4, N'Error de lectura de código QR / Barcode', N'El escáner no lee el código de la tarjeta', 1, N'2026-07-26 17:51:41.663', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSintomasFallaLider] WHERE [ID] = 5)
    INSERT INTO dbo.[CatSintomasFallaLider] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (5, N'Banda transportadora detenida / ruidosa', N'Conveyor atascado o con ruido metálico excesivo', 1, N'2026-07-26 17:51:41.667', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSintomasFallaLider] WHERE [ID] = 6)
    INSERT INTO dbo.[CatSintomasFallaLider] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (6, N'Error de torque en atornillador', N'Torque fuera de especificación alta/baja', 1, N'2026-07-26 17:51:41.670', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSintomasFallaLider] WHERE [ID] = 7)
    INSERT INTO dbo.[CatSintomasFallaLider] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (7, N'Alarmas de temperatura en horno', N'Desviación de temperatura en zona de calentamiento', 1, N'2026-07-26 17:51:41.673', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSintomasFallaLider] WHERE [ID] = 8)
    INSERT INTO dbo.[CatSintomasFallaLider] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (8, N'Atasco de PCB en estación', N'Tablilla atascada en rieles o tope neumático', 1, N'2026-07-26 17:51:41.677', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSintomasFallaLider] WHERE [ID] = 9)
    INSERT INTO dbo.[CatSintomasFallaLider] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (9, N'Fallo de comunicación Ethernet/IP', N'Pérdida de ping/comunicación entre PLC y PC', 1, N'2026-07-26 17:51:41.680', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSintomasFallaLider] WHERE [ID] = 10)
    INSERT INTO dbo.[CatSintomasFallaLider] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (10, N'Celda fotoeléctrica descalibrada', N'Sensor no detecta presencia de producto', 1, N'2026-07-26 17:51:41.683', 1);

SET IDENTITY_INSERT dbo.[CatSintomasFallaLider] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: CatTiposEquipo (9 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[CatTiposEquipo] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[CatTiposEquipo] WHERE [ID] = 1)
    INSERT INTO dbo.[CatTiposEquipo] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (1, N'PLC', N'PLC', 1, N'2026-07-14 19:46:26.910', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatTiposEquipo] WHERE [ID] = 2)
    INSERT INTO dbo.[CatTiposEquipo] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (2, N'PC', N'', 1, N'2026-07-14 20:13:52.163', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatTiposEquipo] WHERE [ID] = 3)
    INSERT INTO dbo.[CatTiposEquipo] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (3, N'ROBOT DE ATORNILLADO', N'', 1, N'2026-07-14 20:14:06.380', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatTiposEquipo] WHERE [ID] = 4)
    INSERT INTO dbo.[CatTiposEquipo] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (4, N'SMT PICK & PLACE', N'Máquina de colocación de componentes SMT', 1, N'2026-07-26 17:51:41.627', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatTiposEquipo] WHERE [ID] = 5)
    INSERT INTO dbo.[CatTiposEquipo] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (5, N'HORNO DE REFLUJO', N'Horno de soldado por reflujo multifase', 1, N'2026-07-26 17:51:41.630', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatTiposEquipo] WHERE [ID] = 6)
    INSERT INTO dbo.[CatTiposEquipo] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (6, N'LECTOR CODIGO DE BARRAS / VISION', N'Sistema de inspección por visión y código QR/1D/2D', 1, N'2026-07-26 17:51:41.637', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatTiposEquipo] WHERE [ID] = 7)
    INSERT INTO dbo.[CatTiposEquipo] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (7, N'ATORNILLADOR ELECTRICO', N'Herramienta de torque controlado eléctrico', 1, N'2026-07-26 17:51:41.640', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatTiposEquipo] WHERE [ID] = 8)
    INSERT INTO dbo.[CatTiposEquipo] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (8, N'BANDA TRANSPORTADORA', N'Conveyor de transporte de tablillas/tarjetas', 1, N'2026-07-26 17:51:41.643', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatTiposEquipo] WHERE [ID] = 9)
    INSERT INTO dbo.[CatTiposEquipo] ([ID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (9, N'PRENSA NEUMATICA', N'Prensa neumática de ensamble de conectores', 1, N'2026-07-26 17:51:41.647', 1);

SET IDENTITY_INSERT dbo.[CatTiposEquipo] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: CatFallasComunes (10 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[CatFallasComunes] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[CatFallasComunes] WHERE [ID] = 1)
    INSERT INTO dbo.[CatFallasComunes] ([ID], [TipoEquipoID], [CodigoFalla], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (1, 2, N'PC-FM-A001', N'PC Ciclada', N'La PC no responde', 1, N'2026-07-17 21:44:43.527', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatFallasComunes] WHERE [ID] = 2)
    INSERT INTO dbo.[CatFallasComunes] ([ID], [TipoEquipoID], [CodigoFalla], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (2, 1, N'PLC-FM-A001', N'PLC-CICLADO', N'PLC CICLADO', 1, N'2026-07-19 15:12:33.917', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatFallasComunes] WHERE [ID] = 3)
    INSERT INTO dbo.[CatFallasComunes] ([ID], [TipoEquipoID], [CodigoFalla], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (3, 3, N'ROB-FM-001', N'Descalibración de Cero / Home', N'Eje Z desfasado provocando paro de emergencia', 1, N'2026-07-26 17:51:41.713', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatFallasComunes] WHERE [ID] = 4)
    INSERT INTO dbo.[CatFallasComunes] ([ID], [TipoEquipoID], [CodigoFalla], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (4, 3, N'ROB-FM-002', N'Error de comunicación con Robot', N'Falta de señal READY de controlador', 1, N'2026-07-26 17:51:41.723', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatFallasComunes] WHERE [ID] = 5)
    INSERT INTO dbo.[CatFallasComunes] ([ID], [TipoEquipoID], [CodigoFalla], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (5, 4, N'SMT-FM-001', N'Vacío insuficiente en boquilla', N'Pérdida de componentes durante el picado', 1, N'2026-07-26 17:51:41.737', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatFallasComunes] WHERE [ID] = 6)
    INSERT INTO dbo.[CatFallasComunes] ([ID], [TipoEquipoID], [CodigoFalla], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (6, 5, N'HRN-FM-001', N'Desviación Térmica en Zona 3', N'Temperatura cayó por debajo de tolerancia de soldadura', 1, N'2026-07-26 17:51:41.750', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatFallasComunes] WHERE [ID] = 7)
    INSERT INTO dbo.[CatFallasComunes] ([ID], [TipoEquipoID], [CodigoFalla], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (7, 6, N'VIS-FM-001', N'Foco desalineado en cámara', N'Lectura borrosa de datamatrix', 1, N'2026-07-26 17:51:41.753', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatFallasComunes] WHERE [ID] = 8)
    INSERT INTO dbo.[CatFallasComunes] ([ID], [TipoEquipoID], [CodigoFalla], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (8, 7, N'ATN-FM-001', N'Embrague de torque desgastado', N'Torque se dispara antes de llegar al valor nominal', 1, N'2026-07-26 17:51:41.767', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatFallasComunes] WHERE [ID] = 9)
    INSERT INTO dbo.[CatFallasComunes] ([ID], [TipoEquipoID], [CodigoFalla], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (9, 8, N'BND-FM-001', N'Banda destensada', N'Riel desalineado provoca patina de la banda', 1, N'2026-07-26 17:51:41.780', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatFallasComunes] WHERE [ID] = 10)
    INSERT INTO dbo.[CatFallasComunes] ([ID], [TipoEquipoID], [CodigoFalla], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (10, 9, N'PRS-FM-001', N'Fuga en Solenoide 5/2', N'Cilindro no baja con suficiente fuerza', 1, N'2026-07-26 17:51:41.793', 1);

SET IDENTITY_INSERT dbo.[CatFallasComunes] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: CatSolucionesComunes (21 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[CatSolucionesComunes] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 1)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (1, 1, N'Reinicio de PC', N'La PC se reinicia para quitar lo ciclado y que responda', 1, N'2026-07-17 21:46:20.903', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 2)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (2, 2, N'RESTART PLC', N'REINICIAR PLC', 1, N'2026-07-19 15:12:51.160', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 3)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (3, 1, N'Solucion de Prueba', N'Descripcion de Prueba', 1, N'2026-07-19 18:21:35.753', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 4)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (4, 1, N'Reemplazo de fuente de poder', N'Solución estandarizada: Reemplazo de fuente de poder', 1, N'2026-07-26 17:51:41.697', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 5)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (5, 2, N'Recarga de programa vía RSLogix', N'Solución estandarizada: Recarga de programa vía RSLogix', 1, N'2026-07-26 17:51:41.707', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 6)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (6, 3, N'Calibración de cero y home de ejes', N'Solución estandarizada: Calibración de cero y home de ejes', 1, N'2026-07-26 17:51:41.717', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 7)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (7, 3, N'Ajuste de sensor home', N'Solución estandarizada: Ajuste de sensor home', 1, N'2026-07-26 17:51:41.720', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 8)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (8, 4, N'Reinicio de controlador de robot', N'Solución estandarizada: Reinicio de controlador de robot', 1, N'2026-07-26 17:51:41.730', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 9)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (9, 4, N'Reemplazo de cable de comunicación I/O', N'Solución estandarizada: Reemplazo de cable de comunicación I/O', 1, N'2026-07-26 17:51:41.733', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 10)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (10, 5, N'Limpieza y reemplazo de boquilla de vacío', N'Solución estandarizada: Limpieza y reemplazo de boquilla de vacío', 1, N'2026-07-26 17:51:41.740', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 11)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (11, 5, N'Ajuste de bomba de vacío', N'Solución estandarizada: Ajuste de bomba de vacío', 1, N'2026-07-26 17:51:41.750', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 12)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (12, 6, N'Reemplazo de sensor termopar', N'Solución estandarizada: Reemplazo de sensor termopar', 1, N'2026-07-26 17:51:41.753', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 13)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (13, 6, N'Calibración de controlador PID de zona', N'Solución estandarizada: Calibración de controlador PID de zona', 1, N'2026-07-26 17:51:41.753', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 14)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (14, 7, N'Ajuste manual de foco y ganancia LED', N'Solución estandarizada: Ajuste manual de foco y ganancia LED', 1, N'2026-07-26 17:51:41.760', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 15)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (15, 7, N'Limpieza de lente con alcohol isopropílico', N'Solución estandarizada: Limpieza de lente con alcohol isopropílico', 1, N'2026-07-26 17:51:41.763', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 16)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (16, 8, N'Reemplazo de resorte y embrague mecánico', N'Solución estandarizada: Reemplazo de resorte y embrague mecánico', 1, N'2026-07-26 17:51:41.773', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 17)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (17, 8, N'Ajuste con torquímetro digital', N'Solución estandarizada: Ajuste con torquímetro digital', 1, N'2026-07-26 17:51:41.777', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 18)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (18, 9, N'Ajuste de tensión de tensores laterales', N'Solución estandarizada: Ajuste de tensión de tensores laterales', 1, N'2026-07-26 17:51:41.783', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 19)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (19, 9, N'Reemplazo de banda de goma', N'Solución estandarizada: Reemplazo de banda de goma', 1, N'2026-07-26 17:51:41.790', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 20)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (20, 10, N'Reemplazo de solenoide neumático', N'Solución estandarizada: Reemplazo de solenoide neumático', 1, N'2026-07-26 17:51:41.793', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatSolucionesComunes] WHERE [ID] = 21)
    INSERT INTO dbo.[CatSolucionesComunes] ([ID], [FallaComunID], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (21, 10, N'Cambio de empaques de cilindro', N'Solución estandarizada: Cambio de empaques de cilindro', 1, N'2026-07-26 17:51:41.797', 1);

SET IDENTITY_INSERT dbo.[CatSolucionesComunes] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: CatModosFallaReal (3 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[CatModosFallaReal] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[CatModosFallaReal] WHERE [ID] = 1)
    INSERT INTO dbo.[CatModosFallaReal] ([ID], [TipoEquipoID], [CodigoFalla], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (1, 2, N'PC-FM-A001', N'Pantallazo Azul', N'Sistema Operativo muestra una pantalla azul al iniciar windows', 1, N'2026-07-17 21:10:08.543', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatModosFallaReal] WHERE [ID] = 2)
    INSERT INTO dbo.[CatModosFallaReal] ([ID], [TipoEquipoID], [CodigoFalla], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (2, 2, N'PC-FM-A002', N'IP Duplicada', N'Perdida de red', 1, N'2026-07-17 21:10:45.720', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatModosFallaReal] WHERE [ID] = 3)
    INSERT INTO dbo.[CatModosFallaReal] ([ID], [TipoEquipoID], [CodigoFalla], [Nombre], [Descripcion], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (3, 1, N'PLC-FM-A001', N'CICLADO', N'PLC CICLADO', 1, N'2026-07-19 15:11:51.740', 1);

SET IDENTITY_INSERT dbo.[CatModosFallaReal] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: CatRutinasPreventivas (5 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[CatRutinasPreventivas] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[CatRutinasPreventivas] WHERE [ID] = 1)
    INSERT INTO dbo.[CatRutinasPreventivas] ([ID], [TipoEquipoID], [Nombre], [Descripcion], [FrecuenciaDias], [activo], [fecharegistro]) VALUES (1, 1, N'Inspección General y Limpieza de Sensores', N'Limpieza profunda de componentes ópticos, soplado y revisión de alineación.', 7, 1, N'2026-07-21 21:37:26.003');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatRutinasPreventivas] WHERE [ID] = 2)
    INSERT INTO dbo.[CatRutinasPreventivas] ([ID], [TipoEquipoID], [Nombre], [Descripcion], [FrecuenciaDias], [activo], [fecharegistro]) VALUES (2, 1, N'Lubricación de Cadenas y Rodamientos', N'Aplicación de lubricante de alta viscoosidad en guías, bandas y rodamientos.', 15, 1, N'2026-07-21 21:37:26.047');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatRutinasPreventivas] WHERE [ID] = 3)
    INSERT INTO dbo.[CatRutinasPreventivas] ([ID], [TipoEquipoID], [Nombre], [Descripcion], [FrecuenciaDias], [activo], [fecharegistro]) VALUES (3, 1, N'Revisión Neumática y Fugas de Aire', N'Inspección de conexiones neumáticas, cambio de empaques y purga de filtro.', 30, 1, N'2026-07-21 21:37:26.047');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatRutinasPreventivas] WHERE [ID] = 4)
    INSERT INTO dbo.[CatRutinasPreventivas] ([ID], [TipoEquipoID], [Nombre], [Descripcion], [FrecuenciaDias], [activo], [fecharegistro]) VALUES (4, 1, N'Verificación de Apriete Eléctrico y Termografía', N'Ajuste de clemas en gabinete de control y medición de temperatura en bornes.', 30, 1, N'2026-07-21 21:37:26.053');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatRutinasPreventivas] WHERE [ID] = 5)
    INSERT INTO dbo.[CatRutinasPreventivas] ([ID], [TipoEquipoID], [Nombre], [Descripcion], [FrecuenciaDias], [activo], [fecharegistro]) VALUES (5, 1, N'Mantenimiento Preventivo Mensual Integral', N'Chequeo completo de desgaste, alineación mecánica y prueba de paros de emergencia.', 30, 1, N'2026-07-21 21:37:26.060');

SET IDENTITY_INSERT dbo.[CatRutinasPreventivas] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: CatUsuarios (18 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[CatUsuarios] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[CatUsuarios] WHERE [ID] = 1)
    INSERT INTO dbo.[CatUsuarios] ([ID], [NoEmpleado], [Nombre], [Correo], [RolID], [AreaID], [TurnoID], [activo], [fecharegistro], [PasswordHash], [UsuarioRegistroID]) VALUES (1, N'9999', N'Administrador CMMS', N'admin@mts.com', 1, 1, 1, 1, N'2026-07-06 22:21:24.220', N'scrypt:32768:8:1$cMHckdOZUZVNf1Q4$9110fbaf63cdfc0c8c7fe00cf5717a350b607a22c1fee781a653878cf28447782b95eae027e7607c84ae1ddeea092326fc7281f29a98b8314e2885d942d5ae07', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatUsuarios] WHERE [ID] = 2)
    INSERT INTO dbo.[CatUsuarios] ([ID], [NoEmpleado], [Nombre], [Correo], [RolID], [AreaID], [TurnoID], [activo], [fecharegistro], [PasswordHash], [UsuarioRegistroID]) VALUES (2, N'1111', N'es 4 veces 1', N'1234@mail.com', 3, 3, 3, 1, N'2026-07-13 11:18:06.173', N'scrypt:32768:8:1$E2amxXV4CqJwqUyO$804670666c8fff17e1534dc003af11927efee187cc95f3bd7486da3e3787e68500172540617c2c3b9a015a9ef311d038e07cf7e3397bc757fb3586af4ee12878', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatUsuarios] WHERE [ID] = 3)
    INSERT INTO dbo.[CatUsuarios] ([ID], [NoEmpleado], [Nombre], [Correo], [RolID], [AreaID], [TurnoID], [activo], [fecharegistro], [PasswordHash], [UsuarioRegistroID]) VALUES (3, N'9001', N'Carlos Mendoza', N'carlos.mendoza@cmms.com', 1, 2, 2, 1, N'2026-07-26 17:51:42.033', N'scrypt:32768:8:1$lCtZaNv7NgGcU4t3$a532014e10ed402f62a39454e5d5285487457da81c2e1406d4dbc0785de3d11a91d83aabd0566c414951fd148e1c56eaa97212f4c91616ecde22049f7e6f137c', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatUsuarios] WHERE [ID] = 4)
    INSERT INTO dbo.[CatUsuarios] ([ID], [NoEmpleado], [Nombre], [Correo], [RolID], [AreaID], [TurnoID], [activo], [fecharegistro], [PasswordHash], [UsuarioRegistroID]) VALUES (4, N'5001', N'Roberto Gómez', N'roberto.gomez@cmms.com', 2, 2, 2, 1, N'2026-07-26 17:51:42.067', N'scrypt:32768:8:1$lCtZaNv7NgGcU4t3$a532014e10ed402f62a39454e5d5285487457da81c2e1406d4dbc0785de3d11a91d83aabd0566c414951fd148e1c56eaa97212f4c91616ecde22049f7e6f137c', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatUsuarios] WHERE [ID] = 5)
    INSERT INTO dbo.[CatUsuarios] ([ID], [NoEmpleado], [Nombre], [Correo], [RolID], [AreaID], [TurnoID], [activo], [fecharegistro], [PasswordHash], [UsuarioRegistroID]) VALUES (5, N'5002', N'Laura Sánchez', N'laura.sanchez@cmms.com', 2, 3, 3, 1, N'2026-07-26 17:51:42.067', N'scrypt:32768:8:1$lCtZaNv7NgGcU4t3$a532014e10ed402f62a39454e5d5285487457da81c2e1406d4dbc0785de3d11a91d83aabd0566c414951fd148e1c56eaa97212f4c91616ecde22049f7e6f137c', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatUsuarios] WHERE [ID] = 6)
    INSERT INTO dbo.[CatUsuarios] ([ID], [NoEmpleado], [Nombre], [Correo], [RolID], [AreaID], [TurnoID], [activo], [fecharegistro], [PasswordHash], [UsuarioRegistroID]) VALUES (6, N'5003', N'Fernando Castillo', N'fernando.castillo@cmms.com', 2, 4, 4, 1, N'2026-07-26 17:51:42.073', N'scrypt:32768:8:1$lCtZaNv7NgGcU4t3$a532014e10ed402f62a39454e5d5285487457da81c2e1406d4dbc0785de3d11a91d83aabd0566c414951fd148e1c56eaa97212f4c91616ecde22049f7e6f137c', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatUsuarios] WHERE [ID] = 7)
    INSERT INTO dbo.[CatUsuarios] ([ID], [NoEmpleado], [Nombre], [Correo], [RolID], [AreaID], [TurnoID], [activo], [fecharegistro], [PasswordHash], [UsuarioRegistroID]) VALUES (7, N'4001', N'Ing. David Morales', N'david.morales@cmms.com', 3, 3, 2, 1, N'2026-07-26 17:51:42.080', N'scrypt:32768:8:1$lCtZaNv7NgGcU4t3$a532014e10ed402f62a39454e5d5285487457da81c2e1406d4dbc0785de3d11a91d83aabd0566c414951fd148e1c56eaa97212f4c91616ecde22049f7e6f137c', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatUsuarios] WHERE [ID] = 8)
    INSERT INTO dbo.[CatUsuarios] ([ID], [NoEmpleado], [Nombre], [Correo], [RolID], [AreaID], [TurnoID], [activo], [fecharegistro], [PasswordHash], [UsuarioRegistroID]) VALUES (8, N'4002', N'Ing. Ana Patricia Vega', N'ana.vega@cmms.com', 3, 2, 3, 1, N'2026-07-26 17:51:42.087', N'scrypt:32768:8:1$lCtZaNv7NgGcU4t3$a532014e10ed402f62a39454e5d5285487457da81c2e1406d4dbc0785de3d11a91d83aabd0566c414951fd148e1c56eaa97212f4c91616ecde22049f7e6f137c', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatUsuarios] WHERE [ID] = 9)
    INSERT INTO dbo.[CatUsuarios] ([ID], [NoEmpleado], [Nombre], [Correo], [RolID], [AreaID], [TurnoID], [activo], [fecharegistro], [PasswordHash], [UsuarioRegistroID]) VALUES (9, N'3001', N'Tech. Juan Pérez', N'juan.perez@cmms.com', 4, 3, 2, 1, N'2026-07-26 17:51:42.093', N'scrypt:32768:8:1$lCtZaNv7NgGcU4t3$a532014e10ed402f62a39454e5d5285487457da81c2e1406d4dbc0785de3d11a91d83aabd0566c414951fd148e1c56eaa97212f4c91616ecde22049f7e6f137c', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatUsuarios] WHERE [ID] = 10)
    INSERT INTO dbo.[CatUsuarios] ([ID], [NoEmpleado], [Nombre], [Correo], [RolID], [AreaID], [TurnoID], [activo], [fecharegistro], [PasswordHash], [UsuarioRegistroID]) VALUES (10, N'3002', N'Tech. Miguel Ángel Torres', N'miguel.torres@cmms.com', 4, 3, 3, 1, N'2026-07-26 17:51:42.100', N'scrypt:32768:8:1$lCtZaNv7NgGcU4t3$a532014e10ed402f62a39454e5d5285487457da81c2e1406d4dbc0785de3d11a91d83aabd0566c414951fd148e1c56eaa97212f4c91616ecde22049f7e6f137c', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatUsuarios] WHERE [ID] = 11)
    INSERT INTO dbo.[CatUsuarios] ([ID], [NoEmpleado], [Nombre], [Correo], [RolID], [AreaID], [TurnoID], [activo], [fecharegistro], [PasswordHash], [UsuarioRegistroID]) VALUES (11, N'3003', N'Tech. Ricardo Ruiz', N'ricardo.ruiz@cmms.com', 4, 4, 4, 1, N'2026-07-26 17:51:42.103', N'scrypt:32768:8:1$lCtZaNv7NgGcU4t3$a532014e10ed402f62a39454e5d5285487457da81c2e1406d4dbc0785de3d11a91d83aabd0566c414951fd148e1c56eaa97212f4c91616ecde22049f7e6f137c', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatUsuarios] WHERE [ID] = 12)
    INSERT INTO dbo.[CatUsuarios] ([ID], [NoEmpleado], [Nombre], [Correo], [RolID], [AreaID], [TurnoID], [activo], [fecharegistro], [PasswordHash], [UsuarioRegistroID]) VALUES (12, N'3004', N'Tech. Alejandro Silva', N'alejandro.silva@cmms.com', 4, 2, 5, 1, N'2026-07-26 17:51:42.107', N'scrypt:32768:8:1$lCtZaNv7NgGcU4t3$a532014e10ed402f62a39454e5d5285487457da81c2e1406d4dbc0785de3d11a91d83aabd0566c414951fd148e1c56eaa97212f4c91616ecde22049f7e6f137c', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatUsuarios] WHERE [ID] = 13)
    INSERT INTO dbo.[CatUsuarios] ([ID], [NoEmpleado], [Nombre], [Correo], [RolID], [AreaID], [TurnoID], [activo], [fecharegistro], [PasswordHash], [UsuarioRegistroID]) VALUES (13, N'3005', N'Tech. Daniel Cruz', N'daniel.cruz@cmms.com', 4, 4, 2, 1, N'2026-07-26 17:51:42.110', N'scrypt:32768:8:1$lCtZaNv7NgGcU4t3$a532014e10ed402f62a39454e5d5285487457da81c2e1406d4dbc0785de3d11a91d83aabd0566c414951fd148e1c56eaa97212f4c91616ecde22049f7e6f137c', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatUsuarios] WHERE [ID] = 14)
    INSERT INTO dbo.[CatUsuarios] ([ID], [NoEmpleado], [Nombre], [Correo], [RolID], [AreaID], [TurnoID], [activo], [fecharegistro], [PasswordHash], [UsuarioRegistroID]) VALUES (14, N'2001', N'Líder María Hernández', N'maria.hernandez@cmms.com', 5, 3, 2, 1, N'2026-07-26 17:51:42.113', N'scrypt:32768:8:1$lCtZaNv7NgGcU4t3$a532014e10ed402f62a39454e5d5285487457da81c2e1406d4dbc0785de3d11a91d83aabd0566c414951fd148e1c56eaa97212f4c91616ecde22049f7e6f137c', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatUsuarios] WHERE [ID] = 15)
    INSERT INTO dbo.[CatUsuarios] ([ID], [NoEmpleado], [Nombre], [Correo], [RolID], [AreaID], [TurnoID], [activo], [fecharegistro], [PasswordHash], [UsuarioRegistroID]) VALUES (15, N'2002', N'Líder José Luis Ramírez', N'jose.ramirez@cmms.com', 5, 3, 3, 1, N'2026-07-26 17:51:42.117', N'scrypt:32768:8:1$lCtZaNv7NgGcU4t3$a532014e10ed402f62a39454e5d5285487457da81c2e1406d4dbc0785de3d11a91d83aabd0566c414951fd148e1c56eaa97212f4c91616ecde22049f7e6f137c', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatUsuarios] WHERE [ID] = 16)
    INSERT INTO dbo.[CatUsuarios] ([ID], [NoEmpleado], [Nombre], [Correo], [RolID], [AreaID], [TurnoID], [activo], [fecharegistro], [PasswordHash], [UsuarioRegistroID]) VALUES (16, N'2003', N'Líder Sofía Espinoza', N'sofia.espinoza@cmms.com', 5, 4, 4, 1, N'2026-07-26 17:51:42.123', N'scrypt:32768:8:1$lCtZaNv7NgGcU4t3$a532014e10ed402f62a39454e5d5285487457da81c2e1406d4dbc0785de3d11a91d83aabd0566c414951fd148e1c56eaa97212f4c91616ecde22049f7e6f137c', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatUsuarios] WHERE [ID] = 17)
    INSERT INTO dbo.[CatUsuarios] ([ID], [NoEmpleado], [Nombre], [Correo], [RolID], [AreaID], [TurnoID], [activo], [fecharegistro], [PasswordHash], [UsuarioRegistroID]) VALUES (17, N'2004', N'Líder Gabriel Vargas', N'gabriel.vargas@cmms.com', 5, 2, 5, 1, N'2026-07-26 17:51:42.123', N'scrypt:32768:8:1$lCtZaNv7NgGcU4t3$a532014e10ed402f62a39454e5d5285487457da81c2e1406d4dbc0785de3d11a91d83aabd0566c414951fd148e1c56eaa97212f4c91616ecde22049f7e6f137c', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatUsuarios] WHERE [ID] = 18)
    INSERT INTO dbo.[CatUsuarios] ([ID], [NoEmpleado], [Nombre], [Correo], [RolID], [AreaID], [TurnoID], [activo], [fecharegistro], [PasswordHash], [UsuarioRegistroID]) VALUES (18, N'2005', N'Líder Javier Reyes', N'javier.reyes@cmms.com', 5, 4, 2, 1, N'2026-07-26 17:51:42.123', N'scrypt:32768:8:1$lCtZaNv7NgGcU4t3$a532014e10ed402f62a39454e5d5285487457da81c2e1406d4dbc0785de3d11a91d83aabd0566c414951fd148e1c56eaa97212f4c91616ecde22049f7e6f137c', 1);

SET IDENTITY_INSERT dbo.[CatUsuarios] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: CatLineas (14 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[CatLineas] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[CatLineas] WHERE [ID] = 1)
    INSERT INTO dbo.[CatLineas] ([ID], [AreaID], [Nombre], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (1, 3, N'21MM L1', 1, N'2026-07-13 11:26:55.420', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatLineas] WHERE [ID] = 2)
    INSERT INTO dbo.[CatLineas] ([ID], [AreaID], [Nombre], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (2, 3, N'24MM L1', 1, N'2026-07-13 11:43:31.837', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatLineas] WHERE [ID] = 3)
    INSERT INTO dbo.[CatLineas] ([ID], [AreaID], [Nombre], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (3, 3, N'21MM L2', 1, N'2026-07-13 21:30:03.447', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatLineas] WHERE [ID] = 4)
    INSERT INTO dbo.[CatLineas] ([ID], [AreaID], [Nombre], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (4, 3, N'21MM L3', 1, N'2026-07-13 21:30:07.890', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatLineas] WHERE [ID] = 5)
    INSERT INTO dbo.[CatLineas] ([ID], [AreaID], [Nombre], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (5, 3, N'21MM L4', 1, N'2026-07-13 21:30:13.240', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatLineas] WHERE [ID] = 6)
    INSERT INTO dbo.[CatLineas] ([ID], [AreaID], [Nombre], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (6, 3, N'21MM L5', 1, N'2026-07-13 21:30:18.260', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatLineas] WHERE [ID] = 7)
    INSERT INTO dbo.[CatLineas] ([ID], [AreaID], [Nombre], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (7, 3, N'24MM L2', 1, N'2026-07-13 21:30:32.473', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatLineas] WHERE [ID] = 8)
    INSERT INTO dbo.[CatLineas] ([ID], [AreaID], [Nombre], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (8, 3, N'STL L1', 1, N'2026-07-13 21:30:46.803', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatLineas] WHERE [ID] = 9)
    INSERT INTO dbo.[CatLineas] ([ID], [AreaID], [Nombre], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (9, 3, N'STL L2', 1, N'2026-07-13 21:30:51.780', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatLineas] WHERE [ID] = 10)
    INSERT INTO dbo.[CatLineas] ([ID], [AreaID], [Nombre], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (10, 4, N'AB3', 1, N'2026-07-13 21:31:14.293', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatLineas] WHERE [ID] = 11)
    INSERT INTO dbo.[CatLineas] ([ID], [AreaID], [Nombre], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (11, 4, N'AB4', 1, N'2026-07-13 21:31:18.013', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatLineas] WHERE [ID] = 12)
    INSERT INTO dbo.[CatLineas] ([ID], [AreaID], [Nombre], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (12, 4, N'AB6', 1, N'2026-07-13 21:31:22.010', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatLineas] WHERE [ID] = 13)
    INSERT INTO dbo.[CatLineas] ([ID], [AreaID], [Nombre], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (13, 4, N'AB7', 1, N'2026-07-13 21:31:28.383', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatLineas] WHERE [ID] = 14)
    INSERT INTO dbo.[CatLineas] ([ID], [AreaID], [Nombre], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (14, 4, N'ECO RUN', 1, N'2026-07-13 21:31:33.487', 1);

SET IDENTITY_INSERT dbo.[CatLineas] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: CatEstaciones (57 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[CatEstaciones] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 1)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (1, 1, N'FTQ', N'QR-FTQ', 0, N'2026-07-13 21:36:22.103', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 2)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (2, 1, N'EMMC', N'QR-EMMC', 0, N'2026-07-14 20:13:43.837', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 3)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (3, 10, N'Flash', N'QR-FLASH-10', 1, N'2026-07-14 21:01:25.120', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 4)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (4, 11, N'Flash', N'QR-FLASH-11', 1, N'2026-07-14 21:01:25.123', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 5)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (5, 12, N'Flash', N'QR-FLASH-12', 1, N'2026-07-14 21:01:25.127', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 6)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (6, 13, N'Flash', N'QR-FLASH-13', 1, N'2026-07-14 21:01:25.130', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 7)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (7, 1, N'EMMC', N'QR-EMMC-1', 1, N'2026-07-14 21:17:45.607', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 8)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (8, 3, N'EMMC', N'QR-EMMC-3', 1, N'2026-07-14 21:17:45.610', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 9)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (9, 4, N'EMMC', N'QR-EMMC-4', 1, N'2026-07-14 21:17:45.613', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 10)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (10, 5, N'EMMC', N'QR-EMMC-5', 1, N'2026-07-14 21:17:45.613', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 11)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (11, 6, N'EMMC', N'QR-EMMC-6', 1, N'2026-07-14 21:17:45.620', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 12)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (12, 1, N'H2 ATORNILLADO DE PANEL', N'QR-H2-ATORNILLADO-DE-PANEL-1', 1, N'2026-07-18 18:44:43.573', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 13)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (13, 3, N'H2 ATORNILLADO DE PANEL', N'QR-H2-ATORNILLADO-DE-PANEL-3', 1, N'2026-07-18 18:44:43.577', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 14)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (14, 4, N'H2 ATORNILLADO DE PANEL', N'QR-H2-ATORNILLADO-DE-PANEL-4', 1, N'2026-07-18 18:44:43.577', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 15)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (15, 5, N'H2 ATORNILLADO DE PANEL', N'QR-H2-ATORNILLADO-DE-PANEL-5', 1, N'2026-07-18 18:44:43.580', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 16)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (16, 1, N'21MM L1 EST-01 ATORNILLADO', N'QR-21MM-L1-ST1', 1, N'2026-07-26 17:51:42.133', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 17)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (17, 1, N'21MM L1 EST-02 TESTER / INSPECCIÓN', N'QR-21MM-L1-ST2', 1, N'2026-07-26 17:51:42.150', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 18)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (18, 1, N'21MM L1 EST-03 ENSAMBLE FINAL', N'QR-21MM-L1-ST3', 1, N'2026-07-26 17:51:42.153', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 19)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (19, 2, N'24MM L1 EST-01 ATORNILLADO', N'QR-24MM-L1-ST1', 1, N'2026-07-26 17:51:42.153', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 20)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (20, 2, N'24MM L1 EST-02 TESTER / INSPECCIÓN', N'QR-24MM-L1-ST2', 1, N'2026-07-26 17:51:42.153', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 21)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (21, 2, N'24MM L1 EST-03 ENSAMBLE FINAL', N'QR-24MM-L1-ST3', 1, N'2026-07-26 17:51:42.157', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 22)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (22, 3, N'21MM L2 EST-01 ATORNILLADO', N'QR-21MM-L2-ST1', 1, N'2026-07-26 17:51:42.157', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 23)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (23, 3, N'21MM L2 EST-02 TESTER / INSPECCIÓN', N'QR-21MM-L2-ST2', 1, N'2026-07-26 17:51:42.157', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 24)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (24, 3, N'21MM L2 EST-03 ENSAMBLE FINAL', N'QR-21MM-L2-ST3', 1, N'2026-07-26 17:51:42.157', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 25)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (25, 4, N'21MM L3 EST-01 ATORNILLADO', N'QR-21MM-L3-ST1', 1, N'2026-07-26 17:51:42.157', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 26)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (26, 4, N'21MM L3 EST-02 TESTER / INSPECCIÓN', N'QR-21MM-L3-ST2', 1, N'2026-07-26 17:51:42.160', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 27)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (27, 4, N'21MM L3 EST-03 ENSAMBLE FINAL', N'QR-21MM-L3-ST3', 1, N'2026-07-26 17:51:42.160', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 28)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (28, 5, N'21MM L4 EST-01 ATORNILLADO', N'QR-21MM-L4-ST1', 1, N'2026-07-26 17:51:42.160', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 29)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (29, 5, N'21MM L4 EST-02 TESTER / INSPECCIÓN', N'QR-21MM-L4-ST2', 1, N'2026-07-26 17:51:42.163', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 30)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (30, 5, N'21MM L4 EST-03 ENSAMBLE FINAL', N'QR-21MM-L4-ST3', 1, N'2026-07-26 17:51:42.163', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 31)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (31, 6, N'21MM L5 EST-01 ATORNILLADO', N'QR-21MM-L5-ST1', 1, N'2026-07-26 17:51:42.167', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 32)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (32, 6, N'21MM L5 EST-02 TESTER / INSPECCIÓN', N'QR-21MM-L5-ST2', 1, N'2026-07-26 17:51:42.167', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 33)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (33, 6, N'21MM L5 EST-03 ENSAMBLE FINAL', N'QR-21MM-L5-ST3', 1, N'2026-07-26 17:51:42.170', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 34)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (34, 7, N'24MM L2 EST-01 ATORNILLADO', N'QR-24MM-L2-ST1', 1, N'2026-07-26 17:51:42.170', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 35)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (35, 7, N'24MM L2 EST-02 TESTER / INSPECCIÓN', N'QR-24MM-L2-ST2', 1, N'2026-07-26 17:51:42.170', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 36)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (36, 7, N'24MM L2 EST-03 ENSAMBLE FINAL', N'QR-24MM-L2-ST3', 1, N'2026-07-26 17:51:42.170', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 37)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (37, 8, N'STL L1 EST-01 ATORNILLADO', N'QR-STL-L1-ST1', 1, N'2026-07-26 17:51:42.173', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 38)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (38, 8, N'STL L1 EST-02 TESTER / INSPECCIÓN', N'QR-STL-L1-ST2', 1, N'2026-07-26 17:51:42.183', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 39)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (39, 8, N'STL L1 EST-03 ENSAMBLE FINAL', N'QR-STL-L1-ST3', 1, N'2026-07-26 17:51:42.187', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 40)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (40, 9, N'STL L2 EST-01 ATORNILLADO', N'QR-STL-L2-ST1', 1, N'2026-07-26 17:51:42.190', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 41)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (41, 9, N'STL L2 EST-02 TESTER / INSPECCIÓN', N'QR-STL-L2-ST2', 1, N'2026-07-26 17:51:42.190', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 42)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (42, 9, N'STL L2 EST-03 ENSAMBLE FINAL', N'QR-STL-L2-ST3', 1, N'2026-07-26 17:51:42.190', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 43)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (43, 10, N'AB3 EST-01 ATORNILLADO', N'QR-AB3-ST1', 1, N'2026-07-26 17:51:42.197', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 44)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (44, 10, N'AB3 EST-02 TESTER / INSPECCIÓN', N'QR-AB3-ST2', 1, N'2026-07-26 17:51:42.210', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 45)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (45, 10, N'AB3 EST-03 ENSAMBLE FINAL', N'QR-AB3-ST3', 1, N'2026-07-26 17:51:42.213', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 46)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (46, 11, N'AB4 EST-01 ATORNILLADO', N'QR-AB4-ST1', 1, N'2026-07-26 17:51:42.217', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 47)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (47, 11, N'AB4 EST-02 TESTER / INSPECCIÓN', N'QR-AB4-ST2', 1, N'2026-07-26 17:51:42.217', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 48)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (48, 11, N'AB4 EST-03 ENSAMBLE FINAL', N'QR-AB4-ST3', 1, N'2026-07-26 17:51:42.220', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 49)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (49, 12, N'AB6 EST-01 ATORNILLADO', N'QR-AB6-ST1', 1, N'2026-07-26 17:51:42.220', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 50)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (50, 12, N'AB6 EST-02 TESTER / INSPECCIÓN', N'QR-AB6-ST2', 1, N'2026-07-26 17:51:42.220', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 51)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (51, 12, N'AB6 EST-03 ENSAMBLE FINAL', N'QR-AB6-ST3', 1, N'2026-07-26 17:51:42.220', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 52)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (52, 13, N'AB7 EST-01 ATORNILLADO', N'QR-AB7-ST1', 1, N'2026-07-26 17:51:42.220', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 53)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (53, 13, N'AB7 EST-02 TESTER / INSPECCIÓN', N'QR-AB7-ST2', 1, N'2026-07-26 17:51:42.223', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 54)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (54, 13, N'AB7 EST-03 ENSAMBLE FINAL', N'QR-AB7-ST3', 1, N'2026-07-26 17:51:42.227', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 55)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (55, 14, N'ECO RUN EST-01 ATORNILLADO', N'QR-ECO-RUN-ST1', 1, N'2026-07-26 17:51:42.227', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 56)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (56, 14, N'ECO RUN EST-02 TESTER / INSPECCIÓN', N'QR-ECO-RUN-ST2', 1, N'2026-07-26 17:51:42.227', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEstaciones] WHERE [ID] = 57)
    INSERT INTO dbo.[CatEstaciones] ([ID], [LineaID], [Nombre], [CodigoQR], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (57, 14, N'ECO RUN EST-03 ENSAMBLE FINAL', N'QR-ECO-RUN-ST3', 1, N'2026-07-26 17:51:42.230', 1);

SET IDENTITY_INSERT dbo.[CatEstaciones] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: CatEquipos (47 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[CatEquipos] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 1)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (1, 7, 1, N'PLC001', N'KEYENCE001', N'PLCKEY001', 1, N'2026-07-19 14:32:54.013', 1, N'EQ-PLC-002');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 2)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (2, 12, 3, N'Robot Kuka K1', N'KR 16', N'SN-KUKA-001', 1, N'2026-07-19 15:17:04.383', 1, N'EQ-KUKA-001');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 3)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (3, 7, 2, N'PC Control EMMC', N'OptiPlex 7080', N'SN-PC-001', 1, N'2026-07-19 15:17:04.390', 1, N'EQ-PC-001');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 4)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (4, 3, 1, N'Siemens S7-1500', N'CPU 1511-1 PN', N'SN-PLC-001', 1, N'2026-07-19 15:17:04.400', 1, N'EQ-PLC-001');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 5)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (5, 13, 3, N'Robot Kuka K2', N'KR 16', N'SN-KUKA-002', 1, N'2026-07-19 15:17:04.400', 1, N'EQ-KUKA-002');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 6)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (6, 16, 8, N'EQUIPO-21MM-L1-ST1', N'MOD-2026-IND', N'SN-2026-0016', 1, N'2026-07-26 17:51:42.143', 1, N'EQ-QR-21MM-L1-ST1');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 7)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (7, 17, 4, N'EQUIPO-21MM-L1-ST2', N'MOD-2026-IND', N'SN-2026-0017', 1, N'2026-07-26 17:51:42.150', 1, N'EQ-QR-21MM-L1-ST2');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 8)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (8, 18, 1, N'EQUIPO-21MM-L1-ST3', N'MOD-2026-IND', N'SN-2026-0018', 1, N'2026-07-26 17:51:42.153', 1, N'EQ-QR-21MM-L1-ST3');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 9)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (9, 19, 6, N'EQUIPO-24MM-L1-ST1', N'MOD-2026-IND', N'SN-2026-0019', 1, N'2026-07-26 17:51:42.153', 1, N'EQ-QR-24MM-L1-ST1');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 10)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (10, 20, 9, N'EQUIPO-24MM-L1-ST2', N'MOD-2026-IND', N'SN-2026-0020', 1, N'2026-07-26 17:51:42.157', 1, N'EQ-QR-24MM-L1-ST2');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 11)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (11, 21, 4, N'EQUIPO-24MM-L1-ST3', N'MOD-2026-IND', N'SN-2026-0021', 1, N'2026-07-26 17:51:42.157', 1, N'EQ-QR-24MM-L1-ST3');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 12)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (12, 22, 2, N'EQUIPO-21MM-L2-ST1', N'MOD-2026-IND', N'SN-2026-0022', 1, N'2026-07-26 17:51:42.157', 1, N'EQ-QR-21MM-L2-ST1');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 13)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (13, 23, 4, N'EQUIPO-21MM-L2-ST2', N'MOD-2026-IND', N'SN-2026-0023', 1, N'2026-07-26 17:51:42.157', 1, N'EQ-QR-21MM-L2-ST2');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 14)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (14, 24, 1, N'EQUIPO-21MM-L2-ST3', N'MOD-2026-IND', N'SN-2026-0024', 1, N'2026-07-26 17:51:42.157', 1, N'EQ-QR-21MM-L2-ST3');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 15)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (15, 25, 6, N'EQUIPO-21MM-L3-ST1', N'MOD-2026-IND', N'SN-2026-0025', 1, N'2026-07-26 17:51:42.160', 1, N'EQ-QR-21MM-L3-ST1');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 16)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (16, 26, 2, N'EQUIPO-21MM-L3-ST2', N'MOD-2026-IND', N'SN-2026-0026', 1, N'2026-07-26 17:51:42.160', 1, N'EQ-QR-21MM-L3-ST2');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 17)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (17, 27, 6, N'EQUIPO-21MM-L3-ST3', N'MOD-2026-IND', N'SN-2026-0027', 1, N'2026-07-26 17:51:42.160', 1, N'EQ-QR-21MM-L3-ST3');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 18)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (18, 28, 6, N'EQUIPO-21MM-L4-ST1', N'MOD-2026-IND', N'SN-2026-0028', 1, N'2026-07-26 17:51:42.163', 1, N'EQ-QR-21MM-L4-ST1');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 19)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (19, 29, 7, N'EQUIPO-21MM-L4-ST2', N'MOD-2026-IND', N'SN-2026-0029', 1, N'2026-07-26 17:51:42.163', 1, N'EQ-QR-21MM-L4-ST2');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 20)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (20, 30, 6, N'EQUIPO-21MM-L4-ST3', N'MOD-2026-IND', N'SN-2026-0030', 1, N'2026-07-26 17:51:42.163', 1, N'EQ-QR-21MM-L4-ST3');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 21)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (21, 31, 6, N'EQUIPO-21MM-L5-ST1', N'MOD-2026-IND', N'SN-2026-0031', 1, N'2026-07-26 17:51:42.167', 1, N'EQ-QR-21MM-L5-ST1');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 22)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (22, 32, 1, N'EQUIPO-21MM-L5-ST2', N'MOD-2026-IND', N'SN-2026-0032', 1, N'2026-07-26 17:51:42.167', 1, N'EQ-QR-21MM-L5-ST2');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 23)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (23, 33, 8, N'EQUIPO-21MM-L5-ST3', N'MOD-2026-IND', N'SN-2026-0033', 1, N'2026-07-26 17:51:42.170', 1, N'EQ-QR-21MM-L5-ST3');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 24)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (24, 34, 2, N'EQUIPO-24MM-L2-ST1', N'MOD-2026-IND', N'SN-2026-0034', 1, N'2026-07-26 17:51:42.170', 1, N'EQ-QR-24MM-L2-ST1');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 25)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (25, 35, 7, N'EQUIPO-24MM-L2-ST2', N'MOD-2026-IND', N'SN-2026-0035', 1, N'2026-07-26 17:51:42.170', 1, N'EQ-QR-24MM-L2-ST2');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 26)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (26, 36, 4, N'EQUIPO-24MM-L2-ST3', N'MOD-2026-IND', N'SN-2026-0036', 1, N'2026-07-26 17:51:42.170', 1, N'EQ-QR-24MM-L2-ST3');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 27)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (27, 37, 6, N'EQUIPO-STL-L1-ST1', N'MOD-2026-IND', N'SN-2026-0037', 1, N'2026-07-26 17:51:42.180', 1, N'EQ-QR-STL-L1-ST1');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 28)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (28, 38, 5, N'EQUIPO-STL-L1-ST2', N'MOD-2026-IND', N'SN-2026-0038', 1, N'2026-07-26 17:51:42.187', 1, N'EQ-QR-STL-L1-ST2');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 29)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (29, 39, 8, N'EQUIPO-STL-L1-ST3', N'MOD-2026-IND', N'SN-2026-0039', 1, N'2026-07-26 17:51:42.190', 1, N'EQ-QR-STL-L1-ST3');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 30)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (30, 40, 2, N'EQUIPO-STL-L2-ST1', N'MOD-2026-IND', N'SN-2026-0040', 1, N'2026-07-26 17:51:42.190', 1, N'EQ-QR-STL-L2-ST1');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 31)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (31, 41, 8, N'EQUIPO-STL-L2-ST2', N'MOD-2026-IND', N'SN-2026-0041', 1, N'2026-07-26 17:51:42.190', 1, N'EQ-QR-STL-L2-ST2');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 32)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (32, 42, 6, N'EQUIPO-STL-L2-ST3', N'MOD-2026-IND', N'SN-2026-0042', 1, N'2026-07-26 17:51:42.193', 1, N'EQ-QR-STL-L2-ST3');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 33)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (33, 43, 9, N'EQUIPO-AB3-ST1', N'MOD-2026-IND', N'SN-2026-0043', 1, N'2026-07-26 17:51:42.207', 1, N'EQ-QR-AB3-ST1');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 34)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (34, 44, 2, N'EQUIPO-AB3-ST2', N'MOD-2026-IND', N'SN-2026-0044', 1, N'2026-07-26 17:51:42.210', 1, N'EQ-QR-AB3-ST2');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 35)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (35, 45, 5, N'EQUIPO-AB3-ST3', N'MOD-2026-IND', N'SN-2026-0045', 1, N'2026-07-26 17:51:42.217', 1, N'EQ-QR-AB3-ST3');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 36)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (36, 46, 7, N'EQUIPO-AB4-ST1', N'MOD-2026-IND', N'SN-2026-0046', 1, N'2026-07-26 17:51:42.217', 1, N'EQ-QR-AB4-ST1');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 37)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (37, 47, 2, N'EQUIPO-AB4-ST2', N'MOD-2026-IND', N'SN-2026-0047', 1, N'2026-07-26 17:51:42.217', 1, N'EQ-QR-AB4-ST2');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 38)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (38, 48, 2, N'EQUIPO-AB4-ST3', N'MOD-2026-IND', N'SN-2026-0048', 1, N'2026-07-26 17:51:42.220', 1, N'EQ-QR-AB4-ST3');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 39)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (39, 49, 9, N'EQUIPO-AB6-ST1', N'MOD-2026-IND', N'SN-2026-0049', 1, N'2026-07-26 17:51:42.220', 1, N'EQ-QR-AB6-ST1');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 40)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (40, 50, 5, N'EQUIPO-AB6-ST2', N'MOD-2026-IND', N'SN-2026-0050', 1, N'2026-07-26 17:51:42.220', 1, N'EQ-QR-AB6-ST2');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 41)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (41, 51, 9, N'EQUIPO-AB6-ST3', N'MOD-2026-IND', N'SN-2026-0051', 1, N'2026-07-26 17:51:42.220', 1, N'EQ-QR-AB6-ST3');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 42)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (42, 52, 1, N'EQUIPO-AB7-ST1', N'MOD-2026-IND', N'SN-2026-0052', 1, N'2026-07-26 17:51:42.223', 1, N'EQ-QR-AB7-ST1');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 43)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (43, 53, 7, N'EQUIPO-AB7-ST2', N'MOD-2026-IND', N'SN-2026-0053', 1, N'2026-07-26 17:51:42.227', 1, N'EQ-QR-AB7-ST2');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 44)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (44, 54, 7, N'EQUIPO-AB7-ST3', N'MOD-2026-IND', N'SN-2026-0054', 1, N'2026-07-26 17:51:42.227', 1, N'EQ-QR-AB7-ST3');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 45)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (45, 55, 1, N'EQUIPO-ECO-RUN-ST1', N'MOD-2026-IND', N'SN-2026-0055', 1, N'2026-07-26 17:51:42.227', 1, N'EQ-QR-ECO-RUN-ST1');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 46)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (46, 56, 5, N'EQUIPO-ECO-RUN-ST2', N'MOD-2026-IND', N'SN-2026-0056', 1, N'2026-07-26 17:51:42.227', 1, N'EQ-QR-ECO-RUN-ST2');
IF NOT EXISTS (SELECT 1 FROM dbo.[CatEquipos] WHERE [ID] = 47)
    INSERT INTO dbo.[CatEquipos] ([ID], [EstacionID], [TipoEquipoID], [Nombre], [Modelo], [NumeroSerie], [activo], [fecharegistro], [UsuarioRegistroID], [CodigoQR]) VALUES (47, 57, 8, N'EQUIPO-ECO-RUN-ST3', N'MOD-2026-IND', N'SN-2026-0057', 1, N'2026-07-26 17:51:42.230', 1, N'EQ-QR-ECO-RUN-ST3');

SET IDENTITY_INSERT dbo.[CatEquipos] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: RecursosSoporte (11 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[RecursosSoporte] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[RecursosSoporte] WHERE [ID] = 1)
    INSERT INTO dbo.[RecursosSoporte] ([ID], [TipoEquipoID], [FallaComunID], [Nombre], [TipoRecurso], [PathArchivo], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (1, 2, 1, N'Restart PC', N'Ayuda Visual', N'1784345792_OfficeInstructions_1.pdf', 1, N'2026-07-17 22:36:32.270', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[RecursosSoporte] WHERE [ID] = 2)
    INSERT INTO dbo.[RecursosSoporte] ([ID], [TipoEquipoID], [FallaComunID], [Nombre], [TipoRecurso], [PathArchivo], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (2, 7, 8, N'WI', N'WI', N'1785117954_OfficeInstructions.pdf', 1, N'2026-07-26 21:05:54.960', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[RecursosSoporte] WHERE [ID] = 3)
    INSERT INTO dbo.[RecursosSoporte] ([ID], [TipoEquipoID], [FallaComunID], [Nombre], [TipoRecurso], [PathArchivo], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (3, 8, 9, N'WI', N'WI', N'1785117954_OfficeInstructions.pdf', 1, N'2026-07-26 21:05:54.960', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[RecursosSoporte] WHERE [ID] = 4)
    INSERT INTO dbo.[RecursosSoporte] ([ID], [TipoEquipoID], [FallaComunID], [Nombre], [TipoRecurso], [PathArchivo], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (4, 5, 6, N'WI', N'WI', N'1785117954_OfficeInstructions.pdf', 1, N'2026-07-26 21:05:54.963', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[RecursosSoporte] WHERE [ID] = 5)
    INSERT INTO dbo.[RecursosSoporte] ([ID], [TipoEquipoID], [FallaComunID], [Nombre], [TipoRecurso], [PathArchivo], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (5, 2, 1, N'WI', N'WI', N'1785117954_OfficeInstructions.pdf', 1, N'2026-07-26 21:05:54.967', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[RecursosSoporte] WHERE [ID] = 6)
    INSERT INTO dbo.[RecursosSoporte] ([ID], [TipoEquipoID], [FallaComunID], [Nombre], [TipoRecurso], [PathArchivo], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (6, 1, 2, N'WI', N'WI', N'1785117954_OfficeInstructions.pdf', 1, N'2026-07-26 21:05:54.970', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[RecursosSoporte] WHERE [ID] = 7)
    INSERT INTO dbo.[RecursosSoporte] ([ID], [TipoEquipoID], [FallaComunID], [Nombre], [TipoRecurso], [PathArchivo], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (7, 9, 10, N'WI', N'WI', N'1785117954_OfficeInstructions.pdf', 1, N'2026-07-26 21:05:54.970', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[RecursosSoporte] WHERE [ID] = 8)
    INSERT INTO dbo.[RecursosSoporte] ([ID], [TipoEquipoID], [FallaComunID], [Nombre], [TipoRecurso], [PathArchivo], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (8, 3, 3, N'WI', N'WI', N'1785117954_OfficeInstructions.pdf', 1, N'2026-07-26 21:05:54.973', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[RecursosSoporte] WHERE [ID] = 9)
    INSERT INTO dbo.[RecursosSoporte] ([ID], [TipoEquipoID], [FallaComunID], [Nombre], [TipoRecurso], [PathArchivo], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (9, 3, 4, N'WI', N'WI', N'1785117954_OfficeInstructions.pdf', 1, N'2026-07-26 21:05:54.977', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[RecursosSoporte] WHERE [ID] = 10)
    INSERT INTO dbo.[RecursosSoporte] ([ID], [TipoEquipoID], [FallaComunID], [Nombre], [TipoRecurso], [PathArchivo], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (10, 4, 5, N'WI', N'WI', N'1785117954_OfficeInstructions.pdf', 1, N'2026-07-26 21:05:54.980', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[RecursosSoporte] WHERE [ID] = 11)
    INSERT INTO dbo.[RecursosSoporte] ([ID], [TipoEquipoID], [FallaComunID], [Nombre], [TipoRecurso], [PathArchivo], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (11, 6, 7, N'WI', N'WI', N'1785118617_drowsiness_detector_demo.gif', 1, N'2026-07-26 21:05:54.980', 1);

SET IDENTITY_INSERT dbo.[RecursosSoporte] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: OrdenesTrabajo (79 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[OrdenesTrabajo] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 3)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (3, 8, 1, 1, 5, 1, 3, 1, 2, 1, N'ESTACION_REGULAR', 2, N'3', N'2026-06-18 21:49:00.000', N'CORRECTIVO', NULL, 1, N'2026-07-18 21:46:21.607', 1, N'2026-07-19 14:33:03.800');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 7)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (7, 6, 3, 1, 5, 1, 4, 1, 2, 1, N'ESTACION_REGULAR', 5, N'test5', N'2026-06-18 21:49:00.000', N'CORRECTIVO', NULL, 1, N'2026-07-18 22:01:34.433', 1, N'2026-07-19 15:24:47.173');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 8)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (8, 6, 3, NULL, 3, 1, 4, 1, 2, 1, N'ESTACION_REGULAR', 5, N'test-python-app', N'2026-06-18 21:49:00.000', N'CORRECTIVO', NULL, 1, N'2026-07-18 22:03:59.950', 1, N'2026-07-19 15:44:17.173');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 9)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (9, 5, NULL, NULL, 1, 1, 3, 1, 8, 4, N'ESTACION_CUELLO_BOTELLA', 1, N'test9', N'2026-07-18 22:02:00.000', N'CORRECTIVO', NULL, 1, N'2026-07-18 22:11:39.330', 1, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 11)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (11, 3, 4, 2, 5, 1, 4, NULL, NULL, NULL, NULL, 0, N'Soporte in-situ iniciado directamente por el técnico sin OT previa.', N'2026-07-19 19:52:57.623', N'CORRECTIVO', NULL, 1, N'2026-07-19 19:52:57.623', 1, N'2026-07-19 19:52:57.623');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 12)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (12, 7, 1, 2, 5, 1, 1, NULL, NULL, NULL, NULL, 0, N'[PM PROGRAMADO] Prueba PM Recurrente E2E. Instrucciones de prueba automatizada.', N'2026-08-01 09:00:00.000', N'PREVENTIVO', 1, 1, N'2026-07-21 21:38:20.433', 1, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 14)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (14, 7, 1, 1, 5, 1, 1, NULL, NULL, NULL, NULL, 0, N'[PM PROGRAMADO] Prueba PM Recurrente E2E. Instrucciones de prueba automatizada.', N'2026-08-05 09:00:00.000', N'PREVENTIVO', 1, 1, N'2026-07-21 21:40:04.257', 1, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 15)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (15, 7, 1, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, 0, N'[PM RECURRENTE] Prueba PM Recurrente E2E. Instrucciones de prueba automatizada.', N'2026-07-28 09:00:00.000', N'PREVENTIVO', 1, 1, N'2026-07-21 21:40:04.353', 1, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 16)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (16, 7, 1, 1, 5, 1, 1, NULL, NULL, NULL, NULL, 0, N'[PM PROGRAMADO] Prueba PM Recurrente E2E. Instrucciones de prueba automatizada.', N'2026-08-05 09:00:00.000', N'PREVENTIVO', 1, 1, N'2026-07-21 21:45:31.493', 1, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 17)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (17, 7, 1, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, 0, N'[PM RECURRENTE] Prueba PM Recurrente E2E. Instrucciones de prueba automatizada.', N'2026-07-28 09:00:00.000', N'PREVENTIVO', 1, 1, N'2026-07-21 21:45:31.547', 1, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 18)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (18, 7, 1, 1, 5, 1, 1, NULL, NULL, NULL, NULL, 0, N'[PM PROGRAMADO] Prueba PM Recurrente E2E. Instrucciones de prueba automatizada.', N'2026-08-05 09:00:00.000', N'PREVENTIVO', 1, 1, N'2026-07-21 21:58:48.733', 1, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 19)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (19, 7, 1, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, 0, N'[PM RECURRENTE] Prueba PM Recurrente E2E. Instrucciones de prueba automatizada.', N'2026-07-28 09:00:00.000', N'PREVENTIVO', 1, 1, N'2026-07-21 21:58:48.793', 1, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 20)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (20, 7, 1, 1, 5, 1, 1, NULL, NULL, NULL, NULL, 0, N'[PM PROGRAMADO] Prueba PM Recurrente E2E. Instrucciones de prueba automatizada.', N'2026-08-05 09:00:00.000', N'PREVENTIVO', 1, 1, N'2026-07-23 21:14:16.770', 1, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 21)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (21, 7, 1, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, 0, N'[PM RECURRENTE] Prueba PM Recurrente E2E. Instrucciones de prueba automatizada.', N'2026-07-30 09:00:00.000', N'PREVENTIVO', 1, 1, N'2026-07-23 21:14:17.017', 1, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 22)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (22, 7, 1, 1, 5, 1, 1, NULL, NULL, NULL, NULL, 0, N'[PM PROGRAMADO] PM Test Sync Full. Verificar prueba de sincronizacion', N'2026-07-25 10:00:00.000', N'PREVENTIVO', NULL, 1, N'2026-07-23 21:16:08.260', 1, N'2026-07-23 21:16:08.297');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 23)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (23, 7, 1, 1, 5, 1, 1, NULL, NULL, NULL, NULL, 0, N'[PM PROGRAMADO] PM Test Sync Full. Verificar prueba de sincronizacion', N'2026-07-25 10:00:00.000', N'PREVENTIVO', NULL, 1, N'2026-07-23 22:04:52.347', 1, N'2026-07-23 22:04:52.403');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 24)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (24, 31, NULL, NULL, 1, 18, 4, 6, 7, 4, N'LINEA_COMPLETA', 7, N'Reporte automático de prueba en CORRECTIVO para estación 31.', N'2026-07-12 09:12:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-12 09:12:42.237', 18, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 25)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (25, 35, 6, 9, 5, 18, 4, 6, 4, 1, N'LINEA_COMPLETA', 1, N'Reporte automático de prueba en CORRECTIVO para estación 35.', N'2026-07-22 08:22:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-22 08:22:42.237', 18, N'2026-07-26 21:34:45.217');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 26)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (26, 53, NULL, NULL, 1, 14, 4, 8, 8, 3, N'ESTACION_REGULAR', 5, N'Reporte automático de prueba en CORRECTIVO para estación 53.', N'2026-07-17 14:40:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-17 14:40:42.237', 14, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 27)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (27, 21, NULL, NULL, 1, 17, 3, 4, 5, 2, N'ESTACION_CUELLO_BOTELLA', 0, N'Reporte automático de prueba en CORRECTIVO para estación 21.', N'2026-07-20 09:19:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-20 09:19:42.237', 17, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 28)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (28, 31, NULL, NULL, 1, 15, 2, 4, 3, 1, N'ESTACION_REGULAR', 8, N'Reporte automático de prueba en CORRECTIVO para estación 31.', N'2026-07-19 11:57:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-19 11:57:42.237', 15, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 29)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (29, 57, NULL, NULL, 1, 15, 5, 8, 5, 4, N'ESTACION_CUELLO_BOTELLA', 6, N'Reporte automático de prueba en CORRECTIVO para estación 57.', N'2026-07-16 01:05:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-16 01:05:42.237', 15, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 30)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (30, 30, NULL, NULL, 1, 15, 2, 7, 7, 4, N'ESTACION_CUELLO_BOTELLA', 8, N'Reporte automático de prueba en CORRECTIVO para estación 30.', N'2026-07-16 12:04:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-16 12:04:42.237', 15, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 31)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (31, 54, NULL, NULL, 1, 17, 4, 6, 6, 1, N'ESTACION_CUELLO_BOTELLA', 3, N'Reporte automático de prueba en CORRECTIVO para estación 54.', N'2026-07-21 18:04:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-21 18:04:42.237', 17, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 32)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (32, 29, NULL, NULL, 1, 18, 5, 10, 2, 3, N'ESTACION_REGULAR', 0, N'Reporte automático de prueba en PREVENTIVO para estación 29.', N'2026-07-16 21:39:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-16 21:39:42.237', 18, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 33)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (33, 46, NULL, NULL, 1, 15, 4, 10, 3, 4, N'ESTACION_REGULAR', 2, N'Reporte automático de prueba en PREVENTIVO para estación 46.', N'2026-07-13 21:54:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-13 21:54:42.237', 15, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 34)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (34, 28, NULL, NULL, 1, 17, 2, 3, 8, 3, N'ESTACION_CUELLO_BOTELLA', 6, N'Reporte automático de prueba en PREVENTIVO para estación 28.', N'2026-07-14 12:20:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-14 12:20:42.237', 17, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 35)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (35, 48, NULL, NULL, 1, 17, 4, 5, 5, 4, N'ESTACION_REGULAR', 4, N'Reporte automático de prueba en PREVENTIVO para estación 48.', N'2026-07-16 19:05:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-16 19:05:42.237', 17, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 36)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (36, 19, 34, 1, 2, 18, 3, 4, 6, 4, N'LINEA_COMPLETA', 6, N'Reporte automático de prueba en CORRECTIVO para estación 19.', N'2026-07-14 05:17:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-14 05:17:42.237', 18, N'2026-07-14 05:40:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 37)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (37, 33, 37, 5, 2, 17, 2, 5, 7, 4, N'ESTACION_CUELLO_BOTELLA', 6, N'Reporte automático de prueba en CORRECTIVO para estación 33.', N'2026-07-19 00:44:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-19 00:44:42.237', 17, N'2026-07-19 01:02:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 38)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (38, 48, 25, 2, 2, 15, 4, 6, 6, 2, N'ESTACION_REGULAR', 3, N'Reporte automático de prueba en CORRECTIVO para estación 48.', N'2026-07-12 11:09:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-12 11:09:42.237', 15, N'2026-07-12 11:31:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 39)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (39, 48, 7, 7, 2, 16, 5, 4, 2, 2, N'ESTACION_CUELLO_BOTELLA', 3, N'Reporte automático de prueba en CORRECTIVO para estación 48.', N'2026-07-21 21:30:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-21 21:30:42.237', 16, N'2026-07-21 21:45:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 40)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (40, 24, 14, 1, 2, 14, 5, 10, 4, 3, N'ESTACION_CUELLO_BOTELLA', 6, N'Reporte automático de prueba en CORRECTIVO para estación 24.', N'2026-07-19 03:05:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-19 03:05:42.237', 14, N'2026-07-19 03:38:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 41)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (41, 23, 28, 5, 2, 16, 3, 2, 5, 1, N'ESTACION_REGULAR', 4, N'Reporte automático de prueba en CORRECTIVO para estación 23.', N'2026-07-13 06:38:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-13 06:38:42.237', 16, N'2026-07-13 06:53:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 42)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (42, 29, 46, 10, 2, 16, 4, 2, 5, 4, N'ESTACION_CUELLO_BOTELLA', 3, N'Reporte automático de prueba en CORRECTIVO para estación 29.', N'2026-07-12 04:25:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-12 04:25:42.237', 16, N'2026-07-12 04:43:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 43)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (43, 39, 13, 8, 2, 18, 5, 4, 4, 1, N'ESTACION_REGULAR', 6, N'Reporte automático de prueba en CORRECTIVO para estación 39.', N'2026-07-22 01:11:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-22 01:11:42.237', 18, N'2026-07-22 01:28:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 44)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (44, 48, 19, 3, 2, 18, 4, 8, 8, 1, N'LINEA_COMPLETA', 5, N'Reporte automático de prueba en CORRECTIVO para estación 48.', N'2026-07-25 04:53:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-25 04:53:42.237', 18, N'2026-07-25 05:19:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 45)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (45, 39, 35, 9, 2, 16, 4, 6, 2, 2, N'ESTACION_REGULAR', 6, N'Reporte automático de prueba en CORRECTIVO para estación 39.', N'2026-07-19 19:37:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-19 19:37:42.237', 16, N'2026-07-19 19:57:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 46)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (46, 55, 18, 2, 2, 16, 5, 2, 7, 2, N'LINEA_COMPLETA', 1, N'Reporte automático de prueba en PREVENTIVO para estación 55.', N'2026-07-17 13:07:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-17 13:07:42.237', 16, N'2026-07-17 13:36:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 47)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (47, 29, 27, 7, 2, 15, 4, 10, 6, 2, N'ESTACION_REGULAR', 6, N'Reporte automático de prueba en PREVENTIVO para estación 29.', N'2026-07-13 20:33:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-13 20:33:42.237', 15, N'2026-07-13 20:42:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 48)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (48, 41, 45, 10, 2, 15, 4, 10, 6, 2, N'ESTACION_CUELLO_BOTELLA', 8, N'Reporte automático de prueba en PREVENTIVO para estación 41.', N'2026-07-20 08:06:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-20 08:06:42.237', 15, N'2026-07-20 08:35:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 49)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (49, 27, 47, 2, 2, 14, 5, 5, 5, 2, N'ESTACION_REGULAR', 2, N'Reporte automático de prueba en PREVENTIVO para estación 27.', N'2026-07-16 04:56:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-16 04:56:42.237', 14, N'2026-07-16 05:26:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 50)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (50, 40, 18, 4, 2, 16, 3, 5, 6, 2, N'ESTACION_CUELLO_BOTELLA', 2, N'Reporte automático de prueba en PREVENTIVO para estación 40.', N'2026-07-25 21:57:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-25 21:57:42.237', 16, N'2026-07-25 22:12:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 51)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (51, 44, 24, 8, 3, 15, 5, 7, 3, 3, N'ESTACION_REGULAR', 7, N'Reporte automático de prueba en CORRECTIVO para estación 44.', N'2026-07-20 03:09:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-20 03:09:42.237', 15, N'2026-07-20 03:23:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 52)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (52, 24, 31, 9, 3, 16, 5, 5, 7, 2, N'ESTACION_REGULAR', 8, N'Reporte automático de prueba en CORRECTIVO para estación 24.', N'2026-07-21 17:37:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-21 17:37:42.237', 16, N'2026-07-21 18:08:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 53)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (53, 37, 26, 1, 3, 18, 5, 2, 5, 3, N'ESTACION_REGULAR', 6, N'Reporte automático de prueba en CORRECTIVO para estación 37.', N'2026-07-20 05:30:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-20 05:30:42.237', 18, N'2026-07-20 05:56:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 54)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (54, 53, 20, 5, 3, 16, 4, 1, 1, 4, N'LINEA_COMPLETA', 4, N'Reporte automático de prueba en CORRECTIVO para estación 53.', N'2026-07-23 07:59:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-23 07:59:42.237', 16, N'2026-07-23 08:10:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 55)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (55, 18, 26, 6, 3, 14, 3, 4, 6, 2, N'ESTACION_REGULAR', 8, N'Reporte automático de prueba en CORRECTIVO para estación 18.', N'2026-07-14 10:05:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-14 10:05:42.237', 14, N'2026-07-14 10:35:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 56)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (56, 33, 31, 4, 3, 14, 5, 9, 1, 1, N'ESTACION_CUELLO_BOTELLA', 5, N'Reporte automático de prueba en CORRECTIVO para estación 33.', N'2026-07-15 05:00:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-15 05:00:42.237', 14, N'2026-07-15 05:30:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 57)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (57, 36, 47, 4, 3, 16, 5, 9, 5, 1, N'LINEA_COMPLETA', 0, N'Reporte automático de prueba en PREVENTIVO para estación 36.', N'2026-07-24 08:02:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-24 08:02:42.237', 16, N'2026-07-24 08:23:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 58)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (58, 47, 20, 2, 3, 18, 2, 5, 2, 1, N'ESTACION_REGULAR', 8, N'Reporte automático de prueba en PREVENTIVO para estación 47.', N'2026-07-18 12:46:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-18 12:46:42.237', 18, N'2026-07-18 13:04:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 59)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (59, 48, NULL, NULL, 4, 16, 5, 5, 6, 4, N'LINEA_COMPLETA', 5, N'Reporte automático de prueba en CORRECTIVO para estación 48.', N'2026-07-15 00:48:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-15 00:48:42.237', 16, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 60)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (60, 47, NULL, NULL, 4, 15, 3, 6, 4, 3, N'ESTACION_REGULAR', 0, N'Reporte automático de prueba en CORRECTIVO para estación 47.', N'2026-07-12 12:23:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-12 12:23:42.237', 15, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 61)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (61, 20, NULL, NULL, 4, 17, 3, 9, 8, 1, N'ESTACION_CUELLO_BOTELLA', 8, N'Reporte automático de prueba en CORRECTIVO para estación 20.', N'2026-07-23 07:17:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-23 07:17:42.237', 17, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 62)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (62, 24, NULL, NULL, 4, 17, 5, 5, 4, 3, N'LINEA_COMPLETA', 3, N'Reporte automático de prueba en PREVENTIVO para estación 24.', N'2026-07-12 07:46:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-12 07:46:42.237', 17, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 63)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (63, 32, NULL, NULL, 4, 15, 5, 7, 7, 2, N'LINEA_COMPLETA', 4, N'Reporte automático de prueba en PREVENTIVO para estación 32.', N'2026-07-24 08:07:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-24 08:07:42.237', 15, NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 64)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (64, 54, 43, 2, 5, 15, 3, 1, 7, 4, N'ESTACION_REGULAR', 3, N'Reporte automático de prueba en CORRECTIVO para estación 54.', N'2026-07-17 12:04:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-17 12:04:42.237', 15, N'2026-07-17 12:32:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 65)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (65, 36, 7, 5, 5, 15, 4, 10, 3, 1, N'ESTACION_CUELLO_BOTELLA', 8, N'Reporte automático de prueba en CORRECTIVO para estación 36.', N'2026-07-15 03:56:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-15 03:56:42.237', 15, N'2026-07-15 04:21:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 66)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (66, 36, 10, 2, 5, 16, 4, 9, 3, 2, N'LINEA_COMPLETA', 6, N'Reporte automático de prueba en CORRECTIVO para estación 36.', N'2026-07-23 03:16:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-23 03:16:42.237', 16, N'2026-07-23 03:23:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 67)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (67, 37, 14, 3, 5, 16, 3, 1, 2, 2, N'ESTACION_REGULAR', 7, N'Reporte automático de prueba en CORRECTIVO para estación 37.', N'2026-07-26 14:50:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-26 14:50:42.237', 16, N'2026-07-26 15:18:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 68)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (68, 37, 39, 3, 5, 15, 3, 9, 3, 3, N'LINEA_COMPLETA', 3, N'Reporte automático de prueba en CORRECTIVO para estación 37.', N'2026-07-15 09:22:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-15 09:22:42.237', 15, N'2026-07-15 09:36:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 69)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (69, 32, 16, 7, 5, 15, 2, 9, 2, 1, N'LINEA_COMPLETA', 5, N'Reporte automático de prueba en CORRECTIVO para estación 32.', N'2026-07-19 14:50:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-19 14:50:42.237', 15, N'2026-07-19 15:16:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 70)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (70, 33, 32, 7, 5, 18, 5, 6, 5, 2, N'ESTACION_CUELLO_BOTELLA', 4, N'Reporte automático de prueba en CORRECTIVO para estación 33.', N'2026-07-13 01:33:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-13 01:33:42.237', 18, N'2026-07-13 01:56:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 71)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (71, 19, 7, 3, 5, 18, 3, 10, 8, 1, N'LINEA_COMPLETA', 4, N'Reporte automático de prueba en CORRECTIVO para estación 19.', N'2026-07-20 07:56:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-20 07:56:42.237', 18, N'2026-07-20 08:17:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 72)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (72, 45, 32, 8, 5, 16, 3, 5, 4, 4, N'ESTACION_REGULAR', 4, N'Reporte automático de prueba en CORRECTIVO para estación 45.', N'2026-07-19 18:32:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-19 18:32:42.237', 16, N'2026-07-19 18:46:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 73)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (73, 40, 16, 9, 5, 17, 4, 10, 2, 3, N'LINEA_COMPLETA', 1, N'Reporte automático de prueba en CORRECTIVO para estación 40.', N'2026-07-15 13:54:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-15 13:54:42.237', 17, N'2026-07-15 14:23:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 74)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (74, 21, 43, 10, 5, 15, 2, 6, 7, 4, N'ESTACION_REGULAR', 1, N'Reporte automático de prueba en CORRECTIVO para estación 21.', N'2026-07-22 07:46:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-22 07:46:42.237', 15, N'2026-07-22 07:59:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 75)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (75, 44, 22, 6, 5, 18, 3, 5, 7, 2, N'ESTACION_REGULAR', 5, N'Reporte automático de prueba en CORRECTIVO para estación 44.', N'2026-07-19 05:31:42.237', N'CORRECTIVO', NULL, 1, N'2026-07-19 05:31:42.237', 18, N'2026-07-19 05:54:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 76)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (76, 32, 18, 3, 5, 18, 4, 10, 8, 4, N'ESTACION_CUELLO_BOTELLA', 5, N'Reporte automático de prueba en PREVENTIVO para estación 32.', N'2026-07-24 06:52:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-24 06:52:42.237', 18, N'2026-07-24 07:03:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 77)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (77, 17, 9, 2, 5, 17, 3, 2, 2, 2, N'ESTACION_REGULAR', 4, N'Reporte automático de prueba en PREVENTIVO para estación 17.', N'2026-07-18 13:06:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-18 13:06:42.237', 17, N'2026-07-18 13:26:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 78)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (78, 38, 8, 7, 5, 15, 2, 5, 7, 2, N'ESTACION_CUELLO_BOTELLA', 3, N'Reporte automático de prueba en PREVENTIVO para estación 38.', N'2026-07-22 19:11:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-22 19:11:42.237', 15, N'2026-07-22 19:35:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 79)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (79, 42, 36, 1, 5, 15, 2, 1, 7, 1, N'ESTACION_CUELLO_BOTELLA', 1, N'Reporte automático de prueba en PREVENTIVO para estación 42.', N'2026-07-20 15:16:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-20 15:16:42.237', 15, N'2026-07-20 15:36:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 80)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (80, 51, 30, 1, 5, 15, 4, 6, 7, 3, N'LINEA_COMPLETA', 1, N'Reporte automático de prueba en PREVENTIVO para estación 51.', N'2026-07-22 19:19:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-22 19:19:42.237', 15, N'2026-07-22 19:28:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 81)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (81, 54, 39, 6, 5, 18, 5, 4, 6, 1, N'ESTACION_REGULAR', 3, N'Reporte automático de prueba en PREVENTIVO para estación 54.', N'2026-07-22 12:26:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-22 12:26:42.237', 18, N'2026-07-22 12:51:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 82)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (82, 16, 15, 4, 5, 18, 3, 6, 2, 3, N'ESTACION_REGULAR', 0, N'Reporte automático de prueba en PREVENTIVO para estación 16.', N'2026-07-23 14:39:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-23 14:39:42.237', 18, N'2026-07-23 14:49:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 83)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (83, 44, 40, 7, 5, 14, 3, 6, 2, 2, N'ESTACION_REGULAR', 8, N'Reporte automático de prueba en PREVENTIVO para estación 44.', N'2026-07-17 14:25:42.237', N'PREVENTIVO', NULL, 1, N'2026-07-17 14:25:42.237', 14, N'2026-07-17 14:46:42.237');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 84)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (84, 17, 7, NULL, 2, 1, 4, NULL, NULL, NULL, NULL, 0, N'Soporte in-situ iniciado directamente por el técnico sin OT previa.', N'2026-07-26 20:12:10.783', N'CORRECTIVO', NULL, 1, N'2026-07-26 20:12:10.783', 1, N'2026-07-26 20:12:10.783');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 85)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (85, 16, 6, NULL, 2, 1, 4, NULL, NULL, NULL, NULL, 0, N'Soporte in-situ iniciado directamente por el técnico sin OT previa.', N'2026-07-29 22:13:19.100', N'CORRECTIVO', NULL, 1, N'2026-07-29 22:13:19.100', 1, N'2026-07-29 22:13:19.100');
IF NOT EXISTS (SELECT 1 FROM dbo.[OrdenesTrabajo] WHERE [ID] = 86)
    INSERT INTO dbo.[OrdenesTrabajo] ([ID], [EstacionID], [EquipoID], [FallaRealID], [EstadoID], [LiderReportaID], [TurnoID], [SintomaFallaLiderID], [ClasificacionFallaLiderID], [Causa4MID], [AreaAfectadaImpacto], [EmpleadosAfectados], [ComentarioLider], [FechaReporte], [TipoMantenimiento], [RutinaPreventivaID], [activo], [fecharegistro], [UsuarioRegistroID], [FechaInicioSoporte]) VALUES (86, 24, 14, 2, 5, 1, 4, NULL, NULL, NULL, NULL, 0, N'Soporte in-situ iniciado directamente por el técnico sin OT previa.', N'2026-07-29 22:20:45.687', N'CORRECTIVO', NULL, 1, N'2026-07-29 22:20:45.687', 1, N'2026-07-29 22:20:45.687');

SET IDENTITY_INSERT dbo.[OrdenesTrabajo] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: DetalleTecnicosOT (57 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[DetalleTecnicosOT] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 1)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (1, 11, 1, N'2026-07-19 19:52:57.623', N'2026-07-19 19:52:57.623', N'2026-07-19 19:53:36.167', 1, N'2026-07-19 19:52:57.623');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 4)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (4, 14, 1, N'2026-07-21 21:40:04.267', NULL, N'2026-07-21 21:40:04.330', 1, N'2026-07-21 21:40:04.267');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 5)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (5, 15, 1, N'2026-07-21 21:40:04.360', NULL, NULL, 1, N'2026-07-21 21:40:04.360');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 6)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (6, 16, 1, N'2026-07-21 21:45:31.500', NULL, N'2026-07-21 21:45:31.530', 1, N'2026-07-21 21:45:31.500');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 7)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (7, 17, 1, N'2026-07-21 21:45:31.550', NULL, NULL, 1, N'2026-07-21 21:45:31.550');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 8)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (8, 18, 1, N'2026-07-21 21:58:48.740', NULL, N'2026-07-21 21:58:48.780', 1, N'2026-07-21 21:58:48.740');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 9)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (9, 19, 1, N'2026-07-21 21:58:48.800', NULL, NULL, 1, N'2026-07-21 21:58:48.800');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 10)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (10, 20, 1, N'2026-07-23 21:14:16.780', NULL, N'2026-07-23 21:14:16.983', 1, N'2026-07-23 21:14:16.780');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 11)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (11, 21, 1, N'2026-07-23 21:14:17.023', NULL, NULL, 1, N'2026-07-23 21:14:17.023');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 12)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (12, 22, 1, N'2026-07-23 21:16:08.267', N'2026-07-23 21:16:08.297', N'2026-07-23 21:16:08.370', 1, N'2026-07-23 21:16:08.267');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 13)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (13, 23, 1, N'2026-07-23 22:04:52.357', N'2026-07-23 22:04:52.403', N'2026-07-23 22:04:52.490', 1, N'2026-07-23 22:04:52.357');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 14)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (14, 36, 13, N'2026-07-14 05:27:42.237', N'2026-07-14 05:40:42.237', NULL, 1, N'2026-07-26 17:51:42.300');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 15)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (15, 37, 10, N'2026-07-19 00:52:42.237', N'2026-07-19 01:02:42.237', NULL, 1, N'2026-07-26 17:51:42.303');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 16)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (16, 38, 9, N'2026-07-12 11:13:42.237', N'2026-07-12 11:31:42.237', NULL, 1, N'2026-07-26 17:51:42.303');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 17)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (17, 39, 12, N'2026-07-21 21:36:42.237', N'2026-07-21 21:45:42.237', NULL, 1, N'2026-07-26 17:51:42.303');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 18)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (18, 40, 11, N'2026-07-19 03:18:42.237', N'2026-07-19 03:38:42.237', NULL, 1, N'2026-07-26 17:51:42.307');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 19)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (19, 41, 10, N'2026-07-13 06:49:42.237', N'2026-07-13 06:53:42.237', NULL, 1, N'2026-07-26 17:51:42.310');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 20)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (20, 42, 12, N'2026-07-12 04:39:42.237', N'2026-07-12 04:43:42.237', NULL, 1, N'2026-07-26 17:51:42.310');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 21)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (21, 43, 12, N'2026-07-22 01:16:42.237', N'2026-07-22 01:28:42.237', NULL, 1, N'2026-07-26 17:51:42.310');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 22)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (22, 44, 12, N'2026-07-25 05:05:42.237', N'2026-07-25 05:19:42.237', NULL, 1, N'2026-07-26 17:51:42.310');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 23)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (23, 45, 11, N'2026-07-19 19:44:42.237', N'2026-07-19 19:57:42.237', NULL, 1, N'2026-07-26 17:51:42.310');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 24)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (24, 46, 12, N'2026-07-17 13:18:42.237', N'2026-07-17 13:36:42.237', NULL, 1, N'2026-07-26 17:51:42.313');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 25)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (25, 47, 11, N'2026-07-13 20:35:42.237', N'2026-07-13 20:42:42.237', NULL, 1, N'2026-07-26 17:51:42.313');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 26)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (26, 48, 11, N'2026-07-20 08:18:42.237', N'2026-07-20 08:35:42.237', NULL, 1, N'2026-07-26 17:51:42.317');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 27)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (27, 49, 11, N'2026-07-16 05:06:42.237', N'2026-07-16 05:26:42.237', NULL, 1, N'2026-07-26 17:51:42.317');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 28)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (28, 50, 11, N'2026-07-25 22:06:42.237', N'2026-07-25 22:12:42.237', NULL, 1, N'2026-07-26 17:51:42.317');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 29)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (29, 51, 13, N'2026-07-20 03:16:42.237', N'2026-07-20 03:23:42.237', NULL, 1, N'2026-07-26 17:51:42.320');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 30)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (30, 52, 13, N'2026-07-21 17:51:42.237', N'2026-07-21 18:08:42.237', NULL, 1, N'2026-07-26 17:51:42.333');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 31)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (31, 53, 11, N'2026-07-20 05:40:42.237', N'2026-07-20 05:56:42.237', NULL, 1, N'2026-07-26 17:51:42.337');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 32)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (32, 54, 9, N'2026-07-23 08:01:42.237', N'2026-07-23 08:10:42.237', NULL, 1, N'2026-07-26 17:51:42.343');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 33)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (33, 55, 13, N'2026-07-14 10:17:42.237', N'2026-07-14 10:35:42.237', NULL, 1, N'2026-07-26 17:51:42.347');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 34)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (34, 56, 13, N'2026-07-15 05:12:42.237', N'2026-07-15 05:30:42.237', NULL, 1, N'2026-07-26 17:51:42.347');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 35)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (35, 57, 11, N'2026-07-24 08:17:42.237', N'2026-07-24 08:23:42.237', NULL, 1, N'2026-07-26 17:51:42.350');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 36)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (36, 58, 13, N'2026-07-18 12:53:42.237', N'2026-07-18 13:04:42.237', NULL, 1, N'2026-07-26 17:51:42.350');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 37)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (37, 64, 12, N'2026-07-17 12:16:42.237', N'2026-07-17 12:32:42.237', N'2026-07-17 13:42:42.237', 1, N'2026-07-26 17:51:42.370');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 38)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (38, 65, 12, N'2026-07-15 04:02:42.237', N'2026-07-15 04:21:42.237', N'2026-07-15 05:20:42.237', 1, N'2026-07-26 17:51:42.380');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 39)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (39, 66, 12, N'2026-07-23 03:18:42.237', N'2026-07-23 03:23:42.237', N'2026-07-23 06:18:42.237', 1, N'2026-07-26 17:51:42.380');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 40)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (40, 67, 10, N'2026-07-26 15:01:42.237', N'2026-07-26 15:18:42.237', N'2026-07-26 15:55:42.237', 1, N'2026-07-26 17:51:42.380');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 41)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (41, 68, 13, N'2026-07-15 09:25:42.237', N'2026-07-15 09:36:42.237', N'2026-07-15 10:04:42.237', 1, N'2026-07-26 17:51:42.383');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 42)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (42, 69, 12, N'2026-07-19 14:57:42.237', N'2026-07-19 15:16:42.237', N'2026-07-19 15:42:42.237', 1, N'2026-07-26 17:51:42.383');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 43)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (43, 70, 10, N'2026-07-13 01:37:42.237', N'2026-07-13 01:56:42.237', N'2026-07-13 04:47:42.237', 1, N'2026-07-26 17:51:42.387');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 44)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (44, 71, 9, N'2026-07-20 08:07:42.237', N'2026-07-20 08:17:42.237', N'2026-07-20 10:35:42.237', 1, N'2026-07-26 17:51:42.387');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 45)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (45, 72, 11, N'2026-07-19 18:38:42.237', N'2026-07-19 18:46:42.237', N'2026-07-19 21:31:42.237', 1, N'2026-07-26 17:51:42.387');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 46)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (46, 73, 13, N'2026-07-15 14:08:42.237', N'2026-07-15 14:23:42.237', N'2026-07-15 16:24:42.237', 1, N'2026-07-26 17:51:42.390');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 47)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (47, 74, 10, N'2026-07-22 07:53:42.237', N'2026-07-22 07:59:42.237', N'2026-07-22 08:42:42.237', 1, N'2026-07-26 17:51:42.390');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 48)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (48, 75, 11, N'2026-07-19 05:46:42.237', N'2026-07-19 05:54:42.237', N'2026-07-19 06:14:42.237', 1, N'2026-07-26 17:51:42.393');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 49)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (49, 76, 10, N'2026-07-24 06:56:42.237', N'2026-07-24 07:03:42.237', N'2026-07-24 08:00:42.237', 1, N'2026-07-26 17:51:42.393');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 50)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (50, 77, 12, N'2026-07-18 13:10:42.237', N'2026-07-18 13:26:42.237', N'2026-07-18 14:59:42.237', 1, N'2026-07-26 17:51:42.393');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 51)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (51, 78, 11, N'2026-07-22 19:16:42.237', N'2026-07-22 19:35:42.237', N'2026-07-22 20:48:42.237', 1, N'2026-07-26 17:51:42.397');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 52)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (52, 79, 11, N'2026-07-20 15:23:42.237', N'2026-07-20 15:36:42.237', N'2026-07-20 16:39:42.237', 1, N'2026-07-26 17:51:42.400');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 53)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (53, 80, 13, N'2026-07-22 19:23:42.237', N'2026-07-22 19:28:42.237', N'2026-07-22 20:34:42.237', 1, N'2026-07-26 17:51:42.400');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 54)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (54, 81, 9, N'2026-07-22 12:40:42.237', N'2026-07-22 12:51:42.237', N'2026-07-22 14:09:42.237', 1, N'2026-07-26 17:51:42.400');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 55)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (55, 82, 12, N'2026-07-23 14:45:42.237', N'2026-07-23 14:49:42.237', N'2026-07-23 15:19:42.237', 1, N'2026-07-26 17:51:42.400');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 56)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (56, 83, 13, N'2026-07-17 14:36:42.237', N'2026-07-17 14:46:42.237', N'2026-07-17 15:35:42.237', 1, N'2026-07-26 17:51:42.403');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 57)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (57, 84, 1, N'2026-07-26 20:12:10.787', N'2026-07-26 20:12:10.787', NULL, 1, N'2026-07-26 20:12:10.787');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 58)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (58, 85, 1, N'2026-07-29 22:13:19.103', N'2026-07-29 22:13:19.103', NULL, 1, N'2026-07-29 22:13:19.103');
IF NOT EXISTS (SELECT 1 FROM dbo.[DetalleTecnicosOT] WHERE [ID] = 59)
    INSERT INTO dbo.[DetalleTecnicosOT] ([ID], [OrdenTrabajoID], [TecnicoID], [FechaAsignacion], [FechaArriboQR], [FechaFinActividad], [activo], [fecharegistro]) VALUES (59, 86, 1, N'2026-07-29 22:20:45.687', N'2026-07-29 22:20:45.687', N'2026-07-29 22:21:00.690', 1, N'2026-07-29 22:20:45.687');

SET IDENTITY_INSERT dbo.[DetalleTecnicosOT] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: RegistroPausasOT (12 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[RegistroPausasOT] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[RegistroPausasOT] WHERE [ID] = 1)
    INSERT INTO dbo.[RegistroPausasOT] ([ID], [OrdenTrabajoID], [MotivoPausaID], [UsuarioPausaID], [FechaInicioPausa], [FechaFinPausa], [Comentario], [activo], [fecharegistro]) VALUES (1, 3, 4, 1, N'2026-07-19 17:06:29.780', N'2026-07-19 17:52:25.350', N'en espera de personal tecnico', 1, N'2026-07-19 17:06:29.780');
IF NOT EXISTS (SELECT 1 FROM dbo.[RegistroPausasOT] WHERE [ID] = 2)
    INSERT INTO dbo.[RegistroPausasOT] ([ID], [OrdenTrabajoID], [MotivoPausaID], [UsuarioPausaID], [FechaInicioPausa], [FechaFinPausa], [Comentario], [activo], [fecharegistro]) VALUES (2, 8, 3, 1, N'2026-07-19 19:23:11.457', NULL, N'tst', 1, N'2026-07-19 19:23:11.457');
IF NOT EXISTS (SELECT 1 FROM dbo.[RegistroPausasOT] WHERE [ID] = 3)
    INSERT INTO dbo.[RegistroPausasOT] ([ID], [OrdenTrabajoID], [MotivoPausaID], [UsuarioPausaID], [FechaInicioPausa], [FechaFinPausa], [Comentario], [activo], [fecharegistro]) VALUES (3, 22, 1, 1, N'2026-07-23 21:16:08.313', N'2026-07-23 21:16:08.347', N'Pausa de prueba', 1, N'2026-07-23 21:16:08.313');
IF NOT EXISTS (SELECT 1 FROM dbo.[RegistroPausasOT] WHERE [ID] = 4)
    INSERT INTO dbo.[RegistroPausasOT] ([ID], [OrdenTrabajoID], [MotivoPausaID], [UsuarioPausaID], [FechaInicioPausa], [FechaFinPausa], [Comentario], [activo], [fecharegistro]) VALUES (4, 23, 1, 1, N'2026-07-23 22:04:52.430', N'2026-07-23 22:04:52.467', N'Pausa de prueba', 1, N'2026-07-23 22:04:52.430');
IF NOT EXISTS (SELECT 1 FROM dbo.[RegistroPausasOT] WHERE [ID] = 5)
    INSERT INTO dbo.[RegistroPausasOT] ([ID], [OrdenTrabajoID], [MotivoPausaID], [UsuarioPausaID], [FechaInicioPausa], [FechaFinPausa], [Comentario], [activo], [fecharegistro]) VALUES (5, 51, 4, 13, N'2026-07-20 03:52:42.237', NULL, N'En espera de refacciones/soporte.', 1, N'2026-07-26 17:51:42.330');
IF NOT EXISTS (SELECT 1 FROM dbo.[RegistroPausasOT] WHERE [ID] = 6)
    INSERT INTO dbo.[RegistroPausasOT] ([ID], [OrdenTrabajoID], [MotivoPausaID], [UsuarioPausaID], [FechaInicioPausa], [FechaFinPausa], [Comentario], [activo], [fecharegistro]) VALUES (6, 52, 3, 13, N'2026-07-21 18:26:42.237', NULL, N'En espera de refacciones/soporte.', 1, N'2026-07-26 17:51:42.333');
IF NOT EXISTS (SELECT 1 FROM dbo.[RegistroPausasOT] WHERE [ID] = 7)
    INSERT INTO dbo.[RegistroPausasOT] ([ID], [OrdenTrabajoID], [MotivoPausaID], [UsuarioPausaID], [FechaInicioPausa], [FechaFinPausa], [Comentario], [activo], [fecharegistro]) VALUES (7, 53, 3, 11, N'2026-07-20 06:39:42.237', NULL, N'En espera de refacciones/soporte.', 1, N'2026-07-26 17:51:42.343');
IF NOT EXISTS (SELECT 1 FROM dbo.[RegistroPausasOT] WHERE [ID] = 8)
    INSERT INTO dbo.[RegistroPausasOT] ([ID], [OrdenTrabajoID], [MotivoPausaID], [UsuarioPausaID], [FechaInicioPausa], [FechaFinPausa], [Comentario], [activo], [fecharegistro]) VALUES (8, 54, 4, 9, N'2026-07-23 08:36:42.237', NULL, N'En espera de refacciones/soporte.', 1, N'2026-07-26 17:51:42.343');
IF NOT EXISTS (SELECT 1 FROM dbo.[RegistroPausasOT] WHERE [ID] = 9)
    INSERT INTO dbo.[RegistroPausasOT] ([ID], [OrdenTrabajoID], [MotivoPausaID], [UsuarioPausaID], [FechaInicioPausa], [FechaFinPausa], [Comentario], [activo], [fecharegistro]) VALUES (9, 55, 3, 13, N'2026-07-14 11:13:42.237', NULL, N'En espera de refacciones/soporte.', 1, N'2026-07-26 17:51:42.347');
IF NOT EXISTS (SELECT 1 FROM dbo.[RegistroPausasOT] WHERE [ID] = 10)
    INSERT INTO dbo.[RegistroPausasOT] ([ID], [OrdenTrabajoID], [MotivoPausaID], [UsuarioPausaID], [FechaInicioPausa], [FechaFinPausa], [Comentario], [activo], [fecharegistro]) VALUES (10, 56, 2, 13, N'2026-07-15 05:41:42.237', NULL, N'En espera de refacciones/soporte.', 1, N'2026-07-26 17:51:42.347');
IF NOT EXISTS (SELECT 1 FROM dbo.[RegistroPausasOT] WHERE [ID] = 11)
    INSERT INTO dbo.[RegistroPausasOT] ([ID], [OrdenTrabajoID], [MotivoPausaID], [UsuarioPausaID], [FechaInicioPausa], [FechaFinPausa], [Comentario], [activo], [fecharegistro]) VALUES (11, 57, 2, 11, N'2026-07-24 08:37:42.237', NULL, N'En espera de refacciones/soporte.', 1, N'2026-07-26 17:51:42.350');
IF NOT EXISTS (SELECT 1 FROM dbo.[RegistroPausasOT] WHERE [ID] = 12)
    INSERT INTO dbo.[RegistroPausasOT] ([ID], [OrdenTrabajoID], [MotivoPausaID], [UsuarioPausaID], [FechaInicioPausa], [FechaFinPausa], [Comentario], [activo], [fecharegistro]) VALUES (12, 58, 2, 13, N'2026-07-18 13:43:42.237', NULL, N'En espera de refacciones/soporte.', 1, N'2026-07-26 17:51:42.350');

SET IDENTITY_INSERT dbo.[RegistroPausasOT] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: BitacoraEstadosOT (175 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[BitacoraEstadosOT] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 3)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (3, 3, NULL, 1, 1, N'2026-07-18 21:46:21.607', N'OT Correctiva creada.', 1, N'2026-07-18 21:46:21.607');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 7)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (7, 7, NULL, 1, 1, N'2026-07-18 22:01:34.433', N'OT Correctiva creada.', 1, N'2026-07-18 22:01:34.433');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 8)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (8, 8, NULL, 1, 1, N'2026-07-18 22:03:59.950', N'OT Correctiva creada.', 1, N'2026-07-18 22:03:59.950');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 9)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (9, 9, NULL, 1, 1, N'2026-07-18 22:11:39.330', N'OT Correctiva creada.', 1, N'2026-07-18 22:11:39.330');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 10)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (10, 3, 1, 2, 1, N'2026-07-19 14:33:03.800', N'Arribo de tecnico e inicio de soporte de equipo.', 1, N'2026-07-19 14:33:03.800');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 11)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (11, 7, 1, 2, 1, N'2026-07-19 15:24:47.173', N'Arribo de tecnico e inicio de soporte de equipo.', 1, N'2026-07-19 15:24:47.173');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 12)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (12, 8, 1, 2, 1, N'2026-07-19 15:44:17.173', N'Arribo de tecnico e inicio de soporte de equipo.', 1, N'2026-07-19 15:44:17.173');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 13)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (13, 3, 2, 3, 1, N'2026-07-19 17:06:29.783', N'en espera de personal tecnico', 1, N'2026-07-19 17:06:29.783');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 14)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (14, 3, 3, 2, 1, N'2026-07-19 17:52:25.353', N'OT reanudada por escaneo de QR.', 1, N'2026-07-19 17:52:25.353');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 15)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (15, 3, 2, 5, 1, N'2026-07-19 17:53:02.327', N'RESTART PLC', 1, N'2026-07-19 17:53:02.327');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 16)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (16, 3, 5, 5, 1, N'2026-07-19 18:16:15.507', N'Test final', 1, N'2026-07-19 18:16:15.507');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 17)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (17, 7, 2, 5, 1, N'2026-07-19 18:59:28.530', N'OT #7 CON FOTO', 1, N'2026-07-19 18:59:28.530');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 18)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (18, 8, 2, 3, 1, N'2026-07-19 19:23:11.457', N'tst', 1, N'2026-07-19 19:23:11.457');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 19)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (19, 11, NULL, 2, 1, N'2026-07-19 19:52:57.627', N'OT creada e iniciada en sitio por el técnico.', 1, N'2026-07-19 19:52:57.627');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 20)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (20, 11, 2, 5, 1, N'2026-07-19 19:53:36.170', N'si se cerro la 11? ', 1, N'2026-07-19 19:53:36.170');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 21)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (21, 14, 1, 5, 1, N'2026-07-21 21:40:04.330', N'Mantenimiento preventivo completado exitosamente en prueba E2E.', 1, N'2026-07-21 21:40:04.330');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 22)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (22, 16, 1, 5, 1, N'2026-07-21 21:45:31.530', N'Mantenimiento preventivo completado exitosamente en prueba E2E.', 1, N'2026-07-21 21:45:31.530');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 23)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (23, 18, 1, 5, 1, N'2026-07-21 21:58:48.780', N'Mantenimiento preventivo completado exitosamente en prueba E2E.', 1, N'2026-07-21 21:58:48.780');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 24)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (24, 12, 1, 5, 1, N'2026-07-23 21:00:36.713', N'test', 1, N'2026-07-23 21:00:36.713');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 25)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (25, 20, 1, 5, 1, N'2026-07-23 21:14:16.983', N'Mantenimiento preventivo completado exitosamente en prueba E2E.', 1, N'2026-07-23 21:14:16.983');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 26)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (26, 22, 1, 2, 1, N'2026-07-23 21:16:08.297', N'Arribo de tecnico e inicio de soporte de equipo.', 1, N'2026-07-23 21:16:08.297');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 27)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (27, 22, 2, 3, 1, N'2026-07-23 21:16:08.317', N'Pausa de prueba', 1, N'2026-07-23 21:16:08.317');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 28)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (28, 22, 3, 2, 1, N'2026-07-23 21:16:08.347', N'OT reanudada por escaneo de QR.', 1, N'2026-07-23 21:16:08.347');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 29)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (29, 22, 2, 5, 1, N'2026-07-23 21:16:08.370', N'Limpieza y ajuste completo.', 1, N'2026-07-23 21:16:08.370');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 30)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (30, 23, 1, 2, 1, N'2026-07-23 22:04:52.403', N'Arribo de tecnico e inicio de soporte de equipo.', 1, N'2026-07-23 22:04:52.403');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 31)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (31, 23, 2, 3, 1, N'2026-07-23 22:04:52.430', N'Pausa de prueba', 1, N'2026-07-23 22:04:52.430');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 32)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (32, 23, 3, 2, 1, N'2026-07-23 22:04:52.467', N'OT reanudada por escaneo de QR.', 1, N'2026-07-23 22:04:52.467');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 33)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (33, 23, 2, 5, 1, N'2026-07-23 22:04:52.490', N'Limpieza y ajuste completo.', 1, N'2026-07-23 22:04:52.490');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 34)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (34, 24, NULL, 1, 18, N'2026-07-12 09:12:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.257');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 35)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (35, 25, NULL, 1, 18, N'2026-07-22 08:22:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.260');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 36)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (36, 26, NULL, 1, 14, N'2026-07-17 14:40:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.267');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 37)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (37, 27, NULL, 1, 17, N'2026-07-20 09:19:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.273');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 38)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (38, 28, NULL, 1, 15, N'2026-07-19 11:57:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.277');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 39)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (39, 29, NULL, 1, 15, N'2026-07-16 01:05:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.277');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 40)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (40, 30, NULL, 1, 15, N'2026-07-16 12:04:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.280');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 41)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (41, 31, NULL, 1, 17, N'2026-07-21 18:04:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.280');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 42)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (42, 32, NULL, 1, 18, N'2026-07-16 21:39:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.283');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 43)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (43, 33, NULL, 1, 15, N'2026-07-13 21:54:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.283');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 44)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (44, 34, NULL, 1, 17, N'2026-07-14 12:20:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.290');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 45)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (45, 35, NULL, 1, 17, N'2026-07-16 19:05:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.290');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 46)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (46, 36, NULL, 1, 18, N'2026-07-14 05:17:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.293');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 47)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (47, 36, 1, 2, 13, N'2026-07-14 05:40:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.297');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 48)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (48, 37, NULL, 1, 17, N'2026-07-19 00:44:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.303');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 49)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (49, 37, 1, 2, 10, N'2026-07-19 01:02:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.303');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 50)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (50, 38, NULL, 1, 15, N'2026-07-12 11:09:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.303');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 51)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (51, 38, 1, 2, 9, N'2026-07-12 11:31:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.303');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 52)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (52, 39, NULL, 1, 16, N'2026-07-21 21:30:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.303');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 53)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (53, 39, 1, 2, 12, N'2026-07-21 21:45:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.303');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 54)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (54, 40, NULL, 1, 14, N'2026-07-19 03:05:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.303');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 55)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (55, 40, 1, 2, 11, N'2026-07-19 03:38:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.307');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 56)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (56, 41, NULL, 1, 16, N'2026-07-13 06:38:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.307');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 57)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (57, 41, 1, 2, 10, N'2026-07-13 06:53:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.307');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 58)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (58, 42, NULL, 1, 16, N'2026-07-12 04:25:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.310');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 59)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (59, 42, 1, 2, 12, N'2026-07-12 04:43:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.310');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 60)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (60, 43, NULL, 1, 18, N'2026-07-22 01:11:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.310');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 61)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (61, 43, 1, 2, 12, N'2026-07-22 01:28:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.310');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 62)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (62, 44, NULL, 1, 18, N'2026-07-25 04:53:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.310');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 63)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (63, 44, 1, 2, 12, N'2026-07-25 05:19:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.310');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 64)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (64, 45, NULL, 1, 16, N'2026-07-19 19:37:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.310');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 65)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (65, 45, 1, 2, 11, N'2026-07-19 19:57:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.310');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 66)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (66, 46, NULL, 1, 16, N'2026-07-17 13:07:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.310');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 67)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (67, 46, 1, 2, 12, N'2026-07-17 13:36:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.313');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 68)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (68, 47, NULL, 1, 15, N'2026-07-13 20:33:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.313');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 69)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (69, 47, 1, 2, 11, N'2026-07-13 20:42:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.313');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 70)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (70, 48, NULL, 1, 15, N'2026-07-20 08:06:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.317');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 71)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (71, 48, 1, 2, 11, N'2026-07-20 08:35:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.317');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 72)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (72, 49, NULL, 1, 14, N'2026-07-16 04:56:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.317');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 73)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (73, 49, 1, 2, 11, N'2026-07-16 05:26:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.317');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 74)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (74, 50, NULL, 1, 16, N'2026-07-25 21:57:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.317');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 75)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (75, 50, 1, 2, 11, N'2026-07-25 22:12:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.317');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 76)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (76, 51, NULL, 1, 15, N'2026-07-20 03:09:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.320');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 77)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (77, 51, 1, 2, 13, N'2026-07-20 03:23:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.320');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 78)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (78, 51, 2, 3, 13, N'2026-07-20 03:52:42.237', N'OT Pausada por técnico.', 1, N'2026-07-26 17:51:42.323');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 79)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (79, 52, NULL, 1, 16, N'2026-07-21 17:37:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.330');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 80)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (80, 52, 1, 2, 13, N'2026-07-21 18:08:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.333');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 81)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (81, 52, 2, 3, 13, N'2026-07-21 18:26:42.237', N'OT Pausada por técnico.', 1, N'2026-07-26 17:51:42.333');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 82)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (82, 53, NULL, 1, 18, N'2026-07-20 05:30:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.337');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 83)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (83, 53, 1, 2, 11, N'2026-07-20 05:56:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.337');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 84)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (84, 53, 2, 3, 11, N'2026-07-20 06:39:42.237', N'OT Pausada por técnico.', 1, N'2026-07-26 17:51:42.343');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 85)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (85, 54, NULL, 1, 16, N'2026-07-23 07:59:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.343');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 86)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (86, 54, 1, 2, 9, N'2026-07-23 08:10:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.343');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 87)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (87, 54, 2, 3, 9, N'2026-07-23 08:36:42.237', N'OT Pausada por técnico.', 1, N'2026-07-26 17:51:42.343');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 88)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (88, 55, NULL, 1, 14, N'2026-07-14 10:05:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.343');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 89)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (89, 55, 1, 2, 13, N'2026-07-14 10:35:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.347');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 90)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (90, 55, 2, 3, 13, N'2026-07-14 11:13:42.237', N'OT Pausada por técnico.', 1, N'2026-07-26 17:51:42.347');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 91)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (91, 56, NULL, 1, 14, N'2026-07-15 05:00:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.347');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 92)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (92, 56, 1, 2, 13, N'2026-07-15 05:30:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.347');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 93)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (93, 56, 2, 3, 13, N'2026-07-15 05:41:42.237', N'OT Pausada por técnico.', 1, N'2026-07-26 17:51:42.347');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 94)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (94, 57, NULL, 1, 16, N'2026-07-24 08:02:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.347');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 95)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (95, 57, 1, 2, 11, N'2026-07-24 08:23:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.350');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 96)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (96, 57, 2, 3, 11, N'2026-07-24 08:37:42.237', N'OT Pausada por técnico.', 1, N'2026-07-26 17:51:42.350');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 97)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (97, 58, NULL, 1, 18, N'2026-07-18 12:46:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.350');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 98)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (98, 58, 1, 2, 13, N'2026-07-18 13:04:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.350');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 99)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (99, 58, 2, 3, 13, N'2026-07-18 13:43:42.237', N'OT Pausada por técnico.', 1, N'2026-07-26 17:51:42.350');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 100)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (100, 59, NULL, 1, 16, N'2026-07-15 00:48:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.353');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 101)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (101, 59, 1, 2, 11, N'2026-07-15 01:07:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.353');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 102)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (102, 59, 1, 4, 2, N'2026-07-15 01:06:42.237', N'OT Cancelada por duplicidad o falsa alarma.', 1, N'2026-07-26 17:51:42.357');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 103)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (103, 60, NULL, 1, 15, N'2026-07-12 12:23:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.360');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 104)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (104, 60, 1, 2, 11, N'2026-07-12 12:47:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.360');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 105)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (105, 60, 1, 4, 7, N'2026-07-12 12:47:42.237', N'OT Cancelada por duplicidad o falsa alarma.', 1, N'2026-07-26 17:51:42.360');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 106)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (106, 61, NULL, 1, 17, N'2026-07-23 07:17:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.360');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 107)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (107, 61, 1, 2, 10, N'2026-07-23 07:39:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.360');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 108)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (108, 61, 1, 4, 3, N'2026-07-23 07:36:42.237', N'OT Cancelada por duplicidad o falsa alarma.', 1, N'2026-07-26 17:51:42.360');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 109)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (109, 62, NULL, 1, 17, N'2026-07-12 07:46:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.363');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 110)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (110, 62, 1, 2, 11, N'2026-07-12 08:11:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.363');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 111)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (111, 62, 1, 4, 7, N'2026-07-12 08:11:42.237', N'OT Cancelada por duplicidad o falsa alarma.', 1, N'2026-07-26 17:51:42.363');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 112)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (112, 63, NULL, 1, 15, N'2026-07-24 08:07:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.363');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 113)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (113, 63, 1, 2, 12, N'2026-07-24 08:21:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.367');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 114)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (114, 63, 1, 4, 2, N'2026-07-24 08:24:42.237', N'OT Cancelada por duplicidad o falsa alarma.', 1, N'2026-07-26 17:51:42.367');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 115)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (115, 64, NULL, 1, 15, N'2026-07-17 12:04:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.367');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 116)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (116, 64, 1, 2, 12, N'2026-07-17 12:32:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.367');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 117)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (117, 64, 2, 5, 12, N'2026-07-17 13:42:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.377');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 118)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (118, 65, NULL, 1, 15, N'2026-07-15 03:56:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.377');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 119)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (119, 65, 1, 2, 12, N'2026-07-15 04:21:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.377');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 120)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (120, 65, 2, 5, 12, N'2026-07-15 05:20:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.380');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 121)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (121, 66, NULL, 1, 16, N'2026-07-23 03:16:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.380');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 122)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (122, 66, 1, 2, 12, N'2026-07-23 03:23:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.380');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 123)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (123, 66, 2, 5, 12, N'2026-07-23 06:18:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.380');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 124)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (124, 67, NULL, 1, 16, N'2026-07-26 14:50:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.380');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 125)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (125, 67, 1, 2, 10, N'2026-07-26 15:18:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.380');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 126)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (126, 67, 2, 5, 10, N'2026-07-26 15:55:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.380');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 127)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (127, 68, NULL, 1, 15, N'2026-07-15 09:22:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.383');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 128)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (128, 68, 1, 2, 13, N'2026-07-15 09:36:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.383');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 129)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (129, 68, 2, 5, 13, N'2026-07-15 10:04:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.383');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 130)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (130, 69, NULL, 1, 15, N'2026-07-19 14:50:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.383');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 131)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (131, 69, 1, 2, 12, N'2026-07-19 15:16:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.383');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 132)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (132, 69, 2, 5, 12, N'2026-07-19 15:42:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.383');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 133)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (133, 70, NULL, 1, 18, N'2026-07-13 01:33:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.383');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 134)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (134, 70, 1, 2, 10, N'2026-07-13 01:56:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.383');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 135)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (135, 70, 2, 5, 10, N'2026-07-13 04:47:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.387');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 136)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (136, 71, NULL, 1, 18, N'2026-07-20 07:56:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.387');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 137)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (137, 71, 1, 2, 9, N'2026-07-20 08:17:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.387');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 138)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (138, 71, 2, 5, 9, N'2026-07-20 10:35:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.387');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 139)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (139, 72, NULL, 1, 16, N'2026-07-19 18:32:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.387');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 140)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (140, 72, 1, 2, 11, N'2026-07-19 18:46:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.387');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 141)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (141, 72, 2, 5, 11, N'2026-07-19 21:31:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.387');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 142)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (142, 73, NULL, 1, 17, N'2026-07-15 13:54:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.390');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 143)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (143, 73, 1, 2, 13, N'2026-07-15 14:23:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.390');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 144)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (144, 73, 2, 5, 13, N'2026-07-15 16:24:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.390');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 145)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (145, 74, NULL, 1, 15, N'2026-07-22 07:46:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.390');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 146)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (146, 74, 1, 2, 10, N'2026-07-22 07:59:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.390');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 147)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (147, 74, 2, 5, 10, N'2026-07-22 08:42:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.390');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 148)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (148, 75, NULL, 1, 18, N'2026-07-19 05:31:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.393');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 149)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (149, 75, 1, 2, 11, N'2026-07-19 05:54:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.393');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 150)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (150, 75, 2, 5, 11, N'2026-07-19 06:14:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.393');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 151)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (151, 76, NULL, 1, 18, N'2026-07-24 06:52:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.393');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 152)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (152, 76, 1, 2, 10, N'2026-07-24 07:03:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.393');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 153)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (153, 76, 2, 5, 10, N'2026-07-24 08:00:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.393');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 154)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (154, 77, NULL, 1, 17, N'2026-07-18 13:06:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.393');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 155)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (155, 77, 1, 2, 12, N'2026-07-18 13:26:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.393');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 156)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (156, 77, 2, 5, 12, N'2026-07-18 14:59:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.393');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 157)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (157, 78, NULL, 1, 15, N'2026-07-22 19:11:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.393');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 158)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (158, 78, 1, 2, 11, N'2026-07-22 19:35:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.393');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 159)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (159, 78, 2, 5, 11, N'2026-07-22 20:48:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.397');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 160)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (160, 79, NULL, 1, 15, N'2026-07-20 15:16:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.400');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 161)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (161, 79, 1, 2, 11, N'2026-07-20 15:36:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.400');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 162)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (162, 79, 2, 5, 11, N'2026-07-20 16:39:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.400');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 163)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (163, 80, NULL, 1, 15, N'2026-07-22 19:19:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.400');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 164)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (164, 80, 1, 2, 13, N'2026-07-22 19:28:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.400');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 165)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (165, 80, 2, 5, 13, N'2026-07-22 20:34:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.400');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 166)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (166, 81, NULL, 1, 18, N'2026-07-22 12:26:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.400');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 167)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (167, 81, 1, 2, 9, N'2026-07-22 12:51:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.400');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 168)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (168, 81, 2, 5, 9, N'2026-07-22 14:09:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.400');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 169)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (169, 82, NULL, 1, 18, N'2026-07-23 14:39:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.400');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 170)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (170, 82, 1, 2, 12, N'2026-07-23 14:49:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.400');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 171)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (171, 82, 2, 5, 12, N'2026-07-23 15:19:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.400');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 172)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (172, 83, NULL, 1, 14, N'2026-07-17 14:25:42.237', N'OT Creada.', 1, N'2026-07-26 17:51:42.403');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 173)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (173, 83, 1, 2, 13, N'2026-07-17 14:46:42.237', N'Técnico escaneó QR y comenzó atención.', 1, N'2026-07-26 17:51:42.403');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 174)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (174, 83, 2, 5, 13, N'2026-07-17 15:35:42.237', N'OT Finalizada y Cerrada exitosamente.', 1, N'2026-07-26 17:51:42.403');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 175)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (175, 84, NULL, 2, 1, N'2026-07-26 20:12:10.787', N'OT creada e iniciada en sitio por el técnico.', 1, N'2026-07-26 20:12:10.787');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 176)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (176, 25, 1, 2, 1, N'2026-07-26 21:34:45.217', N'Arribo de tecnico e inicio de soporte de equipo.', 1, N'2026-07-26 21:34:45.217');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 177)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (177, 85, NULL, 2, 1, N'2026-07-29 22:13:19.107', N'OT creada e iniciada en sitio por el técnico.', 1, N'2026-07-29 22:13:19.107');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 178)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (178, 86, NULL, 2, 1, N'2026-07-29 22:20:45.687', N'OT creada e iniciada en sitio por el técnico.', 1, N'2026-07-29 22:20:45.687');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 179)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (179, 86, 2, 5, 1, N'2026-07-29 22:21:00.690', N'test', 1, N'2026-07-29 22:21:00.690');
IF NOT EXISTS (SELECT 1 FROM dbo.[BitacoraEstadosOT] WHERE [ID] = 180)
    INSERT INTO dbo.[BitacoraEstadosOT] ([ID], [OrdenTrabajoID], [EstadoAnteriorID], [EstadoNuevoID], [UsuarioID], [FechaCambio], [Comentario], [activo], [fecharegistro]) VALUES (180, 25, 2, 5, 1, N'2026-07-29 22:21:19.597', N'cerrado', 1, N'2026-07-29 22:21:19.597');

SET IDENTITY_INSERT dbo.[BitacoraEstadosOT] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: EvidenciasOT (16 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[EvidenciasOT] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[EvidenciasOT] WHERE [ID] = 1)
    INSERT INTO dbo.[EvidenciasOT] ([ID], [OrdenTrabajoID], [UsuarioID], [TipoEvidencia], [PathArchivo], [activo], [fecharegistro]) VALUES (1, 3, 1, N'FALLA', N'ot_3_falla_Picture1.png', 1, N'2026-07-19 14:33:15.267');
IF NOT EXISTS (SELECT 1 FROM dbo.[EvidenciasOT] WHERE [ID] = 2)
    INSERT INTO dbo.[EvidenciasOT] ([ID], [OrdenTrabajoID], [UsuarioID], [TipoEvidencia], [PathArchivo], [activo], [fecharegistro]) VALUES (2, 3, 1, N'FALLA', N'ot_3_falla_Picture3.png', 1, N'2026-07-19 17:52:58.810');
IF NOT EXISTS (SELECT 1 FROM dbo.[EvidenciasOT] WHERE [ID] = 3)
    INSERT INTO dbo.[EvidenciasOT] ([ID], [OrdenTrabajoID], [UsuarioID], [TipoEvidencia], [PathArchivo], [activo], [fecharegistro]) VALUES (3, 8, 1, N'FALLA', N'ot_8_falla_camera_capture.jpg', 1, N'2026-07-19 18:08:20.297');
IF NOT EXISTS (SELECT 1 FROM dbo.[EvidenciasOT] WHERE [ID] = 4)
    INSERT INTO dbo.[EvidenciasOT] ([ID], [OrdenTrabajoID], [UsuarioID], [TipoEvidencia], [PathArchivo], [activo], [fecharegistro]) VALUES (4, 8, 1, N'FALLA', N'ot_8_falla_camera_capture.jpg', 1, N'2026-07-19 18:08:27.967');
IF NOT EXISTS (SELECT 1 FROM dbo.[EvidenciasOT] WHERE [ID] = 5)
    INSERT INTO dbo.[EvidenciasOT] ([ID], [OrdenTrabajoID], [UsuarioID], [TipoEvidencia], [PathArchivo], [activo], [fecharegistro]) VALUES (5, 8, 1, N'FALLA', N'ot_8_falla_02223755-cbf9-4dc7-ab11-3d6e46ac2390.png', 1, N'2026-07-19 18:11:37.670');
IF NOT EXISTS (SELECT 1 FROM dbo.[EvidenciasOT] WHERE [ID] = 6)
    INSERT INTO dbo.[EvidenciasOT] ([ID], [OrdenTrabajoID], [UsuarioID], [TipoEvidencia], [PathArchivo], [activo], [fecharegistro]) VALUES (6, 8, 1, N'FALLA', N'ot_8_falla_camera_capture.jpg', 1, N'2026-07-19 18:12:01.377');
IF NOT EXISTS (SELECT 1 FROM dbo.[EvidenciasOT] WHERE [ID] = 7)
    INSERT INTO dbo.[EvidenciasOT] ([ID], [OrdenTrabajoID], [UsuarioID], [TipoEvidencia], [PathArchivo], [activo], [fecharegistro]) VALUES (7, 8, 1, N'FALLA', N'ot_8_falla_Picture3.png', 1, N'2026-07-19 18:12:32.753');
IF NOT EXISTS (SELECT 1 FROM dbo.[EvidenciasOT] WHERE [ID] = 8)
    INSERT INTO dbo.[EvidenciasOT] ([ID], [OrdenTrabajoID], [UsuarioID], [TipoEvidencia], [PathArchivo], [activo], [fecharegistro]) VALUES (8, 7, 1, N'FALLA', N'ot_7_falla_camera_capture.jpg', 1, N'2026-07-19 18:59:25.493');
IF NOT EXISTS (SELECT 1 FROM dbo.[EvidenciasOT] WHERE [ID] = 9)
    INSERT INTO dbo.[EvidenciasOT] ([ID], [OrdenTrabajoID], [UsuarioID], [TipoEvidencia], [PathArchivo], [activo], [fecharegistro]) VALUES (9, 11, 1, N'FALLA', N'ot_11_falla_camera_capture.jpg', 1, N'2026-07-19 19:53:31.923');
IF NOT EXISTS (SELECT 1 FROM dbo.[EvidenciasOT] WHERE [ID] = 10)
    INSERT INTO dbo.[EvidenciasOT] ([ID], [OrdenTrabajoID], [UsuarioID], [TipoEvidencia], [PathArchivo], [activo], [fecharegistro]) VALUES (10, 83, 1, N'FALLA', N'sample_evidence.png', 1, N'2026-07-26 18:15:38.410');
IF NOT EXISTS (SELECT 1 FROM dbo.[EvidenciasOT] WHERE [ID] = 11)
    INSERT INTO dbo.[EvidenciasOT] ([ID], [OrdenTrabajoID], [UsuarioID], [TipoEvidencia], [PathArchivo], [activo], [fecharegistro]) VALUES (11, 80, 1, N'FALLA', N'sample_evidence.png', 1, N'2026-07-26 18:15:38.413');
IF NOT EXISTS (SELECT 1 FROM dbo.[EvidenciasOT] WHERE [ID] = 12)
    INSERT INTO dbo.[EvidenciasOT] ([ID], [OrdenTrabajoID], [UsuarioID], [TipoEvidencia], [PathArchivo], [activo], [fecharegistro]) VALUES (12, 75, 1, N'FALLA', N'sample_evidence.png', 1, N'2026-07-26 18:15:38.413');
IF NOT EXISTS (SELECT 1 FROM dbo.[EvidenciasOT] WHERE [ID] = 13)
    INSERT INTO dbo.[EvidenciasOT] ([ID], [OrdenTrabajoID], [UsuarioID], [TipoEvidencia], [PathArchivo], [activo], [fecharegistro]) VALUES (13, 70, 1, N'FALLA', N'sample_evidence.png', 1, N'2026-07-26 18:15:38.417');
IF NOT EXISTS (SELECT 1 FROM dbo.[EvidenciasOT] WHERE [ID] = 14)
    INSERT INTO dbo.[EvidenciasOT] ([ID], [OrdenTrabajoID], [UsuarioID], [TipoEvidencia], [PathArchivo], [activo], [fecharegistro]) VALUES (14, 65, 1, N'FALLA', N'sample_evidence.png', 1, N'2026-07-26 18:15:38.417');
IF NOT EXISTS (SELECT 1 FROM dbo.[EvidenciasOT] WHERE [ID] = 15)
    INSERT INTO dbo.[EvidenciasOT] ([ID], [OrdenTrabajoID], [UsuarioID], [TipoEvidencia], [PathArchivo], [activo], [fecharegistro]) VALUES (15, 60, 1, N'FALLA', N'sample_evidence.png', 1, N'2026-07-26 18:15:38.417');
IF NOT EXISTS (SELECT 1 FROM dbo.[EvidenciasOT] WHERE [ID] = 16)
    INSERT INTO dbo.[EvidenciasOT] ([ID], [OrdenTrabajoID], [UsuarioID], [TipoEvidencia], [PathArchivo], [activo], [fecharegistro]) VALUES (16, 86, 1, N'FALLA', N'ot_86_falla_camera_capture.jpg', 1, N'2026-07-29 22:20:57.363');

SET IDENTITY_INSERT dbo.[EvidenciasOT] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: ProgramacionPreventivos (13 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[ProgramacionPreventivos] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[ProgramacionPreventivos] WHERE [ID] = 1)
    INSERT INTO dbo.[ProgramacionPreventivos] ([ID], [EquipoID], [RutinaPreventivaID], [FechaUltimaEjecucion], [FechaProximaEjecucion], [activo], [fecharegistro], [UsuarioRegistroID], [EstacionID], [LineaID], [TecnicoID], [OrdenTrabajoID], [Estado], [Titulo], [Comentario], [FrecuenciaDias], [HoraInicio]) VALUES (1, 1, 1, NULL, N'2026-08-01 00:00:00.000', 1, N'2026-07-21 21:38:20.420', 1, 7, 1, 1, NULL, N'PROGRAMADA', N'Prueba PM Recurrente E2E', N'Instrucciones de prueba automatizada.', 7, N'09:00');
IF NOT EXISTS (SELECT 1 FROM dbo.[ProgramacionPreventivos] WHERE [ID] = 5)
    INSERT INTO dbo.[ProgramacionPreventivos] ([ID], [EquipoID], [RutinaPreventivaID], [FechaUltimaEjecucion], [FechaProximaEjecucion], [activo], [fecharegistro], [UsuarioRegistroID], [EstacionID], [LineaID], [TecnicoID], [OrdenTrabajoID], [Estado], [Titulo], [Comentario], [FrecuenciaDias], [HoraInicio]) VALUES (5, NULL, NULL, NULL, N'2026-07-21 21:39:22.987', 0, N'2026-07-21 21:39:22.987', NULL, NULL, 1, NULL, NULL, N'PROGRAMADA', NULL, NULL, 0, N'08:00');
IF NOT EXISTS (SELECT 1 FROM dbo.[ProgramacionPreventivos] WHERE [ID] = 6)
    INSERT INTO dbo.[ProgramacionPreventivos] ([ID], [EquipoID], [RutinaPreventivaID], [FechaUltimaEjecucion], [FechaProximaEjecucion], [activo], [fecharegistro], [UsuarioRegistroID], [EstacionID], [LineaID], [TecnicoID], [OrdenTrabajoID], [Estado], [Titulo], [Comentario], [FrecuenciaDias], [HoraInicio]) VALUES (6, NULL, NULL, NULL, N'2026-07-21 21:39:38.537', 0, N'2026-07-21 21:39:38.537', NULL, NULL, 1, NULL, NULL, N'PROGRAMADA', NULL, NULL, 0, N'08:00');
IF NOT EXISTS (SELECT 1 FROM dbo.[ProgramacionPreventivos] WHERE [ID] = 7)
    INSERT INTO dbo.[ProgramacionPreventivos] ([ID], [EquipoID], [RutinaPreventivaID], [FechaUltimaEjecucion], [FechaProximaEjecucion], [activo], [fecharegistro], [UsuarioRegistroID], [EstacionID], [LineaID], [TecnicoID], [OrdenTrabajoID], [Estado], [Titulo], [Comentario], [FrecuenciaDias], [HoraInicio]) VALUES (7, 1, 1, N'2026-07-21 21:40:04.340', N'2026-08-05 00:00:00.000', 1, N'2026-07-21 21:40:04.243', 1, 7, 1, 1, 14, N'COMPLETADA', N'Prueba PM Recurrente E2E', N'Instrucciones de prueba automatizada.', 7, N'09:00');
IF NOT EXISTS (SELECT 1 FROM dbo.[ProgramacionPreventivos] WHERE [ID] = 8)
    INSERT INTO dbo.[ProgramacionPreventivos] ([ID], [EquipoID], [RutinaPreventivaID], [FechaUltimaEjecucion], [FechaProximaEjecucion], [activo], [fecharegistro], [UsuarioRegistroID], [EstacionID], [LineaID], [TecnicoID], [OrdenTrabajoID], [Estado], [Titulo], [Comentario], [FrecuenciaDias], [HoraInicio]) VALUES (8, 1, 1, NULL, N'2026-07-28 00:00:00.000', 1, N'2026-07-21 21:40:04.347', 1, 7, 1, 1, 15, N'PROGRAMADA', N'Prueba PM Recurrente E2E', N'Instrucciones de prueba automatizada.', 7, N'09:00');
IF NOT EXISTS (SELECT 1 FROM dbo.[ProgramacionPreventivos] WHERE [ID] = 9)
    INSERT INTO dbo.[ProgramacionPreventivos] ([ID], [EquipoID], [RutinaPreventivaID], [FechaUltimaEjecucion], [FechaProximaEjecucion], [activo], [fecharegistro], [UsuarioRegistroID], [EstacionID], [LineaID], [TecnicoID], [OrdenTrabajoID], [Estado], [Titulo], [Comentario], [FrecuenciaDias], [HoraInicio]) VALUES (9, 1, 1, N'2026-07-21 21:45:31.537', N'2026-08-05 00:00:00.000', 1, N'2026-07-21 21:45:31.480', 1, 7, 1, 1, 16, N'COMPLETADA', N'Prueba PM Recurrente E2E', N'Instrucciones de prueba automatizada.', 7, N'09:00');
IF NOT EXISTS (SELECT 1 FROM dbo.[ProgramacionPreventivos] WHERE [ID] = 10)
    INSERT INTO dbo.[ProgramacionPreventivos] ([ID], [EquipoID], [RutinaPreventivaID], [FechaUltimaEjecucion], [FechaProximaEjecucion], [activo], [fecharegistro], [UsuarioRegistroID], [EstacionID], [LineaID], [TecnicoID], [OrdenTrabajoID], [Estado], [Titulo], [Comentario], [FrecuenciaDias], [HoraInicio]) VALUES (10, 1, 1, NULL, N'2026-07-28 00:00:00.000', 1, N'2026-07-21 21:45:31.543', 1, 7, 1, 1, 17, N'PROGRAMADA', N'Prueba PM Recurrente E2E', N'Instrucciones de prueba automatizada.', 7, N'09:00');
IF NOT EXISTS (SELECT 1 FROM dbo.[ProgramacionPreventivos] WHERE [ID] = 11)
    INSERT INTO dbo.[ProgramacionPreventivos] ([ID], [EquipoID], [RutinaPreventivaID], [FechaUltimaEjecucion], [FechaProximaEjecucion], [activo], [fecharegistro], [UsuarioRegistroID], [EstacionID], [LineaID], [TecnicoID], [OrdenTrabajoID], [Estado], [Titulo], [Comentario], [FrecuenciaDias], [HoraInicio]) VALUES (11, 1, 1, N'2026-07-21 21:58:48.783', N'2026-08-05 00:00:00.000', 1, N'2026-07-21 21:58:48.723', 1, 7, 1, 1, 18, N'COMPLETADA', N'Prueba PM Recurrente E2E', N'Instrucciones de prueba automatizada.', 7, N'09:00');
IF NOT EXISTS (SELECT 1 FROM dbo.[ProgramacionPreventivos] WHERE [ID] = 12)
    INSERT INTO dbo.[ProgramacionPreventivos] ([ID], [EquipoID], [RutinaPreventivaID], [FechaUltimaEjecucion], [FechaProximaEjecucion], [activo], [fecharegistro], [UsuarioRegistroID], [EstacionID], [LineaID], [TecnicoID], [OrdenTrabajoID], [Estado], [Titulo], [Comentario], [FrecuenciaDias], [HoraInicio]) VALUES (12, 1, 1, NULL, N'2026-07-28 00:00:00.000', 1, N'2026-07-21 21:58:48.790', 1, 7, 1, 1, 19, N'PROGRAMADA', N'Prueba PM Recurrente E2E', N'Instrucciones de prueba automatizada.', 7, N'09:00');
IF NOT EXISTS (SELECT 1 FROM dbo.[ProgramacionPreventivos] WHERE [ID] = 13)
    INSERT INTO dbo.[ProgramacionPreventivos] ([ID], [EquipoID], [RutinaPreventivaID], [FechaUltimaEjecucion], [FechaProximaEjecucion], [activo], [fecharegistro], [UsuarioRegistroID], [EstacionID], [LineaID], [TecnicoID], [OrdenTrabajoID], [Estado], [Titulo], [Comentario], [FrecuenciaDias], [HoraInicio]) VALUES (13, 1, 1, N'2026-07-23 21:14:16.993', N'2026-08-05 00:00:00.000', 1, N'2026-07-23 21:14:16.757', 1, 7, 1, 1, 20, N'COMPLETADA', N'Prueba PM Recurrente E2E', N'Instrucciones de prueba automatizada.', 7, N'09:00');
IF NOT EXISTS (SELECT 1 FROM dbo.[ProgramacionPreventivos] WHERE [ID] = 14)
    INSERT INTO dbo.[ProgramacionPreventivos] ([ID], [EquipoID], [RutinaPreventivaID], [FechaUltimaEjecucion], [FechaProximaEjecucion], [activo], [fecharegistro], [UsuarioRegistroID], [EstacionID], [LineaID], [TecnicoID], [OrdenTrabajoID], [Estado], [Titulo], [Comentario], [FrecuenciaDias], [HoraInicio]) VALUES (14, 1, 1, NULL, N'2026-07-30 00:00:00.000', 1, N'2026-07-23 21:14:17.003', 1, 7, 1, 1, 21, N'PROGRAMADA', N'Prueba PM Recurrente E2E', N'Instrucciones de prueba automatizada.', 7, N'09:00');
IF NOT EXISTS (SELECT 1 FROM dbo.[ProgramacionPreventivos] WHERE [ID] = 15)
    INSERT INTO dbo.[ProgramacionPreventivos] ([ID], [EquipoID], [RutinaPreventivaID], [FechaUltimaEjecucion], [FechaProximaEjecucion], [activo], [fecharegistro], [UsuarioRegistroID], [EstacionID], [LineaID], [TecnicoID], [OrdenTrabajoID], [Estado], [Titulo], [Comentario], [FrecuenciaDias], [HoraInicio]) VALUES (15, 1, NULL, N'2026-07-23 21:16:08.387', N'2026-07-25 00:00:00.000', 1, N'2026-07-23 21:16:08.247', 1, 7, 1, 1, 22, N'COMPLETADA', N'PM Test Sync Full', N'Verificar prueba de sincronizacion', 0, N'10:00');
IF NOT EXISTS (SELECT 1 FROM dbo.[ProgramacionPreventivos] WHERE [ID] = 16)
    INSERT INTO dbo.[ProgramacionPreventivos] ([ID], [EquipoID], [RutinaPreventivaID], [FechaUltimaEjecucion], [FechaProximaEjecucion], [activo], [fecharegistro], [UsuarioRegistroID], [EstacionID], [LineaID], [TecnicoID], [OrdenTrabajoID], [Estado], [Titulo], [Comentario], [FrecuenciaDias], [HoraInicio]) VALUES (16, 1, NULL, N'2026-07-23 22:04:52.540', N'2026-07-25 00:00:00.000', 1, N'2026-07-23 22:04:52.317', 1, 7, 1, 1, 23, N'COMPLETADA', N'PM Test Sync Full', N'Verificar prueba de sincronizacion', 0, N'10:00');

SET IDENTITY_INSERT dbo.[ProgramacionPreventivos] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: ChecklistTemplates (1 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[ChecklistTemplates] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[ChecklistTemplates] WHERE [ID] = 1)
    INSERT INTO dbo.[ChecklistTemplates] ([ID], [Nombre], [Descripcion], [TipoFrecuencia], [activo], [fecharegistro], [UsuarioRegistroID]) VALUES (1, N'Compresores Diarios', N'Chequeo de presión y nivel de aceite', N'Turno', 1, N'2026-08-12 21:17:36.737', 1);

SET IDENTITY_INSERT dbo.[ChecklistTemplates] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: ChecklistTemplateItems (3 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[ChecklistTemplateItems] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[ChecklistTemplateItems] WHERE [ID] = 1)
    INSERT INTO dbo.[ChecklistTemplateItems] ([ID], [TemplateID], [Nombre], [TipoCampo], [ValorMinimo], [ValorMaximo], [UnidadMedida], [OpcionesSeleccion], [Requerido], [Orden], [activo]) VALUES (1, 1, N'Presion de Linea', N'number', N'80.00', N'120.00', N'psi', NULL, 1, 0, 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[ChecklistTemplateItems] WHERE [ID] = 2)
    INSERT INTO dbo.[ChecklistTemplateItems] ([ID], [TemplateID], [Nombre], [TipoCampo], [ValorMinimo], [ValorMaximo], [UnidadMedida], [OpcionesSeleccion], [Requerido], [Orden], [activo]) VALUES (2, 1, N'Fugas de Aire', N'boolean', NULL, NULL, NULL, NULL, 1, 1, 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[ChecklistTemplateItems] WHERE [ID] = 3)
    INSERT INTO dbo.[ChecklistTemplateItems] ([ID], [TemplateID], [Nombre], [TipoCampo], [ValorMinimo], [ValorMaximo], [UnidadMedida], [OpcionesSeleccion], [Requerido], [Orden], [activo]) VALUES (3, 1, N'Nivel de Aceite', N'select', NULL, NULL, NULL, N'Bajo, Medio, Alto', 1, 2, 1);

SET IDENTITY_INSERT dbo.[ChecklistTemplateItems] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: ChecklistEjecuciones (1 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[ChecklistEjecuciones] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[ChecklistEjecuciones] WHERE [ID] = 1)
    INSERT INTO dbo.[ChecklistEjecuciones] ([ID], [TemplateID], [UsuarioID], [TurnoID], [EstacionID], [EquipoID], [FechaEjecucion], [ComentarioGeneral], [PathEvidencia], [activo]) VALUES (1, 1, 1, 2, 1, 1, N'2026-08-12 21:17:36.763', N'Prueba de llenado con presión baja (alerta)', N'checklists/test_evidencia.jpg', 1);

SET IDENTITY_INSERT dbo.[ChecklistEjecuciones] OFF;
GO

-- ---------------------------------------------------------------------------
-- Datos de Prueba para la Tabla: ChecklistEjecucionValores (3 registros)
-- ---------------------------------------------------------------------------
SET IDENTITY_INSERT dbo.[ChecklistEjecucionValores] ON;

IF NOT EXISTS (SELECT 1 FROM dbo.[ChecklistEjecucionValores] WHERE [ID] = 1)
    INSERT INTO dbo.[ChecklistEjecucionValores] ([ID], [EjecucionID], [ItemID], [ValorTexto], [ValorNumero], [ValorBoolean], [EstaFueraRango]) VALUES (1, 1, 1, NULL, N'75.00', NULL, 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[ChecklistEjecucionValores] WHERE [ID] = 2)
    INSERT INTO dbo.[ChecklistEjecucionValores] ([ID], [EjecucionID], [ItemID], [ValorTexto], [ValorNumero], [ValorBoolean], [EstaFueraRango]) VALUES (2, 1, 2, NULL, NULL, 0, 1);
IF NOT EXISTS (SELECT 1 FROM dbo.[ChecklistEjecucionValores] WHERE [ID] = 3)
    INSERT INTO dbo.[ChecklistEjecucionValores] ([ID], [EjecucionID], [ItemID], [ValorTexto], [ValorNumero], [ValorBoolean], [EstaFueraRango]) VALUES (3, 1, 3, N'Alto', NULL, NULL, 0);

SET IDENTITY_INSERT dbo.[ChecklistEjecucionValores] OFF;
GO

-- 1. ChecklistTemplates
IF OBJECT_ID(N'dbo.ChecklistTemplates', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ChecklistTemplates (
        ID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        Nombre VARCHAR(150) NOT NULL,
        Descripcion VARCHAR(500) NULL,
        TipoFrecuencia VARCHAR(50) NOT NULL, -- e.g., 'Turno', 'Diario', 'Semanal', 'Mensual'
        activo BIT NOT NULL DEFAULT 1,
        fecharegistro DATETIME NOT NULL DEFAULT GETDATE(),
        UsuarioRegistroID INT NOT NULL
    );
END
GO

-- 2. ChecklistTemplateItems
IF OBJECT_ID(N'dbo.ChecklistTemplateItems', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ChecklistTemplateItems (
        ID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        TemplateID INT NOT NULL FOREIGN KEY REFERENCES dbo.ChecklistTemplates(ID),
        Nombre VARCHAR(250) NOT NULL,
        TipoCampo VARCHAR(50) NOT NULL, -- 'text', 'number', 'boolean' (OK/NOK), 'select'
        ValorMinimo DECIMAL(10,2) NULL,
        ValorMaximo DECIMAL(10,2) NULL,
        UnidadMedida VARCHAR(20) NULL, -- e.g., 'psi', 'bar', 'C'
        OpcionesSeleccion VARCHAR(500) NULL, -- comma-separated options for 'select' type
        Requerido BIT NOT NULL DEFAULT 1,
        Orden INT NOT NULL DEFAULT 0,
        activo BIT NOT NULL DEFAULT 1
    );
END
GO

-- 3. ChecklistEjecuciones
IF OBJECT_ID(N'dbo.ChecklistEjecuciones', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ChecklistEjecuciones (
        ID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        TemplateID INT NOT NULL FOREIGN KEY REFERENCES dbo.ChecklistTemplates(ID),
        UsuarioID INT NOT NULL FOREIGN KEY REFERENCES dbo.CatUsuarios(ID),
        TurnoID INT NOT NULL FOREIGN KEY REFERENCES dbo.CatTurnos(ID),
        EstacionID INT NULL FOREIGN KEY REFERENCES dbo.CatEstaciones(ID),
        EquipoID INT NULL FOREIGN KEY REFERENCES dbo.CatEquipos(ID),
        FechaEjecucion DATETIME NOT NULL DEFAULT GETDATE(),
        ComentarioGeneral VARCHAR(1000) NULL,
        PathEvidencia VARCHAR(500) NULL,
        activo BIT NOT NULL DEFAULT 1
    );
END
GO

-- 4. ChecklistEjecucionValores
IF OBJECT_ID(N'dbo.ChecklistEjecucionValores', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ChecklistEjecucionValores (
        ID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        EjecucionID INT NOT NULL FOREIGN KEY REFERENCES dbo.ChecklistEjecuciones(ID),
        ItemID INT NOT NULL FOREIGN KEY REFERENCES dbo.ChecklistTemplateItems(ID),
        ValorTexto VARCHAR(500) NULL,
        ValorNumero DECIMAL(10,2) NULL,
        ValorBoolean BIT NULL,
        EstaFueraRango BIT NOT NULL DEFAULT 0
    );
END
GO

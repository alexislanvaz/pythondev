-- ===========================================================================
-- MTS CMMS - SCRIPT DE ESTRUCTURA Y BASE DE DATOS COMPLETA
-- Incluye: Creación de BD, Tablas, Claves Primarias/Foráneas y Procedimientos Almacenados
-- ===========================================================================

IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = N'MTS_CMMS')
BEGIN
    EXEC('CREATE DATABASE [MTS_CMMS]');
END
GO

USE [MTS_CMMS];
GO

-- ---------------------------------------------------------------------------
-- Tabla: CatAreas
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.CatAreas', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[CatAreas] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [Nombre] VARCHAR(100) NOT NULL,
        [Descripcion] VARCHAR(250) NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioRegistroID] INT NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: CatRoles
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.CatRoles', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[CatRoles] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [Nombre] VARCHAR(50) NOT NULL,
        [Descripcion] VARCHAR(250) NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioRegistroID] INT NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: CatTurnos
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.CatTurnos', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[CatTurnos] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [Nombre] VARCHAR(50) NOT NULL,
        [HoraInicio] TIME NOT NULL,
        [HoraFin] TIME NOT NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioRegistroID] INT NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: CatEstadosOT
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.CatEstadosOT', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[CatEstadosOT] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [Nombre] VARCHAR(50) NOT NULL,
        [Descripcion] VARCHAR(250) NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioRegistroID] INT NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: CatMotivosPausa
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.CatMotivosPausa', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[CatMotivosPausa] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [Nombre] VARCHAR(100) NOT NULL,
        [Descripcion] VARCHAR(250) NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioRegistroID] INT NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: CatCausas4M
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.CatCausas4M', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[CatCausas4M] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [Nombre] VARCHAR(50) NOT NULL,
        [Descripcion] VARCHAR(250) NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioRegistroID] INT NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: CatClasificacionesFallaLider
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.CatClasificacionesFallaLider', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[CatClasificacionesFallaLider] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [Nombre] VARCHAR(100) NOT NULL,
        [Descripcion] VARCHAR(250) NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioRegistroID] INT NULL,
        [Causa4MsID] INT NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: CatSintomasFallaLider
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.CatSintomasFallaLider', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[CatSintomasFallaLider] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [Nombre] VARCHAR(150) NOT NULL,
        [Descripcion] VARCHAR(250) NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioRegistroID] INT NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: CatTiposEquipo
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.CatTiposEquipo', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[CatTiposEquipo] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [Nombre] VARCHAR(100) NOT NULL,
        [Descripcion] VARCHAR(250) NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioRegistroID] INT NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: CatFallasComunes
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.CatFallasComunes', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[CatFallasComunes] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [TipoEquipoID] INT NOT NULL,
        [CodigoFalla] VARCHAR(20) NOT NULL,
        [Nombre] VARCHAR(150) NOT NULL,
        [Descripcion] VARCHAR(500) NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioRegistroID] INT NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: CatSolucionesComunes
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.CatSolucionesComunes', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[CatSolucionesComunes] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [FallaComunID] INT NOT NULL,
        [Nombre] VARCHAR(150) NOT NULL,
        [Descripcion] VARCHAR(500) NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioRegistroID] INT NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: CatModosFallaReal
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.CatModosFallaReal', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[CatModosFallaReal] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [TipoEquipoID] INT NOT NULL,
        [CodigoFalla] VARCHAR(20) NOT NULL,
        [Nombre] VARCHAR(150) NOT NULL,
        [Descripcion] VARCHAR(500) NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioRegistroID] INT NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: CatRutinasPreventivas
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.CatRutinasPreventivas', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[CatRutinasPreventivas] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [TipoEquipoID] INT NOT NULL,
        [Nombre] VARCHAR(150) NOT NULL,
        [Descripcion] VARCHAR(1000) NULL,
        [FrecuenciaDias] INT NOT NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: CatUsuarios
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.CatUsuarios', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[CatUsuarios] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [NoEmpleado] VARCHAR(20) NOT NULL,
        [Nombre] VARCHAR(150) NOT NULL,
        [Correo] VARCHAR(100) NULL,
        [RolID] INT NOT NULL,
        [AreaID] INT NOT NULL,
        [TurnoID] INT NOT NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [PasswordHash] VARCHAR(255) NULL,
        [UsuarioRegistroID] INT NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: CatLineas
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.CatLineas', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[CatLineas] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [AreaID] INT NOT NULL,
        [Nombre] VARCHAR(100) NOT NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioRegistroID] INT NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: CatEstaciones
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.CatEstaciones', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[CatEstaciones] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [LineaID] INT NOT NULL,
        [Nombre] VARCHAR(100) NOT NULL,
        [CodigoQR] VARCHAR(150) NOT NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioRegistroID] INT NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: CatEquipos
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.CatEquipos', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[CatEquipos] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [EstacionID] INT NOT NULL,
        [TipoEquipoID] INT NOT NULL,
        [Nombre] VARCHAR(100) NOT NULL,
        [Modelo] VARCHAR(100) NULL,
        [NumeroSerie] VARCHAR(100) NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioRegistroID] INT NULL,
        [CodigoQR] VARCHAR(150) NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: RecursosSoporte
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.RecursosSoporte', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[RecursosSoporte] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [TipoEquipoID] INT NOT NULL,
        [FallaComunID] INT NULL,
        [Nombre] VARCHAR(150) NOT NULL,
        [TipoRecurso] VARCHAR(50) NOT NULL,
        [PathArchivo] VARCHAR(500) NOT NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioRegistroID] INT NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: CatMateriales
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.CatMateriales', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[CatMateriales] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [NumeroParte] VARCHAR(100) NOT NULL,
        [Nombre] VARCHAR(150) NOT NULL,
        [Stock] DECIMAL(18,2) NOT NULL,
        [UnidadMedida] VARCHAR(20) NOT NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: ConfiguracionEscalaciones
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.ConfiguracionEscalaciones', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[ConfiguracionEscalaciones] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [AreaID] INT NOT NULL,
        [ImpactoAfectacion] VARCHAR(150) NOT NULL,
        [TiempoLimiteMinutos] INT NOT NULL,
        [RolNotificarID] INT NOT NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: OrdenesTrabajo
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.OrdenesTrabajo', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[OrdenesTrabajo] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [EstacionID] INT NOT NULL,
        [EquipoID] INT NULL,
        [FallaRealID] INT NULL,
        [EstadoID] INT NOT NULL,
        [LiderReportaID] INT NOT NULL,
        [TurnoID] INT NOT NULL,
        [SintomaFallaLiderID] INT NULL,
        [ClasificacionFallaLiderID] INT NULL,
        [Causa4MID] INT NULL,
        [AreaAfectadaImpacto] VARCHAR(150) NULL,
        [EmpleadosAfectados] INT NOT NULL,
        [ComentarioLider] VARCHAR(1000) NULL,
        [FechaReporte] DATETIME NOT NULL,
        [TipoMantenimiento] VARCHAR(20) NOT NULL,
        [RutinaPreventivaID] INT NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioRegistroID] INT NULL,
        [FechaInicioSoporte] DATETIME NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: DetalleTecnicosOT
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.DetalleTecnicosOT', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[DetalleTecnicosOT] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [OrdenTrabajoID] INT NOT NULL,
        [TecnicoID] INT NOT NULL,
        [FechaAsignacion] DATETIME NOT NULL,
        [FechaArriboQR] DATETIME NULL,
        [FechaFinActividad] DATETIME NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: RegistroPausasOT
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.RegistroPausasOT', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[RegistroPausasOT] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [OrdenTrabajoID] INT NOT NULL,
        [MotivoPausaID] INT NOT NULL,
        [UsuarioPausaID] INT NOT NULL,
        [FechaInicioPausa] DATETIME NOT NULL,
        [FechaFinPausa] DATETIME NULL,
        [Comentario] VARCHAR(500) NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: BitacoraEstadosOT
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.BitacoraEstadosOT', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[BitacoraEstadosOT] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [OrdenTrabajoID] INT NOT NULL,
        [EstadoAnteriorID] INT NULL,
        [EstadoNuevoID] INT NOT NULL,
        [UsuarioID] INT NOT NULL,
        [FechaCambio] DATETIME NOT NULL,
        [Comentario] VARCHAR(500) NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: BitacoraTransferenciasOT
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.BitacoraTransferenciasOT', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[BitacoraTransferenciasOT] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [OrdenTrabajoID] INT NOT NULL,
        [TecnicoSalienteID] INT NOT NULL,
        [TecnicoEntranteID] INT NOT NULL,
        [ComentarioHandover] VARCHAR(1000) NOT NULL,
        [FechaTransferencia] DATETIME NOT NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: MaterialesOT
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.MaterialesOT', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[MaterialesOT] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [OrdenTrabajoID] INT NOT NULL,
        [MaterialID] INT NOT NULL,
        [Cantidad] DECIMAL(18,2) NOT NULL,
        [UsuarioID] INT NOT NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: EvidenciasOT
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.EvidenciasOT', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[EvidenciasOT] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [OrdenTrabajoID] INT NOT NULL,
        [UsuarioID] INT NOT NULL,
        [TipoEvidencia] VARCHAR(20) NOT NULL,
        [PathArchivo] VARCHAR(500) NOT NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: ColaNotificaciones
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.ColaNotificaciones', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[ColaNotificaciones] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [OrdenTrabajoID] INT NOT NULL,
        [NivelEscalacion] INT NOT NULL,
        [Mensaje] VARCHAR(500) NOT NULL,
        [DestinatarioUsuarioID] INT NOT NULL,
        [FechaEnvio] DATETIME NULL,
        [Enviado] BIT NOT NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: ProgramacionPreventivos
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.ProgramacionPreventivos', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[ProgramacionPreventivos] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [EquipoID] INT NULL,
        [RutinaPreventivaID] INT NULL,
        [FechaUltimaEjecucion] DATETIME NULL,
        [FechaProximaEjecucion] DATETIME NOT NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioRegistroID] INT NULL,
        [EstacionID] INT NULL,
        [LineaID] INT NULL,
        [TecnicoID] INT NULL,
        [OrdenTrabajoID] INT NULL,
        [Estado] VARCHAR(50) NULL,
        [Titulo] VARCHAR(200) NULL,
        [Comentario] VARCHAR(MAX) NULL,
        [FrecuenciaDias] INT NULL,
        [HoraInicio] VARCHAR(10) NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: ChecklistTemplates
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.ChecklistTemplates', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[ChecklistTemplates] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [Nombre] VARCHAR(150) NOT NULL,
        [Descripcion] VARCHAR(500) NULL,
        [TipoFrecuencia] VARCHAR(50) NOT NULL,
        [activo] BIT NOT NULL DEFAULT 1,
        [fecharegistro] DATETIME NOT NULL DEFAULT GETDATE(),
        [UsuarioRegistroID] INT NOT NULL
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: ChecklistTemplateItems
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.ChecklistTemplateItems', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[ChecklistTemplateItems] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [TemplateID] INT NOT NULL,
        [Nombre] VARCHAR(250) NOT NULL,
        [TipoCampo] VARCHAR(50) NOT NULL,
        [ValorMinimo] DECIMAL(10,2) NULL,
        [ValorMaximo] DECIMAL(10,2) NULL,
        [UnidadMedida] VARCHAR(20) NULL,
        [OpcionesSeleccion] VARCHAR(500) NULL,
        [Requerido] BIT NOT NULL,
        [Orden] INT NOT NULL,
        [activo] BIT NOT NULL DEFAULT 1
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: ChecklistEjecuciones
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.ChecklistEjecuciones', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[ChecklistEjecuciones] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [TemplateID] INT NOT NULL,
        [UsuarioID] INT NOT NULL,
        [TurnoID] INT NOT NULL,
        [EstacionID] INT NULL,
        [EquipoID] INT NULL,
        [FechaEjecucion] DATETIME NOT NULL,
        [ComentarioGeneral] VARCHAR(1000) NULL,
        [PathEvidencia] VARCHAR(500) NULL,
        [activo] BIT NOT NULL DEFAULT 1
    );
END
GO

-- ---------------------------------------------------------------------------
-- Tabla: ChecklistEjecucionValores
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.ChecklistEjecucionValores', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.[ChecklistEjecucionValores] (
        [ID] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
        [EjecucionID] INT NOT NULL,
        [ItemID] INT NOT NULL,
        [ValorTexto] VARCHAR(500) NULL,
        [ValorNumero] DECIMAL(10,2) NULL,
        [ValorBoolean] BIT NULL,
        [EstaFueraRango] BIT NOT NULL
    );
END
GO

-- ===========================================================================
-- PROCEDIMIENTOS ALMACENADOS
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- Procedimiento: sp_OT_Crear_Correctiva
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.sp_OT_Crear_Correctiva', N'P') IS NOT NULL
    DROP PROCEDURE dbo.[sp_OT_Crear_Correctiva];
GO

CREATE PROCEDURE sp_OT_Crear_Correctiva    
    @EstacionID INT,    
    @LiderID INT,    
    @SintomaFallaLiderID INT,    
    @ClasificacionFallaLiderID INT,    
    @Causa4MID INT,    
    @AreaAfectadaImpacto VARCHAR(150),    
    @EmpleadosAfectados INT,    
    @ComentarioLider VARCHAR(1000),    
    @UsuarioRegistroID INT = NULL,
    @TurnoID INT = NULL,
    @FechaReporte DATETIME = NULL
AS    
BEGIN    
    SET NOCOUNT ON;    
    BEGIN TRY    
        BEGIN TRANSACTION;    
    
        DECLARE @EstadoCreadaID INT;    
        DECLARE @FinalTurnoID INT = @TurnoID;    
        DECLARE @FinalFechaReporte DATETIME = ISNULL(@FechaReporte, GETDATE());
        DECLARE @HoraActual TIME = CONVERT(TIME, @FinalFechaReporte);    
    
        SELECT TOP 1 @EstadoCreadaID = ID FROM CatEstadosOT WHERE Nombre = 'CREATED' AND activo = 1;    
    
        IF @FinalTurnoID IS NULL
        BEGIN
            SELECT TOP 1 @FinalTurnoID = ID     
            FROM CatTurnos     
            WHERE activo = 1     
              AND (    
                (HoraInicio <= HoraFin AND @HoraActual BETWEEN HoraInicio AND HoraFin) OR    
                (HoraInicio > HoraFin AND (@HoraActual >= HoraInicio OR @HoraActual <= HoraFin))    
              );    
        
            IF @FinalTurnoID IS NULL    
                SELECT @FinalTurnoID = TurnoID FROM CatUsuarios WHERE ID = @LiderID;    
        END
    
        DECLARE @NuevaOTID INT;    
        INSERT INTO OrdenesTrabajo (    
            EstacionID, EstadoID, LiderReportaID, TurnoID,     
            SintomaFallaLiderID, ClasificacionFallaLiderID, Causa4MID,     
            AreaAfectadaImpacto, EmpleadosAfectados, ComentarioLider,     
            FechaReporte, TipoMantenimiento, UsuarioRegistroID    
        )    
        VALUES (    
            @EstacionID, @EstadoCreadaID, @LiderID, @FinalTurnoID,    
            @SintomaFallaLiderID, @ClasificacionFallaLiderID, @Causa4MID,    
            @AreaAfectadaImpacto, @EmpleadosAfectados, @ComentarioLider,     
            @FinalFechaReporte, 'CORRECTIVO', @UsuarioRegistroID    
        );    
    
        SET @NuevaOTID = SCOPE_IDENTITY();    
    
        INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, Comentario)    
        VALUES (@NuevaOTID, NULL, @EstadoCreadaID, @LiderID, 'OT Correctiva creada.');    
    
        COMMIT TRANSACTION;    
        SELECT @NuevaOTID AS OrdenTrabajoID;    
    END TRY    
    BEGIN CATCH    
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;    
        THROW;    
    END CATCH;    
END

GO

-- ---------------------------------------------------------------------------
-- Procedimiento: sp_OT_Completar_V2
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.sp_OT_Completar_V2', N'P') IS NOT NULL
    DROP PROCEDURE dbo.[sp_OT_Completar_V2];
GO

CREATE PROCEDURE sp_OT_Completar_V2
            @OrdenTrabajoID INT,
            @EquipoID INT, 
            @FallaRealID INT,
            @TecnicoID INT,
            @ComentariosSolucion VARCHAR(500)
        AS
        BEGIN
            SET NOCOUNT ON;
            BEGIN TRY
                BEGIN TRANSACTION;

                DECLARE @EstadoClosedID INT;
                DECLARE @EstadoActualID INT;
                
                SELECT TOP 1 @EstadoClosedID = ID FROM CatEstadosOT WHERE Nombre = 'CLOSED' AND activo = 1;
                SELECT @EstadoActualID = EstadoID FROM OrdenesTrabajo WHERE ID = @OrdenTrabajoID;

                -- 1. Actualizar orden principal asegurando FechaInicioSoporte
                UPDATE OrdenesTrabajo
                SET EstadoID = @EstadoClosedID,
                    EquipoID = @EquipoID,
                    FallaRealID = @FallaRealID,
                    FechaInicioSoporte = COALESCE(
                        FechaInicioSoporte, 
                        (SELECT TOP 1 FechaArriboQR FROM DetalleTecnicosOT WHERE OrdenTrabajoID = @OrdenTrabajoID AND activo = 1 ORDER BY ID ASC),
                        GETDATE()
                    )
                WHERE ID = @OrdenTrabajoID;

                -- 2. Registrar fin del técnico firmante
                UPDATE DetalleTecnicosOT
                SET FechaFinActividad = GETDATE()
                WHERE OrdenTrabajoID = @OrdenTrabajoID AND TecnicoID = @TecnicoID AND FechaFinActividad IS NULL AND activo = 1;

                -- 3. Bitácora
                INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, Comentario)
                VALUES (@OrdenTrabajoID, @EstadoActualID, @EstadoClosedID, @TecnicoID, @ComentariosSolucion);

                COMMIT TRANSACTION;
            END TRY
            BEGIN CATCH
                IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
                THROW;
            END CATCH;
        END

GO

-- ---------------------------------------------------------------------------
-- Procedimiento: sp_OT_CrearYAtenderOnDemand
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.sp_OT_CrearYAtenderOnDemand', N'P') IS NOT NULL
    DROP PROCEDURE dbo.[sp_OT_CrearYAtenderOnDemand];
GO

CREATE PROCEDURE sp_OT_CrearYAtenderOnDemand
    @EstacionID INT,
    @TecnicoID INT,
    @EquipoID INT,
    @TurnoID INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @EstadoOngoingID INT;
        DECLARE @FinalTurnoID INT = @TurnoID;
        DECLARE @HoraActual TIME = CONVERT(TIME, GETDATE());

        -- 1. Obtener ID del estado ONGOING
        SELECT TOP 1 @EstadoOngoingID = ID FROM CatEstadosOT WHERE Nombre = 'ONGOING' AND activo = 1;

        -- 2. Obtener Turno
        IF @FinalTurnoID IS NULL
        BEGIN
            SELECT TOP 1 @FinalTurnoID = ID 
            FROM CatTurnos 
            WHERE activo = 1 
              AND (
                (HoraInicio <= HoraFin AND @HoraActual BETWEEN HoraInicio AND HoraFin) OR
                (HoraInicio > HoraFin AND (@HoraActual >= HoraInicio OR @HoraActual <= HoraFin))
              );
        
            IF @FinalTurnoID IS NULL
                SELECT @FinalTurnoID = TurnoID FROM CatUsuarios WHERE ID = @TecnicoID;
        END

        -- 3. Crear la Orden de Trabajo directamente en estado ONGOING
        DECLARE @NuevaOTID INT;
        INSERT INTO OrdenesTrabajo (
            EstacionID, EstadoID, LiderReportaID, TurnoID, 
            FechaReporte, TipoMantenimiento, UsuarioRegistroID,
            EquipoID, FechaInicioSoporte, ComentarioLider, EmpleadosAfectados, activo
        )
        VALUES (
            @EstacionID, @EstadoOngoingID, @TecnicoID, @FinalTurnoID,
            GETDATE(), 'CORRECTIVO', @TecnicoID,
            @EquipoID, GETDATE(), 'Soporte in-situ iniciado directamente por el técnico sin OT previa.', 0, 1
        );

        SET @NuevaOTID = SCOPE_IDENTITY();

        -- 4. Registrar al técnico en DetalleTecnicosOT para esta OT
        INSERT INTO DetalleTecnicosOT (OrdenTrabajoID, TecnicoID, FechaAsignacion, FechaArriboQR, activo, fecharegistro)
        VALUES (@NuevaOTID, @TecnicoID, GETDATE(), GETDATE(), 1, GETDATE());

        -- 5. Registrar bitácora
        INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, Comentario)
        VALUES (@NuevaOTID, NULL, @EstadoOngoingID, @TecnicoID, 'OT creada e iniciada en sitio por el técnico.');

        COMMIT TRANSACTION;
        SELECT @NuevaOTID AS OrdenTrabajoID;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END

GO

-- ---------------------------------------------------------------------------
-- Procedimiento: sp_OT_IniciarSoporte
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.sp_OT_IniciarSoporte', N'P') IS NOT NULL
    DROP PROCEDURE dbo.[sp_OT_IniciarSoporte];
GO

CREATE PROCEDURE sp_OT_IniciarSoporte
    @OrdenTrabajoID INT,
    @TecnicoID INT,
    @EquipoID INT
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @EstadoOngoingID INT;
        DECLARE @EstadoActualID INT;
        SELECT TOP 1 @EstadoOngoingID = ID FROM CatEstadosOT WHERE Nombre = 'ONGOING' AND activo = 1;
        SELECT @EstadoActualID = EstadoID FROM OrdenesTrabajo WHERE ID = @OrdenTrabajoID;

        -- 1. Actualizar la orden con el EquipoID y FechaInicioSoporte
        -- Si no tenia FechaInicioSoporte, registrarla como la fecha actual
        UPDATE OrdenesTrabajo
        SET EquipoID = @EquipoID,
            FechaInicioSoporte = COALESCE(FechaInicioSoporte, GETDATE()),
            EstadoID = CASE WHEN EstadoID = (SELECT ID FROM CatEstadosOT WHERE Nombre = 'CREATED' AND activo = 1) THEN @EstadoOngoingID ELSE EstadoID END
        WHERE ID = @OrdenTrabajoID;

        -- 2. Si el arribo no se habia registrado en DetalleTecnicosOT, registrarlo
        IF EXISTS (SELECT 1 FROM DetalleTecnicosOT WHERE OrdenTrabajoID = @OrdenTrabajoID AND TecnicoID = @TecnicoID AND activo = 1)
        BEGIN
            UPDATE DetalleTecnicosOT
            SET FechaArriboQR = COALESCE(FechaArriboQR, GETDATE())
            WHERE OrdenTrabajoID = @OrdenTrabajoID AND TecnicoID = @TecnicoID AND activo = 1;
        END

        -- 3. Si cambio de CREATED a ONGOING, registrarlo en la bitacora
        IF EXISTS (SELECT 1 FROM CatEstadosOT WHERE ID = @EstadoActualID AND Nombre = 'CREATED')
        BEGIN
            INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, Comentario)
            VALUES (@OrdenTrabajoID, @EstadoActualID, @EstadoOngoingID, @TecnicoID, 'Arribo de tecnico e inicio de soporte de equipo.');
        END

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END

GO

-- ---------------------------------------------------------------------------
-- Procedimiento: sp_OT_Pausar
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.sp_OT_Pausar', N'P') IS NOT NULL
    DROP PROCEDURE dbo.[sp_OT_Pausar];
GO

CREATE PROCEDURE sp_OT_Pausar
    @OrdenTrabajoID INT,
    @MotivoPausaID INT,
    @TecnicoID INT,
    @Comentario VARCHAR(500)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @EstadoStoppedID INT;
        DECLARE @EstadoAnteriorID INT;
        SELECT TOP 1 @EstadoStoppedID = ID FROM CatEstadosOT WHERE Nombre = 'STOPPED' AND activo = 1;
        SELECT @EstadoAnteriorID = EstadoID FROM OrdenesTrabajo WHERE ID = @OrdenTrabajoID;

        -- Actualizar Estado en Orden Principal
        UPDATE OrdenesTrabajo SET EstadoID = @EstadoStoppedID WHERE ID = @OrdenTrabajoID;

        -- Registrar en Historial de Pausas
        INSERT INTO RegistroPausasOT (OrdenTrabajoID, MotivoPausaID, UsuarioPausaID, FechaInicioPausa, Comentario)
        VALUES (@OrdenTrabajoID, @MotivoPausaID, @TecnicoID, GETDATE(), @Comentario);

        -- Registrar Bitacora
        INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, Comentario)
        VALUES (@OrdenTrabajoID, @EstadoAnteriorID, @EstadoStoppedID, @TecnicoID, @Comentario);

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END

GO

-- ---------------------------------------------------------------------------
-- Procedimiento: sp_OT_Reanudar
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.sp_OT_Reanudar', N'P') IS NOT NULL
    DROP PROCEDURE dbo.[sp_OT_Reanudar];
GO

CREATE PROCEDURE sp_OT_Reanudar
    @OrdenTrabajoID INT,
    @TecnicoID INT,
    @CodigoQR VARCHAR(150)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @CleanQR VARCHAR(150) = LTRIM(RTRIM(@CodigoQR));

        -- Validar Escaneo QR: puede ser el QR de la estacion, el del equipo asignado, o el de cualquier equipo de esa estacion
        IF NOT EXISTS (
            SELECT 1 FROM OrdenesTrabajo ot
            INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
            WHERE ot.ID = @OrdenTrabajoID AND est.CodigoQR = @CleanQR
        ) AND NOT EXISTS (
            SELECT 1 FROM OrdenesTrabajo ot
            INNER JOIN CatEquipos eq ON ot.EquipoID = eq.ID
            WHERE ot.ID = @OrdenTrabajoID AND eq.CodigoQR = @CleanQR
        ) AND NOT EXISTS (
            SELECT 1 FROM OrdenesTrabajo ot
            INNER JOIN CatEquipos eq ON ot.EstacionID = eq.EstacionID
            WHERE ot.ID = @OrdenTrabajoID AND eq.CodigoQR = @CleanQR
        )
        BEGIN
            THROW 50002, 'QR incorrecto. Debe escanear el QR fisico de la estacion o equipo para reanudar.', 1;
        END

        DECLARE @EstadoOngoingID INT;
        DECLARE @EstadoAnteriorID INT;
        SELECT TOP 1 @EstadoOngoingID = ID FROM CatEstadosOT WHERE Nombre = 'ONGOING' AND activo = 1;
        SELECT @EstadoAnteriorID = EstadoID FROM OrdenesTrabajo WHERE ID = @OrdenTrabajoID;

        -- Cerrar la pausa activa
        UPDATE RegistroPausasOT
        SET FechaFinPausa = GETDATE()
        WHERE OrdenTrabajoID = @OrdenTrabajoID AND FechaFinPausa IS NULL AND activo = 1;

        -- Regresar estado principal a ONGOING
        UPDATE OrdenesTrabajo SET EstadoID = @EstadoOngoingID WHERE ID = @OrdenTrabajoID;

        -- Registrar en Bitacora
        INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, Comentario)
        VALUES (@OrdenTrabajoID, @EstadoAnteriorID, @EstadoOngoingID, @TecnicoID, 'OT reanudada por escaneo de QR.');

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END

GO

-- ---------------------------------------------------------------------------
-- Procedimiento: sp_OT_RegistrarArriboQR
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.sp_OT_RegistrarArriboQR', N'P') IS NOT NULL
    DROP PROCEDURE dbo.[sp_OT_RegistrarArriboQR];
GO

CREATE PROCEDURE sp_OT_RegistrarArriboQR
            @OrdenTrabajoID INT,
            @TecnicoID INT,
            @CodigoQR VARCHAR(150)
        AS
        BEGIN
            SET NOCOUNT ON;
            BEGIN TRY
                BEGIN TRANSACTION;

                -- Verificar que el QR corresponda a la estación de la OT o a un equipo de dicha estación
                DECLARE @CleanQR VARCHAR(150) = LTRIM(RTRIM(@CodigoQR));
                IF NOT EXISTS (
                    SELECT 1 
                    FROM OrdenesTrabajo ot
                    INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
                    WHERE ot.ID = @OrdenTrabajoID AND est.CodigoQR = @CleanQR AND ot.activo = 1
                ) AND NOT EXISTS (
                    SELECT 1
                    FROM OrdenesTrabajo ot
                    INNER JOIN CatEquipos eq ON ot.EstacionID = eq.EstacionID
                    WHERE ot.ID = @OrdenTrabajoID AND eq.CodigoQR = @CleanQR AND ot.activo = 1
                )
                BEGIN
                    THROW 50001, 'El código QR escaneado no corresponde a la estación ni a los equipos de esta orden de trabajo.', 1;
                END

                DECLARE @EstadoOngoingID INT;
                DECLARE @EstadoActualID INT;
                SELECT TOP 1 @EstadoOngoingID = ID FROM CatEstadosOT WHERE Nombre = 'ONGOING' AND activo = 1;
                SELECT @EstadoActualID = EstadoID FROM OrdenesTrabajo WHERE ID = @OrdenTrabajoID;

                -- 1. Actualizar OrdenesTrabajo: cambiar a ONGOING y asegurar FechaInicioSoporte
                UPDATE OrdenesTrabajo
                SET EstadoID = @EstadoOngoingID,
                    FechaInicioSoporte = COALESCE(FechaInicioSoporte, GETDATE())
                WHERE ID = @OrdenTrabajoID;

                -- 2. Registrar en Bitacora si cambió de estado
                IF EXISTS (SELECT 1 FROM CatEstadosOT WHERE ID = @EstadoActualID AND Nombre = 'CREATED')
                BEGIN
                    INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, Comentario)
                    VALUES (@OrdenTrabajoID, @EstadoActualID, @EstadoOngoingID, @TecnicoID, 'Arribo de técnico registrado por escaneo de QR. Estado cambiado a ONGOING.');
                END

                -- 3. Insertar o actualizar en DetalleTecnicosOT
                IF EXISTS (SELECT 1 FROM DetalleTecnicosOT WHERE OrdenTrabajoID = @OrdenTrabajoID AND TecnicoID = @TecnicoID AND activo = 1)
                BEGIN
                    UPDATE DetalleTecnicosOT
                    SET FechaArriboQR = COALESCE(FechaArriboQR, GETDATE())
                    WHERE OrdenTrabajoID = @OrdenTrabajoID AND TecnicoID = @TecnicoID AND activo = 1;
                END
                ELSE
                BEGIN
                    INSERT INTO DetalleTecnicosOT (OrdenTrabajoID, TecnicoID, FechaAsignacion, FechaArriboQR, activo, fecharegistro)
                    VALUES (@OrdenTrabajoID, @TecnicoID, GETDATE(), GETDATE(), 1, GETDATE());
                END

                COMMIT TRANSACTION;
            END TRY
            BEGIN CATCH
                IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
                THROW;
            END CATCH;
        END

GO

-- ---------------------------------------------------------------------------
-- Procedimiento: sp_OT_TransferirTurno
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.sp_OT_TransferirTurno', N'P') IS NOT NULL
    DROP PROCEDURE dbo.[sp_OT_TransferirTurno];
GO

CREATE PROCEDURE sp_OT_TransferirTurno
    @OrdenTrabajoID INT,
    @TecnicoSalienteID INT,
    @TecnicoEntranteID INT,
    @ComentarioHandover VARCHAR(1000)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        -- 1. Cerrar actividad del técnico saliente
        UPDATE DetalleTecnicosOT
        SET FechaFinActividad = GETDATE()
        WHERE OrdenTrabajoID = @OrdenTrabajoID AND TecnicoID = @TecnicoSalienteID AND FechaFinActividad IS NULL AND activo = 1;

        -- 2. Asignar nuevo técnico en Detalle (esperando su arribo QR en sitio)
        INSERT INTO DetalleTecnicosOT (OrdenTrabajoID, TecnicoID, FechaAsignacion)
        VALUES (@OrdenTrabajoID, @TecnicoEntranteID, GETDATE());

        -- 3. Registrar en Bitácora de Transferencias
        INSERT INTO BitacoraTransferenciasOT (OrdenTrabajoID, TecnicoSalienteID, TecnicoEntranteID, ComentarioHandover)
        VALUES (@OrdenTrabajoID, @TecnicoSalienteID, @TecnicoEntranteID, @ComentarioHandover);

        -- 4. Registrar en Bitacora general de estados indicando el Handover
        DECLARE @EstadoActual INT;
        SELECT @EstadoActual = EstadoID FROM OrdenesTrabajo WHERE ID = @OrdenTrabajoID;
        
        INSERT INTO BitacoraEstadosOT (OrdenTrabajoID, EstadoAnteriorID, EstadoNuevoID, UsuarioID, Comentario)
        VALUES (@OrdenTrabajoID, @EstadoActual, @EstadoActual, @TecnicoSalienteID, 
                CONCAT('Transferencia de turno realizada. Notas: ', SUBSTRING(@ComentarioHandover, 1, 200)));

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END

GO

-- ---------------------------------------------------------------------------
-- Procedimiento: sp_ProcesarEscalacionAlertas
-- ---------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.sp_ProcesarEscalacionAlertas', N'P') IS NOT NULL
    DROP PROCEDURE dbo.[sp_ProcesarEscalacionAlertas];
GO

CREATE PROCEDURE sp_ProcesarEscalacionAlertas
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Insertar en la cola las alertas de OTs creadas sin atención oportuna
    INSERT INTO ColaNotificaciones (OrdenTrabajoID, NivelEscalacion, Mensaje, DestinatarioUsuarioID)
    SELECT 
        ot.ID AS OrdenTrabajoID,
        1 AS NivelEscalacion,
        CONCAT('ALERTA: OT #', ot.ID, ' en estación ', est.Nombre, ' ha superado el tiempo límite de atención sin arribo del técnico.'),
        usr.ID AS DestinatarioUsuarioID
    FROM OrdenesTrabajo ot
    INNER JOIN CatEstaciones est ON ot.EstacionID = est.ID
    INNER JOIN CatLineas lin ON est.LineaID = lin.ID
    INNER JOIN CatAreas ar ON lin.AreaID = ar.ID
    INNER JOIN ConfiguracionEscalaciones esc ON esc.AreaID = ar.ID AND esc.ImpactoAfectacion = ot.AreaAfectadaImpacto
    -- Buscar usuarios del area con el Rol configurado en la escalacion
    INNER JOIN CatUsuarios usr ON usr.AreaID = ar.ID AND usr.RolID = esc.RolNotificarID AND usr.activo = 1
    WHERE ot.EstadoID = (SELECT ID FROM CatEstadosOT WHERE Nombre = 'Creada')
      AND ot.TipoMantenimiento = 'CORRECTIVO'
      -- Si han pasado más minutos del limite desde que se reportó
      AND DATEDIFF(MINUTE, ot.FechaReporte, GETDATE()) > esc.TiempoLimiteMinutos
      -- Evitar duplicar alertas del mismo nivel para la misma OT
      AND NOT EXISTS (
          SELECT 1 
          FROM ColaNotificaciones 
          WHERE OrdenTrabajoID = ot.ID AND NivelEscalacion = 1 AND activo = 1
      )
      AND ot.activo = 1;
END

GO
